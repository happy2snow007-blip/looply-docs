#!/usr/bin/env python3
"""
A.16 检查:JSX 字符串属性中文文案嵌套 ASCII 双引号。

特征:`<Tag attr="某中文"中文"...">` —— 属性闭合引号后紧跟中文字符 = 未转义。
Babel 会报 SyntaxError,整页白屏(A1 market 实测踩坑)。

输入:产物 HTML 文件路径
输出:违规处数量(stdout)
--verbose:输出每处的行号 + 上下文
"""
import re
import sys

# 属性=\"...\"中文(且中文不是合法的属性名,即不是 attr2=...这种)
PATTERN = re.compile(r'(\w+)="([^"]*)"([一-鿿])')


def check(path):
    violations = []
    with open(path, encoding='utf-8') as f:
        for i, line in enumerate(f, 1):
            for m in PATTERN.finditer(line):
                violations.append((i, m.group(1), line.strip()[:120]))
    return violations


def main():
    if len(sys.argv) < 2:
        print("用法: check_jsx_quotes.py <产物.html> [--verbose]", file=sys.stderr)
        sys.exit(2)
    path = sys.argv[1]
    verbose = '--verbose' in sys.argv
    violations = check(path)
    print(len(violations))
    if verbose and violations:
        for line, attr, text in violations:
            print(f"  L{line} attr={attr}: {text}", file=sys.stderr)


if __name__ == '__main__':
    main()
