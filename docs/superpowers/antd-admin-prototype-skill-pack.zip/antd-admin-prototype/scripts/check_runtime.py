#!/usr/bin/env python3
"""
逐页运行时错误检查 —— 填补 check.sh 与 render_sim 都够不着的一类缺陷。

为什么需要它
------------
check.sh 14 项读的是代码（IIFE / 引号 / rowKey / CDN / Modal 配置…），render_sim 渲染的是
**详情页组件与弹窗**。都不覆盖「整个 App 在浏览器里能不能跑起来」。

实测（2026-09-03 支付打款 v5）：用正则删一个弹窗时误删了相邻 4 个函数定义，
Babel 编译通过、check.sh 14 项全绿、render_sim 报「无渲染硬伤」，
但产物一打开就白屏——`ReferenceError: ExportModal is not defined`。

做法
----
往产物里注入 window error 捕获，逐个页面 key 渲染，dump-dom 读回错误。
只依赖本机 Chrome。

用法
----
    python3 check_runtime.py 产物.html                      # 自动探测页面 key
    python3 check_runtime.py 产物.html --pages a,b,c        # 指定页面 key
"""
import re, sys, os, subprocess, tempfile, argparse

CHROMES = ['/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
           '/Applications/Chromium.app/Contents/MacOS/Chromium',
           '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge']
INJECT = ("""<script>window.__e=[];window.addEventListener('error',function(e){window.__e.push(String(e.message));"""
          """var p=document.getElementById('__err__')||document.createElement('pre');p.id='__err__';"""
          """p.textContent=window.__e.join(' ||| ');document.body.appendChild(p);});"""
          """window.addEventListener('unhandledrejection',function(e){window.__e.push('REJECT: '+e.reason);"""
          """var p=document.getElementById('__err__')||document.createElement('pre');p.id='__err__';"""
          """p.textContent=window.__e.join(' ||| ');document.body.appendChild(p);});</script>""")

def find_chrome():
    for c in CHROMES:
        if os.path.exists(c): return c
    return None

def detect_pages(src):
    """从 currentPage/page 的 state 初值 + 条件渲染里抠出页面 key"""
    keys = set(re.findall(r"(?:currentPage|page)\s*===\s*'([a-zA-Z0-9_-]+)'", src))
    return sorted(keys)

def state_line(src):
    m = re.search(r"const \[(?:page|currentPage), set\w+\] = useState\('([a-zA-Z0-9_-]+)'\);", src)
    return (m.group(0), m.group(1)) if m else (None, None)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('path'); ap.add_argument('--pages', default='')
    a = ap.parse_args()
    chrome = find_chrome()
    if not chrome:
        print('❌ 没找到 Chrome/Chromium/Edge，运行时检查跑不了。'); sys.exit(0)
    src = open(a.path, encoding='utf-8').read()
    line, default = state_line(src)
    pages = [p for p in a.pages.split(',') if p] or detect_pages(src)
    if not pages:
        pages = [default] if default else []
    if not pages:
        print('ℹ️  没探测到页面 key，只跑默认首屏。'); pages = ['__default__']
    print('▶ 逐页运行时检查: %s  (%d 个页面)' % (os.path.basename(a.path), len(pages)))
    bad = 0
    for pg in pages:
        t = src.replace('<div id="root"></div>', INJECT + '\n<div id="root"></div>')
        if line and pg != '__default__':
            t = t.replace(line, line.replace("'%s'" % default, "'%s'" % pg))
        tmp = os.path.join(tempfile.gettempdir(), '_rt_%s.html' % re.sub(r'\W', '_', pg))
        open(tmp, 'w', encoding='utf-8').write(t)
        dom = subprocess.run([chrome, '--headless=new', '--disable-gpu', '--no-sandbox',
                              '--virtual-time-budget=10000', '--dump-dom', 'file://' + tmp],
                             capture_output=True, text=True, timeout=180).stdout
        m = re.search(r'<pre id="__err__">([\s\S]*?)</pre>', dom)
        if m:
            bad += 1; print('  ❌ %-18s %s' % (pg, m.group(1)[:110]))
        else:
            print('  ✅ %-18s' % pg)
    print('\n%s' % ('  全部 %d 个页面无运行时错误' % len(pages) if bad == 0
                    else '  ❌ %d/%d 个页面有运行时错误 —— 产物打开会白屏或功能缺失' % (bad, len(pages))))
    sys.exit(2 if bad else 0)

if __name__ == '__main__':
    main()
