#!/usr/bin/env python3
"""
check_text_redundancy.py — 页面上不该有的说明文字 · 两类初筛

(文件名沿用首版,现已不止查"复述"一类;check.sh 按此名引用,勿改名)

对应 SKILL.md「页面文案的边界 → 第二条判据:同屏已经有元素在说这件事了吗?」

## 它找什么

说明性文本(Alert 的 message/description、.lp-nodata 空态、helper 提示)里,
**字符串拼接了同屏已经渲染出来的值或 label**。这是"文字块复述 tag"最可靠的代码指纹。

2026-08-01 售后 v16 一次点测被圈掉的三处,全部命中这个 pattern:

    'BAD  message={REG_VS_LIVE_TIP + "(登记值 " + r.returnTrackingNo + ...}'
         → returnTrackingNo 头条已经渲染过

    'BAD  description={"本单仍为「" + st.label + "」,可直接重新发起。"}'
         → st.label 页头已经是一个 StatusTag

    'BAD  "本单按「" + OUTLETS.deny.label + "」出口关闭,未产生退款单"'
         → OUTLETS[...].label 同模块已经是一个 StatusTag

## 它不找什么

- 纯静态说明文字(不拼接变量的)—— 那类由第一条判据「不看会不会操作错」人工判
- 弹窗里的说明 —— 弹窗是独立视口,"同屏"不成立,默认不报(--include-modal 可开)

## 判读

命中 ≠ 必删。逐条问两句:
  1. 拼进来的这个值,**同一屏**上是不是真的已经有元素在展示?(脚本只看代码,判不了布局)
  2. 这句话有没有携带 tag 装不下的**增量信息**且运营当下就要用?(典型:失败原因)
     有 → 先找更合适的落点(如"重新发起"弹窗),详情页正文不是默认落点。

## 第二类:论证结构(2026-08-01 补)

页面上在**解释某个做法为什么正当**,而不是告诉运营该干什么。

    'BAD  与买家在进度页看到的一致。文案即买家看到的英文原文,运营端不另出中文版'
    '     —— 显示中文就不是「买家看到的那一份」了。'
         → 后半句在论证"为什么不出中文版"。运营不看这句也不会操作错

⚠️ **为什么要单独加这一类**:上一版只覆盖了「复述」一种失效模式,
而「页面上不该有的文字」这个大类至少五种形状——复述 / 论证 / 轮次溯源 / 复述规则 / 本期声明。
只覆盖自己刚遇到的那一种,下一种照样漏。本类补的是**论证**,并把扫描范围从
`helper=/description=/message=` 属性扩到 **JSX 文本节点**(漏网的那句正在文本节点里)。

**留与删的分界**(命中后逐条判):
- 删:解释为什么这么设计 / 复述规则与状态机 / 轮次与决策编号 / "本期只有…因为…"
- 留:填什么格式(placeholder 示例)· 不可逆后果 · 操作被拦住的原因 · 对外可见性标注
  —— 这四类**都会**命中信号词(它们也带破折号、也提 C 端),属预期内的假阳性。
  实测售后 v16:8 处命中,7 处属这四类该留,1 处该删。**初筛的价值是把范围从整个文件缩到 8 行。**

退出码恒为 0 —— 这是初筛,不是硬性失败项。
"""
import re
import sys

# 说明性文本的容器:Alert 的两个属性 + 空态 + 常见 helper
TEXT_SLOTS = [
    ('Alert.message',     r'message=\{([^}]*(?:\{[^}]*\}[^}]*)*)\}'),
    ('Alert.description', r'description=\{([^}]*(?:\{[^}]*\}[^}]*)*)\}'),
    ('lp-nodata',         r'className="lp-nodata[\w-]*"\s*>([^<]*)<'),
    ('lp-nodata(拼接)',   r'className="lp-nodata[\w-]*"\s*>\{([^}]*)\}'),
    ('helper',            r'helper=\{([^}]*)\}'),
]

# 拼进说明文本里的"同屏已渲染值"的形态
REDUNDANT_REFS = [
    ('label 常量',  r'\b([A-Za-z_$][\w$]*(?:\.[\w$]+)*\.label)\b'),
    ('记录字段',    r'\b(r\.[\w$]+(?:\.[\w$]+)*)\b'),
    ('状态对象',    r'\b(st\.[\w$]+)\b'),
]


def strip_comments(src: str) -> str:
    """把注释内容抹成空白,但【保留换行】—— 否则报出的行号对不上原文件,定位不了。
    (2026-08-01 首版就是直接 re.sub 删掉,行号偏了几百行)"""
    def blank(m):
        return re.sub(r'[^\n]', ' ', m.group(0))
    src = re.sub(r'\{\s*/\*[\s\S]*?\*/\s*\}', blank, src)
    src = re.sub(r'/\*[\s\S]*?\*/', blank, src)
    return src


def line_of(src: str, pos: int) -> int:
    return src.count('\n', 0, pos) + 1


# ── 第二类:论证结构 ──
# 扫的是【渲染层的一切中文文本】,不限于 helper/description/message 属性 ——
# 2026-08-01 漏网的那句正在 JSX 文本节点里,只扫属性抓不到。
ARGUE_SIGNALS = [
    ('论证',     r'(就不是[^<>{}"\']{0,20}了|才是[^<>{}"\']{0,20}的|否则[^<>{}"\']{2,30}|不然[^<>{}"\']{2,30}|等于是[^<>{}"\']{2,30})'),
    ('规则宣告', r'(不另出|不再出|一律[^<>{}"\']{2,20}|统一为[^<>{}"\']{2,20}|恒为[^<>{}"\']{2,20}|不区分[^<>{}"\']{2,20})'),
    ('解释连接', r'(本期[^<>{}"\']{2,30}|因为[^<>{}"\']{2,30}|这是为了[^<>{}"\']{2,30}|由[^<>{}"\']{0,8}决定|不受影响)'),
    ('轮次溯源', r'(第\s*\d+\s*轮|决策\s*[A-Z]\d|原来是[^<>{}"\']{2,20}现在)'),
]
# 渲染层文本:JSX 文本节点(>文字<)+ 常见文案属性
RENDER_TEXT = [
    ('JSX文本节点', r'>\s*([^<>{}\n][^<>{}]{8,})\s*<'),
    ('文案属性',    r'(?:helper|description|message|title|placeholder|label)=["\{]\s*[\'"]?([^"\'\}]{12,})'),
]


def scan_argue(src: str):
    """返回 [(行号, 片段, [命中的信号类型])]"""
    out = {}
    for _slot, tp in RENDER_TEXT:
        for m in re.finditer(tp, src):
            text = m.group(1)
            if not re.search(r'[一-鿿]', text):
                continue
            kinds = [k for k, p in ARGUE_SIGNALS if re.search(p, text)]
            # 破折号后接中文解释:单独算一个弱信号
            if re.search(r'——\s*[^<>{}"\']{6,}', text):
                kinds.append('破折号后解释')
            if kinds:
                ln = src.count('\n', 0, m.start()) + 1
                prev = out.get(ln)
                if prev is None or len(text) > len(prev[0]):
                    out[ln] = (text, sorted(set(kinds)))
    return [(ln, t, k) for ln, (t, k) in sorted(out.items())]


def main() -> int:
    if len(sys.argv) < 2:
        print(__doc__)
        return 0
    path = sys.argv[1]
    with open(path, encoding='utf-8') as f:
        raw = f.read()
    src = strip_comments(raw)

    print(f"页面说明文字初筛 — {path.split('/')[-1]}\n")

    hits = []
    for slot_name, pat in TEXT_SLOTS:
        for m in re.finditer(pat, src):
            body = m.group(1)
            # 必须含中文字面量才算"说明性文本";纯变量传递(message={tip})不算
            if not re.search(r'[一-鿿]', body):
                continue
            refs = []
            for ref_kind, ref_pat in REDUNDANT_REFS:
                for rm in re.finditer(ref_pat, body):
                    refs.append((ref_kind, rm.group(1)))
            if refs:
                hits.append((line_of(src, m.start()), slot_name, body.strip(), refs))

    if not hits:
        print("  ✅ 未发现「说明文本拼接同屏已渲染值」的形态")
    else:
        print(f"  ⚠ {len(hits)} 处说明性文本拼接了可能已在同屏渲染的值:\n")
        for ln, slot, body, refs in sorted(hits):
            snippet = re.sub(r'\s+', ' ', body)
            if len(snippet) > 110:
                snippet = snippet[:110] + '…'
            uniq = sorted({f'{k}:{v}' for k, v in refs})
            print(f"  L{ln:<6} [{slot}]")
            print(f"          {snippet}")
            print(f"          拼进来的值 → {', '.join(uniq)}\n")

    print("  判读:命中 ≠ 必删。逐条确认 ①这个值同一屏上是否真的已有元素展示")
    print("        ②这句话是否携带 tag 装不下且运营当下要用的增量信息(如失败原因)")
    print("        —— 有增量也先找更合适的落点,详情页正文不是默认落点\n")

    # ── 第二类:论证结构 ──
    print("── 第二类:论证结构(解释设计决策 / 复述规则 / 轮次溯源)──\n")
    argue = scan_argue(src)
    if not argue:
        print("  ✅ 未发现论证结构的说明文字")
    else:
        # 命中的信号【类数】本身就是判据:实测该删的那句命中 3 类,
        # 该留的 placeholder 只命中「破折号后解释」这一个弱信号。按类数倒序,重的排前面。
        argue.sort(key=lambda x: (-len(x[2]), x[0]))
        print(f"  ⚠ {len(argue)} 处渲染层文本命中论证信号(按信号类数排序,越多越可疑):\n")
        for ln, text, kinds in argue:
            snippet = re.sub(r'\s+', ' ', text).strip()
            if len(snippet) > 100:
                snippet = snippet[:100] + '…'
            mark = '⚠⚠ 重点' if len(kinds) >= 2 else '·  弱信号'
            print(f"  {mark}  L{ln:<6} [{'/'.join(kinds)}]")
            print(f"          {snippet}\n")
    print("  判读:**命中类数 ≥2 的重点看**——实测该删的那句命中 3 类;")
    print("        只命中「破折号后解释」一个弱信号的,多数是该留的四类:")
    print("        填写示例(placeholder)、不可逆后果、操作被拦住的原因、对外可见性标注。")
    print("        该删的是:解释为什么这么设计 / 复述规则与状态机 / 轮次与决策编号。")
    print("        判据:这句话不看,运营会不会操作错?不会 → 删。\n")

    print("完成(初筛,不判失败)")
    return 0


if __name__ == '__main__':
    sys.exit(main())
