#!/usr/bin/env python3
"""
embed_logo.py — 把产物里的 LOGO_PLACEHOLDER 替换为完整 base64 logo 数据。

用法:python3 scripts/embed_logo.py outputs/产物.html

为什么需要这个脚本:
- 新版 Looply Logo 使用 assets/logo.svg
- 让 subagent 手抄/复制 base64 → 高概率截断或误改
- 改用占位符 `{{LOGO_PLACEHOLDER}}` + 后处理脚本注入,subagent 完全不碰 base64

约定:
- subagent 在产物里写 `const LOGO_SRC = "data:image/svg+xml;base64,{{LOGO_PLACEHOLDER}}";`
- subagent 在交付前跑本脚本(scripts/check.sh 也会检查 占位是否未替换 → ❌)
"""
import base64
import sys
from pathlib import Path

PLACEHOLDER = "{{LOGO_PLACEHOLDER}}"


def main():
    if len(sys.argv) < 2:
        print("用法: python3 embed_logo.py <产物.html>", file=sys.stderr)
        sys.exit(2)

    target = Path(sys.argv[1])
    if not target.exists():
        print(f"❌ 文件不存在: {target}", file=sys.stderr)
        sys.exit(2)

    # 定位新版 logo.svg(基于本脚本的相对路径)
    script_dir = Path(__file__).resolve().parent
    logo_path = script_dir.parent / "assets" / "logo.svg"
    if not logo_path.exists():
        print(f"❌ logo 文件不存在: {logo_path}", file=sys.stderr)
        sys.exit(2)

    # 读 SVG → base64
    with open(logo_path, "rb") as f:
        logo_b64 = base64.b64encode(f.read()).decode()

    # 替换占位符
    txt = target.read_text(encoding="utf-8")
    if PLACEHOLDER not in txt:
        print(f"⚠ 产物里没有 {PLACEHOLDER},无需注入(可能已经注入过,或 subagent 没写占位)")
        sys.exit(0)

    new = txt.replace(PLACEHOLDER, logo_b64)
    target.write_text(new, encoding="utf-8")
    print(f"✅ logo 已注入 {target.name}({len(logo_b64)} 字符 base64)")


if __name__ == "__main__":
    main()
