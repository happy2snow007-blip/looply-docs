#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
sketch_detail.py — 从 antd 原型产物里反抽「详情页版式草图」。

为什么需要它
------------
详情页返工的反馈全是视觉的（"这条线去掉""左对齐""不要竖排""每个模块长得不一样"），
而 agent 看不到渲染结果，只能读代码。这个信息差没法靠"更仔细地读代码"补上。

但用户真正在反馈的那一层，其实不是像素，是**字段落位**：
哪些模块、每个模块什么容器、切几栏、每栏放哪些字段、谁下沉整行。
这一层是**纯文本可表达**的 —— 于是它同时能被 agent 读、被用户 30 秒扫完。

所以本脚本干两件事：

  ① 动手前（迭代场景）：跑一次拿到**现状草图**，在草图上改、给用户确认，再动代码。
     改一张 30 行的草图，比改 200 行 JSX 再让用户开浏览器便宜两个数量级。
  ② 改完后：再跑一次，和确认过的草图逐行比 —— 机械回答"我实现的是不是他确认的那个"。

另外顺带跑 rules.md A.21「判定/自检」要求的那张**逐模块语言表**
（容器 / 标题层级 / 栅格与标签宽 / 空态），那张表原本要人工列，现在自动出。

用法
----
  python3 sketch_detail.py 产物.html                 # 出草图 + 语言表
  python3 sketch_detail.py 产物.html --page 详情     # 只看名字含"详情"的页面组件
  python3 sketch_detail.py 产物.html --check         # 只跑机械检查，给 check.sh 用

限制（先说清楚，免得被当成渲染器）
--------------------------------
- 它抽的是**结构**，不是像素。列宽够不够、折不折行、观感好不好，它答不了。
- 字段名靠解析 `k:` 字面量。字段来自 map/三元/远端变量时抽不全，会标 `?`。
- 抽不到 ≠ 没有。草图上出现 `?` 就是提示你回代码确认，不是判它违规。
"""

import re
import sys
import os

# ── 容器语言：类名 → 人话 + 它的合法场景（场景描述来自 rules.md A.21，改规则时同步改这里）
CONTAINERS = {
    'lp-card':  ('边框卡',   '圈定可重复子实体 / 标出外部系统回传的数据边界'),
    'lp-sub':   ('灰底块',   '仅弹窗内「只读核对区 + 可编辑表单区」并存时划界'),
    'lp-note':  ('紫提示条', '操作提示'),
    'lp-nodata': ('空态一行灰字', '模块 / 子区级空态'),
}
SUBTITLES = {
    'lp-section':    ('模块标题',   '黑 15/600 + 底线，全页唯一'),
    'lp-subtitle':   ('子区标题',   '卡外，13/700 + 3px 主色竖条'),
    'lp-card-label': ('卡内分组标签', '卡内，12px 浅灰，不带竖条'),
}


def strip_comments(src):
    """把 /* */ 与 // 注释抹成同长空白，保留换行 —— 行号才对得上原文。"""
    out = list(src)
    i, n = 0, len(src)
    while i < n - 1:
        if src[i] == '/' and src[i + 1] == '*':
            j = src.find('*/', i + 2)
            j = n if j < 0 else j + 2
            for k in range(i, j):
                if out[k] != '\n':
                    out[k] = ' '
            i = j
        elif src[i] == '/' and src[i + 1] == '/':
            j = src.find('\n', i)
            j = n if j < 0 else j
            for k in range(i, j):
                out[k] = ' '
            i = j
        else:
            i += 1
    return ''.join(out)


def collect_row_arrays(src):
    """收集 `const XXX = [ { k: '标签', ... }, ... ]` 形式的字段数组，供 rows/groups 引用时回查。

    同时判断这个数组**有没有可能是空的** —— 只要里面有一条无条件的字段项，它就永远非空，
    调用方不需要在传给 groups 之前 filter。这个区分决定了空栏检查会不会误报。
    """
    arrays, may_empty = {}, {}
    for m in re.finditer(r'\bconst\s+([A-Za-z_$][\w$]*)\s*=\s*\[', src):
        name = m.group(1)
        i = m.end() - 1
        depth, j = 0, i
        while j < len(src):
            if src[j] == '[':
                depth += 1
            elif src[j] == ']':
                depth -= 1
                if depth == 0:
                    break
            j += 1
        body = src[i:j + 1]
        labels = re.findall(r"\bk\s*:\s*['\"]([^'\"]{1,40})['\"]", body)
        if labels:
            arrays[name] = labels
            entries = split_top(body[1:-1])
            # 无条件项 = 直接写成对象字面量、没有 && / ?: 守卫的那种
            unconditional = [e for e in entries
                             if e.lstrip().startswith('{') and '&&' not in e and '?' not in e]
            may_empty[name] = len(unconditional) == 0
    return arrays, may_empty


def labels_of(expr, arrays):
    """从 rows=/groups= 的表达式里尽力取出字段标签列表。取不到返回 None。"""
    expr = expr.strip()
    inline = re.findall(r"\bk\s*:\s*['\"]([^'\"]{1,40})['\"]", expr)
    if inline:
        return inline
    name = expr.strip('{} ')
    if re.fullmatch(r'[A-Za-z_$][\w$]*', name) and name in arrays:
        return arrays[name]
    return None


def classes_on(line):
    """取出该行所有 className 里的类名 token（精确匹配，避免 lp-card 误吞 lp-card-head）。"""
    toks = set()
    for m in re.finditer(r'className=(?:"([^"]*)"|\{[`\'"]([^`\'"]*)[`\'"])', line):
        for t in (m.group(1) or m.group(2) or '').split():
            toks.add(t)
    return toks


def owner_of(src, pos):
    """往回找最近的 function / const 组件名，用来说明这个模块属于哪个页面或弹窗。"""
    best, name = -1, None
    for m in re.finditer(r'(?:function\s+([A-Z][\w$]*)\s*\(|const\s+([A-Z][\w$]*)\s*=\s*\()', src):
        if m.start() < pos and m.start() > best:
            best, name = m.start(), m.group(1) or m.group(2)
    return name or '(顶层)'


def parse_attrs(tag):
    """从 <DetailGrid ...> 标签体里取出关心的属性原文。"""
    out = {}
    for key in ('rows', 'groups', 'cols', 'labelWidth', 'flow'):
        m = re.search(r'\b' + key + r'=\{', tag)
        if m:
            i = m.end() - 1
            depth, j = 0, i
            while j < len(tag):
                if tag[j] == '{':
                    depth += 1
                elif tag[j] == '}':
                    depth -= 1
                    if depth == 0:
                        break
                j += 1
            out[key] = tag[i:j + 1]
        else:
            m = re.search(r'\b' + key + r'=["\']([^"\']*)["\']', tag)
            if m:
                out[key] = m.group(1)
    return out


def find_tags(src, name):
    """返回 [(行号, 标签全文)]，处理跨行标签。"""
    res = []
    for m in re.finditer(r'<' + name + r'\b', src):
        i = m.start()
        depth, j, in_str, q = 0, i, False, ''
        while j < len(src):
            c = src[j]
            if in_str:
                if c == q:
                    in_str = False
            elif c in '"\'':
                in_str, q = True, c
            elif c == '{':
                depth += 1
            elif c == '}':
                depth -= 1
            elif c == '>' and depth == 0:
                break
            j += 1
        res.append((src.count('\n', 0, i) + 1, src[i:j + 1]))
    return res


def build_sketch(src, page_filter=None):
    """线性扫描，按文档顺序把版式事件挂到「当前模块」下。"""
    arrays, _ = collect_row_arrays(src)
    grids = {ln: parse_attrs(tag) for ln, tag in find_tags(src, 'DetailGrid')}
    timelines = {ln for ln, _ in find_tags(src, 'Timeline')}
    tables = {ln for ln, _ in find_tags(src, 'Table')}

    line_start = [0]
    for ln in src.split('\n'):
        line_start.append(line_start[-1] + len(ln) + 1)

    lines = src.split('\n')
    modules, cur = [], None

    for idx, line in enumerate(lines, 1):
        toks = classes_on(line)
        # 模块标题 = 新模块开始
        m = re.search(r'className="lp-section"[^>]*>([^<{]{1,40})', line)
        if m:
            cur = {'title': m.group(1).strip(), 'line': idx, 'items': [],
                   'owner': owner_of(src, line_start[idx - 1]),
                   'containers': [], 'subtitles': [], 'grids': [], 'empty': []}
            modules.append(cur)
        if cur is None:
            continue

        for cls, (label, scene) in CONTAINERS.items():
            if cls not in toks:
                continue
            if cls == 'lp-nodata':
                cur['empty'].append('模块级一行灰字')
                if not (cur['items'] and cur['items'][-1][0] == 'empty'):
                    cur['items'].append(('empty', idx, '空态：一行灰字'))
            else:
                cur['containers'].append(label)
                cur['items'].append(('container', idx, f'{label} 开始'))

        for cls, (label, _) in SUBTITLES.items():
            if cls == 'lp-section' or cls not in toks:
                continue
            m2 = re.search(r'className="[^"]*"[^>]*>([^<{]{0,30})', line)
            cur['subtitles'].append(label)
            cur['items'].append(('subtitle', idx, f'{label}「{(m2.group(1).strip() if m2 else "") or "?"}」'))

        if idx in grids:
            a = grids[idx]
            lw = (a.get('labelWidth') or '{默认}').strip('{}')
            if 'groups' in a:
                inner = a['groups'].strip('{}').strip()
                if inner.startswith('['):
                    parts = split_top(inner[1:-1])
                    cols = [labels_of(p, arrays) or ['?'] for p in parts]
                    n = len(cols)
                    ndesc = str(n)
                else:
                    # groups 是运行期算出来的（如按状态过滤后的栏数组）→ 栏数静态定不了
                    cols = [['? — groups 由 ' + inner[:28] + ' 运行期决定，回代码看']]
                    n, ndesc = 0, '?'
                cur['grids'].append(('groups', n, lw))
                cur['items'].append(('grid', idx, f'{ndesc} 栏（独立流动）· 标签宽 {lw}', cols))
            else:
                n = int(re.sub(r'\D', '', a.get('cols', '1')) or 1)
                lab = labels_of(a.get('rows', ''), arrays) or ['?']
                flow = a.get('flow', '').strip('{}\'"')
                kind = f'{n} 栏按行铺' if flow == 'row' else (f'{n} 栏' if n > 1 else '整行')
                cur['grids'].append(('rows', n, lw))
                cur['items'].append(('grid', idx, f'{kind} · 标签宽 {lw}', [lab]))

        if idx in timelines:
            cur['items'].append(('other', idx, '时间轴 Timeline'))
        if idx in tables:
            cur['items'].append(('other', idx, '表格 Table'))

    if page_filter:
        modules = [m for m in modules if page_filter in m['title']]
    return modules


def split_top(s):
    """按顶层逗号切分数组元素。"""
    parts, depth, cur, in_str, q = [], 0, '', False, ''
    for c in s:
        if in_str:
            cur += c
            if c == q:
                in_str = False
            continue
        if c in '"\'':
            in_str, q = True, c
        elif c in '[{(':
            depth += 1
        elif c in ']})':
            depth -= 1
        elif c == ',' and depth == 0:
            parts.append(cur)
            cur = ''
            continue
        cur += c
    if cur.strip():
        parts.append(cur)
    return [p.strip() for p in parts if p.strip()]


def print_sketch(modules):
    print('╔══ 详情页版式草图 ' + '═' * 46)
    print('║ 用途：动手前拿它和用户确认版式；改完拿它和确认版逐行比。')
    print('╚' + '═' * 64)
    last_owner = None
    for mod in modules:
        if mod['owner'] != last_owner:
            print(f"\n═══ {mod['owner']} " + '─' * max(0, 50 - len(mod['owner'])))
            last_owner = mod['owner']
        print(f"\n▌{mod['title']}   (L{mod['line']})")
        if not mod['items']:
            print('   （空模块 / 内容不是标准结构）')
        for it in mod['items']:
            kind, ln, desc = it[0], it[1], it[2]
            mark = {'container': '┌', 'subtitle': '·', 'grid': '▸',
                    'empty': '∅', 'other': '◇'}.get(kind, ' ')
            print(f'   {mark} {desc}   L{ln}')
            if kind == 'grid' and len(it) > 3:
                for ci, col in enumerate(it[3], 1):
                    tag = f'栏{ci}' if len(it[3]) > 1 else '   '
                    shown = ' / '.join(col[:12]) + (' …' if len(col) > 12 else '')
                    print(f'        {tag} {shown}')


def _w(t):
    """显示宽度：CJK 与全角标点算 2 列，不然中文表格全部错位。"""
    return sum(2 if ord(c) > 0x2E7F else 1 for c in t)


def _pad(t, n):
    return t + ' ' * max(1, n - _w(t))


def print_language_table(modules):
    """rules.md A.21「判定/自检」要求的逐模块表，原本人工列，这里自动出。"""
    print('\n╔══ A.21 逐模块 UI 语言表 ' + '═' * 40)
    print('║ 判据不是"种类少"，是"每种是否有写下来的适用场景"。')
    print('╚' + '═' * 64)
    print(_pad('模块', 16) + _pad('容器', 16) + _pad('子区标题', 16)
          + _pad('栅格 / 标签宽', 30) + '空态')
    print('─' * 86)
    seen = {'container': set(), 'subtitle': set(), 'lw': set(), 'empty': set()}
    for mod in modules:
        c = '、'.join(sorted(set(mod['containers']))) or '无（白底裸排）'
        s = '、'.join(sorted(set(mod['subtitles']))) or '—'
        g = '、'.join(sorted({f'{"?" if n == 0 else n}栏/{lw}' for _, n, lw in mod['grids']})) or '—'
        e = '、'.join(sorted(set(mod['empty']))) or '—'
        seen['container'].add(c)
        seen['subtitle'].update(mod['subtitles'])
        seen['lw'].update(lw for _, _, lw in mod['grids'])
        seen['empty'].update(mod['empty'])
        print(_pad(mod['title'], 16) + _pad(c, 16) + _pad(s, 16) + _pad(g, 30) + e)
    print('─' * 86)
    print(f"  容器语言 {len(seen['container'])} 种 · 子区标题 {len(seen['subtitle'])} 种 · "
          f"标签宽 {len(seen['lw'])} 种 · 空态 {len(seen['empty'])} 种")
    if len(seen['lw']) > 1:
        print(f"  标签宽取值：{'、'.join(sorted(seen['lw']))}"
              "  ← 每一个都要能在 A.21-5 的场景表里找到自己的场景")


def mech_checks(raw, src):
    arrays, may_empty = collect_row_arrays(src)
    """两条「故意留白」的技术成因 —— 它们是 CSS/调用姿势造成的，代码里看不见空字段。"""
    issues = []

    # 只认「选择器恰好是 .lp-detail」的那条规则。
    # 旧写法 re.search(r'\.lp-detail\s*\{...') 会先匹配到 theme.md 里排在前面的
    #   .lp-module>div:last-child>.lp-detail{margin-bottom:0}
    # 于是「照抄 theme.md 的产物」一律被误报缺 align-content（2026-09-02 支付打款模块实测）。
    detail_css = None
    for _m in re.finditer(r'\.lp-detail\s*\{([^}]*)\}', raw):
        _pre = raw[:_m.start()].rstrip()
        if _pre and _pre[-1] not in '};/\n':   # 前面挂着 > 或 , → 是组合选择器的一部分，跳过
            continue
        detail_css = _m
        break
    if detail_css and 'align-content' not in detail_css.group(1):
        issues.append(
            ('FAIL', '.lp-detail 缺 align-content:start',
             '两栏并排时每栏都是外层栅格的 item，默认 stretch 会把矮栏拉到等高，'
             '矮栏的行被平均撑开 —— 页面上凭空多出空隙，而代码里一个空字段都没有。'
             '这是"故意留白"最隐蔽的成因（A.21-4）。'))

    for ln, tag in find_tags(src, 'DetailGrid'):
        a = parse_attrs(tag)
        if 'groups' not in a or 'filter(' in a['groups']:
            continue
        inner = a['groups'].strip('{}').strip()
        if not inner.startswith('['):
            continue
        # 只有「这一栏真的可能空」时才报 —— 栏里有无条件字段项的，永远非空，报了就是噪音
        risky = [p for p in split_top(inner[1:-1])
                 if re.fullmatch(r'[A-Za-z_$][\w$]*', p) and may_empty.get(p, False)]
        if risky:
            issues.append(
                ('WARN', f'L{ln} groups 里 {"、".join(risky)} 可能整栏为空，传入前未见 filter',
                 '整栏没有内容时若传空数组，栅格仍按原栏数分宽 —— 留一个空格子，'
                 '其余栏被挤在左边。应在传入前把空栏 filter 掉，让 N 栏自动降级（A.21-6 / 多列分栏）。'))

    hard = re.findall(r'labelWidth=\{(\d+)\}', src)
    if hard:
        issues.append(
            ('FAIL', f'{len(hard)} 处硬编码 labelWidth（{"、".join(sorted(set(hard)))}）',
             '标签列宽必须走场景常量，一个场景一个（A.21-5）。现场拍数字 = 又长出一种 UI 语言。'))

    return issues


def main():
    args = [a for a in sys.argv[1:] if not a.startswith('--')]
    flags = {a for a in sys.argv[1:] if a.startswith('--')}
    if not args:
        print(__doc__)
        sys.exit(0)
    path = args[0]
    if not os.path.isfile(path):
        print(f'找不到文件: {path}')
        sys.exit(2)
    raw = open(path, encoding='utf-8', errors='replace').read()
    src = strip_comments(raw)

    page_filter = None
    for i, a in enumerate(sys.argv):
        if a == '--page' and i + 1 < len(sys.argv):
            page_filter = sys.argv[i + 1]

    issues = mech_checks(raw, src)

    if '--check' in flags:
        for lvl, title, _ in issues:
            print(f'{lvl}\t{title}')
        sys.exit(2 if any(l == 'FAIL' for l, _, _ in issues) else (1 if issues else 0))

    modules = build_sketch(src, page_filter)
    if not modules:
        print('未发现 .lp-section 模块结构 —— 这个产物可能没有详情页，或详情页没走标准骨架。')
        sys.exit(0)
    print_sketch(modules)
    print_language_table(modules)

    print('\n╔══ 版式机械检查 ' + '═' * 48)
    if not issues:
        print('║ ✅ 未发现"故意留白"的技术成因，也无硬编码标签宽')
    for lvl, title, why in issues:
        print(f'║ {"❌" if lvl == "FAIL" else "⚠"} {title}')
        print(f'║    {why}')
    print('╚' + '═' * 64)
    sys.exit(2 if any(l == 'FAIL' for l, _, _ in issues) else (1 if issues else 0))


if __name__ == '__main__':
    main()
