#!/usr/bin/env bash
# antd-transform 产物合规性一键检查
# 用法: bash scripts/check.sh <产物.html>
#
# 退出码:0 = 全过 / 1 = 有 ⚠ / 2 = 有 ❌(fail)

set -u

if [ $# -lt 1 ]; then
  echo "用法: $0 <产物.html>" >&2
  exit 2
fi

F="$1"
if [ ! -f "$F" ]; then
  echo "❌ 文件不存在: $F" >&2
  exit 2
fi

# 颜色(可选,失败时强提示)
if [ -t 1 ]; then
  G="\033[32m"; Y="\033[33m"; R="\033[31m"; N="\033[0m"
else
  G=""; Y=""; R=""; N=""
fi

pass=0; warn=0; fail=0
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "▶ 检查产物: $F"
echo "  大小: $(wc -c < "$F" | awk '{printf "%.1fKB / %d 行\n", $1/1024, $0}') $(wc -l < "$F") 行"
echo

# ─── A.13 IIFE+Hook(React #300 风险)─────────────────────────
echo "── A.13 React Hook 写法 ──"
iife=$(grep -cE '[^a-zA-Z_]\(\(\)' "$F")
if [ "$iife" -eq 0 ]; then
  echo -e "  ${G}✅${N} IIFE 数 = 0(无 Hook 调用顺序风险)"
  pass=$((pass+1))
else
  # 看 IIFE 块内是否真有 Hook
  hook_in_iife=$(python3 "$SCRIPT_DIR/check_iife_hook.py" "$F" 2>/dev/null || echo "?")
  if [ "$hook_in_iife" = "0" ]; then
    echo -e "  ${Y}⚠${N} 发现 $iife 个 IIFE,但块内无 Hook 调用(可接受)"
    warn=$((warn+1))
  else
    echo -e "  ${R}❌${N} 发现 $iife 个 IIFE,其中 $hook_in_iife 个内含 Hook → React #300 白屏风险"
    grep -nE '[^a-zA-Z_]\(\(\)' "$F" | head -5 | sed 's/^/    /'
    fail=$((fail+1))
  fi
fi

# ─── A.16 JSX 嵌套引号(Babel SyntaxError)──────────────────
echo
echo "── A.16 JSX 字符串属性 ──"
nq=$(python3 "$SCRIPT_DIR/check_jsx_quotes.py" "$F" 2>/dev/null || echo "?")
if [ "$nq" = "0" ]; then
  echo -e "  ${G}✅${N} 无中文文案嵌套 ASCII 双引号"
  pass=$((pass+1))
elif [ "$nq" = "?" ]; then
  echo -e "  ${Y}⚠${N} check_jsx_quotes.py 不可用(python3 缺失?)"
  warn=$((warn+1))
else
  echo -e "  ${R}❌${N} 发现 $nq 处嵌套引号(Babel 会挂掉)"
  python3 "$SCRIPT_DIR/check_jsx_quotes.py" "$F" --verbose 2>/dev/null | head -10 | sed 's/^/    /'
  fail=$((fail+1))
fi

# ─── A.14 Table rowKey ──────────────────────────────────────
echo
echo "── A.14 Table rowKey ──"
t=$(grep -c '<Table ' "$F")
k=$(grep -c 'rowKey=' "$F")
if [ "$k" -ge "$t" ]; then
  echo -e "  ${G}✅${N} Table=$t rowKey=$k"
  pass=$((pass+1))
else
  echo -e "  ${R}❌${N} Table=$t rowKey=$k(漏 $((t-k)) 个)"
  fail=$((fail+1))
fi

# ─── A.4.1 菜单 icon(禁 Emoji)───────────────────────────────
echo
echo "── A.4.1 菜单 icon ──"
emoji=$(grep -cE "icon:\s*['\"][^A-Za-z<]" "$F")
if [ "$emoji" -eq 0 ]; then
  echo -e "  ${G}✅${N} 菜单 icon 全部 @ant-design/icons 组件"
  pass=$((pass+1))
else
  echo -e "  ${R}❌${N} 发现 $emoji 处 Emoji/Unicode 字面量 icon"
  grep -nE "icon:\s*['\"][^A-Za-z<]" "$F" | head -3 | sed 's/^/    /'
  fail=$((fail+1))
fi

# ─── A.17 div+style 仿 antd ──────────────────────────────────
echo
echo "── A.17 div+style 仿 antd 组件(启发式)──"
div=$(grep -cE 'style=\{\{[^}]*background[^}]*border[^}]*borderRadius[^}]*color' "$F")
if [ "$div" -eq 0 ]; then
  echo -e "  ${G}✅${N} 未发现可疑 div+style 仿造"
  pass=$((pass+1))
else
  echo -e "  ${Y}⚠${N} 发现 $div 处 div 含 4+ 视觉 style(可能可用 Tag/Alert/Badge 替代)"
  grep -nE 'style=\{\{[^}]*background[^}]*border[^}]*borderRadius[^}]*color' "$F" | head -3 | sed 's/^/    /'
  warn=$((warn+1))
fi

# ─── A.3 Modal 三件套 ────────────────────────────────────────
echo
echo "── A.3 Modal 配置(closable=false / maskClosable=false / centered=true)──"
m=$(grep -c '<Modal ' "$F")
if [ "$m" -eq 0 ]; then
  echo -e "  ${G}✅${N} 本产物无 Modal(N/A)"
  pass=$((pass+1))
else
  c=$(grep -c 'closable={false}' "$F")
  mc=$(grep -c 'maskClosable={false}' "$F")
  ct=$(grep -c 'centered' "$F")
  if [ "$c" -ge "$m" ] && [ "$mc" -ge "$m" ] && [ "$ct" -ge "$m" ]; then
    echo -e "  ${G}✅${N} Modal=$m closable=$c maskClosable=$mc centered=$ct"
    pass=$((pass+1))
  else
    echo -e "  ${R}❌${N} Modal=$m closable=$c maskClosable=$mc centered=$ct(都应 ≥ $m)"
    fail=$((fail+1))
  fi
fi

# ─── CDN / antd 版本锁定 ────────────────────────────────────
echo
echo "── CDN 锁定 / antd 版本(theme.md A.1)──"
v6=$(grep -c 'antd@6' "$F")
v5=$(grep -c 'antd@5' "$F")
jd=$(grep -c 'cdn.jsdelivr.net' "$F")
up=$(grep -c 'unpkg.com' "$F")
ic=$(grep -c '@ant-design/icons' "$F")
errs=""
[ "$v6" -ge 1 ] || errs="$errs\n    antd@6 必须 ≥ 1(实际 $v6)"
[ "$v5" -eq 0 ] || errs="$errs\n    antd@5 必须 = 0(实际 $v5)"
[ "$jd" -ge 6 ] || errs="$errs\n    jsdelivr CDN 必须 ≥ 6(实际 $jd)"
[ "$up" -eq 0 ] || errs="$errs\n    unpkg 必须 = 0(实际 $up)"
[ "$ic" -ge 1 ] || errs="$errs\n    icons CDN 必须 ≥ 1(实际 $ic)"
if [ -z "$errs" ]; then
  echo -e "  ${G}✅${N} v6=$v6 v5=$v5 jsdelivr=$jd unpkg=$up icons=$ic"
  pass=$((pass+1))
else
  echo -e "  ${R}❌${N} CDN/版本违规:$errs"
  fail=$((fail+1))
fi

# ─── Logo 完整性(theme.md A.0)─────────────────────────────
echo
echo "── Logo base64 完整性 ──"
if grep -q 'LOGO_PLACEHOLDER' "$F"; then
  echo -e "  ${R}❌${N} 发现未替换的 {{LOGO_PLACEHOLDER}} — 跑 python3 scripts/embed_logo.py $F"
  fail=$((fail+1))
else
  # 找产物里最长的 base64 PNG 数据,期望 ≥ 17000 字符
  max_b64=$(grep -oE 'iVBORw0KGgoAAAA[A-Za-z0-9+/=]+' "$F" | awk '{print length($0)}' | sort -rn | head -1)
  if [ -z "$max_b64" ]; then
    echo -e "  ${R}❌${N} 没有任何 base64 logo 数据(LOGO_SRC 缺失或为占位字体仿造)"
    fail=$((fail+1))
  elif [ "$max_b64" -lt 17000 ]; then
    echo -e "  ${R}❌${N} base64 长度 $max_b64 < 17000(被截断/损坏,渲染会空白)→ 跑 embed_logo.py 修复"
    fail=$((fail+1))
  else
    echo -e "  ${G}✅${N} base64 长度 $max_b64 (完整)"
    pass=$((pass+1))
  fi
fi

# ─── 全局 .ant-* CSS 覆盖(禁)─────────────────────────────
echo
echo "── 全局 .ant-* CSS 覆盖 ──"
ant=$(grep -cE '\.ant-[a-z-]+\s*\{' "$F")
if [ "$ant" -eq 0 ]; then
  echo -e "  ${G}✅${N} 无 .ant-* 全局覆盖"
  pass=$((pass+1))
else
  echo -e "  ${R}❌${N} 发现 $ant 处 .ant-* 覆盖(应用 ConfigProvider token / classNames / styles)"
  fail=$((fail+1))
fi

# ─── 汇总 ────────────────────────────────────────────────
echo
echo "═══════════════════════════════════════"
total=$((pass+warn+fail))
echo -e "  ${G}Pass: $pass${N} / ${Y}Warn: $warn${N} / ${R}Fail: $fail${N}  (共 $total 项)"
echo "═══════════════════════════════════════"

if [ "$fail" -gt 0 ]; then
  echo -e "${R}❌ 不合格,修复后再交付${N}"
  exit 2
elif [ "$warn" -gt 0 ]; then
  echo -e "${Y}⚠ 有警告项需人工 review${N}"
  exit 1
else
  echo -e "${G}✅ 全部通过${N}"
  exit 0
fi
