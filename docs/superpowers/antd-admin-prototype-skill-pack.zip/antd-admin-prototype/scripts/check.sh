#!/usr/bin/env bash
# antd-transform 产物合规性一键检查
# 用法: bash scripts/check.sh <产物.html>
#
# 退出码:0 = 全过 / 1 = 有 ⚠ / 2 = 有 ❌(fail)

set -u

if [ $# -lt 1 ]; then
  echo "用法: $0 <产物.html>" >&2
  exit 2
fi

F="$1"
if [ ! -f "$F" ]; then
  echo "❌ 文件不存在: $F" >&2
  exit 2
fi

# 颜色(可选,失败时强提示)
if [ -t 1 ]; then
  G="\033[32m"; Y="\033[33m"; R="\033[31m"; N="\033[0m"
else
  G=""; Y=""; R=""; N=""
fi

pass=0; warn=0; fail=0
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "▶ 检查产物: $F"
echo "  大小: $(wc -c < "$F" | awk '{printf "%.1fKB / %d 行\n", $1/1024, $0}') $(wc -l < "$F") 行"
echo

# ─── A.13 IIFE+Hook(React #300 风险)─────────────────────────
echo "── A.13 React Hook 写法 ──"
iife=$(grep -cE '[^a-zA-Z_]\(\(\)' "$F")
if [ "$iife" -eq 0 ]; then
  echo -e "  ${G}✅${N} IIFE 数 = 0(无 Hook 调用顺序风险)"
  pass=$((pass+1))
else
  # 看 IIFE 块内是否真有 Hook
  hook_in_iife=$(python3 "$SCRIPT_DIR/check_iife_hook.py" "$F" 2>/dev/null || echo "?")
  if [ "$hook_in_iife" = "0" ]; then
    echo -e "  ${Y}⚠${N} 发现 $iife 个 IIFE,但块内无 Hook 调用(可接受)"
    warn=$((warn+1))
  else
    echo -e "  ${R}❌${N} 发现 $iife 个 IIFE,其中 $hook_in_iife 个内含 Hook → React #300 白屏风险"
    grep -nE '[^a-zA-Z_]\(\(\)' "$F" | head -5 | sed 's/^/    /'
    fail=$((fail+1))
  fi
fi

# ─── A.16 JSX 嵌套引号(Babel SyntaxError)──────────────────
echo
echo "── A.16 JSX 字符串属性 ──"
nq=$(python3 "$SCRIPT_DIR/check_jsx_quotes.py" "$F" 2>/dev/null || echo "?")
if [ "$nq" = "0" ]; then
  echo -e "  ${G}✅${N} 无中文文案嵌套 ASCII 双引号"
  pass=$((pass+1))
elif [ "$nq" = "?" ]; then
  echo -e "  ${Y}⚠${N} check_jsx_quotes.py 不可用(python3 缺失?)"
  warn=$((warn+1))
else
  echo -e "  ${R}❌${N} 发现 $nq 处嵌套引号(Babel 会挂掉)"
  python3 "$SCRIPT_DIR/check_jsx_quotes.py" "$F" --verbose 2>/dev/null | head -10 | sed 's/^/    /'
  fail=$((fail+1))
fi

# ─── A.14 Table rowKey ──────────────────────────────────────
echo
echo "── A.14 Table rowKey ──"
t=$(grep -c '<Table ' "$F")
k=$(grep -c 'rowKey=' "$F")
if [ "$k" -ge "$t" ]; then
  echo -e "  ${G}✅${N} Table=$t rowKey=$k"
  pass=$((pass+1))
else
  echo -e "  ${R}❌${N} Table=$t rowKey=$k(漏 $((t-k)) 个)"
  fail=$((fail+1))
fi

# ─── A.4.1 菜单 icon(禁 Emoji)───────────────────────────────
echo
echo "── A.4.1 菜单 icon ──"
emoji=$(grep -cE "icon:\s*['\"][^A-Za-z<]" "$F")
if [ "$emoji" -eq 0 ]; then
  echo -e "  ${G}✅${N} 菜单 icon 全部 @ant-design/icons 组件"
  pass=$((pass+1))
else
  echo -e "  ${R}❌${N} 发现 $emoji 处 Emoji/Unicode 字面量 icon"
  grep -nE "icon:\s*['\"][^A-Za-z<]" "$F" | head -3 | sed 's/^/    /'
  fail=$((fail+1))
fi

# ─── A.17 div+style 仿 antd ──────────────────────────────────
echo
echo "── A.17 div+style 仿 antd 组件(启发式)──"
div=$(grep -cE 'style=\{\{[^}]*background[^}]*border[^}]*borderRadius[^}]*color' "$F")
if [ "$div" -eq 0 ]; then
  echo -e "  ${G}✅${N} 未发现可疑 div+style 仿造"
  pass=$((pass+1))
else
  echo -e "  ${Y}⚠${N} 发现 $div 处 div 含 4+ 视觉 style(可能可用 Tag/Alert/Badge 替代)"
  grep -nE 'style=\{\{[^}]*background[^}]*border[^}]*borderRadius[^}]*color' "$F" | head -3 | sed 's/^/    /'
  warn=$((warn+1))
fi

# ─── A.3 Modal 三件套 ────────────────────────────────────────
echo
echo "── A.3 Modal 配置(closable=false / maskClosable=false / centered=true)──"
m=$(grep -c '<Modal ' "$F")
if [ "$m" -eq 0 ]; then
  echo -e "  ${G}✅${N} 本产物无 Modal(N/A)"
  pass=$((pass+1))
else
  c=$(grep -c 'closable={false}' "$F")
  mc=$(grep -c 'maskClosable={false}' "$F")
  ct=$(grep -c 'centered' "$F")
  if [ "$c" -ge "$m" ] && [ "$mc" -ge "$m" ] && [ "$ct" -ge "$m" ]; then
    echo -e "  ${G}✅${N} Modal=$m closable=$c maskClosable=$mc centered=$ct"
    pass=$((pass+1))
  else
    echo -e "  ${R}❌${N} Modal=$m closable=$c maskClosable=$mc centered=$ct(都应 ≥ $m)"
    fail=$((fail+1))
  fi
fi

# ─── CDN / 版本锁定(必须精确补丁版,禁止浮动 tag)──────────────
echo
echo "── CDN 锁定 / 精确版本(theme.md A.1)──"
v6=$(grep -c 'antd@6' "$F")
v5=$(grep -c 'antd@5' "$F")
jd=$(grep -c 'cdn.jsdelivr.net' "$F")
up=$(grep -c 'unpkg.com' "$F")
ic=$(grep -c '@ant-design/icons' "$F")
# 浮动 tag 检测:react@18 / react-dom@18 / dayjs@1 / antd@6 后面直接跟 / 或 引号 = 没锁补丁版
floatlib=$(grep -Eoc '(react|react-dom|dayjs|antd)@[0-9]+(["/])' "$F")
# icons 浮动 tag(会追到 6.2.5 崩);精确版本如 @6.2.1 不会命中
floaticon=$(grep -Ec '@ant-design/icons@[0-9]+(["/])' "$F")
errs=""
[ "$v6" -ge 1 ] || errs="$errs\n    antd 6.x 必须 ≥ 1(实际 $v6)"
[ "$v5" -eq 0 ] || errs="$errs\n    antd@5 必须 = 0(实际 $v5)"
[ "$jd" -ge 6 ] || errs="$errs\n    jsdelivr CDN 必须 ≥ 6(实际 $jd)"
[ "$up" -eq 0 ] || errs="$errs\n    unpkg 必须 = 0(实际 $up)"
[ "$ic" -ge 1 ] || errs="$errs\n    icons CDN 必须 ≥ 1(实际 $ic)"
[ "$floatlib" -eq 0 ] || errs="$errs\n    禁止浮动 tag react/react-dom/dayjs/antd@<major>,必须精确补丁版(命中 $floatlib;见 theme.md A.1)"
[ "$floaticon" -eq 0 ] || errs="$errs\n    禁止浮动 @ant-design/icons@<major>(会追到 6.2.5 崩 → 白屏),锁 @6.2.1(命中 $floaticon)"
if [ -z "$errs" ]; then
  echo -e "  ${G}✅${N} v6=$v6 v5=$v5 jsdelivr=$jd unpkg=$up icons=$ic 浮动tag=0"
  pass=$((pass+1))
else
  echo -e "  ${R}❌${N} CDN/版本违规:$errs"
  fail=$((fail+1))
fi

# ─── Logo 完整性(theme.md A.0)─────────────────────────────
echo
echo "── Logo base64 完整性 ──"
if grep -q 'LOGO_PLACEHOLDER' "$F"; then
  echo -e "  ${R}❌${N} 发现未替换的 {{LOGO_PLACEHOLDER}} — 跑 python3 scripts/embed_logo.py $F"
  fail=$((fail+1))
else
  # 新版默认 Logo 为 SVG；兼容历史 PNG 产物。
  svg_b64=$(grep -oE 'data:image/svg\+xml;base64,[A-Za-z0-9+/=]+' "$F" | awk '{print length($0)}' | sort -rn | head -1)
  png_b64=$(grep -oE 'data:image/png;base64,[A-Za-z0-9+/=]+' "$F" | awk '{print length($0)}' | sort -rn | head -1)
  if [ -n "$svg_b64" ] && [ "$svg_b64" -ge 1000 ]; then
    echo -e "  ${G}✅${N} SVG logo base64 长度 $svg_b64 (完整)"
    pass=$((pass+1))
  elif [ -n "$png_b64" ] && [ "$png_b64" -ge 17000 ]; then
    echo -e "  ${G}✅${N} PNG logo base64 长度 $png_b64 (历史产物兼容)"
    pass=$((pass+1))
  else
    echo -e "  ${R}❌${N} 没有完整 base64 logo 数据(LOGO_SRC 缺失、占位未注入或字体仿造)"
    fail=$((fail+1))
  fi
fi

# ─── 全局 .ant-* CSS 覆盖(禁)─────────────────────────────
echo
echo "── 全局 .ant-* CSS 覆盖 ──"
ant=$(grep -cE '\.ant-[a-z-]+\s*\{' "$F")
if [ "$ant" -eq 0 ]; then
  echo -e "  ${G}✅${N} 无 .ant-* 全局覆盖"
  pass=$((pass+1))
else
  echo -e "  ${R}❌${N} 发现 $ant 处 .ant-* 覆盖(应用 ConfigProvider token / classNames / styles)"
  fail=$((fail+1))
fi

# ─── A.20 对象字面量重复键(静默覆盖 → 数据错/白屏)────────────
echo
echo "── A.20 JS 对象重复键 ──"
dk=$(python3 "$SCRIPT_DIR/check_dup_keys.py" "$F" 2>/dev/null || echo "?")
if [ "$dk" = "?" ]; then
  echo -e "  ${Y}⚠${N} check_dup_keys.py 不可用(python3 缺失?)"
  warn=$((warn+1))
elif [ "$dk" -eq 0 ]; then
  echo -e "  ${G}✅${N} 无重复键(mock 数据无静默覆盖)"
  pass=$((pass+1))
else
  echo -e "  ${R}❌${N} 发现 $dk 处同一对象内重复键 — JS 只保留最后一个,前面的值会凭空消失"
  python3 "$SCRIPT_DIR/check_dup_keys.py" "$F" --verbose 2>/dev/null | head -10
  fail=$((fail+1))
fi

# ─── A.21 UI 语言一致性(硬编码 labelWidth 为 Fail;多写法为 Warn 需人工判场景) ───
echo
echo "── A.21 同一页面 UI 语言一致性 ──"
if ! command -v python3 >/dev/null 2>&1; then
  echo -e "  ${Y}⚠${N} check_ui_lang.py 不可用(python3 缺失?)"
  warn=$((warn+1))
else
  hard=$(grep -oE 'labelWidth[[:space:]]*=[[:space:]]*\{?[[:space:]]*[0-9]+' "$F" | wc -l | tr -d ' ')
  if [ "$hard" -gt 0 ]; then
    echo -e "  ${R}❌${N} 硬编码 labelWidth $hard 处 — 必须走场景常量(A.21-4)"
    python3 "$SCRIPT_DIR/check_ui_lang.py" "$F" 2>/dev/null | grep -E '硬编码|取值' | head -3
    fail=$((fail+1))
  else
    multi=$(python3 "$SCRIPT_DIR/check_ui_lang.py" "$F" 2>/dev/null | grep -c '⚠' || true)
    if [ "$multi" -gt 0 ]; then
      echo -e "  ${Y}⚠${N} 有多种写法待人工判读场景 — 跑 check_ui_lang.py --verbose 逐项确认"
      warn=$((warn+1))
    else
      echo -e "  ${G}✅${N} 模块标题/子区标题/容器/空态均唯一,无硬编码宽度"
      pass=$((pass+1))
    fi
  fi
fi

# ─── 文案边界:说明性文本复述同屏已有元素(Warn 级初筛,需人工判读) ───
echo
echo "── 文案边界 说明性文本复述初筛 ──"
if ! command -v python3 >/dev/null 2>&1; then
  echo -e "  ${Y}⚠${N} check_text_redundancy.py 不可用(python3 缺失?)"
  warn=$((warn+1))
else
  red=$(python3 "$SCRIPT_DIR/check_text_redundancy.py" "$F" 2>/dev/null | grep -cE '^  L[0-9]+' || true)
  if [ "$red" -gt 0 ]; then
    echo -e "  ${Y}⚠${N} $red 处说明性文本拼接了同屏可能已渲染的值 — 跑 check_text_redundancy.py 逐条判读"
    python3 "$SCRIPT_DIR/check_text_redundancy.py" "$F" 2>/dev/null | grep -E '^  L[0-9]+' | head -5
    warn=$((warn+1))
  else
    echo -e "  ${G}✅${N} 未发现说明性文本复述同屏 tag / 字段值"
    pass=$((pass+1))
  fi
fi

# ─── 详情页版式:「故意留白」的技术成因 + 硬编码标签宽(A.21-4/5) ───
# 没有详情页结构的产物直接跳过(不计入,免得给列表页/配置页记一笔无意义的 Pass)
echo
echo "── 详情页版式(align-content / 标签宽常量 / 空栏 filter)──"
if ! command -v python3 >/dev/null 2>&1; then
  echo -e "  ${Y}⚠${N} sketch_detail.py 不可用(python3 缺失?)"
  warn=$((warn+1))
elif ! grep -q 'lp-detail' "$F"; then
  echo "  ─ 无详情页栅格结构,跳过"
else
  out=$(python3 "$SCRIPT_DIR/sketch_detail.py" "$F" --check 2>/dev/null || true)
  nf=$(printf '%s' "$out" | grep -c '^FAIL' || true)
  nw=$(printf '%s' "$out" | grep -c '^WARN' || true)
  if [ "$nf" -gt 0 ]; then
    echo -e "  ${R}❌${N} $nf 项版式硬伤 — 跑 sketch_detail.py 看详情"
    printf '%s\n' "$out" | grep '^FAIL' | sed 's/^FAIL\t/     /'
    fail=$((fail+1))
  elif [ "$nw" -gt 0 ]; then
    echo -e "  ${Y}⚠${N} $nw 项需人工判读(可能整栏为空却未 filter)"
    printf '%s\n' "$out" | grep '^WARN' | sed 's/^WARN\t/     /'
    warn=$((warn+1))
  else
    echo -e "  ${G}✅${N} 无\"故意留白\"的技术成因,标签宽全部走常量"
    pass=$((pass+1))
  fi
fi

# ─── 渲染仿真:真实数据 × 真实组件渲染后才成立的硬伤 ───
# 前面 13 项都在读代码。这一项真的把每条单据渲染出来量几何——
# 「这张单上摆了个点不了的按钮」这类问题,静态检查结构上就够不着。
echo
echo "── 渲染仿真(逐单渲染详情页+弹窗,量真实几何)──"
CHROME_BIN=""
for c in "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" \
         "/Applications/Chromium.app/Contents/MacOS/Chromium" \
         "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"; do
  [ -x "$c" ] && CHROME_BIN="$c" && break
done
if [ -z "$CHROME_BIN" ]; then
  echo -e "  ${Y}⚠${N} 未找到 Chrome,渲染仿真跳过(静态检查查不出布局类问题,建议装 Chrome 后补跑)"
  warn=$((warn+1))
elif ! command -v python3 >/dev/null 2>&1; then
  echo -e "  ${Y}⚠${N} render_sim.py 不可用(python3 缺失?)"
  warn=$((warn+1))
else
  sim=$(python3 "$SCRIPT_DIR/render_sim.py" "$F" 2>&1 || true)
  hardn=$(printf '%s' "$sim" | sed -n '/【硬伤】/,/【形态证据】/p' | grep -c '⚠\|❌' || true)
  if [ "$hardn" -gt 0 ]; then
    echo -e "  ${R}❌${N} $hardn 项渲染硬伤 — 跑 render_sim.py 看详情"
    printf '%s\n' "$sim" | sed -n '/【硬伤】/,/【形态证据】/p' | grep '⚠\|❌' | head -8 | sed 's/^ */     /'
    fail=$((fail+1))
  else
    echo -e "  ${G}✅${N} 无渲染硬伤"
    echo -e "     ${Y}↑ 形态证据(操作×状态交叉表/模块矩阵/弹窗可达性)不判对错,需人工过一遍:${N}"
    echo "       python3 $SCRIPT_DIR/render_sim.py \"$F\""
    pass=$((pass+1))
  fi
fi

# ─── 汇总 ────────────────────────────────────────────────
echo
echo "═══════════════════════════════════════"
total=$((pass+warn+fail))
echo -e "  ${G}Pass: $pass${N} / ${Y}Warn: $warn${N} / ${R}Fail: $fail${N}  (共 $total 项)"
echo "═══════════════════════════════════════"

if [ "$fail" -gt 0 ]; then
  echo -e "${R}❌ 不合格,修复后再交付${N}"
  exit 2
elif [ "$warn" -gt 0 ]; then
  echo -e "${Y}⚠ 有警告项需人工 review${N}"
  exit 1
else
  echo -e "${G}✅ 全部通过${N}"
  exit 0
fi
