#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
render_sim.py — 渲染仿真：把每条真实单据喂进真实组件，渲染成元素树看排布。

为什么需要它（它和 check.sh / sketch_detail.py 的分工）
------------------------------------------------------
check.sh 读代码，sketch_detail.py 解析 AST——它们都在**代码层**工作，
所以有一整类问题它们结构上就够不着：这些问题只有在「真实数据 × 真实组件 × 真实布局引擎」
三者凑齐、真正渲染出来之后才成立。

  · 这张单上摆了个点不了的按钮（零尺寸 / 被遮住 / pointer-events 被吃掉）
  · 标签宽不够，标签压到值上面
  · 某个模块在 A 单好好的，B 单数据缺一个字段就塌成一条 19px 的空壳
  · 文本超出容器被切掉
  · 「审核」按钮到底出现在哪几单——代码里只是一行 {cond && <Button>}，
    条件展开后的真实分布，读代码是算不出来的

sketch_detail.py 自己的文档里写着它的限制：「它抽的是结构，不是像素。
列宽够不够、折不折行，它答不了」。本脚本就是来补那一句的。

它不做什么（这条很重要，否则会制造大量噪音）
--------------------------------------------
**它不替你判断「点不了」是不是缺陷。** 实测教训：售后 v16 的判责弹窗里，
「判责结论」下拉在退货在途状态是 disabled 的，代码注释写着「货尚未到仓、
无实物可验……展示得出来但改不动」——这是刻意设计，还配了 helper 文案。
如果脚本把所有 disabled 都报成问题，真问题会被淹在噪音里。

所以输出分两层：
  【硬伤】只留不可能是设计意图的：渲染抛异常 / 按钮零尺寸 / 标签与值重叠 /
          溢出父容器 / 文本被截断 / 模块塌陷。这些没有任何一种设计会故意要。
  【形态证据】操作 × 状态交叉表、模块出现矩阵、弹窗可达性、页面高度分布。
          这些不判对错，是摊平给人看的——真正的判断需要业务上下文，那是你和用户的事。

用法
----
  python3 render_sim.py 产物.html                      # 自动识别，跑详情页 + 弹窗
  python3 render_sim.py 产物.html --component XDetail --data X_ROWS
  python3 render_sim.py 产物.html --tree 0             # 额外打印第 0 单的元素树
  python3 render_sim.py 产物.html --no-modal           # 只跑详情页
  python3 render_sim.py 产物.html --json out.json      # 结构化结果留档

依赖：只要本机装了 Chrome（--headless --dump-dom），无需 npm / puppeteer。

限制（先说清，免得被当成像素级验收）
-----------------------------------
- 视口固定 1440 宽。窄屏折行问题看不出来。
- 只渲染组件本身，不跑用户交互路径（点开某个 Tab 后才出现的内容抓不到）。
- 入参靠名字推断（record/row/target/open/onClose…）。签名太特殊的组件会渲染失败，
  失败会如实列出来，不会静默跳过——**渲染失败 ≠ 组件有 bug**，先看是不是入参没喂对。
"""

import re, sys, os, json, subprocess, argparse, html as H

CHROME_CANDIDATES = [
    '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    '/Applications/Chromium.app/Contents/MacOS/Chromium',
    '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge',
]


def find_chrome():
    for p in CHROME_CANDIDATES:
        if os.path.exists(p):
            return p
    return None


# ─────────────────────────────── 自动识别 ───────────────────────────────

def discover(src):
    """从源码里找详情页组件、单据数组、弹窗组件。找不到就返回空，让调用方决定。"""
    # 详情页组件：名字含 Detail，且入参里有 record / row / data
    details = []
    for m in re.finditer(r'^function\s+([A-Z]\w*)\s*\(\s*\{([^}]*)\}', src, re.M):
        name, params = m.group(1), m.group(2)
        if 'Detail' in name and re.search(r'\brecord\b|\brow\b|\bdata\b', params):
            details.append(name)

    # 弹窗组件：名字以 Modal 结尾
    modals = []
    for m in re.finditer(r'^function\s+([A-Z]\w*Modal)\s*\(\s*\{([^}]*)\}', src, re.M):
        modals.append({'name': m.group(1),
                       'params': [p.strip().split('=')[0].strip()
                                  for p in m.group(2).split(',') if p.strip()]})

    # 单据数组：顶层 const XXX = [ ... ]，元素是对象且条数 >= 3
    arrays = []
    for m in re.finditer(r'^const\s+([A-Z][A-Z0-9_]*)\s*=\s*\[', src, re.M):
        name = m.group(1)
        seg = src[m.end() - 1:m.end() + 60000]
        depth, cnt, started = 0, 0, False
        for ch in seg:
            if ch == '[' and not started:
                started = True
                continue
            if not started:
                continue
            if ch in '[{':
                depth += 1
            elif ch in ']}':
                if depth == 0:
                    break
                depth -= 1
                if depth == 0:
                    cnt += 1
        if cnt >= 3:
            keys = set(re.findall(r'[{,]\s*(\w+)\s*:', src[m.end():m.end() + 3000]))
            arrays.append((name, cnt, keys))
    arrays.sort(key=lambda x: -x[1])
    return details, arrays, modals


def rank_candidates(src, comp, arrays):
    """按「组件到底读了哪些字段」选数组，而不是按条数最多。

    实测教训：营销活动产物里条数最多的是 ALERTS（告警），而 PromotionDetailPage 要的是
    活动数据。用「条数最多」这个代理变量选，7 条记录全部渲染抛异常。
    判据要直接描述目标——组件读 record.xxx，那就选 xxx 覆盖率最高的数组。
    """
    if not arrays:
        return []
    names = [x[0] for x in arrays]
    if not comp:
        return names
    m = re.search(r'^function\s+' + re.escape(comp) + r'\s*\(', src, re.M)
    if not m:
        return names
    body = src[m.start():m.start() + 30000]
    used = set(re.findall(r'\b(?:record|r|row)\.(\w+)', body))
    if not used:
        return names
    # 静态分只决定「先试谁」，减少试渲染次数；最终选谁由渲染结果说了算
    return [n for n, c, k in sorted(arrays,
            key=lambda x: -(len(used & x[2]) / len(used) if x[2] else 0))]


# ─────────────────────────────── 浏览器内探针 ───────────────────────────────

PROBE = r'''
(function(){
  const Comp = (typeof __COMP__ !== 'undefined') ? __COMP__ : null;
  // 数据数组靠试渲染选，不靠静态猜。实测两次翻车：按「条数最多」选中了告警数组，
  // 按「字段名交集」选中了策略数组——都能静态说得通，但一渲染就全抛异常。
  // 能不能渲染出来是唯一不会骗人的判据。
  const CANDS = __CANDS__;
  let RECORDS = [], DATANAME = '(none)';
  if (Comp && CANDS.length) {
    let best = -1;
    CANDS.forEach(function(c){
      if (!c.v || !c.v.length) return;
      const probe = document.createElement('div');
      document.body.appendChild(probe);
      let n = -1;
      try {
        const rt = ReactDOM.createRoot(probe);
        ReactDOM.flushSync(function(){
          rt.render(React.createElement(Comp, { record: c.v[0], go: function(){}, onBack: function(){}, onClose: function(){} }));
        });
        n = probe.querySelectorAll('*').length;
      } catch(e) { n = -1; }
      probe.remove();
      if (n > best) { best = n; RECORDS = c.v; DATANAME = c.n; }
    });
  } else if (CANDS.length) { RECORDS = CANDS[0].v || []; DATANAME = CANDS[0].n; }
  RECORDS = RECORDS.slice(0, __LIMIT__);
  const MODALS = __MODALS__;
  const noop = function(){};
  const result = { records: [], modals: [], compName: '__COMPNAME__', dataName: '' };

  const SHOT = __SHOT__;   // >=0 表示只渲染这一单并铺满页面用于截图
  const host = document.createElement('div');
  host.style.cssText = SHOT >= 0
    ? 'position:absolute;left:0;top:0;width:1440px;background:#F9FAFB;z-index:99999'
    : 'position:absolute;left:0;top:0;width:1440px';
  document.body.appendChild(host);
  if (SHOT >= 0) {
    // 把原页面藏掉，只留被截的这一单，避免截到后台框架
    Array.from(document.body.children).forEach(function(el){
      if (el !== host) el.style.display = 'none';
    });
    document.body.style.background = '#F9FAFB';
  }

  // 入参按名字推断。渲染失败会如实记录，不猜到底。
  function propsFor(params, rec){
    const p = {};
    params.forEach(function(k){
      if (k === 'open') p[k] = true;
      else if (/^on[A-Z]/.test(k) || k === 'go' || k === 'setMode') p[k] = noop;
      else if (/^(record|row|target|payload|item|detail)$/.test(k)) p[k] = rec;
      else if (k === 'sheet') p[k] = rec;
      else if (k === 'list') p[k] = (rec && (rec.photos || rec.evidence || rec.files)) || [];
      else if (k === 'index') p[k] = 0;
      else if (k === 'mode') p[k] = 'zero';
      else if (/^(market|data|types)$/.test(k)) p[k] = undefined;
    });
    return p;
  }

  function clsOf(el){
    const c = el.className;
    return String(c && c.baseVal !== undefined ? c.baseVal : (c || ''));
  }
  function ownText(el){
    return Array.from(el.childNodes).filter(function(n){return n.nodeType===3;})
      .map(function(n){return n.textContent.trim();}).join(' ').trim();
  }

  // 硬伤扫描：只留「不可能是设计意图」的形态
  function scan(box){
    const hard = [], modules = [], actions = [];
    box.querySelectorAll('*').forEach(function(el){
      const r = el.getBoundingClientRect();
      const cs = getComputedStyle(el);
      const cls = clsOf(el);
      const antd = cls.split(/\s+/).filter(function(c){return /^ant-|^lp-/.test(c);}).join(' ');
      const own = ownText(el);
      const isBtn = el.tagName === 'BUTTON' || /(^|\s)ant-btn(\s|$)/.test(cls);

      if (/(^|\s)(lp-card|lp-sub|lp-module|ant-card)(\s|$)/.test(cls)) {
        // 模块名要的是「退货轨迹」这种子区标题，不是卡头里的业务值。
        // 实测教训：售后的 .lp-card-head .main 装的是「承运商 + 运单号 + 轨迹状态」，
        // 拿它当模块名会让每单都是不同名字，整张矩阵退化成一堆 1/19，白跑。
        const t = el.querySelector('.lp-section, .lp-card-label, .lp-part-title, .ant-card-head-title, h3, h4');
        let nm = t ? t.textContent.trim() : '';
        if (!nm) {
          const mainEl = el.querySelector('.lp-card-head .main');
          const mt = mainEl ? mainEl.textContent.trim() : '';
          // 含长数字/编号串的是业务值不是标题
          nm = (mt && !/\d{6,}|[A-Z]{2,}\d{4,}/.test(mt)) ? mt : '(无标题)';
        }
        modules.push({ name: nm.slice(0,26), h: Math.round(r.height) });
      }
      if (isBtn) {
        const bt = (el.textContent || '').trim();
        if (bt) actions.push({ label: bt.slice(0,18),
          dis: el.disabled === true || /ant-btn-disabled/.test(cls),
          w: Math.round(r.width), h: Math.round(r.height) });
        // 硬伤①：按钮渲染出来了却点不了。
        // 只判**带业务文本**的按钮：组件库自己的功能件（ant-tabs-nav-more 溢出菜单、
        // Select 的隐藏搜索框等）本来就没文本、本来就按需隐藏，判它们全是噪音。
        if (!bt) { /* 组件库内部件，不判 */ }
        else if (r.width === 0 || r.height === 0)
          hard.push({t:'按钮零尺寸', el: bt || antd, d: Math.round(r.width)+'x'+Math.round(r.height)});
        else if (cs.visibility === 'hidden' || cs.display === 'none')
          hard.push({t:'按钮不可见', el: bt || antd, d: cs.display+'/'+cs.visibility});
        else if (cs.pointerEvents === 'none' && el.disabled !== true)
          hard.push({t:'按钮点不动(pointer-events:none 却未 disabled)', el: bt || antd, d:''});
        else if (r.height > 0 && r.height < 20)
          hard.push({t:'按钮高度异常', el: bt || antd, d: Math.round(r.height)+'px'});
      }
      // 硬伤②：溢出父容器（inline 元素的内边距不算，阈值 6px 滤掉边框级误差）
      if (r.width > 0 && el.parentElement) {
        const p = el.parentElement.getBoundingClientRect();
        const pcs = getComputedStyle(el.parentElement);
        if (p.width > 0 && r.right > p.right + 6 &&
            !/auto|scroll|hidden/.test(pcs.overflowX) && !/^inline/.test(cs.display))
          hard.push({t:'溢出父容器', el:(own||antd).slice(0,26), d:'超出 '+Math.round(r.right-p.right)+'px'});
      }
      // 硬伤③：文本被切掉
      if (own && el.clientWidth > 0 && el.scrollWidth > el.clientWidth + 2 &&
          /ellipsis|hidden/.test(cs.overflow + cs.textOverflow))
        hard.push({t:'文本被截断', el: own.slice(0,26), d: el.scrollWidth+'>'+el.clientWidth});
      // 硬伤④：模块塌陷成空壳（注意用词边界，lp-card 不能吃掉 lp-card-label）
      if (/(^|\s)(lp-card|lp-sub|lp-module)(\s|$)/.test(cls) && r.height > 0 && r.height < 40 &&
          (el.textContent||'').trim().length < 8)
        hard.push({t:'模块塌陷(有壳无内容)', el:(el.textContent||'').trim().slice(0,20)||antd, d: Math.round(r.height)+'px'});
      // 硬伤⑤：字段标签放不下。
      // 注意这里踩过一次坑：原本写的是「标签与值重叠」，但详情栅格 .lp-detail 是
      // CSS Grid（grid-template-columns:132px 1fr），标签和值各占一列，**结构上不可能重叠**
      // ——那条判据写了也永远不触发。列宽不够的真实形态是标签被挤：文字截断，或折成两行
      // 把整行撑高。判据要照着真实布局写，不是照着想象写。
      if (/(^|\s)(dl|lp-form-label|ant-descriptions-item-label)(\s|$)/.test(cls) && own) {
        if (el.scrollWidth > el.clientWidth + 2 && el.clientWidth > 0)
          hard.push({t:'字段标签放不下(被截断)', el: own.slice(0,18),
                     d: el.scrollWidth + '>' + el.clientWidth + 'px'});
        else {
          // 折行要量**文字实际占几行**，不能拿元素高度算。
          // 第二次踩坑：.lp-detail 是 grid，标签单元格的高度会被同一行的值单元格
          // （比如一整片缩略图）撑到 195px，而标签文字仍是一行。高度判据在 grid 下无效。
          // Range 的 client rects 每行一个，这个数字不受容器拉伸影响。
          // 第三次修这条：getClientRects() 是**每个内联片段一个 rect**，不是每行一个。
          // 标签里有「必填星号」「说明小字」这类子元素时，一行就能返回 3 个 rect。
          // 按 rect 的 top 去重才是真实行数。
          const rng = document.createRange();
          rng.selectNodeContents(el);
          const tops = new Set(Array.from(rng.getClientRects())
            .filter(function(x){ return x.width > 0 && x.height > 0; })
            .map(function(x){ return Math.round(x.top); }));
          const lines = tops.size;
          if (lines > 1)
            hard.push({t:'字段标签折行(列宽不够)', el: own.slice(0,18), d: lines + ' 行'});
        }
      }
    });
    return { hard: hard, modules: modules, actions: actions, height: Math.round(box.scrollHeight) };
  }

  // 元素树：只留有 antd 类名 / 有文本 / 可交互的节点，够人扫一眼看懂排布
  function tree(box){
    const lines = [];
    (function walk(el, d){
      if (d > 12) return;
      const r = el.getBoundingClientRect();
      const cs = getComputedStyle(el);
      const cls = clsOf(el);
      const antd = cls.split(/\s+/).filter(function(c){return /^ant-|^lp-/.test(c);}).slice(0,2).join(' ');
      const own = ownText(el);
      const isBtn = el.tagName === 'BUTTON' || /(^|\s)ant-btn(\s|$)/.test(cls);
      if (antd || own || isBtn) {
        let flag = '';
        if (el.disabled === true || /ant-btn-disabled/.test(cls)) flag += ' [disabled]';
        if (r.width === 0 || r.height === 0) flag += ' [零尺寸]';
        if (cs.display === 'none' || cs.visibility === 'hidden') flag += ' [不可见]';
        lines.push('  '.repeat(d) + (antd || el.tagName.toLowerCase()) +
          (own ? ' 「' + own.slice(0,30) + '」' : '') +
          ' ' + Math.round(r.width) + 'x' + Math.round(r.height) + flag);
      }
      for (const c of el.children) walk(c, d + 1);
    })(box, 0);
    return lines;
  }

  // ── 详情页：逐单渲染
  if (Comp) {
    RECORDS.forEach(function(rec, i){
      if (SHOT >= 0 && i !== SHOT) return;
      const box = document.createElement('div');
      box.style.cssText = 'width:1440px';
      host.appendChild(box);
      let res = null, err = null, tr = null;
      try {
        const root = ReactDOM.createRoot(box);
        // flushSync 让渲染同步完成——否则 dump-dom 抓到的是空壳
        ReactDOM.flushSync(function(){
          root.render(React.createElement(Comp, propsFor(['record','go','onBack','onClose'], rec)));
        });
        res = scan(box);
        if (i === __TREEIDX__) tr = tree(box);
      } catch(e) { err = String((e && e.message) || e); }
      result.records.push(Object.assign(
        { i: i, id: rec.id || rec.key || rec.code || ('#' + i),
          status: rec.status || rec.state || '', err: err, tree: tr,
          shotHeight: SHOT >= 0 ? Math.round(box.scrollHeight) : 0 }, res || {}));
      if (SHOT < 0) box.remove();
    });
  }

  // ── 弹窗：每个弹窗拿首单渲染一次（弹窗渲染进 body，用 antd 的挂载点找回来）
  MODALS.forEach(function(md){
    const Fn = window[md.name] || (typeof eval('typeof ' + md.name) !== 'undefined' ? eval(md.name) : null);
    if (!Fn) { result.modals.push({name: md.name, err: '未取到组件引用'}); return; }
    const rec = RECORDS[0];
    const box = document.createElement('div');
    host.appendChild(box);
    let err = null, items = [], hard = [];
    try {
      const root = ReactDOM.createRoot(box);
      ReactDOM.flushSync(function(){
        root.render(React.createElement(Fn, propsFor(md.params, rec)));
      });
      // antd Modal 通过 portal 挂到 body 末尾
      const wraps = document.querySelectorAll('.ant-modal-wrap, .ant-modal-root');
      const w = wraps[wraps.length - 1];
      if (w) {
        const s = scan(w);
        hard = s.hard;
        items = Array.from(w.querySelectorAll('button, input, .ant-select, textarea')).filter(function(el){
          // antd Upload 的 <input type=file> 恒为 0x0 且被刻意隐藏，是常态不是缺陷
          return !(el.tagName === 'INPUT' && el.type === 'file');
        }).map(function(el){
          const r = el.getBoundingClientRect();
          const cls = clsOf(el);
          return { tag: el.tagName.toLowerCase(),
                   label: (el.textContent || el.placeholder || '').trim().slice(0,18),
                   dis: el.disabled === true || /disabled/.test(cls),
                   w: Math.round(r.width), h: Math.round(r.height) };
        });
      }
    } catch(e) { err = String((e && e.message) || e); }
    result.modals.push({ name: md.name, err: err, items: items, hard: hard });
    box.remove();
  });

  result.dataName = DATANAME;
  const pre = document.createElement('pre');
  pre.id = '__SIM__';
  pre.textContent = JSON.stringify(result);
  document.body.appendChild(pre);
})();
'''


def run(src_path, comp, cands, modals, limit, tree_idx, timeout=180, shot=None, shot_out=None):
    src = open(src_path, encoding='utf-8').read()
    cand_js = '[' + ','.join("{n:'%s',v:(typeof %s!=='undefined'?%s:null)}" % (c, c, c)
                             for c in cands) + ']'
    probe = (PROBE
             .replace('__CANDS__', cand_js)
             .replace('__COMP__', comp or 'null')
             .replace('__COMPNAME__', comp or '')
             .replace('__MODALS__', json.dumps(modals, ensure_ascii=False))
             .replace('__LIMIT__', str(limit))
             .replace('__TREEIDX__', str(tree_idx if tree_idx is not None else -1))
             .replace('__SHOT__', str(shot if shot is not None else -1)))
    idx = src.rindex('</script>')
    tmp = os.path.join(os.path.dirname(os.path.abspath(src_path)), '._render_sim_tmp.html')
    # 关键：注入必须落在原 babel script 内部。babel standalone 对每个
    # <script type="text/babel"> 单独编译执行，顶层 const 组件不挂 window，
    # 新开一个 script 是取不到 AfterSaleDetailPage 这类组件的。
    open(tmp, 'w', encoding='utf-8').write(src[:idx] + '\n' + probe + '\n' + src[idx:])
    chrome = find_chrome()
    if not chrome:
        print('❌ 没找到 Chrome/Chromium/Edge，渲染仿真跑不了。')
        sys.exit(3)
    try:
        dom = subprocess.run([chrome, '--headless', '--disable-gpu', '--no-sandbox',
                              '--window-size=1440,3000', '--virtual-time-budget=30000',
                              '--dump-dom', 'file://' + tmp],
                             capture_output=True, text=True, timeout=timeout).stdout
        if shot is not None and shot_out:
            # 第二趟：按刚量到的真实高度截整页，避免截断
            h = 3000
            m0 = re.search(r'<pre id="__SIM__">(.*?)</pre>', dom, re.S)
            if m0:
                try:
                    d0 = json.loads(H.unescape(m0.group(1)))
                    hs = [r.get('shotHeight', 0) for r in d0.get('records', [])]
                    if hs and max(hs):
                        h = min(max(hs) + 80, 12000)
                except Exception:
                    pass
            subprocess.run([chrome, '--headless', '--disable-gpu', '--no-sandbox',
                            '--hide-scrollbars', f'--window-size=1440,{h}',
                            '--virtual-time-budget=30000',
                            '--screenshot=' + shot_out, 'file://' + tmp],
                           capture_output=True, text=True, timeout=timeout)
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)
    m = re.search(r'<pre id="__SIM__">(.*?)</pre>', dom, re.S)
    if not m:
        print('❌ 探针没有产出结果——通常是产物本身就渲染不出来（白屏）。')
        print('   先用浏览器打开产物确认能正常显示，再跑本脚本。')
        sys.exit(2)
    return json.loads(H.unescape(m.group(1)))


# ─────────────────────────────── 报告 ───────────────────────────────

def report(res, show_tree):
    recs = [r for r in res.get('records', [])]
    fails = 0

    print('=' * 66)
    print('【硬伤】只列不可能是设计意图的形态')
    print('=' * 66)
    any_hard = False
    for r in recs:
        if r.get('err'):
            print(f"  ❌ [{r['id']}] 渲染抛异常: {r['err']}")
            any_hard = True
            fails += 1
            continue
        seen, shown = set(), []
        for h in r.get('hard', []):
            k = (h['t'], h['el'])
            if k in seen:
                continue
            seen.add(k)
            shown.append(h)
        if shown:
            any_hard = True
            fails += len(shown)
            print(f"  [{r['id']}] {r.get('status','')}")
            for h in shown:
                print(f"      ⚠ {h['t']}: 「{h['el']}」 {h['d']}")
    for md in res.get('modals', []):
        if md.get('err'):
            print(f"  ❌ 弹窗 {md['name']}: {md['err']}  ← 先确认是不是入参没喂对，不一定是组件问题")
            any_hard = True
        elif md.get('hard'):
            any_hard = True
            fails += len(md['hard'])
            print(f"  [弹窗 {md['name']}]")
            for h in md['hard'][:6]:
                print(f"      ⚠ {h['t']}: 「{h['el']}」 {h['d']}")
    if not any_hard:
        print('  ✅ 无硬伤')

    if recs:
        print()
        print('=' * 66)
        print('【形态证据】不判对错，摊平给人看——真正的判断需要业务上下文')
        print('=' * 66)

        # 操作 × 状态：这张表是本脚本最核心的产出。
        # 代码里只是一行 {cond && <Button>}，条件展开后的真实分布读代码算不出来。
        acts = []
        for r in recs:
            for a in r.get('actions', []):
                if a['label'] not in acts:
                    acts.append(a['label'])
        if acts:
            print('\n── 操作按钮 × 单据状态 ' + '─' * 34)
            n = len(recs)
            for lb in acts:
                hit = [r for r in recs if any(a['label'] == lb for a in r.get('actions', []))]
                from collections import Counter
                st = Counter(r.get('status', '?') for r in hit)
                dis = sum(1 for r in hit if any(a['label'] == lb and a['dis'] for a in r.get('actions', [])))
                mark = ''
                if len(hit) == n:
                    mark = '  (全单可见)'
                tail = f' · {dis} 单为禁用态' if dis else ''
                print(f"  {lb:<16} {len(hit):>2}/{n} ← {dict(st)}{tail}{mark}")
            print('  ↑ 核对方法：把每个操作的状态集合，和 PRD 状态机里该操作的开放状态逐一对照。')
            print('    对不上就是实现与设计不符——这类问题静态检查发现不了。')

        mods = []
        for r in recs:
            for m in r.get('modules', []):
                if m['name'] not in mods:
                    mods.append(m['name'])
        if mods:
            print('\n── 模块 × 单据 ' + '─' * 42)
            for name in mods:
                present = [r for r in recs if any(x['name'] == name for x in r.get('modules', []))]
                tag = '' if len(present) == len(recs) else '  ← 仅部分单出现，确认是否符合预期'
                print(f"  {name:<26} {len(present):>2}/{len(recs)}{tag}")

        hs = sorted([(r['id'], r.get('height', 0)) for r in recs if not r.get('err')], key=lambda x: x[1])
        if hs:
            print('\n── 页面高度分布 ' + '─' * 41)
            print(f"  最矮 3 单: {hs[:3]}")
            print(f"  最高 3 单: {hs[-3:]}")
            if hs[0][1] and hs[-1][1] / max(hs[0][1], 1) > 2.5:
                print('  ⚠ 最高/最矮相差 2.5 倍以上，确认矮的那几单是不是模块没渲染出来')

    if res.get('modals'):
        print('\n── 弹窗可达性 ' + '─' * 43)
        for md in res['modals']:
            if md.get('err'):
                continue
            items = md.get('items', [])
            dis = [x for x in items if x['dis']]
            zero = [x for x in items if x['w'] == 0 or x['h'] == 0]
            line = f"  {md['name']:<22} 可交互 {len(items):>2}"
            if dis:
                line += f" · 禁用 {len(dis)}（{', '.join(x['label'][:8] for x in dis[:3])}）"
            if zero:
                line += f" · ⚠ 零尺寸 {len(zero)}"
            print(line)
        print('  ↑ 禁用不等于缺陷：确认每个禁用态都有对应的业务理由和 helper 文案。')

    if show_tree:
        for r in recs:
            if r.get('tree'):
                print('\n' + '=' * 66)
                print(f"【元素树】{r['id']} {r.get('status','')}")
                print('=' * 66)
                for ln in r['tree']:
                    print('  ' + ln)

    print()
    return fails


def main():
    ap = argparse.ArgumentParser(description='渲染仿真：真实数据 × 真实组件 × 真实布局引擎')
    ap.add_argument('html')
    ap.add_argument('--component', help='详情页组件名（默认自动识别）')
    ap.add_argument('--data', help='单据数组名（默认自动识别）')
    ap.add_argument('--limit', type=int, default=999)
    ap.add_argument('--tree', type=int, default=None, metavar='N', help='额外打印第 N 单的元素树')
    ap.add_argument('--no-modal', action='store_true')
    ap.add_argument('--shot', type=int, default=None, metavar='N',
                    help='把第 N 单渲染出来截成整页 PNG（人看形态用，元素树是给 agent 看的）')
    ap.add_argument('--shot-out', default=None, help='截图输出路径，默认 ./sim-shot-N.png')
    ap.add_argument('--json', help='结构化结果写入该文件')
    a = ap.parse_args()

    if not os.path.exists(a.html):
        print('❌ 找不到文件:', a.html)
        sys.exit(3)
    src = open(a.html, encoding='utf-8').read()
    details, arrays, modals = discover(src)

    comp = a.component or (details[0] if details else None)
    cands = [a.data] if a.data else rank_candidates(src, comp, arrays)[:6]
    data = cands[0] if cands else None
    if not comp:
        print('ℹ️  没找到详情页组件（名字含 Detail 且入参有 record/row）。')
        print('   有些模块的详情是函数式渲染或直接内联，本脚本跳过详情页部分。')
        if not modals:
            print('   也没有 Modal 组件，无事可做。')
            sys.exit(0)
        data = data or '[]'
    if not data:
        print('❌ 没找到单据数组（顶层 const 大写数组、条数 ≥3）。用 --data 指定。')
        sys.exit(3)

    if a.no_modal:
        modals = []
    print(f'▶ 产物: {os.path.basename(a.html)}')
    print(f'▶ 详情页组件: {comp or "(无)"} · 候选数组: {", ".join(cands[:3])}'
          + (f' · 弹窗 {len(modals)} 个' if modals else ''))
    if details and len(details) > 1:
        print(f'  (还识别到其他详情页组件: {", ".join(details[1:])}，用 --component 切换)')
    print()

    shot_out = None
    if a.shot is not None:
        shot_out = os.path.abspath(a.shot_out or f'sim-shot-{a.shot}.png')
    res = run(a.html, comp, cands, modals, a.limit, a.tree, shot=a.shot, shot_out=shot_out)
    if res.get('dataName'):
        print(f'▶ 试渲染选中数组: {res["dataName"]}\n')
    fails = report(res, a.tree is not None)

    if shot_out and os.path.exists(shot_out):
        recs = res.get('records', [])
        rid = recs[0]['id'] if recs else '?'
        print(f'截图已输出: {shot_out}  (单据 {rid}, 高 {recs[0].get("shotHeight",0) if recs else 0}px)')
    if a.json:
        json.dump(res, open(a.json, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
        print(f'结构化结果已写入 {a.json}')

    # 退出码：有硬伤 = 2，便于接进 check.sh；形态证据不影响退出码
    sys.exit(2 if fails else 0)


if __name__ == '__main__':
    main()
