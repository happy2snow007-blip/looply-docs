#!/usr/bin/env python3
"""
A.13 精确判定:IIFE 块内是否含 Hook 调用。

输入:产物 HTML 文件路径
输出:违规 IIFE 数量(stdout 一个整数)

判定逻辑:
- 真正的 IIFE 特征:`((` 前不是字母(排除 useMemo(() 等 Hook 回调)
- 从 IIFE 起点行往下扫描,直到配对的 `})()` 收尾
- 在块内找 Hook 调用(useState/useMemo/useEffect/useRef/useCallback/useContext)
"""
import re
import sys

HOOKS = re.compile(r'\b(useState|useMemo|useEffect|useRef|useCallback|useContext)\s*\(')
IIFE_START = re.compile(r'[^a-zA-Z_]\(\(\)')
IIFE_END = re.compile(r'^\s*\}\)\(\)')


def count_hook_in_iife(path):
    with open(path, encoding='utf-8') as f:
        lines = f.readlines()

    violations = []
    n = len(lines)
    i = 0
    while i < n:
        if IIFE_START.search(lines[i]):
            # 找配对的 })() 收尾,最多向下扫描 100 行
            end = min(i + 100, n)
            for j in range(i + 1, end):
                if IIFE_END.search(lines[j]):
                    block = ''.join(lines[i:j + 1])
                    if HOOKS.search(block):
                        violations.append((i + 1, lines[i].strip()[:80]))
                    i = j
                    break
            else:
                # 没找到收尾(可能是断言失败的 IIFE)
                pass
        i += 1
    return violations


def main():
    if len(sys.argv) < 2:
        print("用法: check_iife_hook.py <产物.html> [--verbose]", file=sys.stderr)
        sys.exit(2)
    path = sys.argv[1]
    verbose = '--verbose' in sys.argv
    violations = count_hook_in_iife(path)
    print(len(violations))
    if verbose and violations:
        print("\n违规 IIFE 起点行:", file=sys.stderr)
        for line, text in violations:
            print(f"  L{line}: {text}", file=sys.stderr)


if __name__ == '__main__':
    main()
