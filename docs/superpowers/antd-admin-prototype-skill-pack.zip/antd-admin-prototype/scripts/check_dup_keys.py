#!/usr/bin/env python3
"""A.19 — JS 对象字面量重复键检测。

失效场景(来自营销活动原型实测):同一个 mock 数据对象里把 `cause` 写了两遍,
JS 静默保留**最后一个**,前一个的值凭空消失。表现是某行数据"莫名其妙不对"
或组件拿不到字段直接白屏,而 Babel 不报错、check.sh 原 9 项也查不出来
——只能靠人肉比对数据才发现。本脚本把它变成可自动判定的检查项。

用法:
    python3 check_dup_keys.py <产物.html>            # 只输出重复键个数
    python3 check_dup_keys.py <产物.html> --verbose  # 逐条列出 键 / 行号

退出码:0 = 无重复 / 1 = 发现重复
"""
import re
import sys

KEY_RE = re.compile(r"""\s*(?:(['"])(?P<q>[^'"]*)\1|(?P<id>[A-Za-z_$][\w$]*))\s*:""")


def scan(src):
    """返回 [(key, [行号...])],只报同一对象字面量内重复的键。"""
    dups = []
    stack = []          # 每层: {'type': 'obj'|'arr'|'paren', 'keys': {k: [line]}}
    expect_key = False  # 当前是否处于"属性名位置"(刚过 { 或 ,)
    i, n, line = 0, len(src), 1

    while i < n:
        c = src[i]

        # ── 注释 ──
        if c == '/' and i + 1 < n:
            if src[i + 1] == '/':
                j = src.find('\n', i)
                i = n if j < 0 else j
                continue
            if src[i + 1] == '*':
                j = src.find('*/', i + 2)
                j = n if j < 0 else j + 2
                line += src.count('\n', i, j)
                i = j
                continue

        # ── 字符串 / 模板串(整体跳过,内部的 { } : 不参与结构判定)──
        if c in '"\'`':
            quote, j = c, i + 1
            while j < n:
                if src[j] == '\\':
                    j += 2
                    continue
                if src[j] == quote:
                    break
                j += 1
            line += src.count('\n', i, j)
            i = j + 1
            expect_key = False
            continue

        if c == '\n':
            line += 1
            i += 1
            continue

        # ── 结构符 ──
        if c == '{':
            stack.append({'type': 'obj', 'keys': {}})
            expect_key = True
            i += 1
            continue
        if c in '([':
            stack.append({'type': 'arr' if c == '[' else 'paren', 'keys': {}})
            expect_key = False
            i += 1
            continue
        if c in '}])':
            if stack:
                frame = stack.pop()
                if frame['type'] == 'obj':
                    for k, lines in frame['keys'].items():
                        if len(lines) > 1:
                            dups.append((k, lines))
            expect_key = False
            i += 1
            continue
        if c == ',':
            expect_key = bool(stack) and stack[-1]['type'] == 'obj'
            i += 1
            continue
        if c.isspace():
            i += 1
            continue

        # ── 属性名位置:尝试匹配 `key:` ──
        if expect_key and stack and stack[-1]['type'] == 'obj':
            m = KEY_RE.match(src, i)
            if m:
                key = m.group('q') if m.group('q') is not None else m.group('id')
                stack[-1]['keys'].setdefault(key, []).append(line)
                line += src.count('\n', i, m.end())
                i = m.end()
                expect_key = False
                continue

        expect_key = False
        i += 1

    return dups


def main():
    if len(sys.argv) < 2:
        print('用法: check_dup_keys.py <产物.html> [--verbose]', file=sys.stderr)
        return 2
    try:
        with open(sys.argv[1], encoding='utf-8') as f:
            src = f.read()
    except OSError as e:
        print(f'读取失败: {e}', file=sys.stderr)
        return 2

    dups = scan(src)
    if '--verbose' in sys.argv:
        for key, lines in dups:
            print(f"  重复键 `{key}` — 行 {', '.join(map(str, lines))}(JS 只保留最后一个)")
    else:
        print(len(dups))
    return 1 if dups else 0


if __name__ == '__main__':
    sys.exit(main())
