#!/usr/bin/env python3
"""
check_ui_lang.py — A.21 同一页面内 UI 语言一致性初筛

用法:
    python3 check_ui_lang.py 产物.html [--verbose]

⚠️ 本脚本只数种类、不懂场景。
   数出多种 ≠ 不合格 —— 弹窗窄、详情页宽本来就该不同。
   判据是「每种是否有明确写下来的适用场景」。
   所以命中项要逐条去代码注释 / rules.md A.21 里找它的场景说明，找不到的才是问题。

退出码: 0 = 无硬性失败; 1 = 有硬性失败(仅硬编码宽度这一项是硬失败)
"""
import re
import sys
from collections import defaultdict


def strip_comments(src: str) -> str:
    """剥掉 /* */ 与 {/* */}，注释里的 class 名不算实际使用"""
    src = re.sub(r'\{\s*/\*[\s\S]*?\*/\s*\}', '', src)
    src = re.sub(r'/\*[\s\S]*?\*/', '', src)
    return src


def collect(src: str, pattern: str) -> dict:
    """返回 {类名: 出现次数}"""
    out = defaultdict(int)
    for m in re.finditer(pattern, src):
        out[m.group(1)] += 1
    return dict(out)


def main() -> int:
    if len(sys.argv) < 2:
        print(__doc__)
        return 0
    path = sys.argv[1]
    verbose = '--verbose' in sys.argv

    with open(path, encoding='utf-8') as f:
        raw = f.read()
    src = strip_comments(raw)

    print(f"A.21 UI 语言一致性初筛 — {path.split('/')[-1]}\n")

    # ---- 1. 模块标题（应只有一种） ----
    titles = collect(src, r'className="(lp-(?:section|title|heading)[\w-]*)"')
    subtitles = collect(src, r'className="(lp-(?:subtitle|zone-title|oplog-title|sub-title)[\w-]*)"')

    # ---- 2. 容器 ----
    # 排除两类【标题/标签】—— 它们不是容器,混进来会让容器种类虚高、每次都要人工解释一句:
    #   · lp-subtitle      → 已在「子区标题」里计过一次
    #   · lp-*-label/title → 卡内分组标签(如 lp-card-label),是标签不是盒子
    boxes = collect(
        src,
        r'className="(lp-(?:sub(?!title)|block|card|panel|box|preview|zone)'
        r'(?:(?!-label|-title)[\w-])*)"',
    )

    # ---- 3. 空态 ----
    empties = collect(src, r'className="(lp-(?:blank|nodata|empty|none)[\w-]*)"')

    # ---- 4. 标签宽度 ----
    consts = dict(re.findall(r'const\s+(\w*LABEL_W\w*)\s*=\s*(\d+)', src))
    hardcoded = re.findall(r'labelWidth\s*=\s*\{?\s*(\d+)\s*\}?', src)

    def show(name, d, note=''):
        n = len(d)
        flag = '·' if n <= 1 else '⚠'
        print(f"  {flag} {name:<14} {n} 种 {note}")
        if verbose and d:
            for k, v in sorted(d.items(), key=lambda x: -x[1]):
                print(f"        {k:<24} ×{v}")

    # 同一套容器语言的多个【部件】合并成 1 种 —— lp-card / -head / -part 是一张卡的
    # 三个部件，不是三种容器语言。不合并会让种类虚高，每次都要人工解释一句。
    def merge_parts(d: dict) -> dict:
        out = defaultdict(int)
        for k, v in d.items():
            root = re.match(r'(lp-[a-z]+)', k)
            out[root.group(1) if root else k] += v
        return dict(out)

    boxes = merge_parts(boxes)

    show('模块标题', titles, '（A.21-1：全页应唯一）')
    show('子区标题', subtitles, '（A.21-3：卡外用 .lp-subtitle，卡内用 12px 灰字标签）')
    show('容器', boxes, '（A.21-2：只读字段不进容器；卡的用法见「什么时候引入边框卡」）')
    show('空态', empties, '（A.21-6：字段级 — / 模块子区级一行灰字；栏级整列不出）')

    print(f"\n  · 标签宽常量      {len(consts)} 个", end='')
    if consts:
        print('  ' + ', '.join(f'{k}={v}' for k, v in sorted(consts.items(), key=lambda x: int(x[1]))))
    else:
        print()

    fail = 0
    if hardcoded:
        uniq = sorted(set(hardcoded), key=int)
        print(f"\n  ❌ 硬编码 labelWidth {len(hardcoded)} 处，取值 {uniq}")
        print("     A.21-4：标签宽必须走场景常量。写死数字就是在制造新的一档。")
        fail = 1

    # ---- 提示 ----
    multi = [n for n, d in
             (('模块标题', titles), ('子区标题', subtitles), ('容器', boxes), ('空态', empties))
             if len(d) > 1]
    if multi:
        print(f"\n  ⚠ 以下出现多种写法：{'、'.join(multi)}")
        print("    逐项确认：每一种是否在代码注释或 rules.md A.21 里写明了适用场景？")
        print("    写明了 → 合格；没写明 → 不合格，要么统一、要么补场景说明。")
    if not multi and not hardcoded:
        print("\n  ✅ 未发现多写法与硬编码宽度")

    print(f"\n{'❌ 有硬性失败' if fail else '完成（多写法项需人工判读场景）'}")
    return fail


if __name__ == '__main__':
    sys.exit(main())
