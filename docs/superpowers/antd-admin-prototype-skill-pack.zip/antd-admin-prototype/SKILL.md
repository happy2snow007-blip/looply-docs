---
name: antd-admin-prototype
description: >
  Use when generating or iterating a Looply backend admin prototype based on antd 6.4.x + React 18,
  for product managers working through the "业务设计 → ER 图 → 原型 → PRD" workflow.
  典型触发场景(中文):"做后台原型"、"生成 antd 后台原型"、"迭代后台原型"、
  "加一个 XX 模块"、"加字段 / 删字段 / 拆字段"、"改一下表单"、"在这个原型上加菜单"、
  "ER 改了同步原型"、"看 ER 影响哪些页面"、"按业务设计画一版原型"。
  Make sure to use this skill whenever a product manager mentions ER 图、业务实体、字段清单、
  后台模块设计, or asks to add/remove/iterate features on an antd-based admin UI —
  **即便他们没明说"做原型"三个字**。
---

# antd-admin-prototype — Looply 后台原型生成 & 迭代

## 何时使用

产品同学进入"原型产出 + 反复迭代"阶段(详见产品工作流):
- **从零生成**:已有业务设计 / ER 图 / 调研结论,需要一版可点的 antd 后台原型
- **迭代既有原型**:已有 antd 版原型,需要新增/删除菜单、页面、字段、弹窗
- **配合 ER 演进**:ER 图改了字段,要在原型里同步;或原型改了字段,要回头同步 ER

典型触发:
- "给我做一版 XX 管理后台原型"
- "在这个原型里加一个 XX 模块"
- "把 XX 字段删掉,菜单也对应清掉"
- "我刚改了 ER,看看哪些原型页面要跟着改"

## 不要使用本 skill 的情况

- 已有 looply 老 HTML 原型(`admin-prototype` skill 产物),要转译成 antd 版 → 用 `antd-transform` skill
- 真实业务后台开发(基于 React + antd 写生产代码) → 用 `antd` / `ant-design` 官方 skill
- C 端 / APP UI / 营销页 → 不在本 skill 范围

## 与 antd-transform 的关系

| | antd-admin-prototype(本 skill) | antd-transform |
|---|---|---|
| 输入 | 业务设计 + ER 图(无现成原型) | 已有 looply HTML 原型 + PRD |
| 任务 | **0→1 生成** + **N→N+1 迭代** | **1:1 转译**(旧 HTML → antd HTML) |
| 谁用 | 产品同学 | 产品同学(转译既有原型) / 开发同学 |
| 视觉规范 | 共用 `references/style-spec/`(本目录) | 引用本 skill 的 references/style-spec/ |

**两个 skill 的视觉规范共用同一份**(本 skill 的 `references/style-spec/`),长期看 antd-transform 会反向引用本 skill;前期为了独立迭代,两边各持一份副本。

## 产品工作流定位

产品同学完整工作流 5 阶段:

```
[1. 业务调研]   AI 调研同类业务 → 调研报告 + 设计建议
       ↓
[2. 业务设计]   产品调整设计 → 必要时输出架构图 → 确认
       ↓
[3. 首版产出]   ER 图 + 原型 并行产出 ← 本 skill 核心场景
       ↓
[4. 反复迭代]   ER ↔ 原型 双向同步 ← 本 skill 核心场景
       ↓
[5. PRD 反推]   基于稳定原型反向输出 PRD
```

**本 skill 覆盖阶段 3+4**。阶段 1/2/5 用对话 + 通用 AI 能力即可,本 skill 不强制接管。

## 必读规范(Layer 0 — `references/style-spec/`)

进入任何原型生成 / 修改前,**按顺序读完**:

1. `references/style-spec/SPEC.md` — 总览 / 版本锁定 / 元决策 / 自主优化边界
2. `references/style-spec/rules.md` — 硬性规则(A.0~A.17)/ 超范围处理 / 列宽决策 / 自检流程
3. `references/style-spec/theme.md` — looplyTheme 完整代码 + Logo 占位约定(直接整段复用到产物)
4. `references/style-spec/components.md` — 28 组件 + 业务组件 + JSX 模板 + 字段术语映射

**不允许跳过 rules.md**。这是和 antd-transform 完全一样的视觉规范。

## 输入约定

产品同学带来的输入,**按优先级**:

| 输入 | 必需性 | 用途 |
|---|---|---|
| 业务背景(对话/文档) | ✅ 至少要一句话说清做什么模块 | 决定菜单结构和核心实体 |
| ER 图 / 数据模型 | ⭐ 强烈推荐 | 决定字段、关联、列表列 |
| 同类业务调研结论 | 可选 | 影响布局选型(看板 / 列表 / 主从) |
| 既有原型(迭代场景) | 迭代时必需 | 在原文件上 Edit,不重写 |
| 产品架构图 | 可选 | 复杂模块的整体导航 |

**输入不足时**:不要脑补,先**问产品同学**:
- 模块名 / 实体名 / 主要操作(增删改查 vs 审批 vs 配置)
- 关键字段清单(至少列表页要哪些列)
- 是否有状态机 / 多角色 / 权限差异

## 输出约定

每次生成或迭代,产出到 `outputs/`:

| 文件 | 内容 |
|---|---|
| `looply-[模块名]-antd-原型-v[N].html` | antd 单 HTML 原型,可双击打开 |
| `looply-[模块名]-antd-原型-v[N]-report.md` | 自检报告 + ER 增量(详见 `references/self-check.md`) |

**版本号约定**:
- v1 = 首版
- v2/v3/... = 迭代版(同模块再生成时递增)
- 不强制保留中间版本,产品同学要历史用 git 即可

## 工作流程

### A. 首版生成(0→1)

```
[1. 对齐意图]
       ↓
   和产品同学确认 { 模块名, 实体列表, 核心字段, 主要操作 }
   如果产品没说清,问到能写出菜单结构为止

[2. 读 ER / 业务设计]
       ↓
   { 实体 → 表, 关联 → 主从页, 字段 → 列表列/表单项 }

[3. 设计信息架构]
       ↓
   - 菜单结构(一/二/三级)
   - 页面清单(每个实体 = 列表页 + 详情页 + [新建/编辑] + [向导])
   - 弹窗清单(确认 / 表单 / 上传 / 危险操作)

[4. 输入预估]
       ↓
   预估产物体量 → 触发分批阈值(> 25 页 / > 6 一级菜单 / > 200KB)
   分批策略 100% 复用 antd-transform 的 references/style-spec/rules.md F 段

[5. 生成 antd 单 HTML]
       ↓
   按 Layer 0 模板 + ER 字段映射,产出 JSX

[6. 自检 + 写报告]
       ↓
   bash scripts/check.sh 产物.html
   按 references/self-check.md 写 6 段报告
```

### B. 迭代演进(N→N+1)

```
[1. 明确变更类型]
       ↓
   增菜单 / 删菜单 / 改字段 / 加页面 / 删页面 / 改弹窗 / 改 ER 同步

[2. 影响面分析]
       ↓
   - 增 → 找插入位置(参考 § 菜单结构修改规则)
   - 删 → 走 § 功能删除标准流程(4 阶段)
   - 改字段 → grep 字段名,改所有相关列表列 / 表单项 / 弹窗
   - ER 改 → 找出哪些页面引用了被改字段,列清单给产品同学确认

[3. 在原文件上 Edit(不要重写)]
       ↓
   保持版本号递增,旧版本由 git 保留

[4. 自检 + 写报告]
       ↓
   bash scripts/check.sh 产物.html
   ER 增量段:列出本次改了哪些字段,提示产品同学回头改 ER 图
```

## 示例对话

下面是产品同学最常见的三类请求,以及你应该如何响应。把它当成节奏模板而不是死板脚本 —
关键是抓住"先问清楚 → 再产出 → 再写报告"的节奏。每个示例的反问清单不是必须照搬,而是
提醒你哪些维度容易缺失。

### 示例 1:从零生成(0→1)

**产品**:
> "给我做一版优惠券管理后台原型,优惠券有名称、面额、有效期、使用次数,我希望有列表 + 新建 + 详情。"

**你应该这样响应**:

1. **先反问澄清**(关键业务规则不能凭空猜):
   - 优惠券类型(满减 / 折扣 / 直减)要不要在列表上区分?
   - 状态机怎么定?(草稿 / 待生效 / 生效中 / 已结束 / 已下架)
   - "使用次数"是单券总数还是每人限领?
   - 是否需要"批量发放"操作入口?批量发放是另开一个页面还是弹窗?

2. **画菜单结构 + 页面清单**给产品确认(不要直接开写):
   - 菜单:营销 → 优惠券 → 列表
   - 页面:列表(KPI 4 项 + Toolbar 搜索/筛选 + 4 种空态)/ 新建(分区表单)/ 详情(基本信息 + 操作日志)
   - 弹窗:删除确认、批量发放确认

3. **按 Layer 0 模板 + § 页面结构模板生成单 HTML**,产出 `outputs/looply-优惠券管理-antd-原型-v1.html`

4. **跑 `scripts/check.sh` + 写 6 段报告**;报告里的 ER 增量段建议产品同学新增表 `coupons` 及字段清单(名称 / 类型 / 面额 / 状态 / 有效期 / ...),并标注状态机定义还要补全。

### 示例 2:迭代演进(N→N+1,加字段)

**产品**:
> "给优惠券加一个'适用商品分类'字段,可多选,然后列表上加一列展示。"

**你应该这样响应**:

1. **反问澄清**(字段语义不明):
   - 分类来源是固定枚举还是从已有商品类目表带过来?
   - 是否支持"全部分类"作为兜底选项?
   - 列表展示是"标签云"还是"X 个分类"加 tooltip 看详情?

2. **影响面分析**(grep 一下,列清单):
   - 新建表单:加 `<Select mode="multiple">`(或者级联选择 Cascader,看分类是否有层级)
   - 编辑表单:同上,默认值带回当前选中
   - 列表 Table:加新列(用 `<Tag>` 展示多选,超过 3 个用 +N tooltip)
   - 筛选区:可能要加"按分类筛"的下拉

3. **在原文件上 Edit**(不要重写整个 HTML),版本号 v1 → v2

4. **ER 增量段**列清:
   - 新关系 `coupons.applicable_categories`(关联表 `coupon_category_map` 还是 JSON 字段?让产品决定)
   - 提示需要数据迁移(老优惠券默认"全部分类")

### 示例 3:ER 改了反向同步原型

**产品**:
> "ER 把 `face_value`(面额)拆成了 `discount_type` + `discount_value`,看哪些原型页面要跟着改。"

**你应该这样响应**:

1. **不要立刻动手改原型** — 先做影响分析:
   - grep 原型文件里 `面额` / `face_value` 出现的位置(列表列 / 筛选项 / 新建表单 / 详情展示 / 批量操作弹窗 / KPI...)
   - 列清单给产品同学

2. **反问产品布局选择**(单字段 → 双字段的 UI 设计不唯一):
   - 新建表单:下拉选类型(满减 / 折扣 / 直减)+ 数字输入,还是 2 个并列字段?
   - 列表展示:合并展示"满 100 减 50"/"8 折"还是拆两列?
   - 筛选:要不要按"类型 + 金额区间"组合筛选?

3. 产品决定后,按 § 工作流程 B 走迭代流程,Edit 原文件 → v2 → 报告。

## 技术栈(硬性)

完全沿用 antd-transform 的技术栈,详见 `references/style-spec/theme.md` A 节:

- antd **6.4.x** + React **18** UMD via CDN(jsdelivr 锁定)
- Babel Standalone in-browser JSX
- 单 HTML 文件交付,可双击在浏览器打开
- looplyTheme + ConfigProvider,**禁止覆盖 .ant-* 全局 class**
- 自定义业务组件用 `.lp-*` 前缀

## 布局框架总览

```
┌─ Header (64px, white, border-bottom #E5E7EB) ────────────────────┐
│  Logo(base64) │ divider │ 系统标签 ................ Breadcrumb    │
├───────────┬──────────────────────────────────────────────────────┤
│ Sider     │  Content (padding: 28px, bg: #F9FAFB)               │
│ 220px     │  Card { padding: 24px, radius: 8px, shadow }        │
│ white     │                                                      │
│ overflow  │                                                      │
└───────────┴──────────────────────────────────────────────────────┘
```

对应 antd 组件：`Layout` > `Layout.Header` + `Layout` > `Layout.Sider` + `Layout.Content`，详见 components.md A.1。

## 交互规范

| 场景 | 时长 | 说明 |
|---|---|---|
| 菜单展开/折叠 | `.15s` | antd Menu 默认 |
| 箭头旋转 | `.2s` | 折叠指示器 |
| 面板折叠 | `.3s` | `cubic-bezier(.4,0,.2,1)` |

- **减弱动效**：全局 CSS 必须包含 `@media(prefers-reduced-motion:reduce){ *{transition:none!important;animation:none!important} }`
- **键盘焦点**：`:focus-visible` 使用紫色 inset shadow（`inset 0 0 0 2px rgba(124,58,237,.4)`）
- **触摸目标最小高度**：一级菜单 44px / 二级菜单 40px / 三级菜单 36px

## 页面结构模板

5 种基本页面类型(对应 antd-transform components.md C 段的 ListPage / FormPage 高阶组件):

### 1. 列表页(ListPage)
- KPI 4 列(可选)
- Toolbar(搜索 + 筛选 + 查询)
- Table(操作列硬性用 `<Button size="small">`)
- **操作列按钮数量规则**：
  - ≤4 个按钮：直接平铺展示，用 `<Space size={6}>` 排列
  - >4 个按钮：保留最常用的 2-3 个直接展示，其余收进 `<Dropdown>` 下拉菜单（用 `<EllipsisOutlined>` 图标触发）
  - 如果"更多"下拉菜单里只有 1 个操作，则不收起，全部直接展示
  - 危险操作（如注销、删除）在下拉菜单中用 `danger:true` 标红
- 紧凑分页(spec 方案 B,见 components.md B.9)
- 4 种空态切换(零数据 / 无匹配 / 异常 / 正常)演示按钮

### 2. 新建 / 编辑页(FormPage)
- 分区(`.lp-section` 黑色标题 + 底线)
- 表单网格(Label 96px,详见 theme.md `.lp-form-row`)
- 操作栏(右对齐:取消 + 保存)

### 3. 向导页(Steps)
- 顶部 Steps 条
- 当前步骤的表单区
- 底部导航(上一步 / 下一步 / 完成)

### 4. 详情 / 分栏页
- 左:Tree / List 导航
- 右:Tabs + 详细信息

### 5. 主从页(列表 + 详情同屏)
- 左侧 Table(主)
- 右侧 Drawer / 内嵌 Panel(从)

**禁止**自己发明第六种布局。如果业务硬要,先问产品同学是否能映射到上面 5 种之一。

## 菜单结构

完全沿用 antd-transform components.md A.2 节,核心约束:

- **一/二/三级菜单都用 `<Menu items={...}>` 原生嵌套**,不要手写 DOM
- 二级菜单 `icon` **必须**用 `@ant-design/icons` 组件,**禁止 Emoji / Unicode 字面量**(rules.md A.4.1)
- 激活态自动由 antd 处理,**不要手写**左 3px 边框 / 渐变背景

**菜单层级插入规则**(迭代场景硬性):
- 新增独立一级菜单 → 插到 items 数组顶层
- 新增二级菜单 → 找到对应父菜单的 children 数组追加
- **禁止**插到错误层级(变成同级菜单 / 误入折叠组)
- 改完必须浏览器打开点击验证

## 弹窗规范

完全沿用 antd-transform rules.md A.3:

- `<Modal closable={false} maskClosable={false} centered={true}>`
- 关闭/取消按钮**只在底部 footer**,标题区不放
- 表单类弹窗:`取消` + `确定/保存`(主按钮)
- 信息/上传类:`关闭`
- 危险操作类:`取消` + `确认XX`(danger)
- 编辑含删除:左侧 `删除`(danger 边框)+ 右侧 `取消` + `保存`

弹窗内表单也走 `.lp-form-row`(Label 96px),不要自己造布局类。

## 4 种空态

完全沿用 components.md B.7:

- **零数据态**:首次使用,toolbar 隐藏,主按钮 CTA
- **无匹配态**:筛选无结果,toolbar 可见,默认按钮 CTA(清除筛选)
- **异常态**:网络/服务异常,主按钮 CTA(重试)
- **正常态**:有数据

**所有列表页必须 4 态齐全**,并提供切换按钮组方便产品同学评审。

## 操作日志

放置约定(沿用 admin-prototype 老 skill 的位置):

- **详情页**:放在详情信息后
- **编辑页**:放在表单 / 向导 nav 之后
- **列表页不放**(列表页本身是聚合视图)

表格列:操作时间 / 操作人 / 操作类型 / 操作内容。
数据示例至少 3-5 条,体现完整操作历史(创建 / 编辑 / 配置变更 / 状态切换)。

## 功能删除标准流程

删除某个功能模块时,必须走 4 阶段。这是 admin-prototype 老 skill 已经验证过的流程,直接复用并适配 antd 版。

### 阶段 1:分析
列出删除清单:
- `Menu items` 中的菜单项(by key)
- 受影响的页面组件(by 函数名 / state key)
- Table columns 引用的字段
- Form 的 Form.Item name 引用
- KPI / 筛选选项里的引用

### 阶段 2:备份
```bash
cp outputs/looply-XX-antd-原型-v2.html outputs/looply-XX-antd-原型-v2-backup.html
```

### 阶段 3:删除
**原则**:
- **结构完整性**:删完后 JSX 标签配对一致,Babel 能编译过
- **精确匹配**:Edit 时用足够上下文,避免误删同名引用
- **一次性整块**:复杂区块先 Read 完整结构再 Edit 整段替换,不要逐行删
- **JSX 删除操作结构完整性（硬性）**:
  1. 删除前先理解完整结构：读取该区块的完整 JSX 嵌套关系（从外层容器到内层组件）
  2. 删除时保持结构完整性：确保不破坏外层组件的闭合标签，保持同级元素缩进一致
  3. 删除后验证结构：重新 Read 修改区块，检查标签配对 + 缩进；浏览器打开确认无白屏
  4. 优先整块替换：对复杂嵌套，先 Read 完整区块 → 本地构建删除后结构 → 一次 Edit 替换，不逐行删
  - 反例：删除某个 Form.Item 时连带删除了外层 `<div>` 容器的闭合标签，导致后续表单项全部丢失

### 阶段 4:验证
- `bash scripts/check.sh outputs/产物.html` 全过
- 浏览器打开 → 逐菜单点击 → 确认页面正常 / 删除页面不再可达
- 抽查 2-3 个保留页面字段完整

## ER 交叉对比(原型出来后必做)

**三问走查**(逐页面):

1. **数据从哪张表查?** 多表关联 / 跨模块拉数据 / 计算字段都要列清
2. **用户操作写哪张表的哪个字段?** 字段在 ER 必须存在,类型匹配,状态机完整
3. **触发条件是什么?** GET / POST / 外部事件

**发现不一致时**:
- ER 缺表 / 缺字段 → 反馈产品同学补 ER
- 原型展示了不可能取到的数据 → 两选一:砍功能 / 调模块边界

**报告里输出 ER 增量段**,列清楚:
- 新增字段建议(名字 / 类型 / 默认值 / 校验)
- 字段重命名建议(旧名 → 新名)
- 删除字段建议
- 跨模块依赖建议

让产品同学拿这个清单回头改 ER 图。**本 skill 不自动改 ER**。

## 质量检查

交付前**必须**:

1. `bash scripts/check.sh outputs/产物.html` — 9 项静态合规(IIFE+Hook / JSX 引号 / Table rowKey / 菜单 icon / div+style / Modal 三件套 / CDN / Logo 完整性 / 全局 .ant-* 覆盖)
2. `python3 scripts/embed_logo.py outputs/产物.html` — 把 `{{LOGO_PLACEHOLDER}}` 替换成真实 base64
3. `references/self-check.md` 6 段报告全部填写
4. 浏览器实际打开,菜单 / 页面 / 弹窗 / 空态切换都点过

**手动视觉检查补充**(scripts/check.sh 不覆盖的项):
- [ ] 页面结构是否符合 5 种模板之一(ListPage / FormPage / WizardPage / DetailPage / 主从页)
- [ ] Header 系统标签是否已替换为当前模块名
- [ ] 键盘焦点态是否有 `:focus-visible` 样式
- [ ] `@media(prefers-reduced-motion)` 是否存在
- [ ] 所有颜色值是否来自 looplyTheme token(不允许出现规范外色值)

跳过任何一项 = 不算交付。

## 已知局限

- 富文本编辑器 / 图片裁剪 / 拖拽排序等 antd 无原生组件的需求 → 占位 + 报告标注
- 产物仅作"原型阶段交付物",**不可作为生产代码**
- 单次 Edit 输出仍受 sonnet ~32k token 限制,极端大模块按 antd-transform 的分批策略(见 references/style-spec/rules.md F 段)拆 PlaceholderModule

## 给 subagent 的执行约定

如果你是被 subagent 调用执行本 skill:

1. 读本 SKILL.md
2. 读 Layer 0 4 文件(SPEC → rules → theme → components)
3. 读 `references/prd-format.md`(产品如果给了 PRD,按此格式解析)
4. 读 `references/self-check.md`
5. 和用户/产品同学确认输入清单(模块名 / 实体 / 字段 / 操作)
6. **输入预估**:对照分批阈值,确定走单次还是分批
7. **按分批模式产出**(必要时:骨架 Write → 模块 Edit → 全局补充)
8. 每次 Edit 后即时跑 `bash scripts/check.sh`,关注 A.13 IIFE 项必为 0
9. 全量自检:`bash scripts/check.sh outputs/产物.html`
10. `python3 scripts/embed_logo.py outputs/产物.html`
11. 写 6 段报告

⚠ **不允许**单次 Write 全量大于 100KB 的产物 — 必走分批模式。

⚠ **不要**修改 `.claude/settings*.json`。沙箱拒绝 Bash 时,在报告标注"N/A — sandbox limited",继续任务,不装包。

## 版本

- v0.1 — 初版,参考 admin-prototype 老 skill 结构 + 沿用 antd-transform 视觉规范资产,覆盖产品工作流阶段 3+4
- v0.2 — 合并 admin-prototype 最新内容:布局框架总览图、交互规范（动效/焦点/触摸目标）、质量检查手动视觉项（5项）、JSX 删除结构完整性原则
- v0.3 计划 — 评估是否需要 ER 字段 → antd 组件的自动映射 references/
