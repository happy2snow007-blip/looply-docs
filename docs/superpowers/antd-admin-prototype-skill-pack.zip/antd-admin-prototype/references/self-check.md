# self-check.md — 自检报告模板

> 每个 antd 产物完成后,**强制**产出一份自检报告。
>
> 文件命名:`outputs/[原文件名]-antd-report.md`(与产物同名,后缀 `-report.md`)
>
> 报告读者:**产品(主)+ 工程师(次)**。前 3 段产品看,后 3 段工程师/AI 看。

## A. 自检流程(写报告前先做)

按 `style-spec/rules.md` F 段:

1. **硬性规则**(style-spec/rules.md A 段):操作列 Button / Tooltip / Modal / 菜单 icon / 4 空态 / Tag pill / 空值显示 / 默认排序 / 字号 → 任一违反就修
2. **列宽决策**(style-spec/rules.md D 段):表是少列还是宽列?对应规则是否应用?
3. **v3 标准**(style-spec/rules.md E 段):RangePicker / Input prefix / 按钮 icon / Upload.Dragger / Table.Summary 等 → 能用 antd 原生的是否都用了?
4. **无法还原项**(style-spec/rules.md B 段):已知清单内的项是否标注?新发现的是否补?
5. **超范围项**(style-spec/rules.md C 段):是否有占位 + 报告标注?
6. **PRD 对账**(prd-format.md F 段):字段缺失 / 多余 / 类型不一致 / 流程不一致 → 全部列出
7. **自主优化项**:本次转译有哪些主动改动?(每条记录)

**修复完所有可修项后**再写报告。**不要把"我没修的问题"作为报告内容糊弄**。

### A.1 手动视觉检查补充(scripts/check.sh 不覆盖,人工过)

check.sh 只覆盖工程合规(IIFE / 引号 / rowKey / CDN / Modal 等)。以下视觉 / 设计规范项**脚本测不出,必须人工对照**:

- [ ] 页面结构符合 5 种模板之一(ListPage / FormPage / WizardPage / DetailPage / 主从页)
- [ ] **`Select` 都显式给了 `width`**(只给 `maxWidth` 会被内容撑窄,多选态尤其明显;表单内多选用 `width:'100%'`+`maxWidth`,见 `components.md` Select)
- [ ] **操作列 ≤4 全平铺;>4 则前 3 个平铺、第 4 个起收进 Dropdown**(可见元素恒为 4,`style-spec/rules.md` A.1.1)
- [ ] **操作数随行状态变化时逐行判定**(同列出现"4 平铺"与"3+更多"两种形态属正常,不按列强行统一,A.1.1)
- [ ] Header 系统名已替换为当前模块名(不是占位"系统名")
- [ ] 键盘焦点态有 `:focus-visible` 品牌红色 inset shadow(`style-spec/theme.md` G)
- [ ] 全局含 `@media(prefers-reduced-motion)`(`style-spec/theme.md` G)
- [ ] 所有颜色值来自 looplyTheme token / `.lp-*`,无规范外裸色值

## B. 报告模板(完整 6 段 + 元信息)

```markdown
# {原文件名} — antd 转译自检报告

**生成时间**:{ISO 日期}
**Skill 版本**:antd-transform v0.1
**Layer 0 版本**:antd-style-spec(锁定 antd 6.4.x)
**输入**:
- 原型:`inputs/{原文件名}.html`(N 行)
- PRD:`inputs/{PRD 文件名}.md`(M 行)  ← 如有
- 其他:{ER 图等}

**输出**:`outputs/{原文件名}-antd.html`

**模型**:{Opus 4.7 / Sonnet 4.6 / ...}
**Token 用量(估)**:输入 X k / 输出 Y k

---

## 1. 字段来源(给产品)

| 模块 | 子页面 | 字段来源 | 备注 |
|---|---|---|---|
| 类目管理 | 类目列表 | 原型 + PRD 2.1.1 | 一致 |
| 类目管理 | 类目新建 | PRD 2.1.2(原型部分字段缺失) | 详见冲突段 |
| 品牌管理 | 品牌编辑 | 仅原型(PRD 2.2.3 未找到) | 自动按原型实现 |
| ... |

**统计**:
- 来自 PRD: N 项
- 来自原型: M 项
- 冲突已对齐: K 项
- 仅来自原型(PRD 未覆盖): J 项

---

## 2. 冲突项(给产品决策)

> 原型与 PRD 不一致的地方。**已按 PRD 实现**,如需调整请通知工程师。

| # | 位置 | 原型显示 | PRD 描述 | 已采用 | 建议 |
|---|---|---|---|---|---|
| 1 | `page-category-create` 字段 | 原型有"序号"列 | PRD 字段表无"序号" | **按 PRD**,移除"序号" | 如需保留请补 PRD |
| 2 | `page-product-create` 步骤数 | 原型 3 步 | PRD 5 步(操作流程章节) | **按 PRD**,实现 5 步 | — |
| ... |

---

## 3. PRD 待补 / 缺失项(给产品)

> 原型有但 PRD 没覆盖的字段、按钮、跳转,或 PRD 与 antd 实现需要的默认值缺失。

### 3.1 原型有 / PRD 未定义

| 模块 | 项目 | 当前处理 | 建议 |
|---|---|---|---|
| 品牌管理 | "导出 CSV" 按钮 | 已保留(按原型) | 补 PRD 说明业务行为 |
| 系列管理 | "诞生年份" 字段验证规则 | 仅留输入,无校验 | 补 PRD 校验:如 1900-2100 范围 |
| ... |

### 3.2 PRD 与 antd 实现需要的默认值

| 字段 | PRD 描述 | antd 需要的额外信息 |
|---|---|---|
| 状态字段(全模块) | "启用/停用" | 默认值是哪个? |
| ... |

---

## 4. antd 组件选型清单(给工程师/AI)

| 模块 | 子页面 | 主要组件 | 备注 |
|---|---|---|---|
| 类目管理 | 类目列表 | `<Tree>` + `titleRender`(自主优化,见 6 段) | 替代原型的扁平表格 |
| 类目管理 | 类目新建 | `<FormPage>` + `<Input>` + `<Select>` + `<InputNumber>` | 标准表单 |
| 商品管理 | 商品创建 | `<WizardPage>` (Steps 4 步) | 按 PRD |
| ... |

**业务组件用量**:
- `<Kpi>`: N 处
- `<StatusTag>`: M 处
- `<TipText>`: K 处
- `<EditableNumber>`: J 处
- `<CompactPagination>`: 全列表页
- `<OpLog>`: 全编辑页/详情页
- `<RadioCardGroup>`: K 处

---

## 5. 视觉妥协(给工程师/AI)

### 5.1 已知"无法原生还原"(沿用规范固定项)

| # | 项 | 现状 | 详见 |
|---|---|---|---|
| 1 | 菜单激活态 3px 品牌红色左边框 | 不实现 | `style-spec/rules.md` B.1 |
| 2 | 菜单激活态渐变背景 | 降级纯色 `#FCEEEF` | `style-spec/rules.md` B.2 |
| 3 | 表头 uppercase + letter-spacing | 不实现 | `style-spec/rules.md` B.3 |

### 5.2 本次新增的视觉妥协(如有)

| # | 位置 | 原型期望 | antd 限制 | 处理 |
|---|---|---|---|---|
| 1 | (示例)X 处 | Y 视觉 | antd 没 token | 用 style prop 注入近似值 |

### 5.3 超范围项(antd 无原生组件)

| 位置 | 需求 | 占位描述 | 建议集成方案 |
|---|---|---|---|
| `page-spu-edit` 描述字段 | 富文本编辑器 | 占位 div | `react-quill` 或 `@wangeditor/editor-for-react` |
| `page-product-edit` 主图 | 图片裁剪 | 占位 Upload | `react-image-crop` |

---

## 0. ⚠ 工程合规性自检(给 AI / 工程师 — 必填,不可省)

> 这一段放在最前,作为"质量门"。任何一项标红,产物**不合格**,先修后交付。

**第一步**:跑 `bash scripts/check.sh outputs/产物.html`,把输出整段贴下面。

```text
{贴 check.sh 完整输出}
```

**第二步**:看汇总行 `Pass: N / Warn: M / Fail: K`,按表填判定:

| Pass/Warn/Fail | 判定 | 处理 |
|---|---|---|
| Fail = 0 且 Warn = 0 | ✅ 合格,可交付 | — |
| Fail = 0 且 Warn > 0 | ⚠ 警告需人工 review | 在下面 § 0.1 列出每条 Warn 是否可接受 + 理由 |
| Fail > 0 | ❌ 不合格 | 修复后重跑 check.sh,直到 Fail = 0 |

### § 0.1 Warn 项 review(如有)

| Warn 项 | 触发位置(行号) | 判定 | 理由 |
|---|---|---|---|
| (示例)A.17 div+style 仿造 | `outputs/xxx.html:142` | 合法保留 | 是业务卡片布局 wrapper,不是 Tag/Alert 仿造 |

### § 0.2 未覆盖检查(非常态,需要时跑)

- A.14 .map 用 index 作 key: `grep -nE "\.map\(\(?[a-zA-Z_]+,\s*[a-zA-Z_]+\)?\s*=>\s*<[A-Z][a-zA-Z]*\s+key=\{[a-zA-Z_]+\}" 产物.html`
- A.1 `<a onClick=` 做操作列: `grep -nE "<a [^>]*onClick=" 产物.html`
- A.2 `<Tooltip>` 配 `InfoCircleOutlined`: `grep -B1 -A1 "<InfoCircleOutlined" 产物.html | grep -i tooltip`

详见 `style-spec/rules.md` F.2.1。

### § 0.3 已知未修问题(如有)

任一 Fail / Warn 修不掉(超时 / 模型限制 / 沙箱权限):**不允许藏起来**,显式列在这。

| # | 问题 | 阻塞原因 | 建议处理 |
|---|---|---|---|
| 1 | (示例)A.17 line 945 没改 Alert | 时间不够 + 不是阻断性 | 下一轮 PR 修 |

## 6. ⭐ 自主优化项(给产品 review)

> skill 在 PRD/原型基础上**主动改动**的地方。**不是 bug,是基于 antd / React 最佳实践的优化**,但**透明上报**让产品决定是否接受。

| # | 位置 | 原做法(原型/PRD) | 优化后 | 原因 | 影响范围 | 需 review? |
|---|---|---|---|---|---|---|
| 1 | 类目列表(`page-category-list`) | 扁平表格(原型 HTML + PRD 页面元素表) | antd `<Tree>` 树形展示 + titleRender 注入操作 | 类目本身是树结构,Tree 直观展示层级,功能与表格等价 | 仅视觉/交互,业务功能(新增/编辑/停用/搜索/筛选)完全保留 | 是 |
| 2 | (示例)汇率流水日期筛选 | 原型两个 DatePicker(开始 + 结束) | `<DatePicker.RangePicker>` | spec v3 标准,一个组件原生支持区间联动 | 仅交互优化,字段语义不变 | 否 |
| ... |

**回退方式**:如果产品不接受某项优化,请在反馈中指明 "#编号",工程师会在 v0.X 版本恢复原方案。

---

## 附录:Skill 输入 → 输出对照

### 输入
- 原型 page 总数:N
- PRD 子页面总数:M(其中 K 与原型 page 锚定一致)
- PRD 与原型不一致项:Y

### 输出
- antd 单 HTML:`outputs/{原文件名}-antd.html`({文件大小})
- 包含 page 总数:N
- 包含弹窗总数:Z
- 复用业务组件总数:W

### 验证建议
- 浏览器双击打开,首屏菜单切换是否流畅
- 重点查看自主优化项(本报告 6 段)是否可接受
- 重点查看冲突项(本报告 2 段)的取舍是否符合产品意图
- 列表页底部 4 个空态切换按钮,逐个点开看是否符合规范

```

## C. 报告写作要求

### C.1 准确,不糊弄

- 每个表格的数字必须准确(不要写"约 N 项")
- 每个引用的文件路径必须正确(可被点击 / 查找)
- 不允许出现"待补充"、"暂未完成"等占位文字 — 要么真补完,要么明确写在"PRD 待补"段落

### C.2 简短,不堆砌

- 每段只放该段读者关心的内容
- 表格优于段落
- 链接到 `style-spec/rules.md` 等规范文件,**不重复**规范内容

### C.3 透明,不掩盖

- 所有"我做了主动改动"必须在第 6 段列出
- 所有"我没遵守某规则"必须在对应段落标注原因
- 不允许"做了但没说"或"说了没做"

### C.4 可执行,不抽象

- "建议补 PRD" 要具体到字段名 / 章节号
- "建议集成 X 库" 要给具体库名
- "需要 review" 要明确产品决策点

## D. 报告交付方式

skill 完成转译后:

1. 输出 antd HTML 到 `outputs/`
2. 输出 self-check report 到 `outputs/`
3. 在最后的回复里:
   - 列出两个文件路径
   - 摘要式说明 4 类重点:
     - **冲突项数量** + 是否需要产品决策
     - **PRD 待补项数量** + 关键缺失
     - **自主优化项数量** + 是否有需 review 的
     - **超范围项数量** + 是否影响产品验收

不需要在回复里复述报告全文,产品 / 工程师自己读报告文件即可。
