# rules.md — 硬性规则 + 无法原生还原 + 超范围处理 + 列宽决策 + v3 升级标准

> 转译每个产出前自查本文件。**A 段是硬性约束(违反 = 不合格)**,B-E 是边界与决策,F 段是自检流程。

## 目录(按用途查)

| 段 | 内容 | 行号 |
|---|---|---|
| **A. 硬性规则(17 条,违反 = 不合格)** | | 5-330 |
| A.1-A.12 | 操作列 / 字段提示 / Modal / 菜单 icon / 4 空态 / Tag / KPI / OpLog / 影响范围 / 空值 / 默认排序 / 字号 | 7-160 |
| A.13 React Hook 写法 | 禁 IIFE 内调 Hook(React #300 风险)| 174 |
| A.14 列表 key | 禁 index 作 key,Table 必有 rowKey | 214 |
| A.15 inline component | 禁 render 体内定义子组件 | 232 |
| A.16 JSX 字符串属性 | 中文带 ASCII " 必须 JSX 表达式包裹 | 260 |
| A.17 优先 antd 组件 | 禁手写 div+CSS 仿 Tag/Alert/Badge/Progress | 295 |
| **B. 无法原生还原清单** | 已知 antd 表达不了的项,直接接受降级 | 330 |
| **C. 超范围处理(逃生门)** | C.0 判定流程 + 真超范围的 8 类 + 占位规范 | 343 |
| **D. 表格列宽决策** | ≤6 列 vs ≥7 列 / 操作列 fixed / scroll.x 副作用 | 410 |
| **E. v3 转译标准** | antd 原生 API 升级清单(RangePicker / prefix / Dragger / Summary / 等)| 460 |
| **F. 自检流程** | F.1 人工对照 / F.2 跑 scripts/check.sh / F.3 运行验收 / F.4 不达标处理 | 480 |

## A. 硬性规则(来自 admin-prototype skill,转译时必须满足)

### A.1 表格操作列:必须用带边框 Button,禁止 link 链接

```jsx
// ❌ 错
<a onClick={...} style={{ color:'#7C3AED' }}>编辑</a>
<span className="link">查看</span>

// ✅ 对
<Button size="small" onClick={() => go('edit')}>编辑</Button>
<Button size="small" danger>删除</Button>
<Button size="small" style={{ borderColor:'#D97706', color:'#D97706' }}>确认到货</Button>  // 警告色
```

### A.2 字段提示:虚线下划线 + Tooltip,禁止 ⓘ icon

```jsx
// ❌ 错
<Tooltip title="说明">可售库存 <InfoCircleOutlined /></Tooltip>

// ✅ 对(使用业务组件 TipText,见 components.md B.3)
<TipText label="可售库存" tip="可售库存 = 在库 - 预占 - 锁定" />
```

### A.3 Modal 弹窗:标题区不放关闭按钮,只有底部 footer 控制

```jsx
<Modal title="..." open={open} onCancel={onClose}
  closable={false}        // 必须 false(不在标题区显示 X)
  maskClosable={false}    // 必须 false(默认禁止点遮罩关闭;运营操作复杂,防误触丢失填写内容。如确需点遮罩关闭再显式 true)
  centered={true}         // 必须 true(垂直居中;antd 默认 top:100px 偏上,Looply 风格要居中)
  footer={[
    <Button key="c" onClick={onClose}>取消</Button>,
    <Button key="s" type="primary" onClick={onSave}>保存</Button>,
  ]}>
  {/* 内容 */}
</Modal>
```

按钮模式:
- 表单类:`取消 + 保存/确定`
- 信息/上传类:`关闭`
- 危险操作:`取消 + 确认XX`(右侧 danger)
- 编辑含删除:`删除(左下,danger 边框) + 取消 + 保存`(右侧)

### A.4 二级菜单必须有 icon(15px 视觉)

```jsx
// ❌ 错
{ key: 'overview', label: '总览' }

// ✅ 对
{ key: 'overview', icon: <AppstoreOutlined />, label: '总览' }
```

icon 语义对照(没有现成时也要选合适的近义 icon,不要用占位):

| 业务 | 推荐 antd icon |
|---|---|
| 国家/地区 | `<GlobalOutlined />` / `<FlagOutlined />` |
| 货币 | `<DollarOutlined />` / `<WalletOutlined />` |
| 语言 | `<TranslationOutlined />` / `<FontSizeOutlined />` |
| 列表 | `<UnorderedListOutlined />` |
| 设置 | `<SettingOutlined />` |
| 用户 | `<UserOutlined />` |
| 商品 | `<ShoppingOutlined />` / `<ShopOutlined />` |
| 标签 | `<TagOutlined />` / `<TagsOutlined />` |
| 时间/时区 | `<ClockCircleOutlined />` |
| 类目 | `<AppstoreOutlined />` |
| 品牌 | `<TagOutlined />` |
| 系列 | `<BranchesOutlined />` |
| 属性 | `<UnorderedListOutlined />` / `<OrderedListOutlined />` |
| 度量/单位 | `<ColumnHeightOutlined />` / `<FontSizeOutlined />` |
| 尺码 | `<BorderOutlined />` 不要用,改 `<ColumnHeightOutlined />` |
| 渠道 | `<GlobalOutlined />` / `<NodeIndexOutlined />` |
| 库存 | `<AppstoreOutlined />` |
| 翻译 | `<TranslationOutlined />` |
| Key/字段 | `<KeyOutlined />` |
| 术语表 | `<BookOutlined />` |
| 文件/文档 | `<FileTextOutlined />` / `<FolderOutlined />` |

**禁止用 `<BorderOutlined />` 作为通用占位 icon(空心方框,语义不明)**。

#### A.4.1 菜单 icon 只允许 `@ant-design/icons` 组件,禁用 Emoji / Unicode 符号

```jsx
// ❌ 错(B 组裸跑就这么干 —— 因为没引 icons CDN,自行用 Emoji 替代)
{ key: 'brand',     icon: '★',  label: '品牌管理' }
{ key: 'attribute', icon: '◈',  label: '属性管理' }
{ key: 'product',   icon: '🛍', label: '商品管理' }

// ✅ 对
{ key: 'brand',     icon: <TagOutlined />,         label: '品牌管理' }
{ key: 'attribute', icon: <UnorderedListOutlined/>,label: '属性管理' }
{ key: 'product',   icon: <ShoppingOutlined />,    label: '商品管理' }
```

原因:
1. Emoji 渲染依赖 OS 字体,Mac / Windows / Linux 视觉差异大(`🛍` 在 Win 显示为单色描边、在 Mac 是彩色)
2. Unicode 几何符号(`★◈⬡▦` 等)对齐和粗细与 antd 风格不一致
3. 失去了"为什么不引 `@ant-design/icons@6` CDN"的强信号 — 必须引

**前置条件:CDN 必须引 `@ant-design/icons@6` UMD**(theme.md 的 CDN 清单已含)。无此 CDN 时,任何 `<XxxOutlined />` 都不可用,会让 sonnet 误判"只能用 Emoji"。检查方式:`grep "@ant-design/icons" 产物.html` 必须 ≥ 1。

### A.5 列表页必须支持 4 种空态切换

PRD 全局约定(第二章开头):

| 态 | 触发 | 表现 |
|---|---|---|
| **正常数据** | 默认 | 显示表格 + 分页 |
| **零数据引导** | 列表无任何数据 | 隐藏搜索栏,居中引导:图标 + "暂无{实体}" + 描述 + CTA"新增{实体}" |
| **筛选无匹配** | 搜索/筛选后无结果 | 保留搜索栏,表格替换为提示 + "清除筛选" |
| **网络异常** | 请求失败 | 保留搜索栏,表格替换为错误提示 + "重试" |
| **加载态** | 数据请求中 | 显示加载指示器(antd `<Spin>` 或 Table `loading=true`) |

实现方式(原型阶段):用 `<EmptyStateSwitcher>` 演示组件,允许评审时切换查看。

### A.6 Tag 必须 pill 圆角 + 无边框

```jsx
// 永远用业务组件 <StatusTag variant={...}>,不要直接 <Tag color="...">
<StatusTag variant="on">启用</StatusTag>
<StatusTag variant="pending">待审</StatusTag>
<StatusTag variant="off">停用</StatusTag>
```

详见 `components.md` B.2。

### A.7 KPI 卡片用业务组件

不要手写 KPI HTML,统一用 `<Kpi num="..." label="..." />`。

### A.8 操作记录区(编辑页 + 详情页默认有)

PRD 全局约定:所有编辑页/详情页**默认**包含操作记录区,字段:操作时间 / 操作人 / 操作类型 / 操作详情。

实现方式:页面尾部统一加 `<OpLog />` 组件(见 `components.md` B.8)。

### A.9 影响范围预览(停用类操作)

PRD 全局约定:停用类操作如涉及关联数据,弹影响范围预览,最多 10 条 + "等 N 个{实体}"。

实现方式:`<Modal>` 内放表格 + 摘要数字。

### A.10 空值显示

PRD 全局约定:表格空值统一显示 `"—"`(中文破折号),不留空白。布尔型字段显示状态标签(启用/停用),不显示 true/false。

### A.11 默认排序

PRD 全局约定:所有列表页默认按创建时间倒序。`<Table>` 不需要主动配 sorter,数据传入时已倒序即可。

### A.12 标题/描述/标签字号(参见 `theme.md`)

| 元素 | 字号 | 字重 | 颜色 |
|---|---|---|---|
| 页面标题 (`.page-title`) | 20px | 700 | #1F2937 |
| 页面描述 (`.page-desc`) | 13px | 400 | #6B7280 |
| 区块标题(`.lp-section`,form-section.section-title) | 15px | 600 | #1F2937 + 底线 |
| 小节标题(`.lp-section-purple`) | 14px | 700 | #7C3AED |
| KPI 数字 | 24px | 700 | #7C3AED |
| Table cell | 13px | 400 | #1F2937 |
| Table header | 12px | 400 | #6B7280(uppercase 无法实现) |
| Tag | 12px | 400 | (各 variant) |
| Form field 值 | **继承 body 14px**,不要主动指定 |
| Tabs item | **继承 antd 默认 14px**,不要主动指定 |

### A.13 React Hook 写法:禁止在条件分支 / IIFE 内调用 Hook

React 规则:每次渲染必须按相同顺序调用相同数量的 Hook。在条件分支(如 `{currentPage === 'xxx' && (...)}`)内调用 `useState` / `useMemo` / `useEffect`,会在 currentPage 变化时改变 Hook 数量 → 触发 **React #300**(Minified React error)→ 整个页面白屏。

**多 page 单文件原型尤其容易踩**:每个 page 内联一个 IIFE,IIFE 里 `const [mode, setMode] = useState(...)` — 切页面时挂掉。

```jsx
// ❌ 错(A 组商品管理就是这么挂的:点"新增类目"白屏 + React #300)
{currentPage === 'page-category-list' && (() => {
  const [mode, setMode] = useState('data');   // ← Hook 在条件 IIFE 内
  return <Card>...</Card>;
})()}
{currentPage === 'page-category-edit' && (() => {
  const [open, setOpen] = useState(false);    // ← 切到这页时,上面那个 useState 消失,Hook 顺序乱
  return <Card>...</Card>;
})()}

// ✅ 对:每个 page 抽成命名函数组件,Hook 在组件顶层
function CategoryListPage({ go }) {
  const [mode, setMode] = useState('data');
  return <Card>...</Card>;
}
function CategoryEditPage({ go }) {
  const [open, setOpen] = useState(false);
  return <Card>...</Card>;
}
// 渲染:
{currentPage === 'page-category-list' && <CategoryListPage go={go} />}
{currentPage === 'page-category-edit' && <CategoryEditPage go={go} />}

// ✅ 也对:无状态的 page 可以保留 IIFE 或直接 JSX,只要 IIFE 内不调 Hook
{currentPage === 'page-category-create' && (
  <Card>...纯展示,无 useState...</Card>
)}
```

判定原则:**IIFE 内不允许出现任何 `useState` / `useMemo` / `useEffect` / `useRef` / `useCallback` / `useContext` 调用**。需要状态就抽组件。

为什么不把所有 state 提到 App 顶层?会爆炸(54 page × 平均 1-2 个 state = 80+ 个 useState 集中在 App,后续维护灾难)。

### A.14 列表渲染必须有稳定 key,禁止 index 作为 key

```jsx
// ❌ 错:index 当 key
{items.map((item, i) => <Row key={i} data={item} />)}

// ❌ 错:漏 key(React warning,严重时 state 错乱)
{items.map(item => <Row data={item} />)}

// ✅ 对:用业务唯一 id
{items.map(item => <Row key={item.id} data={item} />)}

// ✅ Table 用 rowKey
<Table rowKey="id" dataSource={...} columns={...} />
```

理由:index 作为 key,数组顺序变化时 React 复用错误的 DOM/state(行内编辑、Checkbox 选中状态等会跳到错误行)。原型阶段虽然不切顺序,但保留这条规则避免后续工程化时被坑。

### A.15 不允许在 render 函数体内定义新的函数组件

```jsx
// ❌ 错:App 函数体内定义子组件 → 每次 App 重新 render,子组件被当作新组件 mount/unmount → 子组件 state 全丢
function App() {
  const [currentPage, setCurrentPage] = useState('list');
  const ListPage = () => {            // ← 每次 render 都生成新引用
    const [mode, setMode] = useState('data');
    return <Card>...</Card>;
  };
  return <>{currentPage==='list' && <ListPage />}</>;
}

// ✅ 对:子组件定义在 App 外
function ListPage({ go }) {
  const [mode, setMode] = useState('data');
  return <Card>...</Card>;
}
function App() {
  const [currentPage, setCurrentPage] = useState('list');
  return <>{currentPage==='list' && <ListPage go={go} />}</>;
}
```

判定:**JSX 文件中所有 `function XxxPage(...)` / `const XxxPage = (...) => (...)` 必须在最外层定义,不能嵌套在另一个组件的函数体内**。

注意区分:**普通函数**(不是组件)在 App 内定义是允许的,如 `const go = (key) => setCurrentPage(key)`。判定关键看返回值:返回 JSX = 组件 = 必须外置;返回值/操作 = 普通函数 = 可以内嵌。

### A.16 JSX 字符串属性禁忌:中文文案带 ASCII 双引号 → 必须 JSX 表达式包裹

```jsx
// ❌ 错(A1 market 实测挂掉,Babel SyntaxError):中文文案里有 ASCII "..."
<FormRow label="API Key" helper="修改后请点击"测试连接"验证">
//                                      ↑      ↑      ↑       ↑
// Babel 把 helper="修改后请点击" 当作属性闭合,后面 测试连接"验证" 变非法

// ✅ 对(三选一):
// 1. JSX 表达式 + 单引号外包(最稳)
<FormRow label="API Key" helper={'修改后请点击"测试连接"验证'}>

// 2. 换中文双引号 "" "(语义更佳,Looply 文案规范)
<FormRow label="API Key" helper="修改后请点击"测试连接"验证">

// 3. HTML 实体(可读性差,不推荐)
<FormRow label="API Key" helper="修改后请点击&quot;测试连接&quot;验证">
```

**适用范围**:`label / helper / placeholder / title / description / tip / message` 等所有字符串属性。

**判定原则**:写中文文案前,先想"这段话里有没有 ASCII `"`?有就**必须**用 JSX 表达式 `={...}` 或换中文引号"。

**自检命令**(F.2 已加):
```bash
python3 -c "
import re
with open('产物.html') as f:
    for i, line in enumerate(f, 1):
        for m in re.finditer(r'(\w+)=\"([^\"]*)\"([一-鿿])', line):
            print(f'Line {i} attr={m.group(1)}: {line.strip()[:120]}')
"
# 命中即违规(属性闭合引号后紧跟中文字符 = 嵌套未转义)
```

### A.17 优先 antd 原生组件,禁止手写 div + 内联 style 仿造

**原则**:看到原型有"彩色 pill / 信息条 / 计数小圆点 / 进度条"等视觉,**先想 antd 有什么组件可用**,而不是直接 copy 原型 CSS。

```jsx
// ❌ 错(A2/A3 market 实测):用 div + 内联 style 仿造 Tag
<div style={{
  padding: '10px 14px', borderRadius: 10,
  background: '#FEF2F2', border: '1px solid #FECACA',
  color: '#991B1B', fontSize: 12
}}>当前待处理:<strong>2</strong> 条</div>

// ✅ 对:antd Tag(语义化 + 主题自适应 + 一致性)
<Tag color="error" bordered>当前待处理:2 条</Tag>
<Tag color="warning" bordered>高风险波动:1 条</Tag>
<Tag color="default" bordered>固定模式偏离提示:1 条</Tag>
```

#### 原型视觉 → antd 组件 速查表(扩展版在 components.md D 段)

| 原型视觉 | 不要手写 | ✅ 用 antd |
|---|---|---|
| 彩色 pill / 状态标签 | `<div style={{bg,border,radius,color}}>` | `<Tag color="error/warning/success/processing">` 或 `<StatusTag>` 业务组件 |
| 顶部黄/蓝/红信息条 | `<div style={{bg:'#FEF3C7',border,padding}}>` | `<Alert type="info/warning/error/success" message description showIcon>` |
| 菜单项右上红色计数 | `<span style={{position:absolute,bg:'red',borderRadius:999}}>2</span>` | `<Badge count={2} size="small"><span>异常告警</span></Badge>` 嵌入 menu label |
| 状态点 / 在线指示器 | `<span style={{width:8,height:8,borderRadius:99,bg:'green'}}/>` | `<Badge status="success" />` |
| 横线进度 | `<div style={{height:6,bg,borderRadius}}><div style={{width:'60%',bg:primary}}/></div>` | `<Progress percent={60} size="small">` |
| 卡片右上角小贴纸 | `<div style={{position:absolute,top,right,bg,color}}>` | `<Badge.Ribbon text="..." color="...">` 包裹 Card |
| 头像数字 / 字符占位 | `<div style={{width:40,height:40,borderRadius:99,bg,color}}>张</div>` | `<Avatar>张</Avatar>` 或 `<Avatar src=...>` |
| 时间相对显示(几分钟前) | 手写 `dayjs(...).fromNow()` | `<Statistic.Countdown />` 或 `dayjs.fromNow()`(已 OK)|

**判定标准**:**任何用 4 个以上 inline style 属性(`background + border + borderRadius + color + padding + fontSize` 中 ≥ 4)且渲染"看起来像 antd 已有组件"的 div,都要先查 antd 再决定**。

不在表里的视觉(纯结构性 wrapper / 自定义业务组件),允许手写 div + style。

## B. 无法原生还原清单

antd 6.4.x 表达不了的视觉/交互项。这些**不要 hack 也不要假装实现**,在自检报告"视觉妥协"段落如实标注。

| # | spec 要求 | 为何不能 | 处理方案 |
|---|---|---|---|
| 1 | **菜单激活态左 3px 紫色边框** | Menu 无 token 暴露 item border-left;Semantic DOM 不到 selected 态 | **不实现**。激活态用纯色背景 + 加粗 + 主色文字表达 |
| 2 | **菜单激活态渐变背景** `linear-gradient(90deg, rgba(124,58,237,.1), transparent)` | `itemSelectedBg` token 只接纯色 | **降级为纯色 `#F3EEFF`**(已固化在 theme.md 的 Menu.itemSelectedBg) |
| 3 | **表头 uppercase + letter-spacing 0.02em** | Table Semantic DOM 不暴露 header cell,无对应 token | **不实现**。接受 antd 默认表头(正常字重、无 uppercase) |
| 4 | **菜单 L1/L2 分级 padding**(L1:12-16, L2:10-16-10-44) | Menu 只有全局 `inlineIndent`,不能分级 | **接受 antd 默认间距** |

新增的"无法还原"项必须在转译时立即记录到这里(skill 自检流程的副产品)。

## C. 超范围处理(逃生门)

### C.0 ⚠ 先判定:这是不是真的超范围?

"超范围"**不等于**"不在 components.md 28 个子集里"。判定标准:**只有 antd 6.4.x 完全没有该能力 + React 基础能力也搞不定**,才算超范围。

#### 判定流程(必走)

1. **查 antd CLI 确认**(如有 `@ant-design/cli`):
   ```bash
   antd list --version 6.4.0 --format json | grep -i "<能力关键词>"
   antd info <ComponentName> --version 6.4.0 --format json
   ```
   如果 antd 有该组件 → **不是超范围**,补到 components.md 用法清单后正常使用
2. **是不是 React 基础能力能搞定?**
   - 条件渲染、字段联动、状态切换、tabs/steps 分组 → **不是超范围**,正常实现
   - 比如"值约束变化时显示/隐藏子区块" = `{type==='size' && <SizeBlock/>}`,纯 React,不是超范围
3. **PRD 全局约定的功能不允许跳过**:
   - 比如"停用类有关联数据弹影响范围预览"是全局约定 → 即使原型某模块没画,也不能不实现
   - 跳过这类功能不是超范围,是漏需求

#### 真正的超范围(只有这几类)

| 类别 | 例 | antd 缺什么 | 建议三方 |
|---|---|---|---|
| 富文本编辑 | 商品描述 / 公告正文 | antd 无 RichText | `react-quill` / `@wangeditor/editor-for-react` |
| 图片裁剪 | 主图编辑 | antd 无 ImageCrop | `react-image-crop` |
| 拖拽排序(复杂) | 表格行 / 卡片 / 树节点 | antd Sortable 只覆盖基础场景 | `@dnd-kit/sortable` / `react-beautiful-dnd` |
| 多图排序 | SKU 图册排版 | Upload listType="picture-card" 不支持拖动 | `react-sortablejs` |
| 思维导图 / 流程图 | 工作流配置 | 无 | `@xyflow/react` |
| 复杂图表 | 漏斗 / 桑基 / 热力图 | antd 无图表(Statistic 只算 KPI) | `@ant-design/charts` / `echarts` |
| Markdown 编辑 | 文档编辑 | 无 | `@uiw/react-md-editor` |
| 复杂权限矩阵编辑 | 角色 × 资源 × 操作 | 无 | 自定义 + react-table |

**任何其他需求**:先按"判定流程"走,不要直接跳到 C.1 放占位。

### 处理步骤(确认真超范围后)

1. **在产物里放占位组件**

```jsx
<div style={{
  border: '2px dashed #D1D5DB', borderRadius: 10, padding: 24,
  background: '#FAFAFA', color: '#6B7280', textAlign: 'center'
}}>
  <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 4 }}>
    📌 待集成:{需求名}
  </div>
  <div style={{ fontSize: 12 }}>
    antd 6.4.x 无原生组件,需要在实际后台开发阶段集成{建议方案}
  </div>
</div>
```

2. **在自检报告"超范围"段落记录**

```markdown
### 超范围项

| 位置 | 需求 | 占位描述 | 建议集成方案 |
|---|---|---|---|
| `page-spu-edit` 描述字段 | 富文本编辑器 | 占位 div | `react-quill` 或 `@wangeditor/editor-for-react` |
| `page-product-edit` 主图 | 图片裁剪 | 占位 Upload | `react-image-crop` |
```

3. **明确告知**:"该需求超出 skill 范围,**建议在实际后台开发阶段调用 antd / ant-design 官方 skill 处理**"

### 常见超范围项

- 富文本编辑器(描述、文章正文)
- 图片裁剪 / 多图排序
- Markdown 编辑器
- 思维导图 / 流程图编辑
- 复杂图表(echarts / G2)
- 拖拽排序(antd v6 有 Sortable,但复杂场景需要 react-dnd)
- 文件树编辑(antd Tree 支持基础操作,复杂的需要 react-dnd-tree)
- 复杂权限矩阵编辑器
- 工作流配置画布

## D. 表格列宽决策(v3 标准)

**总则**:**业务逻辑 > 视觉**,但表格出现横向滚动严重影响体验,所以列宽要按表的特征分类处理。

### 决策矩阵

| 表特征 | scroll | 列 width | 操作列 fixed |
|---|---|---|---|
| **≤6 列,操作只 1-2 个按钮** | **不设 scroll** | **不设 width**(auto-layout 均摊) | 不用 fixed,直接最右列 |
| **≥7 列,内容长 / 操作多** | `scroll={{ x: 'max-content' }}` | **所有列设 width** | `fixed: 'right'` |
| **少列但有行内编辑或长字段** | 设 scroll | 所有列 width | 操作列 fixed |

### 反例(我们犯过的错)

```jsx
// ❌ 错:只有 6 列,但中间一列没设 width
const columns = [
  { title: '货币代码', dataIndex: 'code', width: 110 },
  { title: '货币名称', dataIndex: 'name' },           // ← 这列吃掉所有剩余空间,变得超大
  { title: '符号',     dataIndex: 'symbol', width: 80 },
  ...
];

// ✅ 对:全部不设 width,走 auto-layout 均摊
const columns = [
  { title: '货币代码', dataIndex: 'code' },
  { title: '货币名称', dataIndex: 'name' },
  { title: '符号',     dataIndex: 'symbol' },
  ...
];
```

### 关键原理(给 AI 看)

- 不设 `scroll.x` 时,Table 默认 `tableLayout="auto"`(浏览器原生)→ 列按内容自适应,剩余空间按内容比例分摊 ≈ 均摊
- 设 `scroll.x` 时,Table 切到 `tableLayout="fixed"` → 必须给所有列设 width,否则未设的列吃所有剩余空间
- `fixed: 'right'` 需要配合 `scroll.x` 才生效,没 scroll 时反而触发 fixed-layout 副作用

## E. v3 转译标准(antd 原生 API 升级清单)

每次转译时优先使用以下 antd 原生能力,而不是手写:

| 项 | 旧做法 | v3 标准 |
|---|---|---|
| 开始日期 + 结束日期 | 两个独立 `<DatePicker>` | `<DatePicker.RangePicker placeholder={['开始日期','结束日期']} />` |
| 搜索 Input | 纯 `<Input>` | `<Input prefix={<SearchOutlined />} allowClear />` |
| 查询按钮 | 纯文字 | `<Button type="primary" icon={<SearchOutlined />}>查询</Button>` |
| 重置按钮 | 纯文字 | `<Button icon={<ReloadOutlined />}>重置</Button>` |
| 导入/导出按钮 | 纯文字 | 加 `<ImportOutlined />` / `<DownloadOutlined />` |
| 上传拖拽区 | 手写 `<div class="dashed-zone">` | `<Upload.Dragger accept="..." beforeUpload={()=>false}>` |
| 预览表底部统计 | 表格下方独立 `<div>` | `<Table summary={() => <Table.Summary.Row>...</Table.Summary.Row>}>` 内嵌 |
| 行内编辑数字 | 自己 state + InputNumber | `<EditableNumber>` 业务组件(见 components.md B.10) |
| 多选筛选 | 多个 Select 串联 | `<Select mode="multiple">` |
| 标签输入 | 手写 chip 输入框 | `<Select mode="tags">` |
| 层级选择 | 多级 Select 串联 | `<TreeSelect>` 或 `<Cascader>` |

## F. 自检流程(每个产物完成前)

### F.1 人工对照(按 A-E 段逐项过)

1. **A 段硬性规则**——操作列 Button / Tooltip / Modal / 菜单 icon / 4 种空态 / Tag pill 圆角 / 空值显示 / 默认排序 / 字号 → 任一违反就修
2. **D 段列宽决策**——表是少列还是宽列?对应规则是否应用?
3. **E 段 v3 标准**——能用 antd 原生的地方是否都用了?
4. **B 段无法还原项**——清单内已知项是否如实标注?新发现的是否补到清单?
5. **C 段超范围判定**——先走 C.0 判定流程(查 antd CLI / 想 React 基础能力),确认真超范围再放占位

### F.2 静态检查清单(必须全跑,任一非 0 即修)

**跑 `scripts/check.sh`(一键)**:

```bash
bash scripts/check.sh outputs/产物.html
```

输出形如:
```
▶ 检查产物: outputs/looply-XXX-antd.html
── A.13 React Hook 写法 ──  ✅ IIFE 数 = 0
── A.16 JSX 字符串属性 ──  ✅ 无嵌套引号
── A.14 Table rowKey ──  ✅ Table=12 rowKey=12
── A.4.1 菜单 icon ──  ✅ 全部 @ant-design/icons
── A.17 div+style 仿 antd 组件 ──  ⚠ 发现 2 处(人工 review)
── A.3 Modal 配置 ──  ✅ closable+maskClosable+centered 三件套覆盖
── CDN 锁定 / antd 版本 ──  ✅
── 全局 .ant-* CSS 覆盖 ──  ✅
═══════════════════════════════════════
  Pass: 7 / Warn: 1 / Fail: 0
═══════════════════════════════════════
```

**退出码语义**:
- `0` = 全过 → 可交付
- `1` = 有 ⚠ → 人工 review(如 A.17 div+style 命中,看是不是合法 wrapper)
- `2` = 有 ❌ → 必须修复后重跑

**check.sh 覆盖**(每项对应 A 段一条):

| 检查 | A 段 | 实现 |
|---|---|---|
| IIFE+Hook 精确判定(排除 useMemo 误报)| A.13 | `scripts/check_iife_hook.py` |
| JSX 中文嵌套 ASCII 双引号 | A.16 | `scripts/check_jsx_quotes.py` |
| Table rowKey 覆盖 | A.14 | `check.sh` 内 grep |
| 菜单 icon 禁 Emoji | A.4.1 | 同上 |
| div+style 仿造 antd(启发式)| A.17 | 同上 |
| Modal 三件套(closable+maskClosable+centered)| A.3 | 多行属性容错 grep |
| CDN 锁定 + antd 版本 | theme.md A.1 | 同上 |
| 禁 `.ant-*` 全局覆盖 | SPEC.md | 同上 |

**新发现违规模式时**:改 `scripts/check.sh`(或加 helper py),不要回到本文档粘贴一条裸 grep。文档里只放"为什么"的解释,具体命令一律在 scripts/。

### F.2.1 check.sh 未覆盖项(独立查)

```bash
# A.14 补充:.map 用 index 作 key
grep -nE "\.map\(\(?[a-zA-Z_]+,\s*[a-zA-Z_]+\)?\s*=>\s*<[A-Z][a-zA-Z]*\s+key=\{[a-zA-Z_]+\}" 产物.html
# 期望为空。反模式:`.map((item, i) => <Row key={i} ... />)`

# A.1 补充:<a onClick=... 做操作列
grep -nE "<a [^>]*onClick=" 产物.html
# 期望为空(必须用 <Button>)

# A.2 补充:<Tooltip> + InfoCircleOutlined(应统一用 TipText 业务组件)
grep -B1 -A1 "<InfoCircleOutlined" 产物.html | grep -i tooltip
# 期望为空
```

这些是低频违规,需要时手动跑。常态化后可以并入 check.sh。

### F.3 运行自检的明确告知(subagent 必做)

subagent 通常无浏览器,**不能真跑**。但必须在交付回复里显式写一行:

> ⚠ 未做浏览器运行测试。请打开产物 + 点击 ≥3 个非首页(列表/新建/编辑)+ 切换菜单展开收起,确认:
> 1. 控制台无 React 错误(尤其 #300 / #310 / #321)
> 2. 左侧 Sider 长菜单可正常滚动,不超出 viewport
> 3. 弹窗 / Tabs / Steps 切换无白屏

把验收责任明确传递给调用方。

### F.4 任何项不达标处理

**修复后再写自检报告**,不要把"我没修的问题"写进报告糊弄。如果时间不够,在 self-check 报告"6. 自主优化项"或新增的"7. 已知未修问题"段落显式列出,而非藏起来。
