# rules.md — 硬性规则 + 无法原生还原 + 超范围处理 + 列宽决策 + v3 升级标准

> 转译每个产出前自查本文件。**A 段是硬性约束(违反 = 不合格)**,B-E 是边界与决策,F 段是自检流程。

## 目录(按用途查)

| 段 | 内容 | 行号 |
|---|---|---|
| **A. 硬性规则(19 条,违反 = 不合格)** | | 22-402 |
| A.1-A.12 | 操作列(A.1.1 按钮数量)/ 字段提示 / Modal / 菜单 icon / 4 空态 / Tag / KPI / OpLog / 影响范围 / 空值 / 默认排序 / 字号 | 24-230 |
| A.13 React Hook 写法 | 禁 IIFE 内调 Hook(React #300 风险)| 231 |
| A.14 列表 key | 禁 index 作 key,Table 必有 rowKey | 271 |
| A.15 inline component | 禁 render 体内定义子组件 | 289 |
| A.16 JSX 字符串属性 | 中文带 ASCII " 必须 JSX 表达式包裹 | 317 |
| A.17 优先 antd 组件 | 禁手写 div+CSS 仿 Tag/Alert/Badge/Progress | 352 |
| A.18 JSX 编辑/删除 | 增删改保持结构完整性,删后验标签配对 | 387 |
| A.19 共享弹窗 | 列表+详情同操作弹窗组件化,且所有数据源同步补字段 | 404 |
| **B. 无法原生还原清单** | 已知 antd 表达不了的项,直接接受降级 | 保留降级项 |
| **C. 超范围处理(逃生门)** | C.0 判定流程 + 真超范围的 8 类 + 占位规范 | 416 |
| **D. 表格列宽决策** | ≤6 列 vs ≥7 列 / 操作列 fixed / scroll.x 副作用 | 495 |
| **E. v3 转译标准** | antd 原生 API 升级清单(RangePicker / prefix / Dragger / Summary / 等)| 533 |
| **F. 自检流程** | F.1 人工对照 / F.2 跑 scripts/check.sh / F.3 运行验收 / F.4 不达标处理 | 551 |

## A. 硬性规则(来自 admin-prototype skill,转译时必须满足)

### A.1 表格操作列:必须用带边框 Button,禁止 link 链接

```jsx
// ❌ 错
<a onClick={...} style={{ color:'#A4002A' }}>编辑</a>
<span className="link">查看</span>

// ✅ 对
<Button size="small" onClick={() => go('edit')}>编辑</Button>
<Button size="small" danger>删除</Button>
<Button size="small" style={{ borderColor:'#D97706', color:'#D97706' }}>确认到货</Button>  // 警告色
```

#### A.1.1 操作列按钮数量:超过 4 个必须收进 Dropdown

操作列按钮过多会撑爆列宽、视觉杂乱。按数量分级:

| 操作数 | 处理 | 实现 |
|---|---|---|
| **≤ 4 个** | 全部平铺 | `<Space size={6}>` 排列 `<Button size="small">` |
| **> 4 个** | **前 3 个平铺,第 4 个起全部收进「更多」** | 平铺部分 + `<Dropdown menu={{items}}>`,触发器用 `<Button size="small" icon={<EllipsisOutlined />} />` |

**可见元素恒为 4**:要么 4 个平铺按钮,要么 3 个平铺按钮 + 1 个「更多」。不存在只平铺 1-2 个就收纳的情况——那样"更多"里塞太多项,反而增加点击成本。

补充规则:
- **逐行判定,不按列统一**:操作数随行状态变化时(如"已结束"行 4 个、"进行中"行 6 个),**按该行自身的操作数判定**。同一列出现"4 个平铺"与"3 个 + 更多"两种形态是正常的;列宽按最宽的那一行预留即可。
- **危险操作标红**:下拉 items 里的注销 / 删除 / 停用用 `danger: true`(前面加 `{ type: 'divider' }` 分隔);平铺时用 `<Button size="small" danger>`
- **留谁在外面**:按"详情 > 编辑 > 状态主操作(发布/暂停/恢复/结束)> 低频操作(复制/日志)> 删除"排序,取前 3 个平铺。危险操作靠后自然会被收进下拉;但当该行 ≤4 全平铺时,删除也平铺(标红即可)。

```jsx
// ✅ 推荐写法:先拼有序 ops 数组,再按 4 切分——规则集中一处,不散落在各分支
render: (_, r) => {
  const ops = [{ key: 'detail', label: '详情', onClick: ... }];
  if (r.status !== 'ended') ops.push({ key: 'edit', label: '编辑', onClick: ... });
  if (r.status === 'active') ops.push({ key: 'pause', label: '暂停' });
  ops.push({ key: 'copy', label: '复制' }, { key: 'log', label: '操作日志' });
  if (canDelete(r)) ops.push({ key: 'del', label: '删除', danger: true, onClick: ... });

  const flat = ops.length <= 4 ? ops : ops.slice(0, 3);   // ← 规则本体
  const more = ops.length <= 4 ? [] : ops.slice(3);
  const moreItems = [];
  more.forEach(o => {
    if (o.danger && moreItems.length) moreItems.push({ type: 'divider' });
    moreItems.push({ key: o.key, label: o.label, danger: o.danger });
  });
  return <Space size={6}>
    {flat.map(o => <Button key={o.key} size="small" danger={o.danger} onClick={o.onClick}>{o.label}</Button>)}
    {more.length > 0 && <Dropdown trigger={['click']} menu={{ items: moreItems, onClick: ... }}>
      <Button size="small" icon={<EllipsisOutlined />} /></Dropdown>}
  </Space>;
}
```

```jsx
// ✅ ≤4 个:平铺
<Space size={6}>
  <Button size="small" onClick={() => go('edit')}>编辑</Button>
  <Button size="small" onClick={() => go('detail')}>详情</Button>
  <Button size="small" danger>停用</Button>
</Space>

// ✅ >4 个:平铺 2-3 个 + Dropdown 收其余(危险项 danger 标红)
<Space size={6}>
  <Button size="small" onClick={() => go('edit')}>编辑</Button>
  <Button size="small" onClick={() => go('detail')}>详情</Button>
  <Dropdown trigger={['click']} menu={{ items: [
    { key: 'copy',   label: '复制' },
    { key: 'export', label: '导出' },
    { key: 'log',    label: '操作日志' },
    { type: 'divider' },
    { key: 'disable', label: '停用', danger: true },
  ] }}>
    <Button size="small" icon={<EllipsisOutlined />} />
  </Dropdown>
</Space>
```

`<Dropdown>` 用法详见 `components.md` A.4。本规则 `scripts/check.sh` 不覆盖(纯视觉),靠 `self-check.md` 手动视觉检查兜底。

### A.2 字段提示:虚线下划线 + Tooltip,禁止 ⓘ icon

```jsx
// ❌ 错
<Tooltip title="说明">可售库存 <InfoCircleOutlined /></Tooltip>

// ✅ 对(使用业务组件 TipText,见 components.md B.3)
<TipText label="可售库存" tip="可售库存 = 在库 - 预占 - 锁定" />
```

### A.3 Modal 弹窗:标题区不放关闭按钮,只有底部 footer 控制

```jsx
<Modal title="..." open={open} onCancel={onClose}
  closable={false}        // 必须 false(不在标题区显示 X)
  maskClosable={false}    // 必须 false(默认禁止点遮罩关闭;运营操作复杂,防误触丢失填写内容。如确需点遮罩关闭再显式 true)
  centered={true}         // 必须 true(垂直居中;antd 默认 top:100px 偏上,Looply 风格要居中)
  footer={[
    <Button key="c" onClick={onClose}>取消</Button>,
    <Button key="s" type="primary" onClick={onSave}>保存</Button>,
  ]}>
  {/* 内容 */}
</Modal>
```

按钮模式:
- 表单类:`取消 + 保存/确定`
- 信息/上传类:`关闭`
- 危险操作:`取消 + 确认XX`(右侧 danger)
- 编辑含删除:`删除(左下,danger 边框) + 取消 + 保存`(右侧)

### A.4 二级菜单必须有 icon(15px 视觉)

```jsx
// ❌ 错
{ key: 'overview', label: '总览' }

// ✅ 对
{ key: 'overview', icon: <AppstoreOutlined />, label: '总览' }
```

icon 语义对照(没有现成时也要选合适的近义 icon,不要用占位):

| 业务 | 推荐 antd icon |
|---|---|
| 国家/地区 | `<GlobalOutlined />` / `<FlagOutlined />` |
| 货币 | `<DollarOutlined />` / `<WalletOutlined />` |
| 语言 | `<TranslationOutlined />` / `<FontSizeOutlined />` |
| 列表 | `<UnorderedListOutlined />` |
| 设置 | `<SettingOutlined />` |
| 用户 | `<UserOutlined />` |
| 商品 | `<ShoppingOutlined />` / `<ShopOutlined />` |
| 标签 | `<TagOutlined />` / `<TagsOutlined />` |
| 时间/时区 | `<ClockCircleOutlined />` |
| 类目 | `<AppstoreOutlined />` |
| 品牌 | `<TagOutlined />` |
| 系列 | `<BranchesOutlined />` |
| 属性 | `<UnorderedListOutlined />` / `<OrderedListOutlined />` |
| 度量/单位 | `<ColumnHeightOutlined />` / `<FontSizeOutlined />` |
| 尺码 | `<BorderOutlined />` 不要用,改 `<ColumnHeightOutlined />` |
| 渠道 | `<GlobalOutlined />` / `<NodeIndexOutlined />` |
| 库存 | `<AppstoreOutlined />` |
| 翻译 | `<TranslationOutlined />` |
| Key/字段 | `<KeyOutlined />` |
| 术语表 | `<BookOutlined />` |
| 文件/文档 | `<FileTextOutlined />` / `<FolderOutlined />` |

**禁止用 `<BorderOutlined />` 作为通用占位 icon(空心方框,语义不明)**。

#### A.4.1 菜单 icon 只允许 `@ant-design/icons` 组件,禁用 Emoji / Unicode 符号

```jsx
// ❌ 错(B 组裸跑就这么干 —— 因为没引 icons CDN,自行用 Emoji 替代)
{ key: 'brand',     icon: '★',  label: '品牌管理' }
{ key: 'attribute', icon: '◈',  label: '属性管理' }
{ key: 'product',   icon: '🛍', label: '商品管理' }

// ✅ 对
{ key: 'brand',     icon: <TagOutlined />,         label: '品牌管理' }
{ key: 'attribute', icon: <UnorderedListOutlined/>,label: '属性管理' }
{ key: 'product',   icon: <ShoppingOutlined />,    label: '商品管理' }
```

原因:
1. Emoji 渲染依赖 OS 字体,Mac / Windows / Linux 视觉差异大(`🛍` 在 Win 显示为单色描边、在 Mac 是彩色)
2. Unicode 几何符号(`★◈⬡▦` 等)对齐和粗细与 antd 风格不一致
3. 失去了"为什么不引 `@ant-design/icons@6` CDN"的强信号 — 必须引

**前置条件:CDN 必须引 `@ant-design/icons@6` UMD**(theme.md 的 CDN 清单已含)。无此 CDN 时,任何 `<XxxOutlined />` 都不可用,会让 sonnet 误判"只能用 Emoji"。检查方式:`grep "@ant-design/icons" 产物.html` 必须 ≥ 1。

### A.5 列表页必须支持 4 种空态切换

PRD 全局约定(第二章开头):

| 态 | 触发 | 表现 |
|---|---|---|
| **正常数据** | 默认 | 显示表格 + 分页 |
| **零数据引导** | 列表无任何数据 | 隐藏搜索栏,居中引导:图标 + "暂无{实体}" + 描述 + CTA"新增{实体}" |
| **筛选无匹配** | 搜索/筛选后无结果 | 保留搜索栏,表格替换为提示 + "清除筛选" |
| **网络异常** | 请求失败 | 保留搜索栏,表格替换为错误提示 + "重试" |
| **加载态** | 数据请求中 | 显示加载指示器(antd `<Spin>` 或 Table `loading=true`) |

实现方式(原型阶段):用 `<EmptyStateSwitcher>` 演示组件,允许评审时切换查看。

### A.6 Tag 必须 pill 圆角 + 无边框

```jsx
// 永远用业务组件 <StatusTag variant={...}>,不要直接 <Tag color="...">
<StatusTag variant="on">启用</StatusTag>
<StatusTag variant="pending">待审</StatusTag>
<StatusTag variant="off">停用</StatusTag>
```

详见 `components.md` B.2。

### A.7 KPI 卡片用业务组件

不要手写 KPI HTML,统一用 `<Kpi num="..." label="..." />`。

### A.8 操作记录区(编辑页 + 详情页默认有)

PRD 全局约定:所有编辑页/详情页**默认**包含操作记录区,字段:操作时间 / 操作人 / 操作类型 / 操作详情。

实现方式:统一加 `<OpLog />` 组件(见 `components.md` B.8)。

**位置(硬性):编辑页 / 配置页的顺序必须是「表单 → 操作栏(取消/保存) → 操作记录」。**

⚠️ **不要写成「页面尾部」** —— 那会把操作栏挤到操作记录下面。实测(2026-08-06 营销活动 v15 用户点测)
用户原话「保存放在操作记录上边」。原因:**操作栏作用于它上方的表单**,中间隔一段只读的操作记录,
读者要越过一整张表格才找到提交按钮,且容易误以为「保存」是在保存操作记录的筛选结果。

```jsx
// ❌ 错(v14 编辑折扣页 + v15 初版都这么写):操作记录把表单和它的提交按钮隔开
{isEdit && <OpLog />}
<div className="操作栏"><Button>取消</Button><Button type="primary">保存</Button></div>

// ✅ 对:操作栏紧跟表单,操作记录沉到最后
<div className="操作栏"><Button>取消</Button><Button type="primary">保存</Button></div>
{isEdit && <OpLog />}
```

**详情页不受此约束** —— 详情页的操作在页头(A.21-7「推进状态的动作只在页头」),正文末尾放 OpLog 没有隔开任何东西。

### A.9 影响范围预览(停用类操作)

PRD 全局约定:停用类操作如涉及关联数据,弹影响范围预览,最多 10 条 + "等 N 个{实体}"。

实现方式:`<Modal>` 内放表格 + 摘要数字。

### A.10 空值显示

PRD 全局约定:表格空值统一显示 `"—"`(中文破折号),不留空白。布尔型字段显示状态标签(启用/停用),不显示 true/false。

### A.11 默认排序

PRD 全局约定:所有列表页默认按创建时间倒序。`<Table>` 不需要主动配 sorter,数据传入时已倒序即可。

### A.12 标题/描述/标签字号(参见 `theme.md`)

| 元素 | 字号 | 字重 | 颜色 |
|---|---|---|---|
| 页面标题 (`.page-title`) | 20px | 700 | #1F2937 |
| 页面描述 (`.page-desc`) | 13px | 400 | #6B7280 |
| 区块标题(`.lp-section`,form-section.section-title) | 15px | 600 | #1F2937 + 底线 |
| 小节标题(`.lp-section-brand`) | 14px | 700 | #A4002A |
| KPI 数字 | 24px | 700 | #A4002A |
| Table cell | 13px | 400 | #1F2937 |
| Table header | 12px | 400 | #6B7280(uppercase 无法实现) |
| Tag | 12px | 400 | (各 variant) |
| Form field 值 | **继承 body 14px**,不要主动指定 |
| Tabs item | **继承 antd 默认 14px**,不要主动指定 |

### A.13 React Hook 写法:禁止在条件分支 / IIFE 内调用 Hook

React 规则:每次渲染必须按相同顺序调用相同数量的 Hook。在条件分支(如 `{currentPage === 'xxx' && (...)}`)内调用 `useState` / `useMemo` / `useEffect`,会在 currentPage 变化时改变 Hook 数量 → 触发 **React #300**(Minified React error)→ 整个页面白屏。

**多 page 单文件原型尤其容易踩**:每个 page 内联一个 IIFE,IIFE 里 `const [mode, setMode] = useState(...)` — 切页面时挂掉。

```jsx
// ❌ 错(A 组商品管理就是这么挂的:点"新增类目"白屏 + React #300)
{currentPage === 'page-category-list' && (() => {
  const [mode, setMode] = useState('data');   // ← Hook 在条件 IIFE 内
  return <Card>...</Card>;
})()}
{currentPage === 'page-category-edit' && (() => {
  const [open, setOpen] = useState(false);    // ← 切到这页时,上面那个 useState 消失,Hook 顺序乱
  return <Card>...</Card>;
})()}

// ✅ 对:每个 page 抽成命名函数组件,Hook 在组件顶层
function CategoryListPage({ go }) {
  const [mode, setMode] = useState('data');
  return <Card>...</Card>;
}
function CategoryEditPage({ go }) {
  const [open, setOpen] = useState(false);
  return <Card>...</Card>;
}
// 渲染:
{currentPage === 'page-category-list' && <CategoryListPage go={go} />}
{currentPage === 'page-category-edit' && <CategoryEditPage go={go} />}

// ✅ 也对:无状态的 page 可以保留 IIFE 或直接 JSX,只要 IIFE 内不调 Hook
{currentPage === 'page-category-create' && (
  <Card>...纯展示,无 useState...</Card>
)}
```

判定原则:**IIFE 内不允许出现任何 `useState` / `useMemo` / `useEffect` / `useRef` / `useCallback` / `useContext` 调用**。需要状态就抽组件。

为什么不把所有 state 提到 App 顶层?会爆炸(54 page × 平均 1-2 个 state = 80+ 个 useState 集中在 App,后续维护灾难)。

### A.14 列表渲染必须有稳定 key,禁止 index 作为 key

```jsx
// ❌ 错:index 当 key
{items.map((item, i) => <Row key={i} data={item} />)}

// ❌ 错:漏 key(React warning,严重时 state 错乱)
{items.map(item => <Row data={item} />)}

// ✅ 对:用业务唯一 id
{items.map(item => <Row key={item.id} data={item} />)}

// ✅ Table 用 rowKey
<Table rowKey="id" dataSource={...} columns={...} />
```

理由:index 作为 key,数组顺序变化时 React 复用错误的 DOM/state(行内编辑、Checkbox 选中状态等会跳到错误行)。原型阶段虽然不切顺序,但保留这条规则避免后续工程化时被坑。

### A.15 不允许在 render 函数体内定义新的函数组件

```jsx
// ❌ 错:App 函数体内定义子组件 → 每次 App 重新 render,子组件被当作新组件 mount/unmount → 子组件 state 全丢
function App() {
  const [currentPage, setCurrentPage] = useState('list');
  const ListPage = () => {            // ← 每次 render 都生成新引用
    const [mode, setMode] = useState('data');
    return <Card>...</Card>;
  };
  return <>{currentPage==='list' && <ListPage />}</>;
}

// ✅ 对:子组件定义在 App 外
function ListPage({ go }) {
  const [mode, setMode] = useState('data');
  return <Card>...</Card>;
}
function App() {
  const [currentPage, setCurrentPage] = useState('list');
  return <>{currentPage==='list' && <ListPage go={go} />}</>;
}
```

判定:**JSX 文件中所有 `function XxxPage(...)` / `const XxxPage = (...) => (...)` 必须在最外层定义,不能嵌套在另一个组件的函数体内**。

注意区分:**普通函数**(不是组件)在 App 内定义是允许的,如 `const go = (key) => setCurrentPage(key)`。判定关键看返回值:返回 JSX = 组件 = 必须外置;返回值/操作 = 普通函数 = 可以内嵌。

### A.16 JSX 字符串属性禁忌:中文文案带 ASCII 双引号 → 必须 JSX 表达式包裹

```jsx
// ❌ 错(A1 market 实测挂掉,Babel SyntaxError):中文文案里有 ASCII "..."
<FormRow label="API Key" helper="修改后请点击"测试连接"验证">
//                                      ↑      ↑      ↑       ↑
// Babel 把 helper="修改后请点击" 当作属性闭合,后面 测试连接"验证" 变非法

// ✅ 对(三选一):
// 1. JSX 表达式 + 单引号外包(最稳)
<FormRow label="API Key" helper={'修改后请点击"测试连接"验证'}>

// 2. 换中文双引号 "" "(语义更佳,Looply 文案规范)
<FormRow label="API Key" helper="修改后请点击"测试连接"验证">

// 3. HTML 实体(可读性差,不推荐)
<FormRow label="API Key" helper="修改后请点击&quot;测试连接&quot;验证">
```

**适用范围**:`label / helper / placeholder / title / description / tip / message` 等所有字符串属性。

**判定原则**:写中文文案前,先想"这段话里有没有 ASCII `"`?有就**必须**用 JSX 表达式 `={...}` 或换中文引号"。

**自检命令**(F.2 已加):
```bash
python3 -c "
import re
with open('产物.html') as f:
    for i, line in enumerate(f, 1):
        for m in re.finditer(r'(\w+)=\"([^\"]*)\"([一-鿿])', line):
            print(f'Line {i} attr={m.group(1)}: {line.strip()[:120]}')
"
# 命中即违规(属性闭合引号后紧跟中文字符 = 嵌套未转义)
```

### A.17 优先 antd 原生组件,禁止手写 div + 内联 style 仿造

**原则**:看到原型有"彩色 pill / 信息条 / 计数小圆点 / 进度条"等视觉,**先想 antd 有什么组件可用**,而不是直接 copy 原型 CSS。

```jsx
// ❌ 错(A2/A3 market 实测):用 div + 内联 style 仿造 Tag
<div style={{
  padding: '10px 14px', borderRadius: 10,
  background: '#FEF2F2', border: '1px solid #FECACA',
  color: '#991B1B', fontSize: 12
}}>当前待处理:<strong>2</strong> 条</div>

// ✅ 对:antd Tag(语义化 + 主题自适应 + 一致性)
<Tag color="error" bordered>当前待处理:2 条</Tag>
<Tag color="warning" bordered>高风险波动:1 条</Tag>
<Tag color="default" bordered>固定模式偏离提示:1 条</Tag>
```

#### 原型视觉 → antd 组件 速查表(扩展版在 components.md D 段)

| 原型视觉 | 不要手写 | ✅ 用 antd |
|---|---|---|
| 彩色 pill / 状态标签 | `<div style={{bg,border,radius,color}}>` | `<Tag color="error/warning/success/processing">` 或 `<StatusTag>` 业务组件 |
| 顶部黄/蓝/红信息条 | `<div style={{bg:'#FEF3C7',border,padding}}>` | `<Alert type="info/warning/error/success" message description showIcon>` |
| 菜单项右上红色计数 | `<span style={{position:absolute,bg:'red',borderRadius:999}}>2</span>` | `<Badge count={2} size="small"><span>异常告警</span></Badge>` 嵌入 menu label |
| 状态点 / 在线指示器 | `<span style={{width:8,height:8,borderRadius:99,bg:'green'}}/>` | `<Badge status="success" />` |
| 横线进度 | `<div style={{height:6,bg,borderRadius}}><div style={{width:'60%',bg:primary}}/></div>` | `<Progress percent={60} size="small">` |
| 卡片右上角小贴纸 | `<div style={{position:absolute,top,right,bg,color}}>` | `<Badge.Ribbon text="..." color="...">` 包裹 Card |
| 头像数字 / 字符占位 | `<div style={{width:40,height:40,borderRadius:99,bg,color}}>张</div>` | `<Avatar>张</Avatar>` 或 `<Avatar src=...>` |
| 时间相对显示(几分钟前) | 手写 `dayjs(...).fromNow()` | `<Statistic.Countdown />` 或 `dayjs.fromNow()`(已 OK)|

**判定标准**:**任何用 4 个以上 inline style 属性(`background + border + borderRadius + color + padding + fontSize` 中 ≥ 4)且渲染"看起来像 antd 已有组件"的 div,都要先查 antd 再决定**。

不在表里的视觉(纯结构性 wrapper / 自定义业务组件),允许手写 div + style。

### A.18 JSX 编辑 / 删除:必须保持结构完整性(硬性)

在既有产物上增删改 JSX(迭代加字段 / 删模块 / 改表单,或转译时替换占位块)最常见的事故是:**误删或漏掉配对闭合标签 → 后续整块被吞 / Babel 编译失败 → 白屏**。删除尤其危险,按 4 步走:

1. **删前先读全结构**:Read 目标区块的完整 JSX 嵌套(从外层容器到内层组件),搞清谁包谁
2. **删时保闭合**:不破坏外层组件的闭合标签,同级元素缩进保持一致
3. **删后验结构**:重新 Read 改动区块,检查标签配对 + 缩进 → `bash scripts/check.sh` 过 → 浏览器打开确认无白屏
4. **复杂嵌套优先整块替换**:先 Read 完整区块 → 本地构建删除后的结构 → 一次 Edit 整段替换,**不要逐行删**

```
// ❌ 反例:删某个 Form.Item 时连带删掉了外层 <div> 容器的闭合标签
//    → 后续所有表单项被吞进残缺结构 / Babel 报 unexpected token → 整页白屏
```

判定:任何删除后,改动区块的 `<Xxx>...</Xxx>` / `<div>...</div>` / `( ... )` 必须配对闭合。这条同样适用于 antd-transform 的分批 Edit —— 替换 PlaceholderModule 时 `old_string` 必须锁定**完整**占位区块(见 `batching.md`),不要只截一半。

### A.19 同一操作在列表页 + 详情页出现时:弹窗共享组件化,且**所有数据源同步补字段**(硬性)

同一个业务操作(发起退款、发货、审核、分配…)经常在**列表页的行操作**和**详情页的操作栏**两个入口都出现。两个入口如果各写一份内联 `<Modal>`,迭代时改了一处忘了另一处,同一操作在两个入口会长得不一样、逻辑对不上。产品评审一定会追问"为什么两处不一致"。

这条规则有**两层**,第二层是最容易踩的隐蔽坑:

**第一层 —— 弹窗抽成一个共享组件,两处引用**

```jsx
// ❌ 错:列表页和详情页各写一个 <Modal title="发起退款">,内容随迭代慢慢分叉

// ✅ 对:抽成一个组件,两处 <RefundModal>
function RefundModal({ open, onClose, order, stage }) {   // App 外定义(A.15),Hook 在顶层(A.13)
  const [checked, setChecked] = useState([]);
  return <Modal ...>{/* 单一实现 */}</Modal>;
}
// 列表页:<RefundModal key={row.id} order={row} stage={orderStage(row.status)} .../>
// 详情页:<RefundModal order={curOrder} stage="paid" .../>
```
状态→策略的映射表(如 `CANCEL_STAGE_MAP`)提到全局常量,两处共用;换数据用 `key={order.id}` 强制重挂重置内部 state。

**第二层 —— 组件依赖的字段,喂给它的每个数据源都要补齐(容易漏)**

共享组件解决了"结构一致",但**没解决"数据源一致"**。列表页和详情页往往从**不同的数据来源**取 `order`:详情页可能是本地 `orderItems`,列表页可能是 `ORDER_ITEMS_MAP[row.id]`。当你给共享组件**新增一个字段依赖**(比如商品项新增 `stage` 用于展示履约阶段),必须**同时给所有数据源补上这个字段**——否则:详情页打开正常、列表页打开该字段全是"—",表面看又是"两处弹窗不一致",实则是数据没同步。

```jsx
// 场景:给 RefundModal 的商品行新增「当前履约阶段」列,依赖 item.stage

// ❌ 错:只给详情页数据补了 stage
const orderItems = [{id:'OI001', name:'...', rhlNo:'...', stage:'paid'}];        // 补了
const ORDER_ITEMS_MAP = {'ORD...':[{id:'I001', name:'...', rhlNo:'...'}]};       // 漏了 stage!
// → 详情页阶段列有值,列表页阶段列全是"—" → 又"不一致"了

// ✅ 对:两个数据源都补 stage
const ORDER_ITEMS_MAP = {'ORD...':[{id:'I001', name:'...', rhlNo:'...', stage:'paid'}]};
```

**判定 / 自检**:
1. 同一 `title` 的 `<Modal>` 在文件里出现 ≥2 个内联定义 = 违规(应是"组件定义 1 处、`<Xxx>` 引用 N 处",grep 组件名核对)。
2. 每次给共享组件**新增或改字段依赖**后,grep 出该组件的所有数据源(详情页局部数组 + 列表页的 MAP/DATA 常量),逐个确认新字段都补了。改共享组件依赖时,"只改了眼前这处数据"是最常见的疏漏。

### A.20 同一对象字面量内禁止重复键(硬性)

同一个 `{}` 里把同一个键写两遍,**JS 静默保留最后一个**,前面那个的值凭空消失。Babel 不报错、页面照常编译,所以它不是"语法问题"而是"数据问题":轻则某行字段显示错,重则下游组件拿 `undefined` 直接白屏。

**为什么必须做成检查项**:这是营销活动原型实测踩到的——mock 数据里 `cause` 写了两遍,A.13~A.17 全绿、浏览器也能打开,只有逐行比对数据才发现某条告警的成因不对。**"能编译 + 能打开"不等于数据对**。

```js
// ❌ 错:cause 写了两遍,前一个被静默丢弃
{ id: 1, cause: 'discount', name: '满$300减$80', cause: 'listing_price' }
// 实际生效的是 cause: 'listing_price',第一个 'discount' 根本不存在

// ✅ 对:一个对象内每个键只出现一次
{ id: 1, cause: 'both', name: '满$300减$80' }
```

**高发场景**:①改字段时"新增一行"而不是"改原来那行" ②分批 Edit 时同一对象被两次补字段 ③从别的对象整段复制粘贴后只改了一部分。

**判定 / 自检**:跑 `bash scripts/check.sh`,A.20 项必须为 0。单独跑:`python3 scripts/check_dup_keys.py 产物.html --verbose`(逐条列出重复的键与行号)。该脚本按大括号作用域逐层判定,嵌套对象里出现同名键、字符串里出现 `xx:` 都不会误报。

### A.21 同一页面内 UI 语言必须唯一(硬性)

**症状**:一个详情页里,基本信息白底裸排、关闭信息灰底块、判责信息白底带边框卡、操作记录品牌红色标题——四个模块四种长相。用户描述为「每个模块的 UI 差异都很大」。

**根因不是"种类多",是"没有一份规定说明什么场景用什么"**。components.md 给的是**有哪些零件**,从没规定**怎么拼**。于是每次加模块都孤立地做那一个、**参照物只有手上这一个模块**,各自都合理,合起来就是五种容器语言。

#### ⚠️ 条文来源分级(先看这个再执行)

每条末尾的标记表示它**凭什么成立**,决定了它的效力:

| 标记 | 含义 | 效力 |
|---|---|---|
| `[用户确认]` | 用户看过实际效果后明确要求的 | **硬性**,不许自行推翻 |
| `[已验证]` | 跑过渲染/脚本,机制层面证实的 | **硬性** |
| `[推断]` | 从现状观察反推出的解释,**没被用户或渲染验证过** | **参考**,与用户判断冲突时以用户为准,并回来改本条 |

**为什么要分级**:2026-08-01 本节曾写入一条「只有一个实体不用卡,卡圈不出任何东西」——来源是 agent 读订单原型后发现"卡只用于包裹物流",据此**反推**出"卡 = 圈定重复实体"这个因果解释。写进 skill **半小时后就被用户推翻**(用户要求退货信息用卡,尽管售后一单一包裹)。
**教训**:观察到的相关性 ≠ 设计意图。**把 agent 的反推解释直接写成硬性判据,是本节最容易犯的错**。新增条文前先问:这是用户确认过的效果、跑出来的机制,还是我自己想出来的解释?

#### 十条

1. **模块骨架唯一** `[用户确认]`:`<div class="lp-module">` + `<h4 class="lp-section">标题</h4>` + 内容。全页只此一种模块标题(黑 15/600 + 1px 底线)。**模块之间的分界靠标题底线,不靠给每块罩容器**
2. **只读字段不进任何容器** `[用户确认]`,白底裸排,走同一个 Grid 组件。**灰底块只剩一个场景**:弹窗里【只读核对区 + 可编辑表单区并存】时,用它给两段划界(它在那里真的在分东西)。纯只读弹窗、纯只读页面一律不用
3. **子区标题分两个场景,各一种写法** `[用户确认]`:
   · **页面级模块内** = `.lp-subtitle`(13/700 + 3px 主色竖条)。用于模块内的次级内容组——表格 / 时间轴 / 独立成组的字段。**模块的首要字段组紧跟模块标题、不点名;其后每一组才点名**。
   · **边框卡内** = 12px / `#9CA3AF` 浅灰字,**不带竖条**。卡的边框已经把这块圈出来了,卡内再用带竖条的强标题是**双重强调**,视觉上会盖过模块标题本身。
   ⚠️ 本条原写作「子区标题只有 `.lp-subtitle` 一种」并标 `[推断]`,2026-08-01 被用户推翻——售后 v16 卡内用了 `.lp-subtitle`,用户要求「不需要品牌红色的小标记,几个字浅灰色即可」。**订单原型「包裹物流」卡内一直用的就是 12px 灰字,当时被误判为"存量不合规"**,实际它才是对的。

   **升格成子区之前先问:能不能就用一个普通字段行?** 图片组、附件组这类"值恰好是一组东西"的内容,**是字段的值,不是独立的组**——做成 `标签 + 缩略图横排` 的普通字段行即可,不要为它单开一个子区标题。子区是给"读法与字段不同的整块内容"(表格、时间轴)用的。
4. **两栏各自独立流动,不做行对齐** `[用户确认 + 已验证]`:分栏按**字段语义**切成两条互不相干的序列,各自从上到下连续排。**禁止为了左右对齐在栏内插空位**;短的那栏下方自然留白。实现上不能用"两栏成对的 rows 数组"(必然产生配对空位),必须是左右各一个独立字段序列。
   ⚠️ **栏容器必须写 `align-content:start`** —— 两栏并排时每栏都是外层栅格的 item,默认 stretch 会把矮栏拉到等高,而 grid 的 `align-content` 在行高 auto 时表现为 stretch,**矮栏的行被平均撑开、栏内凭空多出空隙**。这是"故意留白"最隐蔽的一种成因:代码里没写任何空字段,空隙是 CSS 默认行为造出来的。
   ⚠️ **2026-08-02 补**:这条规则此前只写在这里,而大家真正复制的 `theme.md` `.lp-detail` 定义里**没有这一行** —— 回扫发现商品 v40 / 营销 v14 / 用户管理 v2 **全部缺失**,即"规则写了但产物照样带病"。已把它落进 theme.md 的 CSS 本身。**教训:约束写在规则里,还得落到别人真正会复制的那段东西上,否则等于没写。** `scripts/sketch_detail.py` 已把它接成机械检查(Fail 级)
5. **标签列宽按场景定常量,一个场景一个** `[已验证]`,禁止现场写数字。
   **容器内标签宽 = 该场景的标签宽 − 容器左内边距** —— 这样容器内外的标签落在**同一条竖线**上。
   典型档位:详情页 / 详情页三列 / 弹窗 / 弹窗内灰底只读区 / 边框卡内分区。
   ⚠️ 这个减法此前只写在代码注释里、规则正文没有,结果每加一种容器就有人现场拍数字。
6. **空态两级** `[用户确认]`:字段级 `—`;模块 / 子区级一行灰字。不用虚线空框(空框比它要说的那句话还大)。**子区照出、内容换空态**,不因为没数据就把整个子区吞掉。
   ⚠️ **例外:栏级空态整列不出**,不留空格子也不写一行灰字。因为**栏没有标题**——子区能"照出"是因为它有 `.lp-subtitle` 当载体,栏什么载体都没有,留个空列只是一片白。
   代价要认:整列消失后,那批字段"为什么没有"在页面上就没有任何交代了(如"已判责但还没发起退款"的单,页面上不再有『尚未发起退款』的痕迹)。**接受这个代价的前提是该状态另有出处**(状态 tag、操作记录);没有出处就别用栏,改用子区。
7. **按钮归位** `[推断]`:推进状态的动作只在页头;模块内只留作用于本模块内容的按钮
8. **强调数唯一** `[推断]`:一个模块内只允许一个视觉强调的数字
9. **间距用定值 token** `[已验证]`:模块间 / 模块标题下 / 字段组间 / 子区标题上下,各取一个固定值。**模块末尾字段组的底边距由 CSS 消除**,不逐处手写 `marginBottom`
10. **有先后顺序的事件列表用时间轴,不用表格** `[用户确认]`:表格把「时间 / 状态 / 描述」摊成等重的三格,读起来和普通字段一样平;时间轴的圆点 + 竖线自带方向感。圆点配色一页一套口径

#### ⚠️ 什么时候引入边框卡 `[用户确认]`

卡的作用有**两个**,命中任一即可用卡:

1. **圈定可重复的子实体** —— 一个订单 N 个包裹,卡把「这些字段属于同一个包裹」框起来。
2. **标出数据的来源边界** —— 模块内容不是本域录的,而是**外部系统持续回传、会随时间变**的一段(物流轨迹、支付回执、风控结论)。此时卡的边框就是「本域静态事实」与「外部动态过程」的分界线,**哪怕全页只有一个实例也要用卡**。

判据问一句:**这块内容里的值,明天自己会变吗?** 会 → 它不是我们录的,用卡把它整段圈起来,运营才知道「这段要以外部为准、刷新才是最新的」。不会 → 白底裸排。

售后详情页即第 2 种:一单一包裹(不满足第 1 条),但退货信息里的物流状态与轨迹全部来自承运商系统,而同页的基本信息、判责信息全是运营自己录的。去掉卡以后这三块长得一样,运营会把「已送达」当成我们登记的字段去核对。

**卡的形制不许各自发挥**:边框 1px `#E5E7EB` / 圆角 14 / 头条 `#FAFAFA` + 14-20 内边距 / 分区 16-20 内边距 / 分区间 1px `#F3F4F6` 分隔线。头条 = 左(主标识 + 状态 tag)、右(次要标识);**分区之间靠分隔线划开,不靠加大间距**。

> ⚠️ 这一节曾写着「**只有一个实体 → 不用卡,卡圈不出任何东西**」,已作废。
> 那句话来自 agent 读订单原型后的**反推**——观察到"卡只用于包裹物流",据此推出"卡 = 圈定重复实体"。
> 但从「卡不只用来圈重复实体」推不出「单实体不能用卡」,**它纠正过度了**,写进 skill 半小时就被用户推翻。
> 这是本节「条文来源分级」那张表的由来。

#### 多列分栏切几列、按什么切 `[用户确认]`

**只按「这批字段是谁产生的」切,不按字段数量切。** 一列 = 一个产生源 = 一条从上到下读得通的独立序列。切之前先给每个字段回答「这个值是谁写进来的、什么时候写的」,答案相同的进同一列。

售后判责信息的三列即三个产生源:**列1 判定**(运营在判责弹窗里人判的)/ **列2 算账**(我们按公式算的)/ **列3 执行**(支付域异步回传的,比列2 晚几天)。混排会让运营看不出该找谁核对;按数量平摊则会把「基准 / 扣减 / 最终」这道算式拆到两列去。

- **上限 3 列**。再多则每列净宽放不下最长的 tag 或单号(实测:详情页 3 列在 1280 视口下每列值区 172px,最长值 136px,已无余量给第 4 列)。
- **不该切列的两种**:①**自由文本**(判责说明、关闭说明)——分到 1/3 宽会被挤成竖条,一律整行下沉;②**同源字段被硬拆** —— 反过来说,同一来源的字段不许为了"两边一样高"拆到两列。
- **各列独立流动、不做行对齐**,列长不等是预期结果,**禁止插空位**(同第 4 条)。
- **整列没有内容时,在传给栅格前就把该列 filter 掉**,让 N 列自动降级成 N−1 / 单列。传空数组会留一个空格子、栅格仍按原列数分宽,剩下的列被挤在左边 —— 这是"故意留白"最容易被误判为 bug 的一种。
- 列内表达算式时,在**结果行上方**插 1px 细分隔线(`grid-column:1/-1`)代替加粗分组;结果行是全模块**唯一**的视觉强调数(第 8 条)。

#### 判定 / 自检

改完**逐模块列一张表**:容器 / 标题层级 / 栅格与标签宽 / 空态。**四列里出现两种以上写法就是不合格**,除非能说出各自的适用场景。

```bash
# 这张表现在自动出(逐模块 容器/子区标题/栅格与标签宽/空态 + 版式草图 + 机械检查)
python3 scripts/sketch_detail.py 产物.html --page 详情
python3 scripts/check_ui_lang.py 产物.html --verbose
grep -oE 'labelWidth=\{?[0-9]+' 产物.html            # 硬编码宽度,应为 0
```

⚠️ **脚本只数种类、不懂场景**。数出多种 ≠ 不合格——弹窗窄、详情页宽本来就该不同。**判据是"每种是否有明确写下来的适用场景"**,没写下来的才是问题。脚本报出的每一项,都要能在代码注释或本规则里找到它的适用场景说明。

#### 新增模块时(最容易破防的时刻)

**先读同页已有模块用的是什么语言,照它写**;需要新语言时,**先回来改本规则**、再全页统一改造,不要只在新模块上用。

#### A.21-11 详情页版式先出草图确认,再写 JSX `[用户确认]`

本节从 A.21-1 到这里全是**约束**——它们回答"这样做对不对",在你已经做完决定之后才起作用。
但售后 13 轮返工里,**绝大多数不是违反了某条约束,是版式决定本身选错了**
(切几栏、谁进卡、谁下沉整行、时间类字段放哪)。约束拦不住选错,只能拦住做错。

所以补一条**构造性**的:**业务单据详情页动 JSX 之前,先把「容器 / 分栏 / 下沉」三个决定
写成纯文本草图,交产品确认。** 做法、草图格式、默认版式在
`references/detail-page-blueprint.md`,流程位置在 SKILL.md § 详情页版式确认点。

**来源**:2026-08-01 用户原话「后台原型的详情页,每次都要花很多时间调布局和 UI,太浪费时间了」;
同一轮里唯一一次先给版式方案(三个 ASCII 草图)再写码的第 9 轮,**落地版式一次通过**。

⚠️ **草图和本节十条不是两套东西**:草图是在本节允许的范围内做选择,
blueprint 里每一个默认答案都对应本节的某一条(默认裸排=第 2 条、按产生源切栏=多列分栏段、
栏不对齐=第 4 条、整行下沉=多列分栏段、空态两级=第 6 条)。
**改了本节任一条,回去同步 blueprint;反过来也一样。**

## B. 无法原生还原清单

antd 6.4.x 表达不了的视觉/交互项。这些**不要 hack 也不要假装实现**,在自检报告"视觉妥协"段落如实标注。

| # | spec 要求 | 为何不能 | 处理方案 |
|---|---|---|---|
| 1 | **菜单激活态左 3px 品牌红色边框** | Menu 无 token 暴露 item border-left;Semantic DOM 不到 selected 态 | **不实现**。激活态用纯色背景 + 加粗 + 主色文字表达 |
| 2 | **菜单激活态渐变背景** `linear-gradient(90deg, rgba(164,0,42,.1), transparent)` | `itemSelectedBg` token 只接纯色 | **降级为纯色 `#FCEEEF`**(已固化在 theme.md 的 Menu.itemSelectedBg) |
| 3 | **表头 uppercase + letter-spacing 0.02em** | Table Semantic DOM 不暴露 header cell,无对应 token | **不实现**。接受 antd 默认表头(正常字重、无 uppercase) |
| 4 | **菜单 L1/L2 分级 padding**(L1:12-16, L2:10-16-10-44) | Menu 只有全局 `inlineIndent`,不能分级 | **接受 antd 默认间距** |

新增的"无法还原"项必须在转译时立即记录到这里(skill 自检流程的副产品)。

## C. 超范围处理(逃生门)

### C.0 ⚠ 先判定:这是不是真的超范围?

"超范围"**不等于**"不在 components.md 29 个子集里"。判定标准:**只有 antd 6.4.x 完全没有该能力 + React 基础能力也搞不定**,才算超范围。

#### 判定流程(必走)

1. **查 antd CLI 确认**(如有 `@ant-design/cli`):
   ```bash
   antd list --version 6.4.0 --format json | grep -i "<能力关键词>"
   antd info <ComponentName> --version 6.4.0 --format json
   ```
   如果 antd 有该组件 → **不是超范围**,补到 components.md 用法清单后正常使用
2. **是不是 React 基础能力能搞定?**
   - 条件渲染、字段联动、状态切换、tabs/steps 分组 → **不是超范围**,正常实现
   - 比如"值约束变化时显示/隐藏子区块" = `{type==='size' && <SizeBlock/>}`,纯 React,不是超范围
3. **PRD 全局约定的功能不允许跳过**:
   - 比如"停用类有关联数据弹影响范围预览"是全局约定 → 即使原型某模块没画,也不能不实现
   - 跳过这类功能不是超范围,是漏需求

#### 真正的超范围(只有这几类)

| 类别 | 例 | antd 缺什么 | 建议三方 |
|---|---|---|---|
| 富文本编辑 | 商品描述 / 公告正文 | antd 无 RichText | `react-quill` / `@wangeditor/editor-for-react` |
| 图片裁剪 | 主图编辑 | antd 无 ImageCrop | `react-image-crop` |
| 拖拽排序(复杂) | 表格行 / 卡片 / 树节点 | antd Sortable 只覆盖基础场景 | `@dnd-kit/sortable` / `react-beautiful-dnd` |
| 多图排序 | SKU 图册排版 | Upload listType="picture-card" 不支持拖动 | `react-sortablejs` |
| 思维导图 / 流程图 | 工作流配置 | 无 | `@xyflow/react` |
| 复杂图表 | 漏斗 / 桑基 / 热力图 | antd 无图表(Statistic 只算 KPI) | `@ant-design/charts` / `echarts` |
| Markdown 编辑 | 文档编辑 | 无 | `@uiw/react-md-editor` |
| 复杂权限矩阵编辑 | 角色 × 资源 × 操作 | 无 | 自定义 + react-table |

**任何其他需求**:先按"判定流程"走,不要直接跳到 C.1 放占位。

### 处理步骤(确认真超范围后)

1. **在产物里放占位组件**

```jsx
<div style={{
  border: '2px dashed #D1D5DB', borderRadius: 10, padding: 24,
  background: '#FAFAFA', color: '#6B7280', textAlign: 'center'
}}>
  <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 4 }}>
    📌 待集成:{需求名}
  </div>
  <div style={{ fontSize: 12 }}>
    antd 6.4.x 无原生组件,需要在实际后台开发阶段集成{建议方案}
  </div>
</div>
```

2. **在自检报告"超范围"段落记录**

```markdown
### 超范围项

| 位置 | 需求 | 占位描述 | 建议集成方案 |
|---|---|---|---|
| `page-spu-edit` 描述字段 | 富文本编辑器 | 占位 div | `react-quill` 或 `@wangeditor/editor-for-react` |
| `page-product-edit` 主图 | 图片裁剪 | 占位 Upload | `react-image-crop` |
```

3. **明确告知**:"该需求超出 skill 范围,**建议在实际后台开发阶段调用 antd / ant-design 官方 skill 处理**"

### 常见超范围项

- 富文本编辑器(描述、文章正文)
- 图片裁剪 / 多图排序
- Markdown 编辑器
- 思维导图 / 流程图编辑
- 复杂图表(echarts / G2)
- 拖拽排序(antd v6 有 Sortable,但复杂场景需要 react-dnd)
- 文件树编辑(antd Tree 支持基础操作,复杂的需要 react-dnd-tree)
- 复杂权限矩阵编辑器
- 工作流配置画布

## D. 表格列宽决策(v3 标准)

**总则**:**业务逻辑 > 视觉**,但表格出现横向滚动严重影响体验,所以列宽要按表的特征分类处理。

### 决策矩阵

| 表特征 | scroll | 列 width | 操作列 fixed |
|---|---|---|---|
| **≤6 列,有长文本列能自然撑满** | **不设 scroll** | **不设 width**(auto-layout 均摊) | 不用 fixed,直接最右列 |
| **≤6 列,内容普遍短(数字/标签/日期为主)** | **不设 scroll** | **所有列设比例 width** | 不用 fixed,直接最右列 |
| **≥7 列,内容长 / 操作多** | `scroll={{ x: 'max-content' }}` | **所有列设 width** | `fixed: 'right'` |
| **少列但有行内编辑或长字段** | 设 scroll | 所有列 width | 操作列 fixed |

### ≤6 列的两种情况判断

**判断标准**:看除操作列外的数据列,是否有至少一列内容足够长(名称、描述、路径等),能在均摊时自然占满分配到的宽度。

- **有长文本列** → 不设 width,auto-layout 均摊效果好(长文本列自然填满空间)
- **没有长文本列**(列内容以数字、状态标签、短日期、ID 为主) → 均摊导致每列都很宽但内容只占一角,操作列被推到最右边,用户鼠标距离远。此时应给所有列按内容比例设 width,Ant Design 会按比例缩放填满表格,短内容列窄、长内容列宽,操作列自然靠近数据。

### 反例(我们犯过的错)

```jsx
// ❌ 错:只有 6 列,但中间一列没设 width
const columns = [
  { title: '货币代码', dataIndex: 'code', width: 110 },
  { title: '货币名称', dataIndex: 'name' },           // ← 这列吃掉所有剩余空间,变得超大
  { title: '符号',     dataIndex: 'symbol', width: 80 },
  ...
];

// ✅ 对:全部不设 width,走 auto-layout 均摊(适用于有长文本列的表格)
const columns = [
  { title: '货币代码', dataIndex: 'code' },
  { title: '货币名称', dataIndex: 'name' },
  { title: '符号',     dataIndex: 'symbol' },
  ...
];

// ❌ 错:≤6 列全部不设 width,但内容普遍短 → 操作列被推到最右边
columns={[
  { title: '类目', dataIndex: 'cat' },          // 内容:"手提包"(3字)
  { title: '类目路径', dataIndex: 'path' },      // 内容:"箱包 > 手提包"(7字)
  { title: '槽位数', dataIndex: 'n' },           // 内容:"5"(1字)
  { title: '状态', dataIndex: 'st' },            // 内容:标签
  { title: '最近更新', dataIndex: 't' },         // 内容:"2026-05-20"
  { title: '操作', key: 'op', width: 80 },       // ← 被推到 1120px 处,距数据很远
]}

// ✅ 对:内容普遍短时,所有列设比例 width
columns={[
  { title: '类目', dataIndex: 'cat', width: 120 },
  { title: '类目路径', dataIndex: 'path', width: 240 },   // 相对最长,给最大比例
  { title: '槽位数', dataIndex: 'n', width: 80 },
  { title: '状态', dataIndex: 'st', width: 80 },
  { title: '最近更新', dataIndex: 't', width: 140 },
  { title: '操作', key: 'op', width: 80 },                // 按比例缩放后自然靠近数据
]}
```

### 关键原理(给 AI 看)

- 不设 `scroll.x` 时,Table 默认 `tableLayout="auto"`(浏览器原生)→ 列按内容自适应,剩余空间按内容比例分摊 ≈ 均摊
- 设 `scroll.x` 时,Table 切到 `tableLayout="fixed"` → 必须给所有列设 width,否则未设的列吃所有剩余空间
- `fixed: 'right'` 需要配合 `scroll.x` 才生效,没 scroll 时反而触发 fixed-layout 副作用
- 所有列都设 width 且不设 scroll 时,Ant Design 按各列 width 的**比例**缩放到填满表格宽度,视觉效果 = 按比例分配空间

## E. v3 转译标准(antd 原生 API 升级清单)

每次转译时优先使用以下 antd 原生能力,而不是手写:

| 项 | 旧做法 | v3 标准 |
|---|---|---|
| 开始日期 + 结束日期 | 两个独立 `<DatePicker>` | `<DatePicker.RangePicker placeholder={['开始日期','结束日期']} />` |
| 搜索 Input | 纯 `<Input>` | `<Input prefix={<SearchOutlined />} allowClear />` |
| 查询按钮 | 纯文字 | `<Button type="primary" icon={<SearchOutlined />}>查询</Button>` |
| 重置按钮 | 纯文字 | `<Button icon={<ReloadOutlined />}>重置</Button>` |
| 导入/导出按钮 | 纯文字 | 加 `<ImportOutlined />` / `<DownloadOutlined />` |
| 上传拖拽区 | 手写 `<div class="dashed-zone">` | `<Upload.Dragger accept="..." beforeUpload={()=>false}>` |
| 预览表底部统计 | 表格下方独立 `<div>` | `<Table summary={() => <Table.Summary.Row>...</Table.Summary.Row>}>` 内嵌 |
| 行内编辑数字 | 自己 state + InputNumber | `<EditableNumber>` 业务组件(见 components.md B.10) |
| 多选筛选 | 多个 Select 串联 | `<Select mode="multiple">` |
| 标签输入 | 手写 chip 输入框 | `<Select mode="tags">` |
| 层级选择 | 多级 Select 串联 | `<TreeSelect>` 或 `<Cascader>` |

## F. 自检流程(每个产物完成前)

### F.1 人工对照(按 A-E 段逐项过)

1. **A 段硬性规则**——操作列 Button / Tooltip / Modal / 菜单 icon / 4 种空态 / Tag pill 圆角 / 空值显示 / 默认排序 / 字号 → 任一违反就修
2. **D 段列宽决策**——表是少列还是宽列?对应规则是否应用?
3. **E 段 v3 标准**——能用 antd 原生的地方是否都用了?
4. **B 段无法还原项**——清单内已知项是否如实标注?新发现的是否补到清单?
5. **C 段超范围判定**——先走 C.0 判定流程(查 antd CLI / 想 React 基础能力),确认真超范围再放占位

### F.2 静态检查清单(必须全跑,任一非 0 即修)

**跑 `scripts/check.sh`(一键)**:

```bash
bash scripts/check.sh outputs/产物.html
```

输出形如:
```
▶ 检查产物: outputs/looply-XXX-antd.html
── A.13 React Hook 写法 ──  ✅ IIFE 数 = 0
── A.16 JSX 字符串属性 ──  ✅ 无嵌套引号
── A.14 Table rowKey ──  ✅ Table=12 rowKey=12
── A.4.1 菜单 icon ──  ✅ 全部 @ant-design/icons
── A.17 div+style 仿 antd 组件 ──  ⚠ 发现 2 处(人工 review)
── A.3 Modal 配置 ──  ✅ closable+maskClosable+centered 三件套覆盖
── CDN 锁定 / antd 版本 ──  ✅
── 全局 .ant-* CSS 覆盖 ──  ✅
═══════════════════════════════════════
  Pass: 7 / Warn: 1 / Fail: 0
═══════════════════════════════════════
```

**退出码语义**:
- `0` = 全过 → 可交付
- `1` = 有 ⚠ → 人工 review(如 A.17 div+style 命中,看是不是合法 wrapper)
- `2` = 有 ❌ → 必须修复后重跑

**check.sh 覆盖**(每项对应 A 段一条):

| 检查 | A 段 | 实现 |
|---|---|---|
| IIFE+Hook 精确判定(排除 useMemo 误报)| A.13 | `scripts/check_iife_hook.py` |
| JSX 中文嵌套 ASCII 双引号 | A.16 | `scripts/check_jsx_quotes.py` |
| Table rowKey 覆盖 | A.14 | `check.sh` 内 grep |
| 菜单 icon 禁 Emoji | A.4.1 | 同上 |
| div+style 仿造 antd(启发式)| A.17 | 同上 |
| Modal 三件套(closable+maskClosable+centered)| A.3 | 多行属性容错 grep |
| CDN 锁定 + antd 版本 | theme.md A.1 | 同上 |
| 禁 `.ant-*` 全局覆盖 | SPEC.md | 同上 |

**新发现违规模式时**:改 `scripts/check.sh`(或加 helper py),不要回到本文档粘贴一条裸 grep。文档里只放"为什么"的解释,具体命令一律在 scripts/。

### F.2.1 check.sh 未覆盖项(独立查)

```bash
# A.14 补充:.map 用 index 作 key
grep -nE "\.map\(\(?[a-zA-Z_]+,\s*[a-zA-Z_]+\)?\s*=>\s*<[A-Z][a-zA-Z]*\s+key=\{[a-zA-Z_]+\}" 产物.html
# 期望为空。反模式:`.map((item, i) => <Row key={i} ... />)`

# A.1 补充:<a onClick=... 做操作列
grep -nE "<a [^>]*onClick=" 产物.html
# 期望为空(必须用 <Button>)

# A.2 补充:<Tooltip> + InfoCircleOutlined(应统一用 TipText 业务组件)
grep -B1 -A1 "<InfoCircleOutlined" 产物.html | grep -i tooltip
# 期望为空
```

这些是低频违规,需要时手动跑。常态化后可以并入 check.sh。

### F.3 运行自检的明确告知(subagent 必做)

subagent 通常无浏览器,**不能真跑**。但必须在交付回复里显式写一行:

> ⚠ 未做浏览器运行测试。请打开产物 + 点击 ≥3 个非首页(列表/新建/编辑)+ 切换菜单展开收起,确认:
> 1. 控制台无 React 错误(尤其 #300 / #310 / #321)
> 2. 左侧 Sider 长菜单可正常滚动,不超出 viewport
> 3. 弹窗 / Tabs / Steps 切换无白屏

把验收责任明确传递给调用方。

### F.4 任何项不达标处理

**修复后再写自检报告**,不要把"我没修的问题"写进报告糊弄。如果时间不够,在 self-check 报告"6. 自主优化项"或新增的"7. 已知未修问题"段落显式列出,而非藏起来。
