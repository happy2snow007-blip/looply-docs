# components.md — 组件子集 + .lp-* 业务组件 + JSX 模板

> 转译时按需查本文件。**按场景读对应段,不要全文 Read**(本文 700+ 行)。

## 目录(按场景导航)

| 段 | 内容 | 大致行号 |
|---|---|---|
| **A. antd 组件子集(29 个)** | 按场景挑用 | 24-318 |
| § A.1 布局 / A.2 导航 / A.3 表单 / A.4 数据展示(含 Dropdown 收纳)/ A.5 反馈 / A.6 全局 | Layout / Menu / Button / Table / Dropdown / Modal / ConfigProvider 等 | |
| **B. .lp-* 业务组件(10 个)** | **必读全部**(React 实现可整段抄) | 319-587 |
| § B.1 Kpi · B.2 StatusTag · B.3 TipText · B.4 CompactPagination · B.5 Empty* · B.6 FormRow · B.7 RadioCardGroup · B.8 OpLog · B.9 InlineProgress · B.10 EditableNumber | | |
| **C. 高层 JSX 模板**(⭐ 强烈推荐) | ListPage / FormPage / WizardPage / DetailPage | 588-722 |
| **D. PRD 字段术语 → antd 组件映射** | 解析 PRD 时查 | 723-743 |

**按场景读**:
- 转列表页 → § A.4 Table + § B.5 Empty + § C.1 ListPage
- 转表单页 → § A.3 + § B.6 FormRow + § C.2 FormPage
- 转向导页 → § A.3 + § B.7 RadioCardGroup + § C.4 WizardPage
- 写主题 → 看 `theme.md`

CSS 在 `theme.md` 的 D 段。

## A. antd 组件子集(原型场景,29 个)

### A.1 布局

#### Layout / Layout.Header / Layout.Sider / Layout.Content

```jsx
<Layout style={{ height: '100vh' }}>
  <Layout.Header style={{ borderBottom: '1px solid #E5E7EB', display:'flex', alignItems:'center' }}>
    {/* Logo:必须 base64 嵌入新版 logo.svg,禁止字体模拟 — 见 theme.md A.0 */}
    <img src={LOGO_SRC} alt="Looply" style={{ width: 118, height: 'auto', display: 'block' }} />
    <div style={{ width:1, height:20, background:'#E5E7EB', margin:'0 16px' }} />
    <span style={{ fontSize:14, fontWeight:500, color:'#6B7280' }}>{系统名}</span>
    <span style={{ marginLeft:'auto', color:'#9CA3AF', fontSize:13 }}>{面包屑}</span>
  </Layout.Header>
  <Layout>
    <Layout.Sider width={220} theme="light" style={SIDER_STYLE}>
      <Menu mode="inline" items={menuItems} selectedKeys={[activeKey]} ... />
    </Layout.Sider>
    <Layout.Content style={{ padding:28, overflow:'auto' }}>{content}</Layout.Content>
  </Layout>
</Layout>
```

**整页布局总览**(对照理解 Header / Sider / Content 三块关系;数值以 theme.md 为准):

```
┌─ Header (60px, white, border-bottom #E5E7EB) ────────────────────┐
│  Logo(base64 SVG, w118) │ divider │ 系统名 ............... 面包屑       │
├───────────┬──────────────────────────────────────────────────────┤
│ Sider     │  Content (padding: 28px, bg: #F9FAFB)                │
│ 220px     │  Card { padding: 28px, radius: 16px, +shadow }       │
│ white     │                                                       │
│ overflow  │  Sider 高度由外层 <Layout style={{height:'100vh'}}> 撑开 │
└───────────┴──────────────────────────────────────────────────────┘
```

#### Card

`<Card style={CARD_STYLE}>` 包裹每个 Page。

#### Space

填工具栏 / 操作列 / 按钮组,`size={12} wrap` 或 `size={6}` 紧凑。

### A.2 导航

#### Menu

- 三级菜单:items 嵌套 children 数组
- icon 必需:每个 item 必有 `icon` prop(`<AppstoreOutlined />` 类)
- 激活态加粗:label 用 JSX 包,根据 activeKey 切 fontWeight

```jsx
const subLabel = (text, key) => <span style={{ fontWeight: activeKey === key ? 600 : 400 }}>{text}</span>;

const menuItems = [
  { key: 'overview', icon: <AppstoreOutlined />, label: subLabel('总览', 'overview') },
  { type: 'divider' },
  {
    key: 'mgmt', icon: <FolderOutlined />, label: '管理',
    children: [
      { key: 'item-1', icon: <FileOutlined />, label: subLabel('项 1', 'item-1') },
    ],
  },
];

<Menu mode="inline" items={menuItems} selectedKeys={[activeKey]}
  defaultOpenKeys={['mgmt']} style={{ borderInlineEnd: 'none' }}
  onClick={({ key }) => setActiveKey(key)} />
```

#### Breadcrumb

```jsx
<Breadcrumb items={[
  { title: <a onClick={onBack}>列表</a> },
  { title: '详情' },
]} />
```

#### Tabs

```jsx
<Tabs defaultActiveKey="basic" items={[
  { key: 'basic', label: '基本信息', children: <BasicTab /> },
  { key: 'related', label: '关联数据', children: <RelatedTab /> },
]} />
```

#### Steps

```jsx
<Steps current={step} items={[
  { title: '步骤 1' }, { title: '步骤 2' }, { title: '步骤 3' },
]} />
```

### A.3 表单

#### Button

```jsx
<Button type="primary" icon={<SearchOutlined />}>查询</Button>
<Button icon={<ReloadOutlined />}>重置</Button>
<Button danger>删除</Button>
<Button size="small" onClick={...}>编辑</Button>  // 表格操作列
```

#### Input / Input.TextArea / Input.Password

```jsx
<Input placeholder="搜索…" prefix={<SearchOutlined style={{ color:'#9CA3AF' }} />} allowClear />
<Input.TextArea rows={3} placeholder="..." />
<Input.Password defaultValue="..." />
```

#### Select

```jsx
<Select defaultValue="" style={{ width:140 }}
  options={[{ value:'', label:'全部' }, ...]} />

<Select mode="multiple" placeholder="..." style={{ width:300 }} options={...} />

<Select mode="tags" placeholder="按 Enter 添加" />  // 标签输入
```

**必须显式给 `width`(硬性)**:`Select` 不像 `Input`/`InputNumber` 那样有默认 100% 宽度,**只写 `maxWidth` 不写 `width` 会被内容撑成很窄一条**,多选态尤其明显——选项文字被截断、placeholder 显示不全,看起来像坏了。

```jsx
// ❌ 只给上限,实际宽度由内容决定 → 表单里显示成很短一截
<Select mode="multiple" placeholder="从商品标签中选择" style={{ maxWidth: 460 }} options={...} />

// ✅ 表单内多选:撑满控件区 + 给上限
<Select mode="multiple" placeholder="从商品标签中选择"
  style={{ width: '100%', maxWidth: 560 }} options={...} />

// ✅ 工具栏筛选器:固定窄宽度
<Select defaultValue="" style={{ width: 140 }} options={...} />
```

选宽度的经验值:工具栏筛选 120-200px 固定;表单内单选 240-360px;**表单内多选一律 `width:'100%'` + `maxWidth` 兜底**(选中项多时才不会挤成多行小格子)。同一表单内同类多选控件宽度要一致。

#### InputNumber

```jsx
<InputNumber defaultValue={100} step={1} style={{ width: '100%' }} />
// 行内编辑用 size="small"
<InputNumber autoFocus size="small" value={val} style={{ width: 100 }}
  onBlur={...} onPressEnter={(e) => e.target.blur()} />
// controls 默认 true(spinner),与 chrome 原生 input[number] 行为对齐
```

#### DatePicker / DatePicker.RangePicker

```jsx
<DatePicker placeholder="选择日期" style={{ width:'100%' }} />
<DatePicker.RangePicker placeholder={['开始日期','结束日期']} />  // 优先用这个,不要拆成两个 DatePicker
```

#### Checkbox / Checkbox.Group

```jsx
<Checkbox defaultChecked>同意条款</Checkbox>
<Checkbox.Group defaultValue={['a','b']} options={[
  { value:'a', label:'选项 A' }, { value:'b', label:'选项 B' },
]} />
```

#### Radio.Group

```jsx
<Radio.Group defaultValue="opt1" options={[
  { value:'opt1', label:'选项 1' }, { value:'opt2', label:'选项 2' },
]} />
// 大卡片样式(spec 见 .lp-radio-card-group)用业务组件 <RadioCardGroup>
```

#### Upload / Upload.Dragger

```jsx
<Upload listType="picture-card" maxCount={5} beforeUpload={() => false}>
  <div><PlusOutlined /><div style={{ marginTop:8, fontSize:12 }}>上传</div></div>
</Upload>

<Upload.Dragger name="file" multiple={false} accept=".xlsx,.csv" beforeUpload={() => false}>
  <p className="ant-upload-drag-icon"><InboxOutlined style={{ color:'#A4002A' }} /></p>
  <p className="ant-upload-text">点击或拖拽文件到此处上传</p>
  <p className="ant-upload-hint">支持 .xlsx / .csv,单次最多 500 条</p>
</Upload.Dragger>
```

### A.4 数据展示

#### Table

详见 `rules.md` D 段(列宽决策)。

```jsx
<Table rowKey="id" columns={columns} dataSource={data} pagination={false}
  styles={TABLE_STYLES}
  // 仅当列数 ≥7 + 有 fixed:'right' 时才传 scroll
  scroll={{ x: 'max-content' }}
/>
```

支持 `<Table.Summary>` 内嵌底部统计:

```jsx
<Table ... summary={() => (
  <Table.Summary fixed>
    <Table.Summary.Row>
      <Table.Summary.Cell index={0} colSpan={4}>共 X 条,Y 通过,Z 失败</Table.Summary.Cell>
    </Table.Summary.Row>
  </Table.Summary>
)} />
```

#### Dropdown(操作列"更多"收纳)

操作列按钮 > 4 个时,用 Dropdown 收纳次要 / 危险操作(规则见 `rules.md` A.1.1)。

```jsx
<Dropdown trigger={['click']} menu={{ items: [
  { key: 'copy', label: '复制' },
  { key: 'log',  label: '操作日志' },
  { type: 'divider' },
  { key: 'del',  label: '删除', danger: true },   // 危险操作标红
], onClick: ({ key }) => handle(key) }}>
  <Button size="small" icon={<EllipsisOutlined />} />
</Dropdown>
```

`menu.items` 结构同 Menu items(`key` / `label` / `danger` / `type:'divider'`)。触发器固定用 `<Button size="small" icon={<EllipsisOutlined />} />`,不要用纯文字"更多"。

#### Tag

**永远配合 `<StatusTag variant={...}>` 业务组件用,不要直接写 Tag**(详见 B 段)。

#### Tooltip

字段提示统一用 `<TipText>` 业务组件(详见 B 段)。

#### Tree

层级数据展示(类目、组织、文件夹等):

```jsx
<Tree treeData={data} defaultExpandAll showLine={{ showLeafIcon: false }}
  titleRender={(node) => (
    <div style={{ display:'flex', justifyContent:'space-between', width:'100%', gap:16 }}>
      <span>{node.title}</span>
      <Space size={6}>
        <Button size="small" onClick={() => edit(node)}>编辑</Button>
      </Space>
    </div>
  )} />
```

#### Badge

```jsx
<Badge count={2} style={{ backgroundColor:'#DC2626' }} />
```

#### Progress

进度条用 Progress;表格行内进度用业务组件 `<InlineProgress>`(详见 B 段)。

```jsx
<Progress percent={62} showInfo={false} strokeColor="#A4002A" trailColor="#E5E7EB" />
```

### A.5 反馈

#### Modal

**Modal 硬性规则**(详见 `rules.md` A 段):
- `closable={false}`
- `maskClosable={true}`
- 底部 footer 自定义

```jsx
<Modal title="新增类目" open={open} onCancel={onClose}
  closable={false} maskClosable={true} width={480}
  footer={[
    <Button key="c" onClick={onClose}>取消</Button>,
    <Button key="s" type="primary" onClick={onSave}>保存</Button>,
  ]}>
  {/* 内容 */}
</Modal>
```

#### Alert

不同语义提示条(替代手写紫/橙/红色 div):

```jsx
<Alert type="info"    showIcon={false} message="提示信息" />
<Alert type="warning" showIcon={false} message="警告" />
<Alert type="error"   showIcon={false} message="错误" />
<Alert type="success" showIcon={false} message="成功" />
```

### A.6 全局

#### ConfigProvider

`<ConfigProvider theme={looplyTheme}>` 包整个 App。

## B. .lp-* 业务组件(React 实现,可直接复用)

### B.1 Kpi(统计卡)

```jsx
function Kpi({ num, label, numStyle, onClick }) {
  return (
    <div className="lp-kpi" style={onClick ? { cursor: 'pointer' } : null} onClick={onClick}>
      <div className="label" style={{ marginBottom: 6 }}>{label}</div>
      <div className="num" style={numStyle}>{num}</div>
    </div>
  );
}
```

### B.2 StatusTag(语义化 Tag)

```jsx
const TAG_COLORS = {
  on: {bg:'#F0FDF4',color:'#16A34A'}, sale: {bg:'#EFF6FF',color:'#2563EB'},
  pending: {bg:'#FFFBEB',color:'#D97706'}, off: {bg:'#F3F4F6',color:'#6B7280'},
  req: {bg:'#FEF2F2',color:'#DC2626'}, warn: {bg:'#FFF1F2',color:'#E11D48'},
  desc: {bg:'#F0FDF4',color:'#16A34A'}, enum: {bg:'#FFFBEB',color:'#D97706'},
  opt: {bg:'#F3F4F6',color:'#6B7280'},
};

function StatusTag({ variant, children, closable, onClose }) {
  const c = TAG_COLORS[variant] || TAG_COLORS.off;
  return (
    <Tag bordered={false} closable={closable} onClose={onClose}
      style={{ background:c.bg, color:c.color, borderRadius:999, padding:'2px 8px',
               fontSize:12, lineHeight:'18px', marginInlineEnd:4 }}>
      {children}
    </Tag>
  );
}
```

### B.3 TipText(字段提示,虚线下划线 hover)

```jsx
function TipText({ label, tip }) {
  return (
    <Tooltip title={<div style={{ whiteSpace:'pre-line', lineHeight:1.6 }}>{tip}</div>}
      color="#fff"
      styles={{ body: { color:'#374151', fontSize:12, padding:'10px 14px' } }}>
      <span className="lp-tip-trigger">{label}</span>
    </Tooltip>
  );
}
```

### B.4 CompactPagination(spec 方案 B 紧凑分页器)

```jsx
function CompactPagination({ total, current=1, pageSize=10, totalPages }) {
  const pages = React.useMemo(() => {
    const tp = totalPages || Math.ceil(total / pageSize) || 1;
    const out = [{ k:'prev', label:'<', disabled:current===1, arrow:true }];
    if (tp <= 6) for (let i=1; i<=tp; i++) out.push({ k:i, label:i });
    else { out.push({k:1,label:1}); out.push({k:2,label:2}); out.push({k:3,label:3}); out.push({k:'gap',label:'…',disabled:true}); out.push({k:tp,label:tp}); }
    out.push({ k:'next', label:'>', disabled:current===tp, arrow:true });
    return out;
  }, [current, totalPages, total, pageSize]);
  const tp = totalPages || Math.ceil(total / pageSize) || 1;
  return (
    <div className="lp-pagination">
      <span>共 {total.toLocaleString()} 条,每页{' '}
        <Select size="small" value={pageSize} style={{ width:72, marginInline:4 }}
          options={[{value:10,label:10},{value:20,label:20},{value:50,label:50}]} />{' '}条</span>
      <div className="divider" />
      <Space size={2}>
        {pages.map(p => (
          <span key={p.k} style={{
            minWidth:32, height:32, display:'inline-flex', alignItems:'center', justifyContent:'center',
            borderRadius:8, fontSize:13, cursor:p.disabled?'default':'pointer',
            background:p.k===current?'#A4002A':(p.arrow?'#fff':'transparent'),
            color:p.k===current?'#fff':'#374151',
            border:p.arrow?'1px solid #E5E7EB':'none',
            fontWeight:p.k===current?600:400, opacity:p.disabled?0.35:1,
          }}>{p.label}</span>
        ))}
      </Space>
      <div className="divider" />
      <span>第 {current}/{tp} 页</span>
    </div>
  );
}
```

### B.5 EmptyZero / EmptyNoMatch / EmptyError / EmptyStateSwitcher(4 种空态)

```jsx
function EmptyZero({ entity, cta, onCta }) {
  return <div className="lp-empty"><InboxOutlined className="icon" />
    <div className="title">暂无{entity}</div>
    <div className="desc">点击下方按钮创建第一个{entity}</div>
    {cta && <Button type="primary" onClick={onCta}>{cta}</Button>}
  </div>;
}
function EmptyNoMatch({ onClear }) {
  return <div className="lp-empty"><SearchOutlined className="icon" />
    <div className="title">未找到匹配结果</div>
    <div className="desc">请尝试调整搜索关键词或筛选条件</div>
    <Button onClick={onClear}>清除筛选条件</Button>
  </div>;
}
function EmptyError({ onRetry }) {
  return <div className="lp-empty"><ExclamationCircleOutlined className="icon err" />
    <div className="title">加载失败</div>
    <div className="desc">网络异常,请检查网络连接后重试</div>
    <Button type="primary" onClick={onRetry}>重试</Button>
  </div>;
}
function EmptyStateSwitcher({ mode, setMode }) {
  return (
    <div style={{ marginTop:12, display:'flex', gap:8, justifyContent:'center' }}>
      {[['data','正常数据'],['zero','零数据态'],['no-match','无匹配态'],['error','异常态']].map(([k, label]) =>
        <Button key={k} type={mode===k?'primary':'default'} onClick={() => setMode(k)}>{label}</Button>
      )}
    </div>
  );
}
```

### B.6 FormRow(表单只读字段行)

```jsx
function FormRow({ label, required, children, helper }) {
  return (
    <>
      <div className="lp-form-row">
        <div className="lp-form-label">{required && <span className="req">*</span>}{label}</div>
        <div className="lp-form-control">{children}</div>
      </div>
      {helper && <div className="lp-helper">{helper}</div>}
    </>
  );
}
```

### B.7 RadioCardGroup(大卡片单选)

```jsx
function RadioCardGroup({ value, onChange, options }) {
  return (
    <div className="lp-radio-card-group">
      {options.map(o => (
        <label key={o.value} className={'lp-radio-card' + (value === o.value ? ' active' : '')}
          onClick={() => onChange(o.value)}>
          <input type="radio" checked={value === o.value} onChange={() => {}} style={{ accentColor:'#A4002A' }} />
          <span>
            <div className="title">{o.title}</div>
            <div className="desc">{o.desc}</div>
          </span>
        </label>
      ))}
    </div>
  );
}
```

### B.8 OpLog(操作记录区块,所有编辑页/详情页通用)

```jsx
const DEFAULT_OPLOG = [
  { i:1, at:'2026-04-13 15:20', who:'张运营', type:'编辑', detail:'修改字段:排序 10 → 20' },
  { i:2, at:'2026-04-10 11:00', who:'王管理', type:'创建', detail:'创建记录' },
];

function OpLog({ types, data, total }) {
  return (
    <>
      <div className="lp-oplog-title">操作记录</div>
      <Space size={8} wrap style={{ marginBottom:12 }}>
        <Select size="small" defaultValue="" style={{ width:130 }} options={[
          { value:'', label:'全部操作类型' },
          ...(types || ['创建','编辑','启用','停用']).map(x => ({ value:x, label:x })),
        ]} />
        <Select size="small" defaultValue="" style={{ width:130 }} options={[
          { value:'', label:'全部操作人' },
          { value:'a', label:'张运营' }, { value:'b', label:'王管理' },
        ]} />
        <DatePicker.RangePicker size="small" placeholder={['开始日期','结束日期']} />
        <Button size="small" icon={<SearchOutlined />}>查询</Button>
      </Space>
      <Table size="small" rowKey="i" pagination={false} styles={TABLE_STYLES}
        columns={[
          { title:'操作时间', dataIndex:'at' },
          { title:'操作人',   dataIndex:'who' },
          { title:'操作类型', dataIndex:'type',
            render:v => <StatusTag variant={v==='编辑'?'pending':'on'}>{v}</StatusTag> },
          { title:'操作详情', dataIndex:'detail' },
        ]} dataSource={data || DEFAULT_OPLOG} />
      <CompactPagination total={total || (data?data.length:DEFAULT_OPLOG.length)} pageSize={10} />
    </>
  );
}
```

### B.9 InlineProgress(表格行内进度条 + x/y)

```jsx
function InlineProgress({ value, label }) {
  return (
    <div style={{ display:'flex', alignItems:'center', gap:8 }}>
      <Progress percent={value} showInfo={false} size={{ width:80, height:8 }}
        strokeColor="#A4002A" trailColor="#E5E7EB" />
      <span style={{ fontSize:12 }}>{label}</span>
    </div>
  );
}
```

### B.10 EditableNumber(行内可编辑数字)

```jsx
function EditableNumber({ value, onChange, width = 100 }) {
  const [editing, setEditing] = React.useState(false);
  const [val, setVal] = React.useState(value);
  const [justSaved, setJustSaved] = React.useState(false);
  // 外层固定宽度 + 居中:切换 display ↔ edit 时列宽不抖动,数字也始终居中可读
  const wrap = { display: 'inline-block', width, textAlign: 'center' };
  if (editing) {
    return (
      <span style={wrap}>
        <InputNumber autoFocus size="small" value={val} style={{ width: '100%' }}
          onChange={(v) => setVal(v)}
          onBlur={() => { setEditing(false); onChange?.(val); setJustSaved(true); setTimeout(() => setJustSaved(false), 1000); }}
          onPressEnter={(e) => e.target.blur()} />
      </span>
    );
  }
  return (
    <span style={wrap}>
      <span className={'lp-editable' + (justSaved ? ' lp-edit-just-saved' : '')}
        onClick={() => setEditing(true)}>{(val ?? 0).toLocaleString()}</span>
    </span>
  );
}
```

**关键设计**(B.10 修订):
- **外层固定 width(默认 100px) + textAlign:center**:切换"显示态↔编辑态"时,容器宽度不变 → 列宽不抖动
- 数字默认右对齐(财务习惯)在表格里反而**让编辑切换感很 weird**(右对齐数字 → 编辑时 InputNumber 撑开列向左)。**改成居中**后,InputNumber 在固定宽度内居中,视觉稳定
- 如果数字位数差异大需要更宽,用 `<EditableNumber width={140} />` 覆盖

**⚠ Table column 必须配套 `align: 'center'`**(同时管表头 + 数据):

```jsx
// ❌ 错:align 不设(默认 left)或设 'right' → 表头跟数据 EditableNumber 内部 center 错位
{
  title: <TipText label="在库" tip="点击数字可修改" />,
  dataIndex: 'stock',
  render: (v, r) => <EditableNumber value={v} onChange={...} />,
  // ← 表头按 antd 默认 left 对齐,数据居中 → 视觉错位
}

// ✅ 对:column 加 align: 'center'
{
  title: <TipText label="在库" tip="点击数字可修改" />,
  dataIndex: 'stock',
  align: 'center',                            // ← 让表头也居中
  render: (v, r) => <EditableNumber value={v} onChange={...} />,
}
```

判定:**用 `EditableNumber` 的列,column 必须 `align: 'center'`**。普通只读数字列(用 `<span>{v.toLocaleString()}</span>`)可以保留 `align: 'right'`(财务对齐习惯)。

## C. 高层 JSX 模板

> ⭐ **强烈推荐使用本段模板,而不是每个 page 内联实现**。
>
> **不用模板的代价**:每个列表页都重复写"标题区 + KPI + 工具栏 + Table + EmptyStateSwitcher + 分页",每页 50-80 行。再加 `const [mode,setMode]=useState('data')`,极易触发**懒人写法**:
>
> ```jsx
> // ❌ A 组真实踩坑(54 page × 平均 80 行,sonnet 选了最省力的内联 IIFE)
> {currentPage==='page-xxx-list' && (() => {
>   const [mode,setMode]=useState('data');  // ← 违反 rules.md A.13,React #300 白屏
>   return <Card>...</Card>;
> })()}
> ```
>
> **用 ListPage 模板的好处**:
> 1. mode state 在模板内部封装,调用方只传配置(`<ListPage title=... columns=... data=... />`),不需要 useState → **天然避开 A.13**
> 2. 列表页平均代码从 80 行降到 15 行,产物体积小 30-40%
> 3. 全局约定(4 态空态 / 分页器 / 工具栏)只在模板里实现一次,各 page 自动统一
>
> **触发条件**:列表页数量 ≥ 4 时,**必须**先定义 ListPage/FormPage,再批量调用。表单页同理用 FormPage,向导用 WizardPage。

### C.1 列表页模板(ListPage)

```jsx
function ListPage({ title, desc, headActions, kpis, filters, columns, data, total,
                    entity, createKey, go, scrollX }) {
  const [mode, setMode] = React.useState('data');
  return (
    <Card style={CARD_STYLE}>
      {/* 标题区 */}
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', gap:16, marginBottom:18 }}>
        <div>
          <div style={{ fontSize:20, fontWeight:700, marginBottom:6 }}>{title}</div>
          {desc && <div style={{ color:'#6B7280', fontSize:13 }}>{desc}</div>}
        </div>
        <div>{headActions}</div>
      </div>

      {/* KPI(可选,3 或 4 列) */}
      {kpis && (
        <div style={{ display:'grid', gridTemplateColumns:`repeat(${kpis.length},1fr)`, gap:12, marginBottom:18 }}>
          {kpis.map((k, i) => <Kpi key={i} num={k.num} label={k.label} numStyle={k.numStyle} />)}
        </div>
      )}

      {/* 筛选/搜索 */}
      {filters && <Space size={12} wrap style={{ marginBottom:16 }}>{filters}</Space>}

      {/* 数据区 + 4 种空态切换 */}
      {mode === 'data' && (
        <>
          <Table rowKey={r => r.id || r.code || r.key} columns={columns} dataSource={data}
            pagination={false} styles={TABLE_STYLES}
            scroll={scrollX ? { x: scrollX } : undefined} />
          <CompactPagination total={total || data.length} pageSize={10} />
        </>
      )}
      {mode==='zero'     && <EmptyZero entity={entity} cta={createKey?`新增${entity}`:null} onCta={createKey?(()=>go(createKey)):null} />}
      {mode==='no-match' && <EmptyNoMatch onClear={() => setMode('data')} />}
      {mode==='error'    && <EmptyError onRetry={() => setMode('data')} />}

      <EmptyStateSwitcher mode={mode} setMode={setMode} />
    </Card>
  );
}
```

### C.2 表单页模板(FormPage)

```jsx
function FormPage({ title, desc, headActions, sections, isEdit, back, onSave, withOpLog=true }) {
  return (
    <Card style={CARD_STYLE}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', gap:16, marginBottom:18 }}>
        <div>
          <div style={{ fontSize:20, fontWeight:700, marginBottom:6 }}>{title}</div>
          {desc && <div style={{ color:'#6B7280', fontSize:13 }}>{desc}</div>}
        </div>
        <Space>{headActions}<Button onClick={back}>返回列表</Button></Space>
      </div>

      {sections.map((s, i) => (
        <div key={i} style={{ marginBottom:24 }}>
          <h4 className="lp-section">{s.title}</h4>
          {s.note && <div style={{ fontSize:12, color:'#6B7280', margin:'-4px 0 12px' }}>{s.note}</div>}
          {s.children}
        </div>
      ))}

      {isEdit && withOpLog && <OpLog />}

      <div style={{ display:'flex', justifyContent:'flex-end', gap:12, padding:'16px 0', borderTop:'1px solid #E5E7EB', marginTop:8 }}>
        <Button onClick={back}>取消</Button>
        <Button type="primary" onClick={onSave}>{isEdit ? '保存' : '保存并创建'}</Button>
      </div>
    </Card>
  );
}
```

### C.3 详情页模板(DetailPage / DetailGrid)

> 这一段此前写的是"详情页直接组合 Tabs + preview 区即可,**不强行抽模板**"。
> 那句话被实测推翻了:同一个模块里,列表页(有 ListPage 模板)界面返工 **0 轮**,
> 详情页(没有模板)返工 **13 轮 / 6 个版本 / 约 4.5 小时**。
> 差别不在页面复杂度,在**有没有一个不用每次重新决定的起点**。
> 下面这套是售后 v16 收敛出来的结果,**照抄,不要重新发明**。
> 版式怎么定(切几栏、谁进卡、谁下沉整行)见 `references/detail-page-blueprint.md`。

**业务单据详情页 = 页头 + N 个模块**,每个模块固定四件:
`.lp-module` 外壳 → `.lp-section` 标题 → 内容(`DetailGrid` / 卡 / 时间轴 / 表格)→ 空态。
CSS 全部在 `theme.md` 详情页模块骨架段,这里只给 JS。

```jsx
/* 信息类区块默认多栏排布,避免几十行标签值竖排成一条长队。
   rows 里的 key 用显式 rk(有 JSX 标签时 k 不能当 key)。
   labelWidth:标签列宽,不传时按栏数取默认值。上下堆叠的两个 DetailGrid 若栏数不同,
   必须显式传同一个 labelWidth,否则两块的「值」左边缘会差出 28px(默认 132 与 104 之差) */
function DetailGrid({ rows, cols, labelWidth, flow, groups }) {
  const list = (rows || []).filter(Boolean);
  const n = groups ? groups.length : (cols || 1);
  const lw = (labelWidth || (n === 1 ? 132 : 104)) + 'px 1fr';
  const cell = (x, i) => <React.Fragment key={x.rk || i}>
    <div className="dl">{x.k}</div><div className="dv">{x.v}</div></React.Fragment>;

  if (!groups && n === 1) return <div className="lp-detail" style={{ gridTemplateColumns: lw }}>{list.map(cell)}</div>;

  /* flow='row':一张真正的多栏栅格,字段按「左 → 右 → 换行」铺,适合
     「一批同类字段摆不下要折行」的场景(弹窗里的快照核对区)。
     ⚠ 它铺出来的左右两项【只是排版上的相邻】,不表示语义上成对。
       想让「每一栏各自是一条独立的语义序列」—— 用 groups,不要用 flow='row' 手工交错写:
       交错写法一旦某栏多一行就全串位。 */
  if (!groups && flow === 'row') return <div className="lp-detail lp-flow-row"
    style={{ gridTemplateColumns: (labelWidth || 104) + 'px 1fr ' + ((labelWidth || 104) + 'px 1fr ').repeat(n - 1) }}>
    {list.map(cell)}</div>;

  /* 分栏渲染。groups = 调用方显式指定「每一栏各放哪些字段」,按【字段性质】分栏
     而不是按行数机械切。栏数由 groups.length 决定,不限两栏。
     各栏长短不一是预期结果,不补占位行凑等高(A.21-4 / A.21-6)。
     ⚠ 整栏没有内容时,调用方应在传入前把该栏 filter 掉 —— 传空数组会留一个空格子,
       栅格仍按原栏数分宽,剩下的栏会挤在左边。写法:
         const cols = [verdictCol, amountCol, execCol].filter(g => g.length > 0); */
  let cg;
  if (groups) {
    cg = groups.map(g => (g || []).filter(Boolean));
  } else {
    const per = Math.ceil(list.length / n);
    cg = [];
    for (let i = 0; i < n; i++) cg.push(list.slice(i * per, (i + 1) * per));
  }
  return <div style={{ display: 'grid', gridTemplateColumns: 'repeat(' + n + ',1fr)', gap: 0 }}>
    {cg.map((g, gi) => <div className="lp-detail" key={'g' + gi}
      style={{ gridTemplateColumns: lw, paddingRight: gi < n - 1 ? 20 : 0 }}>
      {g.map(cell)}</div>)}</div>;
}
```

**标签列宽常量:一个场景一个,禁止现场写数字**(rules.md A.21-5)。
口径是 **容器内标签宽 = 该场景标签宽 − 容器左内边距**,这样容器内外的标签落在同一条竖线上。

```jsx
const SUB_LABEL_W        = 94;   // 弹窗里被 .lp-sub 灰底块包住的只读区(灰底自带 18px 左内边距,94+18=112)
const MODAL_LABEL_W      = 112;  // 弹窗里不在灰底块内的只读区(纯只读弹窗 / 大图弹窗 / 快照)
const DETAIL_LABEL_W     = 116;  // 详情页 1~2 栏 / 整行
const DETAIL_LABEL_W_3COL= 108;  // 详情页 3 栏,以及紧跟在 3 栏下方的整行
```
> 取值理由要写在常量旁边(最长标签几个汉字 × 13px + 余量)。
> **不留没有场景的常量** —— 场景消失就删掉它,否则下次有人会拿它去凑一个新场景。

**调用姿势**(左右两栏各自独立流动,不做行对齐):

```jsx
const basicSection = <div className="lp-module">
  <h4 className="lp-section">基本信息</h4>
  {/* 两栏 = 两条独立语义序列:左「这单是什么、谁的」/ 右「时间线与怎么结束的」 */}
  <DetailGrid groups={[baseLeftRows, baseRightRows]} labelWidth={DETAIL_LABEL_W} />
  {/* 自由文本 / 附件组整行下沉,标签宽传同一个常量,值的左边缘才和上面对齐 */}
  <DetailGrid rows={baseWideRows} labelWidth={DETAIL_LABEL_W} />
</div>;
```

**边框卡**(只在两种场景用,判据见 rules.md A.21「什么时候引入边框卡」):形制整套照抄,一个数值都不自己定。

```jsx
<div className="lp-card">
  <div className="lp-card-head">
    <div className="main">{trackingNo}<Tag>{status}</Tag></div>   {/* 左:主标识 + 状态 */}
    <div className="side">{address}</div>                          {/* 右:次要标识 */}
  </div>
  <div className="lp-card-part">
    <div className="lp-card-label">退货轨迹</div>                   {/* 卡内分组标签,12px 灰字,不用 .lp-subtitle */}
    <Timeline items={...} />
  </div>
</div>
```

```css
.lp-card{border:1px solid #E5E7EB;border-radius:14px;overflow:hidden;margin-bottom:24px}
.lp-card:last-child{margin-bottom:0}
.lp-card-head{padding:14px 20px;background:#FAFAFA;border-bottom:1px solid #E5E7EB;display:flex;justify-content:space-between;align-items:center;gap:16px}
.lp-card-head .main{display:flex;align-items:center;gap:12px;flex-wrap:wrap;font-size:14px;font-weight:600;color:#1F2937;flex-shrink:0}
/* 头条右槽【不加 white-space:nowrap】——长地址会被顶出卡外;允许折行 + 右对齐,
   左侧标识组 flex-shrink:0 保证单号 / 状态 tag 永远不被挤压 */
.lp-card-head .side{font-size:13px;color:#6B7280;text-align:right;min-width:0}
.lp-card-part{padding:16px 20px;border-bottom:1px solid #F3F4F6}
.lp-card-part:last-child{border-bottom:none}
/* 卡内分组标签:卡的分区分隔线已经把这一层边界划出来了,再叠一条品牌红色竖条等于画两遍 */
.lp-card-label{font-size:12px;color:#9CA3AF;margin-bottom:12px}
```

**验证**:`python3 scripts/sketch_detail.py 产物.html` —— 出版式草图 + A.21 逐模块语言表 + 版式机械检查。

### C.4 向导模板(Wizard)

```jsx
function WizardPage({ title, desc, back, onSave, steps, panels }) {
  const [step, setStep] = React.useState(0);
  return (
    <Card style={CARD_STYLE}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', gap:16, marginBottom:18 }}>
        <div>
          <div style={{ fontSize:20, fontWeight:700, marginBottom:6 }}>{title}</div>
          {desc && <div style={{ color:'#6B7280', fontSize:13 }}>{desc}</div>}
        </div>
        <Button onClick={back}>返回列表</Button>
      </div>

      <Steps current={step} style={{ marginBottom:24 }} items={steps} />
      <div style={{ minHeight:240, marginBottom:24 }}>{panels[step]}</div>

      <div style={{ display:'flex', justifyContent:'space-between', paddingTop:16, borderTop:'1px solid #E5E7EB' }}>
        <Button onClick={back}>取消</Button>
        <Space>
          {step > 0 && <Button onClick={() => setStep(step - 1)}>上一步</Button>}
          {step < panels.length - 1 && <Button type="primary" onClick={() => setStep(step + 1)}>下一步</Button>}
          {step === panels.length - 1 && <Button type="primary" onClick={onSave}>提交</Button>}
        </Space>
      </div>
    </Card>
  );
}
```

## D. PRD 字段类型术语 → antd 组件 映射

| PRD 字段类型 | antd 组件 | 关键 props | 备注 |
|---|---|---|---|
| 文本输入 | `<Input>` | placeholder, allowClear | 单行 |
| 文本域 / 多行文本 | `<Input.TextArea>` | rows={3 或更多} | |
| 数字输入 | `<InputNumber>` | min, max, step, prefix | 默认 controls=true 带 spinner |
| 下拉选择 | `<Select>` | options, mode (single/multiple/tags), showSearch | 选项 ≤5 时可选 Radio.Group |
| 单选 / 单选按钮 | `<Radio.Group>` | options | |
| 单选(大卡片) | `<RadioCardGroup>` | options=[{value,title,desc}] | 业务组件,见 B.7 |
| 多选 / 复选 | `<Checkbox.Group>` | options | |
| 开关 / 是否 | `<Switch>` 或 `<Select>` 二选一 | | spec 多用 Select(启用/停用) |
| 日期 / 日期选择 | `<DatePicker>` | placeholder | |
| 日期范围 / 时间段 | `<DatePicker.RangePicker>` | placeholder=[...,...] | **必须用 RangePicker,不要拆两个** |
| 文件上传 | `<Upload>` 或 `<Upload.Dragger>` | accept, beforeUpload, listType | 拖拽区用 Dragger |
| 树形选择 / 类目选择 | `<TreeSelect>` 或 `<Cascader>` | treeData / options | |
| 自动计算 / 只读 | `<Input value={...} disabled />` | | 灰底 |
| 密码 | `<Input.Password>` | | |
| 富文本 | **不支持** | 占位 + 自检报告标注 | 详见 `rules.md` C 段 |
| 图片裁剪 | **不支持** | 占位 Upload | |

## E. 操作类型 → 按钮样式映射

| PRD 操作 | 按钮 | 备注 |
|---|---|---|
| 编辑 / 详情 / 查看 | `<Button size="small">` | 表格操作列 |
| 新增 / 创建 / 保存 | `<Button type="primary">` | 头部主按钮或表单操作栏 |
| 删除 / 冻结 / 停用 / 移除 | `<Button danger>` 或 `<Button size="small" danger>` | 白底红边,**不是**实心红 |
| 解冻 / 启用 | `<Button>` | 默认样式 |
| 导出 / 下载 | `<Button icon={<DownloadOutlined />}>` | |
| 导入 / 上传 | `<Button icon={<ImportOutlined />}>` 或 `<Button icon={<UploadOutlined />}>` | |
| 查询 | `<Button type="primary" icon={<SearchOutlined />}>` | |
| 重置 | `<Button icon={<ReloadOutlined />}>` | |
| 返回列表 | `<Button>` | |

## F. 操作触发模式

PRD 中"操作"按钮的触发方式:

| 行为 | 实现 |
|---|---|
| 跳转到子页面 | `setSub('xxx-edit')` + `<onClick={() => go('xxx-edit')}>` |
| 弹出 Modal(简单确认) | 通用 confirmModal state |
| 弹出 Modal(表单) | 独立的 Modal 组件 + open state |
| 行内编辑 | `<EditableNumber>` 或 `<Input>` 替换显示节点 |
| 单选切换 | 直接 onChange |

约定:**子页面跳转用 state 切换**,不用 antd 路由(原型场景不引入 react-router)。
