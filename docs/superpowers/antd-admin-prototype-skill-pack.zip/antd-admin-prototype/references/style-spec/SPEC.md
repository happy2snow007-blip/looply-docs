# antd-transform / style-spec(Layer 0)

> **本目录不是 skill,是规范层**——`antd-transform` 和 `antd-prototype-gen` 两个 skill 引用本目录的文件作为单一真理源。
>
> 因为不是 skill,本目录下的 markdown **不带 frontmatter**。

## 用途

为 looply 后台的 antd 原型生成 / 转译,提供:
- 视觉规范的 antd token 实现(`theme.md`)
- 允许使用的 antd 组件子集 + 业务组件 + JSX 模板(`components.md`)
- 硬性规则 / 无法原生还原 / 超范围处理 / 转译标准(`rules.md`)

## 锁定版本

| | 版本 | 备注 |
|---|---|---|
| antd | **6.4.x** | 不主动升级大版本/中版本;补丁可以 |
| React | **18.x** | antd v6 peer ≥18;React 19 没 UMD,单 HTML 用不了 |
| @ant-design/icons | **6.x** | 与 antd 大版本对齐 |
| dayjs | **1.x** | antd 内部依赖 |

## 元决策(为什么这么定)

| 决策 | 理由 |
|---|---|
| 产物用 React 18 UMD + CDN | 产品需"零环境双击打开";React 19 没 UMD |
| Babel Standalone 浏览器内编译 | 单 HTML 无构建,这是必需依赖 |
| 不依赖 Ant Design Pro / ProComponents | `@ant-design/pro-components@latest` 仅支持 antd v5,@beta(v3 系列)支持 v6 但仍预发 |
| 不依赖 antd / ant-design 官方 skill | 它们面向真实业务开发;原型场景的 antd 用法是受限子集,本规范固化够用 |
| 自检报告中可包含"自主优化"段落 | AI 可基于专业理解优化组件选型/视觉/交互,但必须透明上报 |

## 转译质量优先级

**业务逻辑 > 交互 > 视觉**

- 业务逻辑(字段 / 校验 / 操作流程 / 异常处理 / 跳转 / 数据关系):**严格对齐 PRD**,不可改
- 交互(具体怎么用 antd 组件实现操作):**优先按 PRD,可在自检报告说明的前提下基于最佳实践优化**
- 视觉(色板 / 间距 / 圆角):**按 `theme.md`(已固化 looply 规范),"无法原生还原"清单内的项允许妥协**

## 文档导航

| 文件 | 内容 | 调用时机 |
|---|---|---|
| `SPEC.md`(本文件) | 总览 / 版本锁定 / 元决策 | 进入规范前先读 |
| `theme.md` | looplyTheme 完整代码 + token 映射 + 全局 CSS | 写产物 `<script>` / `<style>` 时整段复用 |
| `components.md` | 28 个 antd 组件子集用法 + .lp-* 业务组件 + JSX 模板 + 字段术语→组件映射 | 转译每个页面时查 |
| `rules.md` | 硬性规则 + 无法原生还原 + 超范围处理 + 表格列宽 + v3 升级标准 | 转译每条产出前自查 |

## 给 AI 的使用约定

进入 Skill 1 或 Skill 2 时,**按以下顺序加载本规范**:

1. 读 `SPEC.md`(本文件)——理解锁定版本和元决策
2. 读 `rules.md`——理解必须遵守的硬性规则和边界
3. 读 `theme.md`——拿到可直接复用的 looplyTheme 代码
4. 转译每个页面时按需读 `components.md` 的对应组件 / 模板段落

**不允许跳过 rules.md** 而只读 components.md。

## 自主优化的边界(全文统一)

允许优化:
- 组件选型(如类目层级用 Tree 替代 Table)
- 同语义不同组件(选项多/少切换 Select/Radio)
- 交互细节(分页器样式 / 空态切换 / Tooltip 截断)
- 视觉细节(列宽 auto-layout / 紧凑分页器)

禁止改动:
- 跳过 PRD 字段 / 改变必填性 / 跳过校验
- 改变操作流程顺序或步数
- 跳过异常处理
- 改变跳转关系或数据关系

灰色地带:
- 原型 vs PRD 冲突 → 以 PRD 为准,报告标注
- 原型有 / PRD 没说 → 按原型,报告标注
- PRD 有 / 原型没画 → 按 PRD,报告标注

**所有自主优化必须出现在自检报告的"自主优化项"段落**(详见 `antd-transform/self-check.md`)。
