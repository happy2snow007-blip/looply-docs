# theme.md — looplyTheme 完整代码

> 取自 `original-spec/looply-admin-ui-spec.md`,固化为 antd 6.4.x 可直接使用的 token + 全局 CSS。
>
> **转译时整段复制本文件的代码到产物**,不要重新推导 token 值。

## 目录

| 段 | 内容 | 行号 |
|---|---|---|
| **A. CDN 引用块**(必需,`<head>` 整段复制) | React 18 + antd 6 + dayjs + icons + Babel | 16 |
| § A.0 Logo | base64 嵌入新版 `logo.svg`(禁字体仿造)| 22 |
| § A.1 CDN 锁定(硬性) | jsdelivr + antd@6 + icons@6,禁 unpkg / antd@5 | 49 |
| **B. ConfigProvider 主题 token** | `looplyTheme` 对象,直接整段抄进 `<script>` | 71 |
| **C. 通用 style 常量** | token 表达不了的部分(CARD_STYLE / TABLE_STYLES / SIDER_STYLE) | 160 |
| **D. 全局 CSS** | `.lp-*` 业务组件用的 class,放 `<style>` | 180 |
| **E. 字段值速查**(token → spec 章节锚点) | 反查"这个值为什么是这个数" | 269 |
| **F. 语义色 → Tag variant 映射** | StatusTag 颜色编码 | 286 |
| **G. 交互 / 动效规范** | 动效时长 / 焦点态 / 触摸目标(self-check 手动视觉项对照) | 384 |

**按场景读**:
- 初次转译 → A 段整段抄 + B 段整段抄到 `<script>`
- 改主题色 → 改 § B `looplyTheme` 即可
- 写新业务组件 → 看 § C 常量 + § D CSS class 命名约定

## A. CDN 引用块(必需,放在 `<head>`)

**整段照抄,不要改任何一行**。版本号 / CDN 提供方 / `crossorigin` 属性 / 顺序都已经过验证。

> ⚠ **必须用精确补丁版本(下方就是),禁止用浮动 major tag(`@6` / `@18` / `@1`)。**
> 浮动 tag 会自动追 latest,某天 latest 出回归你的产物就白屏 —— 实测 `@ant-design/icons@6` 追到 **6.2.5** 后,其 UMD 与 React 18 UMD 不兼容,初始化抛 `TypeError: ...reading 'S'` → `icons` 全局没生成 → 产物 `const {…}=icons` 抛 `ReferenceError` → 整页白屏。详见 § A.1。

```html
<script crossorigin src="https://cdn.jsdelivr.net/npm/react@18.3.1/umd/react.production.min.js"></script>
<script crossorigin src="https://cdn.jsdelivr.net/npm/react-dom@18.3.1/umd/react-dom.production.min.js"></script>
<script crossorigin src="https://cdn.jsdelivr.net/npm/dayjs@1.11.21/dayjs.min.js"></script>
<script crossorigin src="https://cdn.jsdelivr.net/npm/antd@6.4.3/dist/antd.min.js"></script>
<script crossorigin src="https://cdn.jsdelivr.net/npm/@ant-design/icons@6.2.1/dist/index.umd.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@babel/standalone@7.28.4/babel.min.js"></script>
```

**这一组 6 个精确版本是经全栈联调验证可用的"黄金组合"**(react 18.3.1 + react-dom 18.3.1 + dayjs 1.11.21 + antd 6.4.3 + icons 6.2.1 + babel 7.28.4)。要升级任何一个,**必须先用 § A.2 的 Node vm 离线验证整组能加载 + 产物脚本能 eval 无错**,再改这里。

UMD 暴露的全局变量:`React` / `ReactDOM` / `dayjs` / `antd` / `icons` / `Babel`

### A.0 Logo(必须嵌入 base64,禁止字体模拟)

产物 Header 左上角 logo **必须**使用本仓库 `assets/logo.svg` 的 base64 嵌入,这是 Looply 新版黑色 Logo。**禁止**用 `<span style={{fontSize,fontWeight,color,letterSpacing}}>Looply</span>` 这种字体仿造。

#### 嵌入方式:占位符 + 后处理(**唯一允许的方式**)

```jsx
// 1. 在 <script type="text/babel"> 顶部声明:
const LOGO_SRC = "data:image/svg+xml;base64,{{LOGO_PLACEHOLDER}}";

// 2. Layout.Header 内使用:
<img src={LOGO_SRC} alt="Looply" style={{ width: 118, height: 'auto', display: 'block' }} />

// 3. 产物完成后 / 交付前,跑:
//    python3 scripts/embed_logo.py outputs/产物.html
//    脚本会读 assets/logo.svg 转 base64,替换 {{LOGO_PLACEHOLDER}}
```

**禁止做的事**:
- ❌ **subagent 自己把 base64 字面字符串塞进产物** — 易截断或误改,导致浏览器渲染失败
- ❌ 跳过 `embed_logo.py`,产物里留 `{{LOGO_PLACEHOLDER}}` 字面符号 — `scripts/check.sh` 会报 ❌
- ❌ 用文字 `LOOPLY` / `Looply` 模拟 Logo

#### 自检

```bash
# 产物里不应该残留占位符
grep "LOGO_PLACEHOLDER" outputs/产物.html  # 期望:无输出
# 产物里应该有新版 SVG logo data URL
grep -E 'data:image/svg\+xml;base64,[A-Za-z0-9+/=]+' outputs/产物.html  # 期望:有输出
```

**理由**:
- 字体仿造跨平台渲染不一致(macOS / Windows / Linux 字重不同)
- Logo 是品牌资产,不能用文字替代
- base64 嵌入保证"双击 HTML 打开"零依赖,即使无网络也显示

**约束**:
- 用 `logo.svg`(新版黑色 Logo),不要回退到旧紫色 Logo
- 宽度默认 `width: 118`,高度自适应；antd Header 60px 高时视觉居中

### A.1 CDN 锁定(硬性 —— 必须精确版本,禁止浮动 tag)

| 库 | 锁定值(精确版本) | 不允许 |
|---|---|---|
| CDN 提供方 | **`cdn.jsdelivr.net`** | unpkg.com / cdnjs.cloudflare.com / 其他 |
| react | **`react@18.3.1`** | `react@18`(浮动)/ react@19(无 UMD)/ react@17 |
| react-dom | **`react-dom@18.3.1`** | `react-dom@18`(浮动)/ 与 react 不同版本 |
| dayjs | **`dayjs@1.11.21`** | `dayjs@1`(浮动)/ dayjs@2 |
| antd | **`antd@6.4.3`** | `antd@6`(浮动)/ `antd@5` / 任何 v5 |
| @ant-design/icons | **`@ant-design/icons@6.2.1`** | `@ant-design/icons@6`(浮动 → 追到 **6.2.5** 必崩)/ 省略(只能用 Emoji,违反 A.4.1)|
| @babel/standalone | **`@babel/standalone@7.28.4`** | `@babel/standalone`(浮动) |

#### 为什么必须精确版本(2026-06 实测事故)

`@ant-design/icons@6` 是**浮动 major tag**,会自动追 latest。某用户产物"原本能开",`cmd+shift+r` 强刷后(或换无缓存的电脑)白屏:

- latest 已从可用的早期 6.x 漂到 **6.2.5**
- icons **6.2.5 的 UMD 与 react@18 UMD 全局变量不兼容**,初始化即抛 `TypeError: Cannot read properties of undefined (reading 'S')`
- → `window.icons` 全局没生成 → 产物 `const {…} = icons;` 抛 `ReferenceError: icons is not defined` → 整页白屏

**经 Node vm 复现**:icons `6.0.0 / 6.1.x / 6.2.0 / 6.2.1` 正常(836 图标),**`6.2.5` 崩溃**。任何浮动 tag(react/antd/dayjs 同理)都有"latest 引入回归"风险 → **一律锁精确补丁版**。

**B 组历史踩坑**(保留警示):
- "v6 没 UMD" → 自行降级到 antd@5 → 主题 token / `.ant-*` 覆盖在 v6 失效。**jsdelivr 的 antd 6.x UMD 存在,用上面的 `antd@6.4.3` 即可**
- 没引 icons CDN → 用 Emoji `★◈` 替代 → 违反 A.4.1

**自检命令**(产物完成时跑;`scripts/check.sh` 已内置,见下):
```bash
grep -c "cdn.jsdelivr.net"               产物.html   # 必须 ≥ 6
grep -Ec "react@18\.3\.1"                产物.html   # 必须 ≥ 1(精确版本,非浮动 react@18)
grep -Ec "antd@6\.4\.3"                  产物.html   # 必须 ≥ 1
grep -Ec "@ant-design/icons@6\.2\.1"     产物.html   # 必须 ≥ 1
grep -Ec '(react|react-dom|dayjs|antd)@[0-9]+/'  产物.html   # 必须为 0(命中=用了浮动 tag,违规)
grep -c "@ant-design/icons@6/"           产物.html   # 必须为 0(浮动 icons tag,会崩)
grep -c "antd@5"                         产物.html   # 必须为 0
grep -c "unpkg.com"                      产物.html   # 必须为 0
```

### A.2 升级版本前的离线验证(Node vm,沙箱无浏览器时必做)

要改 A 段任何一个版本号,**先用 Node `vm` 加载真实 CDN UMD + Babel 编译产物脚本**,确认整组能加载且产物脚本 eval 无 `ReferenceError`,再落地。这能在没有浏览器的环境下抓出"白屏"级回归(就是 icons 6.2.5 那类)。

```js
// 1) curl 各精确版本 UMD 到 /tmp(react/react-dom/dayjs/antd/icons/@babel-standalone)
// 2) node 跑:
const fs=require("fs"), vm=require("vm");
const html=fs.readFileSync("产物.html","utf8");
const body=html.match(/<script type="text\/babel"[^>]*>([\s\S]*?)<\/script>/)[1];
const B=require("/tmp/babel.min.js");                       // @babel/standalone
const compiled=B.transform(body,{presets:["react"]}).code; // 抓 JSX 语法错
const s={}; s.self=s; s.window=s; s.console=console; s.navigator={userAgent:"node"};
s.document={getElementById:()=>({})}; s.setInterval=()=>0; s.clearInterval=()=>{};
vm.createContext(s);
const run=f=>vm.runInContext(fs.readFileSync(f,"utf8"),s,{filename:f});
["react","react-dom","dayjs","antd","icons"].forEach(n=>run("/tmp/"+n+".js")); // 顺序固定
s.ReactDOM.createRoot=()=>({render:()=>console.log("render OK")});
vm.runInContext(compiled,s,{filename:"app"});               // 抓 const{...}=icons 这类 ReferenceError
```

UMD 在无 `module`/`require` 的 vm 里走 `e.X=...` 全局分支,所以能拿到 `s.React / s.antd / s.icons`。局限:`createRoot` 被 stub,不做真实 reconcile —— 验证的是"加载期/解构期"是否报错,这正是白屏事故的发生层。

## B. ConfigProvider 主题 token(JSX,在 `<script type="text/babel">` 内)

```jsx
const looplyTheme = {
  token: {
    colorPrimary: '#A4002A',
    colorInfo: '#A4002A',
    colorBgLayout: '#F9FAFB',
    colorBgContainer: '#FFFFFF',
    colorText: '#1F2937',
    colorTextSecondary: '#374151',
    colorTextTertiary: '#4B5563',
    colorTextDescription: '#6B7280',
    colorTextPlaceholder: '#9CA3AF',
    colorBorder: '#E5E7EB',
    colorBorderSecondary: '#F3F4F6',
    colorSuccess: '#16A34A',
    colorWarning: '#D97706',
    colorError: '#DC2626',
    borderRadius: 8,
    borderRadiusLG: 14,
    borderRadiusSM: 6,
    fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
    fontSize: 14,
    controlHeight: 34,
    controlHeightSM: 28,
  },
  components: {
    Layout: {
      headerBg: '#FFFFFF',
      headerHeight: 60,
      headerPadding: '0 24px',
      siderBg: '#FFFFFF',
      bodyBg: '#F9FAFB',
    },
    Menu: {
      itemBg: 'transparent',
      subMenuItemBg: 'transparent',
      itemHoverBg: 'rgba(0,0,0,.03)',
      itemSelectedBg: '#FCEEEF',
      itemSelectedColor: '#A4002A',
      // 激活态贯穿到边(去 antd 默认胶囊圆角)
      itemBorderRadius: 0,
      itemMarginInline: 0,
      itemMarginBlock: 0,
      itemHeight: 40,
      subMenuItemBorderRadius: 0,
    },
    Card: {
      borderRadiusLG: 16,
      paddingLG: 28,
    },
    Table: {
      headerBg: '#FFFFFF',
      headerColor: '#6B7280',
      rowHoverBg: '#FFF5F5',
      borderColor: '#E5E7EB',
      headerSplitColor: 'transparent',
      // spec 只规定 cell=13px,不分尺寸;small 只在 padding 上紧凑
      cellFontSize: 13,
      cellFontSizeMD: 13,
      cellFontSizeSM: 13,
      cellPaddingBlock: 11,
      cellPaddingInline: 12,
      cellPaddingBlockMD: 11,
      cellPaddingInlineMD: 12,
      cellPaddingBlockSM: 9,
      cellPaddingInlineSM: 12,
      headerBorderRadius: 0,
    },
    Tag: {
      defaultBg: '#F3F4F6',
      defaultColor: '#6B7280',
    },
    Tabs: {
      itemSelectedColor: '#A4002A',
      itemHoverColor: '#374151',
      inkBarColor: '#A4002A',
    },
    Steps: { colorPrimary: '#A4002A' },
    Button: { controlHeight: 34, paddingInline: 14, fontSize: 13 },
    Input:  { controlHeight: 34, paddingInline: 12 },
    Select: { controlHeight: 34 },
    DatePicker: { controlHeight: 34 },
    Modal:  { borderRadiusLG: 16, paddingContentHorizontalLG: 28 },
  },
};
```

## C. 通用 style 常量(token 表达不了的部分,通过 style prop 注入)

```jsx
// Card 卡片阴影(antd Card 没暴露 shadow token)
const CARD_STYLE = { boxShadow: '0 10px 24px rgba(16,24,40,.06)', marginBottom: 20 };

// Table styles.root(token 不能配置整体边框 + 圆角)
const TABLE_STYLES = { root: { borderRadius: 14, border: '1px solid #E5E7EB', overflow: 'hidden' } };

// Sider style(阴影 + 菜单超长滚动)
// 必须带 overflowY:'auto',否则三级菜单 / 长菜单全展开后会超出 viewport
// 配合外层 <Layout style={{ height: '100vh' }}>,Sider 高度由 Layout 撑开
const SIDER_STYLE = {
  boxShadow: '3px 0 12px rgba(0,0,0,0.06)',
  padding: '8px 0',
  overflowY: 'auto',
  height: '100%',
};
```

## D. 全局 CSS(放在 `<style>` 标签里,业务组件用)

```css
/* 基础:加载占位、平台字体 */
html,body,#root{height:100%;margin:0;padding:0}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:#F9FAFB;color:#1F2937}
#root::before{content:'正在加载 antd 原型……';position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);color:#9CA3AF;font-size:14px}
#root:not(:empty)::before{display:none}

/* KPI 卡片(自定义业务组件,详见 components.md) */
.lp-kpi{background:linear-gradient(180deg,#FEFCFF 0%,#FCEEEF 100%);border:1px solid #F3C7CF;border-radius:14px;padding:14px 16px}
.lp-kpi .num{font-size:24px;font-weight:700;color:#A4002A;line-height:1;margin-bottom:6px;font-variant-numeric:tabular-nums}
.lp-kpi .label{font-size:12px;color:#6B7280}

/* 紧凑分页器 */
.lp-pagination{display:flex;align-items:center;justify-content:center;gap:24px;padding:12px 16px;font-size:13px;color:#6B7280}
.lp-pagination .divider{width:1px;height:20px;background:#E5E7EB}

/* 字段提示:虚线下划线(挂在 Tooltip 包裹的 <span> 上) */
.lp-tip-trigger{cursor:help;border-bottom:1px dashed #9CA3AF;padding-bottom:1px}

/* 行内编辑 */
.lp-editable{cursor:pointer;padding:2px 6px;border-radius:6px;border:1px solid transparent;transition:all .15s;display:inline-block;min-width:40px;text-align:right}
.lp-editable:hover{border-color:#F3C7CF;background:#FFF5F5;color:#A4002A}
.lp-edit-just-saved{color:#16A34A!important;transition:color 1s}

/* 品牌红色提示条 / 小提示条 */
.lp-note{padding:14px;border-radius:10px;background:#FCEEEF;border:1px solid #F3C7CF;color:#A4002A;font-size:12px;line-height:1.8}
.lp-note-sm{padding:10px 14px;background:#FCEEEF;border:1px solid #F3C7CF;border-radius:8px;font-size:12px;color:#A4002A}

/* 区块小节标题:两种 */
.lp-section-brand{font-size:14px;font-weight:700;color:#A4002A;margin:0 0 12px}     /* 品牌红,弱区块 */
.lp-section{font-size:15px;font-weight:600;color:#1F2937;margin:0 0 12px;padding-bottom:8px;border-bottom:1px solid #E5E7EB}  /* 黑色+底线,form-section */

/* 操作记录区块标题 */
.lp-oplog-title{font-size:14px;font-weight:700;color:#A4002A;margin:24px 0 12px}

/* 空态 */
.lp-empty{display:flex;flex-direction:column;align-items:center;padding:60px 20px;text-align:center}
.lp-empty .icon{font-size:48px;margin-bottom:16px;color:#9CA3AF}
.lp-empty .icon.err{color:#DC2626}
.lp-empty .title{font-size:16px;font-weight:600;color:#1F2937;margin-bottom:8px}
.lp-empty .desc{font-size:13px;color:#6B7280;margin-bottom:24px;max-width:360px}

/* 表单只读字段网格(详情展示用) */
.lp-form-row{display:flex;gap:16px;margin-bottom:12px;align-items:center}
.lp-form-row:first-of-type{margin-top:8px}  /* 与上方标题区拉开间距 */
.lp-form-row .lp-form-label{width:96px;text-align:right;color:#6B7280;font-size:13px;flex-shrink:0}  /* 96px 够容纳 4-5 字符 + `*` 红点;不要更宽,否则 Modal 内 form 看起来偏右 */
.lp-form-row .lp-form-label .req{color:#DC2626;margin-right:4px}
.lp-form-row .lp-form-control{flex:1}
.lp-helper{font-size:12px;color:#9CA3AF;margin:-4px 0 12px 112px}  /* 112 = label 96 + gap 16 */

/* 大卡片 Radio(汇率模式 / 处理方式 等大选项) */
.lp-radio-card-group{display:flex;gap:12px;margin-bottom:16px}
.lp-radio-card{flex:1;padding:12px 16px;border:2px solid #D1D5DB;border-radius:10px;background:#fff;cursor:pointer;display:flex;align-items:center;gap:8px;transition:all .15s}
.lp-radio-card.active{border-color:#A4002A;background:#FFF5F5}
.lp-radio-card .title{font-weight:600;font-size:13px;color:#1F2937;margin-bottom:2px}
.lp-radio-card .desc{font-size:11px;color:#6B7280}

/* 详情页 preview 区(只读字段块) */
.lp-preview{border:1px solid #E5E7EB;border-radius:14px;padding:16px;background:#fff}
.lp-preview-line{display:flex;justify-content:space-between;gap:20px;padding:10px 0;border-bottom:1px solid #E5E7EB;font-size:13px}
.lp-preview-line:last-child{border-bottom:none}
.lp-preview-line .muted{color:#6B7280}

/* ===== 详情页模块骨架 =====================================================
   这四个类是详情页的**全部**容器语言,配套的 DetailGrid 组件见 components.md C.3。
   数值来自售后 v16(13 轮界面返工后的收敛结果),照抄即可,不要各模块自己拍。 */
/* 模块外壳:零视觉,不是容器,只负责模块间距 + 消掉模块末尾字段组的多余底边距。
   模块之间的分界靠 .lp-section 的底线,不靠给每块罩一层壳(rules.md A.21-1) */
.lp-module{margin-bottom:24px}
.lp-module:last-child{margin-bottom:0}
.lp-module>.lp-detail:last-child,.lp-module>div:last-child>.lp-detail{margin-bottom:0}
/* 模块 / 子区级空态:一行灰字。不用虚线空框 —— 空框比它要说的那句话占的地方还大 */
.lp-nodata{font-size:13px;color:#9CA3AF;padding:2px 0 10px}
/* 子区标题(卡外):比 .lp-section 低一级,无底线。全页只有这一种卡外子区标题类 */
.lp-subtitle{position:relative;font-size:13px;font-weight:700;color:#1F2937;margin:22px 0 10px;padding-left:10px}
.lp-subtitle::before{content:'';position:absolute;left:0;top:2px;bottom:2px;width:3px;border-radius:2px;background:#A4002A}

/* Detail Grid(label-value 网格,详情页用) */
/* ⚠ align-content:start 是必需的,不是保险丝:两栏并排时每一栏都是外层栅格的 item,
   默认 stretch 会把矮的那一栏拉到与高的那一栏等高,而 grid 的 align-content 默认值
   在行高 auto 时表现为 stretch —— 于是矮栏的行被平均撑开,栏内凭空多出空隙。
   这是"故意留白"最隐蔽的成因:代码里一个空字段都没写,空隙是 CSS 默认行为造出来的。
   2026-08-02 回扫发现商品 v40 / 营销 v14 / 用户管理 v2 全部缺这一行 —— 它们抄的是
   本文件的旧版定义,规则写在 rules.md A.21-4 里但没落到大家真正复制的这段 CSS 上。 */
.lp-detail{display:grid;grid-template-columns:120px 1fr;gap:10px 16px;font-size:13px;margin-bottom:20px;align-content:start}
/* 标签列右对齐(与 .lp-form-label 同一口径):标签右边缘与值左边缘各成一条竖线,
   同一区块里长短不一的标签不会把值挤成锯齿 */
.lp-detail .dl{color:#6B7280;text-align:right}
.lp-detail .dv{color:#1F2937}
/* 按行铺的多栏栅格(flow='row'):值与右邻标签之间只有 16px gap 会挤在一起,给值补右内边距 */
.lp-detail.lp-flow-row>.dv{padding-right:20px}

/* Code 样式(用于 Key、ID 等技术字段) */
.lp-code{font-family:Menlo,Monaco,Consolas,monospace;font-size:12px;color:#374151;background:#F3F4F6;padding:1px 6px;border-radius:4px}

/* 涨跌色 */
.rate-up{color:#16A34A;font-weight:600}
.rate-down{color:#DC2626;font-weight:600}
.rate-flat{color:#9CA3AF}

/* 自定义"译文过期"等 spec 6 色之外的语义色 */
.lp-expired-pill{background:#FFF7ED;color:#C2410C;padding:2px 10px;border-radius:6px;font-size:12px;font-weight:500;display:inline-block}

/* 上传拖拽区(若不用 Upload.Dragger 时的占位) */
.lp-upload-zone{border:2px dashed #D1D5DB;border-radius:14px;padding:32px;text-align:center;background:#FAFAFA}
.lp-upload-zone .hint{font-size:13px;color:#6B7280;margin-bottom:8px}
.lp-upload-zone .sub{font-size:12px;color:#9CA3AF;margin-top:8px}

/* 键盘焦点态(a11y 硬性,品牌红色 inset shadow;详见 G 段) */
:focus-visible{outline:none;box-shadow:inset 0 0 0 2px rgba(164,0,42,.4)}

/* 减弱动效(spec 硬性;详见 G 段) */
@media(prefers-reduced-motion:reduce){*{transition:none!important;animation:none!important}}
```

## E. 字段值速查(token → spec 章节)

| token | 值 | spec 来源 |
|---|---|---|
| colorPrimary | `#A4002A` | 品牌主色 brand-primary |
| colorBgLayout | `#F9FAFB` | 页面背景 bg-page |
| colorBorder | `#E5E7EB` | 主分割线 border-primary |
| borderRadius (sm) | 8 | 按钮/输入框 |
| borderRadiusLG | 14 | 表格容器 / KPI 卡 |
| Card.borderRadiusLG | 16 | 卡片 xl 圆角(覆盖全局) |
| controlHeight | 34 | 按钮/输入框 spec 高度 |
| fontSize | 14 | body 默认 |
| Table.cellFontSize | 13 | 表格 cell spec |
| Table.headerColor | `#6B7280` | 表头 spec |
| Menu.itemSelectedBg | `#FCEEEF` | 激活态(原 spec 是渐变,降级纯色) |
| Menu.itemBorderRadius | 0 | 让激活态贯穿到 Sider 两边 |

## F. 语义色 → Tag variant 映射

```jsx
const TAG_COLORS = {
  on:      { bg: '#F0FDF4', color: '#16A34A' },  // 启用/成功
  sale:    { bg: '#EFF6FF', color: '#2563EB' },  // 在售/常规
  pending: { bg: '#FFFBEB', color: '#D97706' },  // 待审/警告
  off:     { bg: '#F3F4F6', color: '#6B7280' },  // 停用/中性
  req:     { bg: '#FEF2F2', color: '#DC2626' },  // 错误/失败
  warn:    { bg: '#FFF1F2', color: '#E11D48' },  // 危险/锁定
  desc:    { bg: '#F0FDF4', color: '#16A34A' },  // 描述/同 on
  enum:    { bg: '#FFFBEB', color: '#D97706' },  // 枚举/同 pending
  opt:     { bg: '#F3F4F6', color: '#6B7280' },  // 可选/同 off
};
```

业务组件 `<StatusTag variant={...}>` 详见 `components.md`。

## G. 交互 / 动效规范

antd 默认动效已够用,本节固化"必须保留"的交互细节。CSS 部分已在 D 段;产物交付前按 `self-check.md` 手动视觉项对照。

### 动效时长

| 场景 | 时长 | 说明 |
|---|---|---|
| 菜单展开 / 折叠 | `.15s` | antd Menu 默认,不改 |
| 折叠箭头旋转 | `.2s` | 折叠指示器 |
| 面板 / 卡片折叠 | `.3s` | 缓动 `cubic-bezier(.4,0,.2,1)` |

`.lp-editable` / `.lp-radio-card` 等业务组件的 `transition:all .15s` 已在 D 段固化。

### 键盘焦点态(a11y,硬性)

- 全局 `:focus-visible` 用品牌红色 inset shadow `inset 0 0 0 2px rgba(164,0,42,.4)`(已在 D 段固化)
- 不要用浏览器默认 outline,也不要 `outline:none` 之后不补焦点态

### 减弱动效(硬性)

- 全局 CSS **必须**含 `@media(prefers-reduced-motion:reduce){*{transition:none!important;animation:none!important}}`(已在 D 段固化)

### 触摸目标最小高度(设计目标)

| 层级 | 最小高度 |
|---|---|
| 一级菜单 | 44px |
| 二级菜单 | 40px |
| 三级菜单 | 36px |

> 当前 `Menu.itemHeight` 为全局 **40**(B 段)。antd Menu 不支持按层级设高(同 rules.md B.4 的分级 padding 限制),二级已达标;一级如需 44 可在 `menu-parent` 上单独加 `minHeight`,三级 36 属下限提示,不必强制压低。这是设计目标,非 token 强约束。
