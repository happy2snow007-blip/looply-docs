# theme.md — looplyTheme 完整代码

> 取自 `original-spec/looply-admin-ui-spec.md`,固化为 antd 6.4.x 可直接使用的 token + 全局 CSS。
>
> **转译时整段复制本文件的代码到产物**,不要重新推导 token 值。

## 目录

| 段 | 内容 | 行号 |
|---|---|---|
| **A. CDN 引用块**(必需,`<head>` 整段复制) | React 18 + antd 6 + dayjs + icons + Babel | 16 |
| § A.0 Logo | base64 嵌入 `logo-240.png`(禁字体仿造)| 22 |
| § A.1 CDN 锁定(硬性) | jsdelivr + antd@6 + icons@6,禁 unpkg / antd@5 | 49 |
| **B. ConfigProvider 主题 token** | `looplyTheme` 对象,直接整段抄进 `<script>` | 71 |
| **C. 通用 style 常量** | token 表达不了的部分(CARD_STYLE / TABLE_STYLES / SIDER_STYLE) | 160 |
| **D. 全局 CSS** | `.lp-*` 业务组件用的 class,放 `<style>` | 180 |
| **E. 字段值速查**(token → spec 章节锚点) | 反查"这个值为什么是这个数" | 269 |
| **F. 语义色 → Tag variant 映射** | StatusTag 颜色编码 | 286 |

**按场景读**:
- 初次转译 → A 段整段抄 + B 段整段抄到 `<script>`
- 改主题色 → 改 § B `looplyTheme` 即可
- 写新业务组件 → 看 § C 常量 + § D CSS class 命名约定

## A. CDN 引用块(必需,放在 `<head>`)

**整段照抄,不要改任何一行**。版本号 / CDN 提供方 / `crossorigin` 属性 / 顺序都已经过验证。

```html
<script crossorigin src="https://cdn.jsdelivr.net/npm/react@18/umd/react.production.min.js"></script>
<script crossorigin src="https://cdn.jsdelivr.net/npm/react-dom@18/umd/react-dom.production.min.js"></script>
<script crossorigin src="https://cdn.jsdelivr.net/npm/dayjs@1/dayjs.min.js"></script>
<script crossorigin src="https://cdn.jsdelivr.net/npm/antd@6/dist/antd.min.js"></script>
<script crossorigin src="https://cdn.jsdelivr.net/npm/@ant-design/icons@6/dist/index.umd.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@babel/standalone/babel.min.js"></script>
```

UMD 暴露的全局变量:`React` / `ReactDOM` / `dayjs` / `antd` / `icons` / `Babel`

### A.0 Logo(必须嵌入 base64,禁止字体模拟)

产物 Header 左上角 logo **必须**使用本仓库 `assets/logo-240.png` 的 base64 嵌入,**禁止**用 `<span style={{fontSize,fontWeight,color,letterSpacing}}>Looply</span>` 这种字体仿造。

#### 嵌入方式:占位符 + 后处理(**唯一允许的方式**)

```jsx
// 1. 在 <script type="text/babel"> 顶部声明:
const LOGO_SRC = "data:image/png;base64,{{LOGO_PLACEHOLDER}}";

// 2. Layout.Header 内使用:
<img src={LOGO_SRC} alt="Looply" style={{ height: 32, display: 'block' }} />

// 3. 产物完成后 / 交付前,跑:
//    python3 scripts/embed_logo.py outputs/产物.html
//    脚本会读 assets/logo-240.png 转 base64,替换 {{LOGO_PLACEHOLDER}}
```

**禁止做的事**:
- ❌ **subagent 自己把 17000 字符的 base64 字面字符串塞进产物** — 实测会**截断**(只复制开头一段然后自己拼 PNG 尾部签名),导致浏览器渲染空白棋盘格
- ❌ 跳过 `embed_logo.py`,产物里留 `{{LOGO_PLACEHOLDER}}` 字面符号 — `scripts/check.sh` 会报 ❌

#### 自检

```bash
# 产物里不应该残留占位符
grep "LOGO_PLACEHOLDER" outputs/产物.html  # 期望:无输出
# 产物里 base64 长度应该 ≥ 17000 字符
grep -oE 'base64,[A-Za-z0-9+/=]+' outputs/产物.html | head -1 | wc -c  # 期望:≥ 17000
```

**理由**:
- 字体仿造跨平台渲染不一致(macOS / Windows / Linux 字重不同)
- Logo 是品牌资产,不能用文字替代
- base64 嵌入保证"双击 HTML 打开"零依赖,即使无网络也显示

**约束**:
- 用 `logo-240.png`(240×78 压缩版,~12KB / base64 ~17KB),不要用原始 1080×352(123KB)版,产物体积会爆
- 高度固定 `height: 32`(antd Header 64px 高,32px 居中视觉舒适)

### A.1 CDN 锁定(硬性)

| 项 | 锁定值 | 不允许 |
|---|---|---|
| CDN 提供方 | **`cdn.jsdelivr.net`** | unpkg.com / cdnjs.cloudflare.com / 其他 |
| antd 版本 tag | **`antd@6`**(自动追 6.x 最新) | `antd@5` / `antd@5.24.6` / 任何 v5 |
| react 版本 tag | **`react@18`** | react@19(无 UMD)/ react@17(过老) |
| icons CDN | **必须显式引入**(`@ant-design/icons@6`) | 省略后导致只能用 Emoji 替代(违反 rules.md A.4.1) |

**B 组实测踩坑**:
- "v6 没 UMD" → 自行降级到 antd@5.24.6 → 主题 token 在 v6 已变,`.ant-*` CSS 覆盖在 v6 失效。**事实是 jsdelivr 的 `antd@6` tag 存在,直接抄上面的清单即可**
- 没引 icons CDN → 用 Emoji `★◈` 替代 → 视觉不统一(违反 A.4.1)

**自检命令**(产物完成时跑):
```bash
grep -c "cdn.jsdelivr.net" 产物.html       # 必须 ≥ 6(对应 6 个 CDN 脚本)
grep -c "antd@6"            产物.html       # 必须 ≥ 1
grep -c "antd@5"            产物.html       # 必须为 0
grep -c "@ant-design/icons" 产物.html       # 必须 ≥ 1
grep -c "unpkg.com"         产物.html       # 必须为 0
```

## B. ConfigProvider 主题 token(JSX,在 `<script type="text/babel">` 内)

```jsx
const looplyTheme = {
  token: {
    colorPrimary: '#7C3AED',
    colorInfo: '#7C3AED',
    colorBgLayout: '#F9FAFB',
    colorBgContainer: '#FFFFFF',
    colorText: '#1F2937',
    colorTextSecondary: '#374151',
    colorTextTertiary: '#4B5563',
    colorTextDescription: '#6B7280',
    colorTextPlaceholder: '#9CA3AF',
    colorBorder: '#E5E7EB',
    colorBorderSecondary: '#F3F4F6',
    colorSuccess: '#16A34A',
    colorWarning: '#D97706',
    colorError: '#DC2626',
    borderRadius: 8,
    borderRadiusLG: 14,
    borderRadiusSM: 6,
    fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
    fontSize: 14,
    controlHeight: 34,
    controlHeightSM: 28,
  },
  components: {
    Layout: {
      headerBg: '#FFFFFF',
      headerHeight: 60,
      headerPadding: '0 24px',
      siderBg: '#FFFFFF',
      bodyBg: '#F9FAFB',
    },
    Menu: {
      itemBg: 'transparent',
      subMenuItemBg: 'transparent',
      itemHoverBg: 'rgba(0,0,0,.03)',
      itemSelectedBg: '#F3EEFF',
      itemSelectedColor: '#7C3AED',
      // 激活态贯穿到边(去 antd 默认胶囊圆角)
      itemBorderRadius: 0,
      itemMarginInline: 0,
      itemMarginBlock: 0,
      itemHeight: 40,
      subMenuItemBorderRadius: 0,
    },
    Card: {
      borderRadiusLG: 16,
      paddingLG: 28,
    },
    Table: {
      headerBg: '#FFFFFF',
      headerColor: '#6B7280',
      rowHoverBg: '#FAF5FF',
      borderColor: '#E5E7EB',
      headerSplitColor: 'transparent',
      // spec 只规定 cell=13px,不分尺寸;small 只在 padding 上紧凑
      cellFontSize: 13,
      cellFontSizeMD: 13,
      cellFontSizeSM: 13,
      cellPaddingBlock: 11,
      cellPaddingInline: 12,
      cellPaddingBlockMD: 11,
      cellPaddingInlineMD: 12,
      cellPaddingBlockSM: 9,
      cellPaddingInlineSM: 12,
      headerBorderRadius: 0,
    },
    Tag: {
      defaultBg: '#F3F4F6',
      defaultColor: '#6B7280',
    },
    Tabs: {
      itemSelectedColor: '#7C3AED',
      itemHoverColor: '#374151',
      inkBarColor: '#7C3AED',
    },
    Steps: { colorPrimary: '#7C3AED' },
    Button: { controlHeight: 34, paddingInline: 14, fontSize: 13 },
    Input:  { controlHeight: 34, paddingInline: 12 },
    Select: { controlHeight: 34 },
    DatePicker: { controlHeight: 34 },
    Modal:  { borderRadiusLG: 16, paddingContentHorizontalLG: 28 },
  },
};
```

## C. 通用 style 常量(token 表达不了的部分,通过 style prop 注入)

```jsx
// Card 卡片阴影(antd Card 没暴露 shadow token)
const CARD_STYLE = { boxShadow: '0 10px 24px rgba(16,24,40,.06)', marginBottom: 20 };

// Table styles.root(token 不能配置整体边框 + 圆角)
const TABLE_STYLES = { root: { borderRadius: 14, border: '1px solid #E5E7EB', overflow: 'hidden' } };

// Sider style(阴影 + 菜单超长滚动)
// 必须带 overflowY:'auto',否则三级菜单 / 长菜单全展开后会超出 viewport
// 配合外层 <Layout style={{ height: '100vh' }}>,Sider 高度由 Layout 撑开
const SIDER_STYLE = {
  boxShadow: '3px 0 12px rgba(0,0,0,0.06)',
  padding: '8px 0',
  overflowY: 'auto',
  height: '100%',
};
```

## D. 全局 CSS(放在 `<style>` 标签里,业务组件用)

```css
/* 基础:加载占位、平台字体 */
html,body,#root{height:100%;margin:0;padding:0}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:#F9FAFB;color:#1F2937}
#root::before{content:'正在加载 antd 原型……';position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);color:#9CA3AF;font-size:14px}
#root:not(:empty)::before{display:none}

/* KPI 卡片(自定义业务组件,详见 components.md) */
.lp-kpi{background:linear-gradient(180deg,#FEFCFF 0%,#F3EEFF 100%);border:1px solid #DDD6FE;border-radius:14px;padding:14px 16px}
.lp-kpi .num{font-size:24px;font-weight:700;color:#7C3AED;line-height:1;margin-bottom:6px;font-variant-numeric:tabular-nums}
.lp-kpi .label{font-size:12px;color:#6B7280}

/* 紧凑分页器 */
.lp-pagination{display:flex;align-items:center;justify-content:center;gap:24px;padding:12px 16px;font-size:13px;color:#6B7280}
.lp-pagination .divider{width:1px;height:20px;background:#E5E7EB}

/* 字段提示:虚线下划线(挂在 Tooltip 包裹的 <span> 上) */
.lp-tip-trigger{cursor:help;border-bottom:1px dashed #9CA3AF;padding-bottom:1px}

/* 行内编辑 */
.lp-editable{cursor:pointer;padding:2px 6px;border-radius:6px;border:1px solid transparent;transition:all .15s;display:inline-block;min-width:40px;text-align:right}
.lp-editable:hover{border-color:#DDD6FE;background:#FAF5FF;color:#7C3AED}
.lp-edit-just-saved{color:#16A34A!important;transition:color 1s}

/* 紫色提示条 / 小提示条 */
.lp-note{padding:14px;border-radius:10px;background:#F3EEFF;border:1px solid #DDD6FE;color:#6D28D9;font-size:12px;line-height:1.8}
.lp-note-sm{padding:10px 14px;background:#F3EEFF;border:1px solid #DDD6FE;border-radius:8px;font-size:12px;color:#6D28D9}

/* 区块小节标题:两种 */
.lp-section-purple{font-size:14px;font-weight:700;color:#7C3AED;margin:0 0 12px}     /* 紫色,弱区块 */
.lp-section{font-size:15px;font-weight:600;color:#1F2937;margin:0 0 12px;padding-bottom:8px;border-bottom:1px solid #E5E7EB}  /* 黑色+底线,form-section */

/* 操作记录区块标题 */
.lp-oplog-title{font-size:14px;font-weight:700;color:#7C3AED;margin:24px 0 12px}

/* 空态 */
.lp-empty{display:flex;flex-direction:column;align-items:center;padding:60px 20px;text-align:center}
.lp-empty .icon{font-size:48px;margin-bottom:16px;color:#9CA3AF}
.lp-empty .icon.err{color:#DC2626}
.lp-empty .title{font-size:16px;font-weight:600;color:#1F2937;margin-bottom:8px}
.lp-empty .desc{font-size:13px;color:#6B7280;margin-bottom:24px;max-width:360px}

/* 表单只读字段网格(详情展示用) */
.lp-form-row{display:flex;gap:16px;margin-bottom:12px;align-items:center}
.lp-form-row:first-of-type{margin-top:8px}  /* 与上方标题区拉开间距 */
.lp-form-row .lp-form-label{width:96px;text-align:right;color:#6B7280;font-size:13px;flex-shrink:0}  /* 96px 够容纳 4-5 字符 + `*` 红点;不要更宽,否则 Modal 内 form 看起来偏右 */
.lp-form-row .lp-form-label .req{color:#DC2626;margin-right:4px}
.lp-form-row .lp-form-control{flex:1}
.lp-helper{font-size:12px;color:#9CA3AF;margin:-4px 0 12px 112px}  /* 112 = label 96 + gap 16 */

/* 大卡片 Radio(汇率模式 / 处理方式 等大选项) */
.lp-radio-card-group{display:flex;gap:12px;margin-bottom:16px}
.lp-radio-card{flex:1;padding:12px 16px;border:2px solid #D1D5DB;border-radius:10px;background:#fff;cursor:pointer;display:flex;align-items:center;gap:8px;transition:all .15s}
.lp-radio-card.active{border-color:#7C3AED;background:#FAF5FF}
.lp-radio-card .title{font-weight:600;font-size:13px;color:#1F2937;margin-bottom:2px}
.lp-radio-card .desc{font-size:11px;color:#6B7280}

/* 详情页 preview 区(只读字段块) */
.lp-preview{border:1px solid #E5E7EB;border-radius:14px;padding:16px;background:#fff}
.lp-preview-line{display:flex;justify-content:space-between;gap:20px;padding:10px 0;border-bottom:1px solid #E5E7EB;font-size:13px}
.lp-preview-line:last-child{border-bottom:none}
.lp-preview-line .muted{color:#6B7280}

/* Detail Grid(label-value 网格,详情页用) */
.lp-detail{display:grid;grid-template-columns:120px 1fr;gap:10px 16px;font-size:13px;margin-bottom:24px}
.lp-detail .dl{color:#6B7280}
.lp-detail .dv{color:#1F2937}

/* Code 样式(用于 Key、ID 等技术字段) */
.lp-code{font-family:Menlo,Monaco,Consolas,monospace;font-size:12px;color:#374151;background:#F3F4F6;padding:1px 6px;border-radius:4px}

/* 涨跌色 */
.rate-up{color:#16A34A;font-weight:600}
.rate-down{color:#DC2626;font-weight:600}
.rate-flat{color:#9CA3AF}

/* 自定义"译文过期"等 spec 6 色之外的语义色 */
.lp-expired-pill{background:#FFF7ED;color:#C2410C;padding:2px 10px;border-radius:6px;font-size:12px;font-weight:500;display:inline-block}

/* 上传拖拽区(若不用 Upload.Dragger 时的占位) */
.lp-upload-zone{border:2px dashed #D1D5DB;border-radius:14px;padding:32px;text-align:center;background:#FAFAFA}
.lp-upload-zone .hint{font-size:13px;color:#6B7280;margin-bottom:8px}
.lp-upload-zone .sub{font-size:12px;color:#9CA3AF;margin-top:8px}

/* 减弱动效(spec 硬性) */
@media(prefers-reduced-motion:reduce){*{transition:none!important;animation:none!important}}
```

## E. 字段值速查(token → spec 章节)

| token | 值 | spec 来源 |
|---|---|---|
| colorPrimary | `#7C3AED` | 品牌主色 brand-primary |
| colorBgLayout | `#F9FAFB` | 页面背景 bg-page |
| colorBorder | `#E5E7EB` | 主分割线 border-primary |
| borderRadius (sm) | 8 | 按钮/输入框 |
| borderRadiusLG | 14 | 表格容器 / KPI 卡 |
| Card.borderRadiusLG | 16 | 卡片 xl 圆角(覆盖全局) |
| controlHeight | 34 | 按钮/输入框 spec 高度 |
| fontSize | 14 | body 默认 |
| Table.cellFontSize | 13 | 表格 cell spec |
| Table.headerColor | `#6B7280` | 表头 spec |
| Menu.itemSelectedBg | `#F3EEFF` | 激活态(原 spec 是渐变,降级纯色) |
| Menu.itemBorderRadius | 0 | 让激活态贯穿到 Sider 两边 |

## F. 语义色 → Tag variant 映射

```jsx
const TAG_COLORS = {
  on:      { bg: '#F0FDF4', color: '#16A34A' },  // 启用/成功
  sale:    { bg: '#EFF6FF', color: '#2563EB' },  // 在售/常规
  pending: { bg: '#FFFBEB', color: '#D97706' },  // 待审/警告
  off:     { bg: '#F3F4F6', color: '#6B7280' },  // 停用/中性
  req:     { bg: '#FEF2F2', color: '#DC2626' },  // 错误/失败
  warn:    { bg: '#FFF1F2', color: '#E11D48' },  // 危险/锁定
  desc:    { bg: '#F0FDF4', color: '#16A34A' },  // 描述/同 on
  enum:    { bg: '#FFFBEB', color: '#D97706' },  // 枚举/同 pending
  opt:     { bg: '#F3F4F6', color: '#6B7280' },  // 可选/同 off
};
```

业务组件 `<StatusTag variant={...}>` 详见 `components.md`。
