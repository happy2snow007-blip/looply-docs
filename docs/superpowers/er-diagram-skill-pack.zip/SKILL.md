---
name: er-diagram-generation
description: Use when designing, creating, modifying, or reviewing entity-relationship diagrams for any module. Triggers on tasks involving ER diagram SVG files, entity field design, database table structure design, or cross-checking ER diagrams against product architecture diagrams.
---

# 实体关系图生成方法（SVG 版）

## 输出格式

**SVG 静态版**：Python 数据驱动 + Graphviz 生成，SVG 源码内嵌结构化 metadata（JSON + YAML）供开发提取

## 通用生成流程

### 前置步骤
1. 用户告诉我模块名
2. **前置检查**：确认该模块的产品架构图是否已完成。没有架构图 → 提醒用户并确认是否继续画ER图
3. 读取该模块的产品架构图，理解模块边界、功能项、术语命名
4. **跨模块字段一致性检查**：扫一遍已有模块的公共字段（如 user_id、country_code、created_at 的命名和类型），同一概念必须用相同的列名、类型、约束
5. 基于产品架构图，梳理出实体列表和关系，逐步跟用户确认：
   - 先确认实体列表和分组
   - 再确认每个实体的核心字段
   - 最后确认实体间关系
6. **架构图交叉对比（双向）**：每次改版时都跑一遍
   - 正向：架构图有但ER图没有的功能项 → 逐项确认是"当前不做"还是"遗漏"
   - 反向：ER图每个实体在架构图里属于哪一层 → 如果属于"外围系统"或"技术能力"，说明不是本模块专属，考虑归入公共能力分组

---

## SVG 版本（Python 数据驱动 + Graphviz）

### 核心原则（硬性）
- **必须用 Python 数据驱动脚本**，禁止手写 .dot 文件
- 数据区（ENTITIES / RELATIONS / LAYERS dict）是唯一数据源
- 渲染区调用 Python graphviz 库 → Graphviz dot 引擎自动布局 → 生成 .svg
- metadata 自动嵌入 SVG，技术可直接提取建表信息
- 改实体只改数据区，不碰渲染逻辑

### 前置依赖
- **Graphviz 命令行工具**：需安装 `dot` 命令（macOS: `brew install graphviz`）
- **Python graphviz 库**：`pip3 install graphviz`
- 首次使用时检查是否已安装，未安装则提醒用户

### 生成步骤
1. 在 Python 脚本数据区定义 ENTITIES / RELATIONS / LAYERS / DESIGN_RULES
2. 渲染区调用 `graphviz.Digraph` 构建图结构
3. `dot.render()` 自动生成 `.dot`（中间产物）+ `.svg`
4. 脚本自动嵌入结构化 JSON metadata 到 SVG `<metadata><er-schema>` 标签
5. **脚本自动从 JSON 生成 YAML 块**（每个 column 追加 type/nullable/default/enum_values/index 空位），嵌入 `<metadata><er-tech-spec>` 标签（CDATA 包裹）
6. 输出文件（均在同目录）：
   - `gen_{模块名}_er.py`（生成脚本，唯一数据源）
   - `looply-{模块名}实体关系图.svg`（最终产物，含 JSON + YAML 双 metadata）
7. 用浏览器打开 SVG 验证

### Python 数据结构

```python
# --- 分层定义 ---
LAYERS = {
    'layer_id': {
        'label': '层名',
        'fillcolor': '#EBF3FB', 'color': '#a3c4e9', 'fontcolor': '#4A90D9',
        'header_bg': '#4A90D9',  # 该层实体卡片标题背景色
    },
}

# --- 实体定义 ---
ENTITIES = [
    {
        'id': 'entity_name',       # 英文实体名（同时作为数据库表名）
        'name': '中文名',           # 卡片标题显示
        'layer': 'layer_id',       # 归属哪一层
        'header_bg': '#546E7A',    # 可选，覆盖层默认标题色（映射表/特殊实体用）
        'note': '备注说明',         # 可选，卡片底部备注
        'fields': [
            {
                'col': 'column_name',    # 英文列名
                'n': '中文说明',          # 卡片显示
                'constraint': 'PK',      # PK / FK / UK / 空
            },
        ],
    },
]

# --- 关系定义 ---
RELATIONS = [
    {
        'from': 'entity_a', 'to': 'entity_b',
        'type': 'N:1', 'label': '关系说明',
        'color': '#1565C0',        # 可选，默认浅蓝
        'penwidth': 1.4,           # 可选，主链路加粗
        'style': 'dashed',         # 可选，虚线表示预留关系
    },
]

# --- 设计规则（嵌入 metadata 供技术参考）---
DESIGN_RULES = {
    'rule_key': '规则说明文本',
}
```

### SVG 视觉规范
- **卡片显示**：中文字段名 + 英文列名 + 约束标记（[PK]/[FK]/[UK]）
- **分组聚集**：用 Graphviz subgraph cluster 实现同层同色聚集
- **布局方向**：`rankdir=LR`（左右布局），Graphviz dot 引擎自动排列
- **卡片样式**：HTML-like TABLE label，标题条深色白字，外边框 2px
- **连线**：带箭头 + 关系标签，主链路加粗，普通引用细线
- **备注行**：浅蓝底斜体，显示设计约束说明

### SVG Metadata 嵌入规范（硬性）
SVG 文件头部自动嵌入 `<metadata>` 元素，包含两个数据块：

1. `<er-schema format="json">` — 产品定义（画图渲染用）
2. `<er-tech-spec format="yaml">` — 技术编码用（CDATA 包裹，开发直接提取补充）

```xml
<svg ...>
  <metadata>
    <er-schema format="json" version="1.0">
    {
      "title": "looply · 模块名 实体关系图",
      "version": "v1.0 · 2026-04-14",
      "tables": [
        {
          "name": "entity_name",
          "comment": "中文名",
          "columns": [
            { "name": "col_name", "comment": "中文说明", "constraint": "PRIMARY KEY" }
          ],
          "note": "备注"
        }
      ],
      "relations": [ ... ],
      "design_rules": { ... }
    }
    </er-schema>
    <er-tech-spec format="yaml"><![CDATA[
    title: looply · 模块名 实体关系图
    version: v1.0 · 2026-04-14
    tables:
    - name: entity_name
      comment: 中文名
      note: ''
      columns:
      - name: col_name
        comment: 中文说明
        constraint: PRIMARY KEY
        type:              # 开发填：VARCHAR(100), BIGINT, DECIMAL(10,2), TIMESTAMP 等
        nullable:          # 开发填：true / false
        default:           # 开发填：'active', NOW(), 0 等
        enum_values:       # 开发填：[active, inactive, deleted] 等
        index:             # 开发填：idx_xxx 等
    relations: [...]
    design_rules: {...}
    ]]></er-tech-spec>
  </metadata>
</svg>
```

YAML 块中每个 column 包含：
- 产品预填字段：`name`、`comment`、`constraint`（从 JSON 同步）
- 技术待填字段：`type`、`nullable`、`default`、`enum_values`、`index`（留空）

只维护一个 SVG 文件，不单独导出 YAML 或 JSON。新建或更新 SVG 时必须同步生成/更新两个块。

技术提取方式：
```python
# 提取 JSON（产品定义）
import xml.etree.ElementTree as ET, json
root = ET.parse('xxx.svg').getroot()
data = json.loads([e for e in root.iter() if 'er-schema' in e.tag][0].text)

# 提取 YAML（技术编码）
import re, yaml
with open('xxx.svg') as f: svg = f.read()
yaml_str = re.search(r'<er-tech-spec[^>]*><!\[CDATA\[(.*?)\]\]></er-tech-spec>', svg, re.DOTALL).group(1)
spec = yaml.safe_load(yaml_str)
```

Shell 提取（无需 Python）：
```bash
sed -n '/<er-tech-spec/,/<\/er-tech-spec>/p' xxx.svg | sed '1d;$d' | sed 's/<!\[CDATA\[//' | sed 's/\]\]>//'
```

### 渲染区模板要点
- 脚本开头自动检测 `/opt/homebrew/bin` 加入 PATH（macOS brew 兼容）
- `build_card_label(entity)` 根据 fields 和 note 生成 HTML TABLE
- `build_graph()` 按 LAYERS 创建 subgraph，按 RELATIONS 创建 edge
- `build_metadata()` 从数据区直接构建 JSON，无需反向解析 .dot
- `build_tech_yaml(meta_json)` 从 JSON 自动生成 YAML 块，每个 column 追加 type/nullable/default/enum_values/index 空位
- `embed_metadata(svg_path, meta_json)` 用 xml.etree 插入 `<metadata>` 节点，同时嵌入 JSON 块和 YAML 块（CDATA 包裹）
- 参考实现：`~/Desktop/海外业务/商品/实体关系图/gen_商品主数据_er.py`

---

## 前置步骤（必须）
- **先确认模块边界**：明确模块的核心职责，只画本模块"拥有"的实体
- **区分"拥有"和"引用"**：本模块创建和管理的实体才画进来，其他模块的实体只标外部引用，不展开字段
- **先梳理核心业务流程**：从用户操作流程推导需要哪些实体，不要凭技术经验直接列
- **先确认本期范围**：新增实体前先确认是否属于本期范围，不确定就先问
- **公共能力判断**：设计每个实体时问三个问题：①这个实体的数据，其他模块会读吗？②其他模块会写吗？③架构图里这个能力放在哪一层？任一答案指向"跨模块"，先标记为公共能力候选，与用户确认

## 欧美电商调研标准化
- 每次涉及业务特征审视（自检清单第6条）时，按业务类型查参考平台：
  - 二手电商：Vinted、Poshmark、Depop、Mercari、TheRealReal、Fashionphile
  - 二手/翻新电子：Back Market
  - 快时尚电商：SHEIN
  - 综合电商：eBay、Amazon、Shopify
  - 本地生活：Etsy
- 每次调研至少查 3 个同类平台，记录结论
- **方案与常规做法不一致时，必须与用户确认后再决定**

## 架构图 vs 实体关系图的边界判断
- **架构图回答"系统能做什么"，实体关系图回答"系统需要记住什么"**
- 架构图该有的：用户可感知的能力、业务规则、技术能力模块
- 只在实体关系图体现的（不需要出现在架构图）：
  - **日志/记录类** — 审计日志、登录日志、操作流水。是能力的"副产品"，不是能力本身
  - **中间状态类** — 验证码记录、Token 存储。用户只感知"收到验证码"这个能力，不关心怎么存
  - **关联/映射类** — 多对多中间表、绑定关系表。是数据结构的需要，不是业务能力
- **一句话判断法**：如果去掉这个东西，用户或产品经理在讨论需求时不会提到它，那它就只属于实体关系图

## 分组规则
- 实体关系图的分组必须和产品架构图的模块划分保持一致，不按技术分类拆分
- 有直接关系的非核心实体必须在同一个 group

## 命名规范
- 实体名称、字段名称必须和产品架构图保持一致
- 新建或修改时先核对产品架构图中的术语

## 修改前自检清单
分阶段执行，降低单次检查负担：
- **阶段A（实体设计时，每个实体必过）**：第3、8、9、10、12条
- **阶段B（字段设计时，每个字段必过）**：第1、4、5、6、7、11条
- **阶段C（整体完成后，全图过一遍）**：全部12条 + 架构图交叉对比

1. **命名对齐**：实体名、字段名是否和产品架构图一致
2. **分组对齐**：分组是否和产品架构图的模块划分一致
3. **范围确认**：新增实体是否属于本期范围，不确定先问
4. **字段完整性**：每个字段都要有 col/t/constraint/desc
5. **数据链路完整性（必须严格执行）**：每个实体的关键字段，沿业务流程从头走到尾，确认数据链路完整——输入→处理→输出→结果，每个环节都有字段承接。不能只设计前半段就停下。**额外检查：每个非用户直接输入的字段，必须追问"这个值怎么产生的"——是用户填的、系统算的、还是外部传的？如果是系统算的，计算规则在哪个实体承载？没有承载就是遗漏**
6. **业务特征审视（必须严格执行）**：每个实体的字段设计，必须结合项目核心业务特征（如多国、多渠道、多角色）审视，确认字段粒度能支撑业务场景。不能按通用模板画，要问自己"这个项目的特殊性会影响哪些字段"。审视时主动搜索欧美电商常规做法作为参考，与用户确认后再决定
7. **三方系统数据确认（必须严格执行）**：涉及三方系统对接的实体，必须逐个列出每个三方平台，由用户确认各平台的数据返回结构和限制后再设计字段。不能按统一模型假设，不能替用户假定三方返回内容
8. **字段归属判断（必须严格执行）**：每个字段问"这个数据的生命周期归谁管——谁创建、谁更新、谁删除"。如果答案是另一个模块的业务流程，就不该放在当前模块。不能按"和谁有关"来放，要按"归谁管"来放
9. **字段必须有业务场景（必须严格执行）**：每个字段必须能说清楚"哪个业务场景用到它"，说不清就不加。不凭直觉觉得"应该有"
10. **如非必要，勿增实体**：能用现有实体加字段解决的，不新建实体。能用代码逻辑区分的，不加数据字段
11. **字段命名产品可读性（必须严格执行）**：字段名和枚举值要从产品视角审视，非技术人员能否一眼看懂含义。如果两个字段名容易混淆（如 result 和 verify_result），必须重新命名让语义清晰
12. **实体归属判断（必须严格执行）**：每个实体问"这个实体只服务于当前模块，还是多个模块都会用"。如果多个模块都会用，归入公共能力分组，备注"本期随XX模块建设"

## 文件存放
- 生成的文件：放到对应业务模块的实体关系图目录下
- SVG 版命名：`looply-{模块名}实体关系图.svg`（同目录还有 `.dot` 和 `gen_{模块名}_er.py`）
- **版本管理**：每次改版前，先将当前主文件复制一份备份（如 `looply-{模块名}实体关系图-v7.0.svg`），再在主文件上修改新版本。主文件始终是最新版

## 参考实现
- 脚本模板：本 skill 目录下 `gen_er_template.py`（渲染区完整实现，数据区为空壳，复制后填数据即可）
- 商品系统实例：`~/Desktop/海外业务/商品/实体关系图/gen_商品主数据_er.py`
- **新建实体关系图时，复制 `gen_er_template.py` 为 `gen_{模块名}_er.py`，只改数据区**
