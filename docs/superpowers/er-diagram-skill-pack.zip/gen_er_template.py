#!/usr/bin/env python3
"""
looply 实体关系图 SVG 生成脚本模板

用法：
  1. 复制本文件，重命名为 gen_{模块名}_er.py
  2. 修改数据区（TITLE / VERSION / OUTPUT_NAME / LAYERS / ENTITIES / RELATIONS / DESIGN_RULES）
  3. 运行：python3 gen_{模块名}_er.py
  4. 产出：{OUTPUT_NAME}.dot + {OUTPUT_NAME}.svg（含 JSON + YAML 双 metadata）

前置依赖：
  - brew install graphviz
  - pip3 install graphviz pyyaml
"""
import graphviz
import json
import os
import re
import xml.etree.ElementTree as ET
import yaml

# 确保 Graphviz 可执行文件在 PATH 中（macOS brew 安装路径）
if os.path.isdir('/opt/homebrew/bin'):
    os.environ['PATH'] = '/opt/homebrew/bin:' + os.environ.get('PATH', '')

# ============================================================
# 数据区（唯一数据源，改实体只改这里）
# ============================================================

TITLE = 'looply · 模块名 实体关系图'
VERSION = 'v1.0 · 2026-04-27'
OUTPUT_NAME = 'looply-模块名实体关系图-v1.0'

# --- 分层定义 ---
# 每层对应一个 Graphviz subgraph cluster，同层实体聚集在一起
LAYERS = {
    'core': {
        'label': '核心层',
        'fillcolor': '#EBF3FB', 'color': '#a3c4e9', 'fontcolor': '#4A90D9',
        'header_bg': '#4A90D9',
    },
    # 按需添加更多层...
    # 'second': {
    #     'label': '第二层',
    #     'fillcolor': '#FDF2E9', 'color': '#f2c9a3', 'fontcolor': '#E8833A',
    #     'header_bg': '#E8833A',
    # },
}

# 中间表 / 映射表用独立标题色（可选）
MAPPING_HEADER_BG = '#546E7A'

# --- 实体定义 ---
# 每个实体：id, name(中文), layer, fields, note(可选), header_bg(可选，覆盖层默认色)
# 每个字段：col(英文列名), n(中文说明), constraint(PK/FK/UK/空，多个用逗号分隔如 'UK,FK')
ENTITIES = [
    # 示例实体，替换为实际数据
    # {
    #     'id': 'example_entity', 'name': '示例实体', 'layer': 'core',
    #     'note': '可选备注，显示在卡片底部',  # 可选
    #     'header_bg': MAPPING_HEADER_BG,       # 可选，覆盖层默认标题色
    #     'fields': [
    #         {'col': 'id', 'n': '主键', 'constraint': 'PK'},
    #         {'col': 'name', 'n': '名称', 'constraint': ''},
    #         {'col': 'parent_id', 'n': '父级', 'constraint': 'FK'},
    #         {'col': 'code', 'n': '编码', 'constraint': 'UK'},
    #         {'col': 'status', 'n': '状态', 'constraint': ''},
    #     ],
    # },
]

# --- 关系定义 ---
# from, to, type(1:1/1:N/N:1/N:N), label, color(可选), penwidth(可选), style(可选)
RELATIONS = [
    # 示例关系，替换为实际数据
    # {'from': 'entity_a', 'to': 'entity_b', 'type': 'N:1', 'label': '关系说明'},
    # {'from': 'entity_a', 'to': 'entity_b', 'type': 'N:1', 'label': '', 'color': '#1565C0', 'penwidth': 1.4},
    # {'from': 'entity_a', 'to': 'entity_b', 'type': '1:1', 'label': '预留', 'style': 'dashed'},
]

# --- 设计规则（嵌入 metadata 供技术参考）---
DESIGN_RULES = {
    # 'rule_key': '规则说明文本',
}


# ============================================================
# 渲染区（改样式改这里，一般不用动）
# ============================================================

FONT = 'PingFang SC, Microsoft YaHei, Helvetica, sans-serif'
DEFAULT_EDGE_COLOR = '#90CAF9'
DEFAULT_EDGE_FONTCOLOR = '#4A90D9'


def build_card_label(entity):
    """构建 HTML-like 卡片标签"""
    layer = LAYERS[entity['layer']]
    header_bg = entity.get('header_bg', layer['header_bg'])

    # 字段行
    rows = ''
    for f in entity['fields']:
        constraint_str = f'[{f["constraint"]}]' if f['constraint'] else ''
        rows += f'<TR><TD ALIGN="LEFT">{f["col"]} {f["n"]}</TD><TD>{constraint_str}</TD></TR>\n'

    # 备注行
    note_row = ''
    if entity.get('note'):
        note_row = f'<TR><TD COLSPAN="2" BGCOLOR="#E3F2FD"><FONT POINT-SIZE="10"><I>{entity["note"]}</I></FONT></TD></TR>\n'

    return f'''<
      <TABLE BORDER="2" CELLBORDER="0" CELLSPACING="0" CELLPADDING="6">
        <TR><TD BGCOLOR="{header_bg}"><FONT COLOR="white"><B>{entity["name"]} {entity["id"]}</B></FONT></TD></TR>
        {rows}{note_row}</TABLE>
    >'''


def build_graph():
    """构建 Graphviz 图"""
    dot = graphviz.Digraph(
        name='ER',
        format='svg',
        engine='dot',
        graph_attr={
            'rankdir': 'LR',
            'fontname': FONT,
            'fontsize': '14',
            'bgcolor': '#f8f9fc',
            'pad': '0.8',
            'nodesep': '0.3',
            'ranksep': '0.6',
            'compound': 'true',
        },
        node_attr={
            'fontname': FONT,
            'shape': 'none',
            'margin': '0',
        },
        edge_attr={
            'fontname': FONT,
            'fontsize': '10',
            'color': '#999999',
            'arrowsize': '0.7',
            'penwidth': '1.0',
        },
    )

    # 按层创建 subgraph
    for layer_id, layer_cfg in LAYERS.items():
        entities = [e for e in ENTITIES if e['layer'] == layer_id]
        if not entities:
            continue
        with dot.subgraph(name=f'cluster_{layer_id}') as sub:
            sub.attr(
                label=f'<<B>{layer_cfg["label"]}</B>>',
                style='filled,rounded',
                fillcolor=layer_cfg['fillcolor'],
                color=layer_cfg['color'],
                fontcolor=layer_cfg['fontcolor'],
                fontsize='14',
                penwidth='2.5',
                margin='16',
            )
            for entity in entities:
                sub.node(entity['id'], label=build_card_label(entity))

    # 连线
    for rel in RELATIONS:
        edge_attrs = {}
        label_text = f'{rel["type"]} {rel["label"]}'.strip() if rel['label'] else rel['type']
        edge_color = rel.get('color', DEFAULT_EDGE_COLOR)
        edge_attrs['color'] = edge_color
        edge_attrs['fontcolor'] = rel.get('color', DEFAULT_EDGE_FONTCOLOR)
        edge_attrs['label'] = label_text
        if rel.get('penwidth'):
            edge_attrs['penwidth'] = str(rel['penwidth'])
        if rel.get('style'):
            edge_attrs['style'] = rel['style']
        dot.edge(rel['from'], rel['to'], **edge_attrs)

    return dot


def build_metadata():
    """构建结构化 metadata JSON"""
    tables = []
    for entity in ENTITIES:
        tables.append({
            'name': entity['id'],
            'comment': entity['name'],
            'columns': [
                {
                    'name': f['col'],
                    'comment': f['n'],
                    'constraint': ', '.join(
                        {'PK': 'PRIMARY KEY', 'FK': 'FOREIGN KEY', 'UK': 'UNIQUE'}[p]
                        for p in (x.strip() for x in f['constraint'].split(','))
                        if p in ('PK', 'FK', 'UK')
                    ) if f['constraint'] else '',
                }
                for f in entity['fields']
            ],
            'note': entity.get('note', ''),
        })

    return json.dumps({
        'title': TITLE,
        'version': VERSION,
        'tables': tables,
        'relations': RELATIONS,
        'design_rules': DESIGN_RULES,
    }, ensure_ascii=False, indent=2)


def build_tech_yaml(meta_json):
    """从 JSON metadata 生成技术 YAML（每个 column 追加技术待填字段）"""
    data = json.loads(meta_json)

    def represent_none(dumper, _data):
        return dumper.represent_scalar('tag:yaml.org,2002:null', '')
    yaml.add_representer(type(None), represent_none)

    output = {
        'title': data['title'],
        'version': data['version'],
        'tables': [],
        'relations': data['relations'],
        'design_rules': data.get('design_rules', {}),
    }
    for table in data['tables']:
        t = {
            'name': table['name'],
            'comment': table['comment'],
            'note': table.get('note', ''),
            'columns': [],
        }
        for col in table['columns']:
            t['columns'].append({
                'name': col['name'],
                'comment': col['comment'],
                'constraint': col['constraint'] if col['constraint'] else None,
                'type': None,
                'nullable': None,
                'default': None,
                'enum_values': None,
                'index': None,
            })
        output['tables'].append(t)

    return yaml.dump(output, allow_unicode=True, default_flow_style=False, sort_keys=False, width=120)


def embed_metadata(svg_path, meta_json):
    """在 SVG 中嵌入 JSON + YAML 双 metadata"""
    ET.register_namespace('', 'http://www.w3.org/2000/svg')
    ET.register_namespace('xlink', 'http://www.w3.org/1999/xlink')
    tree = ET.parse(svg_path)
    root = tree.getroot()

    meta_elem = ET.Element('metadata')

    # JSON block
    schema_elem = ET.SubElement(meta_elem, 'er-schema')
    schema_elem.set('format', 'json')
    schema_elem.set('version', '1.0')
    schema_elem.text = '\n' + meta_json + '\n'

    # YAML block
    yaml_str = build_tech_yaml(meta_json)
    tech_elem = ET.SubElement(meta_elem, 'er-tech-spec')
    tech_elem.set('format', 'yaml')
    tech_elem.text = yaml_str

    root.insert(0, meta_elem)

    # Write SVG, then fix CDATA wrapping for YAML (ET doesn't support CDATA natively)
    tree.write(svg_path, encoding='unicode', xml_declaration=True)

    # Post-process: wrap YAML content in CDATA
    with open(svg_path, 'r', encoding='utf-8') as f:
        svg_content = f.read()
    svg_content = re.sub(
        r'<er-tech-spec format="yaml">(.*?)</er-tech-spec>',
        lambda m: f'<er-tech-spec format="yaml"><![CDATA[\n{yaml_str}]]></er-tech-spec>',
        svg_content, flags=re.DOTALL
    )
    with open(svg_path, 'w', encoding='utf-8') as f:
        f.write(svg_content)


def main():
    # 1. 构建图
    dot = build_graph()

    # 2. 生成 .dot + .svg
    dot.render(OUTPUT_NAME, cleanup=False)
    print(f'Generated: {OUTPUT_NAME}.dot')
    print(f'Generated: {OUTPUT_NAME}.svg')

    # 3. 嵌入 metadata（JSON + YAML）
    svg_path = f'{OUTPUT_NAME}.svg'
    meta_json = build_metadata()
    embed_metadata(svg_path, meta_json)
    print(f'Metadata embedded into {svg_path} (JSON + YAML)')

    # 4. 统计
    data = json.loads(meta_json)
    print(f'  Tables: {len(data["tables"])}')
    print(f'  Relations: {len(data["relations"])}')
    print(f'  Design rules: {len(data["design_rules"])}')


if __name__ == '__main__':
    main()
