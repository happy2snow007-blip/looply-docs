# Looply 前台 UI 设计流程转交包

## 文件说明

本转交包包含 Looply 前台用户端 UI 设计所需的完整文件，共 6 类文件。

### 文件结构

```
looply-ui-workflow-package/
├── README.md                          # 本说明文档
├── skills/
│   └── ui-design-workflow/
│       └── SKILL.md                   # UI 设计流程定义
├── brand/
│   ├── impeccable.md                  # 品牌原则（战略层）
│   └── looply-brand-design-guide.md   # 品牌视觉规范（执行层）
├── components/
│   ├── looply-design.pen              # 组件库源文件
│   └── looply-design.md               # 组件库使用说明
└── assets/
    └── logos/
        ├── logo.png                   # 浅色背景用
        ├── logo2.png                  # 紫色背景用
        └── logo-white-transparent.png # 深色背景用
```

---

## 文件作用说明

### 1. skills/ui-design-workflow/SKILL.md
**作用**：定义 UI 设计的完整流程
**内容**：快照机制、页面分类、标准流程/快速通道、评估检查、定稿交付、组件提取等

### 2. brand/impeccable.md
**作用**：品牌战略层定义（为什么这样设计）
**内容**：目标用户、品牌人格、设计原则、参考 App、无障碍标准等

### 3. brand/looply-brand-design-guide.md
**作用**：品牌执行层规范（视觉上应该长什么样）
**内容**：Logo 使用规则、色彩细则、UI 风格方向、图形语言、字体排版、图片风格等

### 4. components/looply-design.md
**作用**：组件库使用手册（组件具体怎么做、怎么用）
**内容**：字体档位、间距、圆角、29 个色彩变量、28 个组件清单、组件 ID 映射、使用规范等

### 5. components/looply-design.pen
**作用**：Pencil 组件库本体
**使用方式**：新建设计稿时通过 imports 导入，用 ref 引用组件

### 6. assets/logos/（3 个 Logo 文件）
**使用规则**：
- `logo.png`：浅色/白色背景用（紫色文字透明底）
- `logo2.png`：纯紫色实底背景用（白色文字紫色底）
- `logo-white-transparent.png`：渐变紫/深色背景用（白色文字透明底）

---

## 环境配置步骤

### 前置要求
1. 安装 Claude Code CLI
2. 安装 Pencil MCP 插件

### 文件复制

```bash
# 1. 复制 Skill 文件
mkdir -p ~/.claude/skills/ui-design-workflow
cp skills/ui-design-workflow/SKILL.md ~/.claude/skills/ui-design-workflow/

# 2. 复制品牌原则文件（直接复制，不需要重新生成）
cp brand/impeccable.md ~/.impeccable.md

# 3. 复制 Memory 文件（替换 {用户名} 为实际用户名）
mkdir -p ~/.claude/projects/-Users-{用户名}/memory
cp brand/looply-brand-design-guide.md ~/.claude/projects/-Users-{用户名}/memory/
cp components/looply-design.md ~/.claude/projects/-Users-{用户名}/memory/

# 4. 复制组件库
cp components/looply-design.pen ~/Desktop/

# 5. 复制 Logo 资产
mkdir -p ~/Desktop/海外业务/登录注册/UI
cp assets/logos/*.png ~/Desktop/海外业务/登录注册/UI/
```

### 验证环境

在 Claude Code 中输入：
```
我要设计登录页面的 UI
```

如果 AI 能正常启动 `ui-design-workflow` 并加载快照，说明配置成功。

---

## 使用流程

### 标准流程（核心页面）
```
快照加载 → 页面分类 → 出骨架+填内容 → [评估1: 结构+视觉] → 精修 → [评估2: 终检] → 定稿 → 交付准备 → [组件提取]
```

### 快速通道（简单页面）
```
快照加载 → 批量出图 → 截图确认 → 定稿
```

### 首次使用
在 Claude Code 中输入：
```
我要设计 [模块名] 的 UI，请启动 ui-design-workflow
```

AI 会自动：
1. 检查快照是否存在（首次会生成 `/tmp/looply-ui-snapshot.md`）
2. 加载品牌上下文和组件库
3. 引导你完成页面分类和设计流程

---

## 关键规则

### 快照机制
- 首次使用会生成 `/tmp/looply-ui-snapshot.md`
- 后续会话直接读快照，加载速度更快
- 快照失效条件：规范文档更新、切换平台（PC ↔ APP）、用户要求刷新

### 组件库双更新（硬性）
提取新组件时必须同时更新：
1. `looply-design.pen`（.pen 组件库文件）
2. `looply-design.md`（memory 规范文档）

### 变量四文件联动（硬性）
色彩变量变更需同步 4 个文件：
1. 当前设计稿 .pen
2. 组件库 `looply-design.pen`
3. Memory 文档 `looply-design.md`
4. 快照 `/tmp/looply-ui-snapshot.md`

### 页面分类
- **标准流程**：核心页面（如 Login-Default、Register-Default 等主流程页面）
  - 需要跑 2 次评估（评估1: 结构+视觉，评估2: 终检）
- **快速通道**：状态变体（ErrorState、LoadingState 等）、结构高度相似的衍生页面
  - 只做目视检查，不跑评估 skill

---

## 常见问题

### Q1: 为什么不需要运行 `teach-impeccable`？
A: `.impeccable.md` 是项目级配置，所有团队成员应使用同一份文件以保证设计风格一致。直接复制现有文件即可。

### Q2: 如果品牌定义需要调整怎么办？
A: 由一个人重新运行 `teach-impeccable` 生成新的 `.impeccable.md`，然后分发给所有团队成员替换。

### Q3: 快照文件在哪里？
A: `/tmp/looply-ui-snapshot.md`，这是临时文件，每次会话自动生成，不需要手动管理。

### Q4: 如何确认环境配置成功？
A: 在 Claude Code 中输入"我要设计登录页面的 UI"，如果 AI 能正常启动 `ui-design-workflow` 并加载快照，说明配置成功。

---

## 版本信息

- **文档版本**：V1.0
- **打包日期**：2026-04-28
- **适用项目**：looply 二手电商平台
- **适用范围**：前台用户端 UI 设计（不包含后台原型）

---

## 联系方式

如有问题，请联系项目负责人。
