# Looply 设计系统（登录注册 + 电商首页 PC 提取）

> 独立组件库文件：~/Desktop/looply-design.pen
> 设计稿源文件：
>   - 登录注册 PC：~/Desktop/海外业务登录注册/UI/looply-登录注册-PC-v2.pen
>   - 登录注册 APP：~/Desktop/海外业务登录注册/UI/looply-登录注册-APP-v2.pen
>   - 登录注册 APP-v3：~/Desktop/海外业务登录注册/UI/looply-登录注册-APP-v3.pen（⚠️ 未使用组件库，全部手写代码）
>   - 电商首页：~/Desktop/海外业务登录注册/UI/looply-电商首页-PC.pen（方案A-Fixed, kSmej）
> 使用方式：新建 .pen 设计稿时，通过 imports 导入组件库文件复用组件和变量
>
> **重要**: APP-v3 的 StatusBar/OAuthButtonGroup 等元素未使用 ref 引用组件库，而是独立手写节点。组件库更新不会自动同步到 APP-v3。

## 字体

- 全局字体：DM Sans
- 字号档位：11 / 12 / 13 / 14 / 15 / 16 / 17 / 18 / 20 / 22 / 24 / 30 / 36 / 52 px
- 字重：normal (400) / 500 / 600 / 700
- letterSpacing：1（品牌名小字）/ 1.5（标签）/ 2（品牌卡片）

## 间距

- gap 档位：4 / 6 / 8 / 10 / 12 / 16 / 20 / 24 / 28 / 32 / 40 / 48 / 80 px
- padding 常用值：
  - 登录注册：[8,12] / [10,14] / [12,8] / [12,16] / [14,24] / [24,16,32,16] / [48,16,24,16] / [56,16,32,16] / [80,16,32,16]
  - 首页区块：[0,24] / [0,48] / [0,80] / [8,20] / [4,8] / [18,40] / [72,80] / [64,80,32,80]

## 圆角

- 按钮/输入框：10 / 12 px
- 卡片/徽章：6 / 10 / 14 px
- 头像/图标容器：28 / 30 / 32 px
- 圆形图片：100 px
- 产品图片：12 px
- Hero 图片：16 px
- 搜索栏：10 px
- Tag pill：24 px
- 底部弹窗：[20,20,0,0]
- Checkbox：6 px

## 色彩变量（29 个）

| 变量名 | 色值 | 用途 |
|--------|------|------|
| bg-primary | #FFFFFF | 页面/卡片背景 |
| bg-secondary | #F8F9FB | 次级背景（Categories、搜索栏） |
| bg-accent | #6432FC | 品牌紫（主按钮、公告栏、SellCTA） |
| bg-accent-dark | #5228C9 | 深紫（Loading 按钮、hover 态） |
| bg-accent-light | #F0EAFF | 浅紫背景（图标容器、TrustBadges、选中态） |
| bg-input | #FFFFFF | 输入框背景 |
| bg-danger | #EF4444 | 危险操作按钮 |
| bg-error-light | #FEF2F2 | 浅红背景（错误提示、警告框） |
| bg-success-light | #F0FDF4 | 浅绿背景（成功徽章、认证标签） |
| bg-footer | #1A1A1A | Footer 深色背景 |
| overlay | #00000066 | 遮罩层 |
| text-primary | #1A1A1A | 主文字 |
| text-secondary | #6B7280 | 次要文字（描述、品牌名小字） |
| text-tertiary | #7C8694 | 辅助文字 |
| text-body | #4B5563 | 正文段落（Hero 描述） |
| text-muted | #9CA3AF | 弱化文字（原价、Footer 链接、搜索占位） |
| text-white | #FFFFFF | 白色文字 |
| text-link | #6432FC | 链接文字（View All、品牌链接） |
| text-error | #EF4444 | 错误文字 |
| text-success | #22C55E | 成功文字（图标） |
| text-success-dark | #166534 | 深绿文字（认证标签文字） |
| text-discount | #15803D | 折扣文字（WCAG AA 合规） |
| border-default | #E5E7EB | 默认边框（品牌卡片、搜索栏、导航分割线） |
| border-error | #EF4444 | 错误边框 |
| border-focus | #6432FC | 聚焦边框（品牌描边按钮） |
| bg-warning-light | #FFF7ED | 浅橙背景（跨州异地登录警告 Banner） |
| text-warning | #EA580C | 警告文字（跨州异地登录提示） |
| footer-divider | #374151 | Footer 内分割线 |
| footer-link | #9CA3AF | Footer 链接/版权文字 |

## 组件清单（18 + 10 = 28 个）

### 登录注册组件（组件库 looply-design.pen 的 ID）

| 组件名 | ID | 说明 |
|--------|-----|------|
| Button/Primary | Etz9z | 紫色主按钮，w343 r12 p[14,24] |
| Button/Outline | bP61g | 描边按钮，白底+灰边框 |
| Button/Google | vdFOR | Google 登录按钮，含 icon |
| Button/Loading | gbA7Q | 加载中按钮，深紫底+spinner |
| Button/Danger | ic0jE | 红色危险按钮，w343 r12 |
| Input/Default | byNch | 默认输入框，label+input-box |
| Input/Error | GawAC | 字段级错误输入框，label+input-box+error-msg（见使用规范） |
| Checkbox | gHtDC | 复选框，box+label |
| Divider/WithText | Hqcpg | 带文字分割线（"or"） |
| PageHeader | LQaLZ | 标题+副标题，gap:8 |
| IconWrap | qJ2Ic | 圆形图标容器 56x56 r28，浅紫底 |
| ErrorBanner | A3Ki7 | 页面级错误/警告提示条，!图标+message（见使用规范） |
| OAuthButtonGroup | OPc6V | 三方登录按钮组（Google+Apple+Facebook），gap:12 |
| SwitchRow | zrBgW | 页面切换行（文字+链接），gap:4 |
| BackLink | yQjD6 | 返回链接，p[12,8] |
| CodeInputCell | CjHN2 | 验证码单格 48x56 r10 |
| TopBar | swzr2 | 导航栏，返回按钮+logo，w375 |
| BackButton/APP | Qihs3 | APP 返回按钮，← arrow-left 16px + "Back" 14px/500，p[12,16] gap:6，绝对定位 x:0 y:62 |
| StatusBar/APP | j3YM9 | APP 状态栏，w375 h62 居中 "9:41" Inter 15px/600，$bg-primary 底 |
| OAuthButtonGroup/APP | fMomX | OAuth 按钮组，Google+Apple+Facebook 三按钮 vertical gap:12，各 343×48 r12 灰边框 |

### APP 新增组件（APP 设计稿 looply-登录注册-APP-v2.pen 的 ID）

| 组件名 | ID | 说明 |
|--------|-----|------|
| PasswordRules | b8Fcx | 密码规则清单，4条规则 vertical gap:6 p[4,0,0,0]，○图标+文字 12px $text-muted |
| OAuthBadge | l8DXo | OAuth连接状态标签，浅绿底 r10 p[10,14]，✓图标14px + 文字13px |
| WarningBox | mXbkr | 红色警告框，浅红底 r10 p[14,16]，⚠️图标16px + 文字13px $text-error |
| ResendRow | lAiZ0 | 重发验证码行，居中 gap:4 p[12,0]，提示文字13px + 链接13px $text-link |

### APP 新增组件可定制属性速查

- **PasswordRules**: 4条规则各含 `icon/content` 和 `text/content`，可改图标和文案
- **OAuthBadge**: `b1ZRI/content` 改图标，`06sOl/content` 改连接状态文字
- **WarningBox**: `TMBO4/content` 改图标，`NyR9v/content` 改警告文字
- **ResendRow**: `mvKtz/content` 改提示文字，`poive/content` 改链接文字

### 首页组件（组件库 looply-design.pen 的 ID）

| 组件名 | ID | 说明 |
|--------|-----|------|
| AnnouncementBar | jrE5J | 紫色公告栏，w1440 h40 p[0,24]，白色文字 13px/500 |
| AuthBadge | ApGLJ | 认证标签，浅绿底 r6 p[4,8]，shield-check图标12px + 文字11px/600 |
| BrandCard | ULQt6 | 品牌卡片，180x120 r14，白底+灰边框1.5，品牌名16px/700 ls:2 |
| ProductCard | VF6LH | 商品卡片，w300，图片320h r12 + 品牌12px + 名称14px + 价格行 + 认证徽章 |
| CategoryCircle | RapxQ | 分类圆形，200x200 r100 图片 + 标签16px/700，gap:12 |
| TrustBadge | uOWa4 | 信任徽章，w240，紫色图标容器60x60 r30 + 标题17px/700 + 描述13px #4B5563 |
| SectionHeader | hAoAK | 区块标题行，w1280，标题30px/700 + "View All →" 链接15px/700 |
| Navbar/PC | M1hgp | PC 导航栏，w1440 h72 p[0,80]，logo+6链接+搜索栏+3图标 |
| SellCTA | dCpF2 | 卖家号召区，w1440 h400 紫色底，标题36px + 描述16px + 白色按钮 p[18,40] 17px + 图片 |
| Footer/PC | InS3a | PC 页脚，w1440 深色底 p[64,80,32,80]，logo+tagline + 4列链接 + 版权行 |

### 登录注册组件可定制属性速查

- **Button/Primary**: `vMU7J/content` 改按钮文案
- **Button/Outline**: `1i0mU/content` 改按钮文案
- **Button/Google**: `R6WVV/content` 改按钮文案
- **Button/Loading**: `NcgAt/content` 改加载文案
- **Button/Danger**: `5Vzv6/content` 改按钮文案
- **Input/Default**: `z3Dt5/content` 改 label，`qikaR/content` 改 placeholder
- **Input/Error**: `JT8aB/content` 改 label，`ThMlC/content` 改 placeholder，`dBXvH/content` 改错误信息
- **Checkbox**: `eZWVF/content` 改 label
- **Divider/WithText**: `ZDAPPJ/content` 改分割文字
- **PageHeader**: `PcJeY/content` 改标题，`frtPu/content` 改副标题
- **IconWrap**: `Bn9n1/content` 改图标 emoji
- **ErrorBanner**: `HYzkW/content` 改错误信息
- **OAuthButtonGroup**: 内部引用 Button/Google + 2x Button/Outline
- **SwitchRow**: `Yv1kW/content` 改提示文字，`IIrzZ/content` 改链接文字
- **BackLink**: `9VHu4/content` 改链接文字
- **BackButton/APP**: `JUGAPP/iconFontName` 改图标，`XwONt/content` 改文字
- **CodeInputCell**: `DDBJV/content` 改数字
- **TopBar**: `dPaEF/content` 改返回文字，`uouHP/content` 改 logo 文字
- **StatusBar/APP**: `rkx7w/content` 改时间文字
- **OAuthButtonGroup/APP**: `rPl1o/content` 改 Google 文字，`tzQnF/content` 改 Apple 文字，`NYcjE/content` 改 Facebook 文字

### 首页组件可定制属性速查

- **AnnouncementBar**: `rW7RU/content` 改公告文案
- **AuthBadge**: `qHF9S/iconFontName` 改图标，`eXX1Q/content` 改文字
- **BrandCard**: `6Ozmc/content` 改品牌名，`6Ozmc/fontSize` 按文字长度调整
- **ProductCard**: `bZ85U/fill.url` 改商品图，`IYArh/content` 改品牌名，`1oPAf/content` 改商品名，`plHEK/content` 改现价，`JVwiM/content` 改原价，`0x0rY/content` 改折扣
- **CategoryCircle**: `1BcCt/fill.url` 改分类图片，`yxMen/content` 改分类名
- **TrustBadge**: `vpcgD/iconFontName` 改图标，`PmKCe/content` 改标题，`SKqUt/content` 改描述
- **SectionHeader**: `l6Bi8/content` 改标题，`2IgAT/content` 改链接文字
- **Navbar/PC**: `Ap1JG/fill.url` 改 logo，`HBbsG/content` 改搜索占位文字，navLinks 内 6 个链接按 ID 修改
- **SellCTA**: `SkNYo/content` 改标题，`JF8cJ/content` 改描述，`xNtT8/content` 改按钮文案，`bp2XL/fill.url` 改图片
- **Footer/PC**: `yHcwu/fill.url` 改 logo，`erK9E/content` 改 tagline，各列标题和链接按 ID 修改，`hgzhK/content` 改版权文字

## 错误提示组件使用规范

ErrorBanner 和 Input/Error 是两个独立组件，按场景分开使用，**禁止同一错误同时使用两种样式**。

| 组件 | 适用场景 | 示例页面 |
|------|---------|---------|
| **ErrorBanner** | 页面级提示：非表单场景的系统提示、风控拦截、异地登录警告等 | RiskBlocked、VerifyCode-CrossStateLogin |
| **Input/Error** | 字段级提示：表单校验错误，跟随具体输入框下方展示 | Login-ErrorState、Register-ErrorState |

### 判断原则
- 错误能归因到**具体字段** → 用 Input/Error（inline）
- 错误是**页面/系统级**，无法归因到单个字段 → 用 ErrorBanner
- 同一页面可以混用两种（如：顶部 banner 提示会话过期 + 字段 inline 提示格式错误），但**同一条错误信息不能重复展示**

### 设计时检查（硬性）
出 ErrorState 页面时，必须逐条检查每个错误信息的展示方式：
- 能归因到具体字段的错误 → **只用 Input/Error**，不加 ErrorBanner
- 页面/系统级错误 → **只用 ErrorBanner**，不在字段上重复
- **典型反例**：Login-ErrorState 曾同时用 ErrorBanner + Input/Error 展示"邮箱或密码错误"，属于同一错误重复展示，已修复（移除 ErrorBanner）

## Hero 渐变规范

- 方向：135deg（左上→右下）
- 色标：#E8DEFF (0%) → #F0EAFF (35%) → #F8F5FF (70%) → #FFFFFF (100%)
- 用途：首页 Hero 区块背景，品牌紫到白色的柔和过渡

## 弹窗设计规范（APP）

### 内容对齐规则
- **标题**：始终居中（`textAlign:"center"`）
- **描述文字**：
  - ≤3 行：居中对齐（强调严肃操作，如退出登录、删除账号）
  - >3 行：左对齐（提升可读性，适合长文本、列表、段落）
- **按钮**：APP 端统一上下堆叠（`layout:"vertical"`），主按钮在上，次按钮在下

### 容器布局设置
- 弹窗卡片容器必须设置 `alignItems:"center"`，让标题和短文本居中
- 描述文字超过 3 行时，单独给描述节点设置 `alignSelf:"flex-start"` 实现左对齐
- 所有 text 节点必须设置 `width:"fill_container"` + `textGrowth:"fixed-width"`，防止超出弹窗宽度

### 尺寸规范
- 弹窗卡片宽度：343px（APP 标准内容宽度）
- 内边距：24px
- 圆角：20px
- 按钮间距：12px（vertical gap）

## Skill 转换追踪
- 规范最后修改日期：2026-04-07
- 连续未修改使用次数：0
- 转换提醒阈值：4 次
