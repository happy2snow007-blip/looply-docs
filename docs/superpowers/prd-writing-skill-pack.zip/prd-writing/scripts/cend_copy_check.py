#!/usr/bin/env python3
"""C 端源文案冗余扫描（prd-writing 自检 21）
用法: python3 cend_copy_check.py <PRD.md>
输出非空 = 需人工按「删掉这句买家会不会做错决定」逐条复判，不是一律要删。
"""
import re, sys, pathlib, itertools

# 说明性引用（防拆注记、边界表里引用被删原文）不是待交付文案，排除
QUOTE_CTX = re.compile(r'原 `|被删|不得再|不要再补|不写|⚠️|~~|为什么删|存疑')

def strings(t):
    lines = t.split('\n')
    out = {}
    for i, line in enumerate(lines, 1):
        if line.lstrip().startswith('>') or QUOTE_CTX.search(line):
            continue
        for m in re.finditer(r'`([A-Z][^`]{24,})`', line):
            out.setdefault(m.group(1), i)
    return out

def sents(s):
    return [x.strip() for x in re.split(r'(?<=[.!?])\s+', s) if x.strip()]

# 第二句属「行动指引」的白名单尾巴：这类是必要的，不报
ACTIONABLE = re.compile(r'^(Please |Use JPG|Go back|Follow |Contact us|Try again)', re.I)

def main(p):
    t = pathlib.Path(p).read_text(encoding='utf-8')
    S = strings(t)
    hits = 0

    print('── ① 多句文案（逐句问：删掉它买家会不会做错决定？）')
    for s, ln in sorted(S.items(), key=lambda x: x[1]):
        ss = sents(s)
        if len(ss) >= 2 and not ACTIONABLE.match(ss[1]):
            hits += 1
            print(f'  L{ln} [{len(ss)}句] {ss[0][:60]}')
            for x in ss[1:]:
                print(f'         ↳ 存疑: {x[:90]}')

    print('\n── ② 同一信息点在多处重复（一处删了、另一处换个说法留着）')
    # 通用短语白名单：这些跨屏复用是刻意的，不报
    COMMON = {
        'you can start', 'can start a', 'start a new', 'a new request',
        'return window is', 'window is still', 'is still open', 'window is open',
        'please try again', 'contact us', 'our team can', 'if you think',
        'we can t', 'this return request', 'your return window',
    }
    def ngrams(s, n=3):
        w = re.findall(r"[A-Za-z']+", s.lower().replace("'", " "))
        return {' '.join(w[i:i+n]) for i in range(max(0, len(w) - n + 1))}
    idx = {}
    for s_, ln in S.items():
        for g in ngrams(s_):
            if g in COMMON or len(g) < 10:
                continue
            idx.setdefault(g, []).append((ln, s_))
    seen_pair = set()
    for g, lst in sorted(idx.items()):
        if len(lst) < 2:
            continue
        for (l1, s1), (l2, s2) in itertools.combinations(lst, 2):
            key = tuple(sorted((l1, l2)))
            if key in seen_pair:
                continue
            seen_pair.add(key)
            hits += 1
            print(f'  L{l1} ⇄ L{l2}  重复信息点: "{g}"')
            print(f'         A: {s1[:78]}')
            print(f'         B: {s2[:78]}')

    print(f'\n合计待复判 {hits} 处')
    return hits

if __name__ == '__main__':
    sys.exit(0 if main(sys.argv[1]) == 0 else 0)
