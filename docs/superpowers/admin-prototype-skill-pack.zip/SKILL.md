---
name: admin-prototype
description: Use when creating or modifying backend admin HTML prototypes for any module (product, order, marketing, operations, etc.). Triggers on tasks involving admin page prototyping, backend UI wireframes, management console mockups, or "做后台原型" requests. Enforces the Looply admin visual spec extracted from product management v22 Style-A.
---

# Looply 后台原型生成规范

## Overview

生成 Looply 后台管理系统的 HTML 原型，统一视觉风格（活力亲和：紫色品牌主色 + 大圆角 + 柔和阴影）。所有后台模块原型必须遵循本规范，不允许自行发挥新风格。

## When to Use

- 新建任何后台模块原型（订单、营销、运营、财务等）
- 修改现有后台原型的样式或新增页面
- 检查后台原型是否符合规范

不适用于：C 端页面、APP 端 UI（用 `ui-design-workflow`）、前端生产代码（用 `frontend-design`）

---

## 前置检查

开始原型任务前必须确认：
1. 读取本 skill 的 `admin-prototype-css.md` 获取完整 CSS 模板
2. 读取本 skill 的 `gen_prototype_template.py` 了解通用数据驱动生成架构（适用于批量页面生成）
3. 确认模块名称（用于 Header 系统标签和侧边栏菜单）
4. 确认页面清单（哪些列表页、编辑页、详情页）

---

## 色彩体系

### 品牌色（Purple）
| Token | 值 | 用途 |
|-------|------|------|
| brand-primary | `#7C3AED` | 主按钮、激活态文字、KPI 数字、Tab 激活 |
| brand-dark | `#6D28D9` | 提示条文字 |
| brand-bg-light | `#FAF5FF` | KPI 卡片背景、表格行 hover |
| brand-bg-medium | `#F3EEFF` | 激活态渐变起点、树节点选中、步骤当前态 |
| brand-border | `#DDD6FE` | KPI 卡片边框、步骤当前态边框 |

### 中性色（Gray）
| Token | 值 | 用途 |
|-------|------|------|
| bg-page | `#F9FAFB` | 页面背景 |
| bg-card | `#FFFFFF` | 卡片、Header、侧边栏 |
| text-primary | `#1F2937` | 主文字 |
| text-secondary | `#374151` | 侧边栏一级菜单 |
| text-tertiary | `#4B5563` | 侧边栏二级菜单 |
| text-muted | `#6B7280` | 标签、描述、表头 |
| text-light | `#9CA3AF` | 面包屑 |
| border-primary | `#E5E7EB` | 主分割线 |
| border-light | `#F3F4F6` | 表格行底线 |
| border-input | `#D1D5DB` | 输入框/按钮边框 |

### 语义色（Status Tags）
| 语义 | 背景 | 文字 | class |
|------|------|------|-------|
| 在售/蓝 | `#EFF6FF` | `#2563EB` | `.tag.sale` |
| 启用/绿 | `#F0FDF4` | `#16A34A` | `.tag.on` |
| 待审/黄 | `#FFFBEB` | `#D97706` | `.tag.pending` |
| 错误/红 | `#FEF2F2` | `#DC2626` | `.tag.req` |
| 停用/灰 | `#F3F4F6` | `#6B7280` | `.tag.off` |
| 危险/粉 | `#FFF1F2` | `#E11D48` | `.tag.warn` |

---

## 字体体系

| 层级 | 字号 | 字重 | 颜色 |
|------|------|------|------|
| 页面标题 | 20px | 700 | `#1F2937` |
| Logo | 18px | 700 | `#1F2937` |
| 区块标题 | 15px | 600 | `#1F2937` |
| 小节标题 | 14px | 700 | `#7C3AED` |
| 正文/菜单L1 | 14px | 500 | `#374151` |
| 正文/菜单L2 | 13px | 400 | `#4B5563` |
| 表头 | 12px | 400 | `#6B7280` uppercase |
| 菜单L3 | 12px | 400 | `#6B7280` |
| KPI 数字 | 24px | 700 | `#7C3AED` |
| 字体族 | `-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif` |

---

## 圆角 & 阴影

| 圆角 | 值 | 适用 |
|------|------|------|
| xl | 16px | 卡片 |
| lg | 14px | KPI、表格容器、面板 |
| md | 10px | 步骤项、提示条 |
| sm | 8px | 按钮、输入框 |
| pill | 999px | Tag |

| 阴影 | 值 | 适用 |
|------|------|------|
| card | `0 10px 24px rgba(16,24,40,.06)` | 内容卡片 |
| sidebar | `3px 0 12px rgba(0,0,0,0.06)` | 侧边栏 |
| focus | `inset 0 0 0 2px rgba(124,58,237,.4)` | 键盘焦点 |

---

## 布局框架

```
┌─ Header (60px, white, border-bottom) ─────────────────────────┐
│  Logo │ divider │ 系统标签 .................... Breadcrumb     │
├───────────┬───────────────────────────────────────────────────┤
│ Sidebar   │  Main (padding: 28px, bg: #F9FAFB)               │
│ 220px     │  .card { padding: 28px; radius: 16px; shadow }   │
│ white     │                                                   │
│ shadow    │                                                   │
└───────────┴───────────────────────────────────────────────────┘
```

---

## 组件规范速查

### 按钮
- 高度 34px, padding 0 14px, radius 8px
- 内容对齐：按钮文字必须水平 + 垂直居中，统一使用 `display:inline-flex; align-items:center; justify-content:center;`
- 默认：bg white, border `#D1D5DB`
- 主要 `.btn.primary`：bg `#7C3AED`, color white

### 输入框
- 高度 34px, padding 0 12px, radius 8px, border `#D1D5DB`

### 表格
- 容器：border `#E5E7EB`, radius 14px, overflow hidden
- 表头：12px uppercase `#6B7280`, padding 10px 12px
- 单元格：13px, padding 11px 12px
- 行 hover：bg `#FAF5FF`

### KPI 统计卡片
- grid 4列, gap 12px
- bg `#FAF5FF`, border `#DDD6FE`, radius 14px
- 数字 24px 700 `#7C3AED`，标签 12px `#6B7280`

### Tag
- padding 2px 8px, radius 999px, font 12px, 无边框

### Tab
- 底线 1px `#E5E7EB`, gap 4px
- 激活：color `#7C3AED`, border-bottom 2px `#7C3AED`, weight 600

### 侧边栏菜单
- L1：padding 12px 16px, 14px 500, 图标 18px（class="mi"）
- L2：padding 10px 16px 10px 44px, 13px, 图标 15px（class="ci"，**必须有**）
- L3：padding 8px 16px 8px 64px, 12px, 图标 13px（class="gi"）
- 激活态：color `#7C3AED`, weight 600, left-border 3px `#7C3AED`, 渐变背景
- 分割线：1px `#F3F4F6`, margin 8px 16px

**二级菜单图标规范（硬性）**：
- 每个二级菜单项（`.menu-child`）必须有语义匹配的小图标（15px，class="ci"）
- 图标放在文字前面，结构：`<svg class="ci">...</svg><span>菜单名</span>`
- 常用图标语义：国家/地区→globe，货币→coin，语言→translate，列表→list，设置→settings
- 新建原型时必须为所有二级菜单配置图标，不能留空

**菜单层级插入规则（硬性）**：
- 新增独立一级菜单时，只能插入到 sidebar 根层级，作为 `.menu-solo` 或完整 `.menu-group` 的同级节点
- 禁止按注释名直接插入到某个 `.menu-group` 开始标签前，否则会误入折叠组内部变成子菜单
- 正确做法：找到下一个独立菜单（如标品管理）的位置，在它之前插入

**菜单修改后验证规则（硬性）**：
- 必须同时检查 ① DOM 层级是否为 sidebar 直属子节点 ② 点击后激活的 page 是否与其他 `.page` 平级
- 不能嵌套在现有 page 或弹窗容器（如 shelf-dialog）内
- 生成后必须在浏览器中验证菜单点击是否正常显示内容

### 表单
- 网格：150px(label) + 1fr(field), gap 12px 16px
- Label：13px `#6B7280`
- Field：min-height 36px, border `#D1D5DB`, radius 8px, padding 8px 12px
- 操作栏：flex 右对齐, border-top `#E5E7EB`, margin-top 24px

### 向导步骤条
- flex 等宽, gap 8px, radius 10px
- 当前：bg `#F3EEFF`, border `#DDD6FE`, color `#7C3AED`
- 完成：bg `#ecfdf3`, border `#abefc6`, color `#027a48`

### 空态组件

所有列表页必须支持 3 种空态（权限不足态预留）：

**(a) 零数据引导态**（首次使用，列表无数据）
- 容器 `.empty-state`：flex column 居中, padding 60px 20px
- 图标 48px `#9CA3AF`, 标题 16px 600 `#1F2937`, 描述 13px `#6B7280` max-width 360px 居中
- CTA：主按钮样式
- 文案模板：标题"暂无{实体名称}"，描述"点击下方按钮创建第一个{实体名称}"，CTA"新增{实体名称}"
- toolbar 隐藏

**(b) 筛选无匹配态**（搜索/筛选后无结果）
- 同上容器，图标 48px `#9CA3AF`
- 标题"未找到匹配结果"，描述"请尝试调整搜索关键词或筛选条件"
- 操作：默认按钮，文案"清除筛选条件"
- toolbar 可见

**(c) 网络异常态**（请求失败）
- 同上容器，图标 48px `#DC2626`（错误红）
- 标题"加载失败"，描述"网络异常，请检查网络连接后重试"
- 操作：主按钮，文案"重试"
- toolbar 可见

**(d) 权限不足态** — 预留，当前版本不实现

空态替换 `.table-wrap` 区域。

---

## 文件分工

- `admin-prototype-css.md`：静态模板文件，提供完整 CSS、HTML 骨架、JS 切换逻辑、图标 SVG。适合页面较少、直接手写 HTML 的场景。
- `gen_prototype_template.py`：通用 Python 生成器模板，抽象自 `gen_prototype_v3.py` 的数据驱动架构。适合一个模块下有多张列表页 / 新建页 / 编辑页，需要统一批量生成单文件 HTML 原型的场景。

### 何时用哪个文件
- 页面少、临时改版、只想快速拼一个页面：优先用 `admin-prototype-css.md`
- 页面多、结构重复、要长期维护：优先复制 `gen_prototype_template.py` 到模块目录后改 `MENU / DATA / PAGES`

### 通用生成器模板工作流
1. 复制 `gen_prototype_template.py` 到模块目录，重命名为 `gen_{模块名}_prototype.py`
2. 修改 `MODULE_NAME` 与 `OUTPUT_FILE`
3. 按模块结构配置 `MENU`
4. 填写 `DATA` 模拟数据
5. 编写 `page_xxx()` 页面函数，并在 `PAGES` 中注册
6. 运行 `python gen_{模块名}_prototype.py` 生成单文件 HTML
7. 浏览器打开生成结果，按规范自检

---

## 页面结构模板

### 列表页
```html
<div class="card">
  <div class="page-head">
    <div><div class="page-title">页面标题</div><div class="page-desc">描述</div></div>
    <div class="head-actions"><button class="btn primary">新增</button></div>
  </div>
  <div class="kpi"><!-- 4列统计卡片 --></div>
  <div class="toolbar"><!-- 搜索 + 筛选 + 查询 --></div>
  <div class="table-wrap"><table><!-- 有数据时 --></table></div>
  <!-- 无数据时替换 table-wrap -->
  <div class="empty-state" style="display:none"><!-- 空态组件 --></div>
</div>
```

### 新建/编辑页
```html
<div class="card">
  <div class="page-head">
    <div><div class="page-title">新建/编辑</div><div class="page-desc">描述</div></div>
    <div class="head-actions"><button class="btn">返回列表</button></div>
  </div>
  <div class="form-section">
    <div class="section-title">区块标题</div>
    <div class="form-grid"><!-- label + field --></div>
  </div>
  <div class="form-actions"><button class="btn">取消</button><button class="btn primary">保存</button></div>
</div>
```

### 向导页
```html
<div class="card">
  <div class="page-head"><!-- 标题 --></div>
  <div class="steps"><!-- 步骤条 --></div>
  <div class="wizard-body"><!-- 步骤内容 --></div>
  <div class="wizard-nav"><!-- 上一步 / 下一步 --></div>
</div>
```

### 详情/分栏页
```html
<div class="card">
  <div class="page-head"><!-- 标题 --></div>
  <div class="split">
    <div class="left"><div class="panel"><!-- 树/列表 --></div></div>
    <div class="right"><div class="panel"><!-- 详情 --></div></div>
  </div>
</div>
```

---

## 交互规范

- 过渡：`.15s`（菜单）/ `.2s`（箭头）/ `.3s`（折叠）
- 折叠缓动：`cubic-bezier(.4,0,.2,1)`
- 减弱动效：`@media(prefers-reduced-motion:reduce)` → transition:none
- 键盘焦点：`:focus-visible` 紫色 inset shadow
- 触摸目标：L1 44px / L2 40px / L3 36px

---

## 生成流程

```dot
digraph admin_prototype {
  rankdir=TB;
  start [label="收到后台原型任务" shape=ellipse];
  check_css [label="读取 admin-prototype-css.md\n获取完整 CSS" shape=box];
  confirm [label="确认模块名 + 页面清单" shape=box];
  gen_sidebar [label="生成侧边栏菜单结构" shape=box];
  gen_pages [label="逐页生成（套用页面模板）" shape=box];
  gen_js [label="生成页面切换 JS" shape=box];
  verify [label="浏览器打开验证" shape=diamond];
  done [label="交付" shape=ellipse];

  start -> check_css -> confirm -> gen_sidebar -> gen_pages -> gen_js -> verify;
  verify -> done [label="通过"];
  verify -> gen_pages [label="修改"];
}
```

1. 读取 `admin-prototype-css.md` 获取完整 CSS 模板
2. 与用户确认模块名称和页面清单
3. **复制 logo 文件**：从商品模块原型目录复制 `logo-new.png` 到当前模块原型目录
4. 生成 HTML：Header（图片 logo + 系统标签）→ Sidebar（按模块菜单）→ Pages（套用模板）→ JS（页面切换逻辑）
5. 输出单文件 HTML，命名：`looply-{模块名}后台原型-v{版本}.html`
6. 用户浏览器打开验证

---

## 质量检查清单

生成原型后自检：
- [ ] 所有颜色值是否来自规范（不允许出现规范外的色值）
- [ ] 圆角是否使用 16/14/10/8/999px 五档
- [ ] 按钮高度是否 34px
- [ ] 表格容器是否 radius 14px + overflow hidden
- [ ] 侧边栏激活态是否紫色渐变 + 左侧 3px border
- [ ] KPI 数字是否 24px 700 紫色
- [ ] Tag 是否 pill 圆角 + 无边框
- [ ] 页面结构是否符合四种模板之一
- [ ] Header logo 是否使用 `<img src="logo-new.png" height="28">` 图片引用（不能用纯文字）
- [ ] Header 系统标签是否已替换为当前模块名
- [ ] 二级菜单是否每项都有 15px 小图标（class="ci"）
- [ ] 键盘焦点态是否有 :focus-visible 样式
- [ ] `@media(prefers-reduced-motion)` 是否存在

---

---

## 功能删除标准流程

当需要从原型中删除某个功能模块时，必须遵循以下 4 阶段流程，避免误删其他功能。

### 阶段 1：分析（Analysis）

**目标**：全面识别功能在原型中的所有位置

**操作**：
1. 使用 `prototype_maintain.py analyze` 分析功能位置
   ```bash
   python3 ~/.claude/skills/admin-prototype/prototype_maintain.py analyze <原型路径> <功能名> <关键词1> [关键词2...]
   ```
2. 脚本会输出：
   - 菜单项位置（data-page 值）
   - 页面 ID 列表
   - 文本引用分类（菜单/页面标题/表格/表单/KPI/其他）
   - 删除操作清单

**示例**：
```bash
python3 prototype_maintain.py analyze looply-商品管理后台原型-v27.html 属性分组 attr-group 属性分组
```

### 阶段 2：备份（Backup）

**目标**：保护原始文件，确保可回滚

**操作**：
1. 复制原型文件作为备份
   ```bash
   cp 原型-v27.html 原型-v27-backup.html
   ```
2. 确认备份文件存在且完整

### 阶段 3：删除（Deletion）

**目标**：精确删除目标功能，不影响其他内容

**关键原则**：
- **结构一致性原则**：保持与原文件相同的结构"缺陷"（如缺少的 `</div>` 标签）
  - 原型文件可能存在浏览器能容错的结构问题（如 59/60 页面缺少一个 `</div>`）
  - 删除时不要试图"修复"这些问题，保持原样
  - 验证：删除前后 `<div>` 与 `</div>` 的数量差值应保持一致
- **精确匹配原则**：使用精确的正则表达式，避免误删
  - 页面删除：匹配完整的 `<div class="page" id="具体ID">` 到下一个 `<div class="page"` 或 `<script>` 之前
  - 菜单删除：匹配完整的 `<div class="menu-child" data-page="具体值">...</div>`
  - 避免使用模糊匹配（如只匹配注释到某个标签）

**操作**：
1. 使用 `prototype_maintain.py delete` 执行删除
   ```bash
   python3 ~/.claude/skills/admin-prototype/prototype_maintain.py delete <输入文件> <输出文件> --config <删除配置JSON>
   ```
2. 删除配置放在独立 JSON 文件中，例如 `delete-config.json`：
   ```json
   {
     "menu_items": ["attr-group"],
     "page_ids": ["page-attr-group-list", "page-attr-group-create"],
     "table_columns": ["属性分组"],
     "form_fields": ["属性分组"],
     "kpi_items": ["属性分组"],
     "filter_options": ["按属性分组"],
     "new_version": "v28"
   }
   ```

### 阶段 4：验证（Verification）

**目标**：确保删除正确，未破坏其他功能

**检查清单**：
- [ ] **结构完整性**：检查 `<div>` 与 `</div>` 数量差值是否与原文件一致
  ```bash
  # 原文件
  grep -o '<div' v27.html | wc -l  # 例如：2248
  grep -o '</div>' v27.html | wc -l  # 例如：2247
  # 差值：+1

  # 新文件
  grep -o '<div' v28.html | wc -l  # 例如：2189
  grep -o '</div>' v28.html | wc -l  # 例如：2188
  # 差值：+1（应与原文件一致）
  ```
- [ ] **页面数量**：确认删除的页面数量正确
  ```bash
  grep -c '<div class="page"' v27.html  # 例如：60
  grep -c '<div class="page"' v28.html  # 例如：57（删除了3个）
  ```
- [ ] **文件大小**：确认删除的字符数合理
- [ ] **浏览器验证**：
  - 打开新版本原型文件
  - 逐个点击菜单项，确认所有页面正常显示
  - 检查删除功能相关的页面已不存在
  - 检查其他页面的样式和布局未受影响
- [ ] **内容抽查**：随机检查几个保留页面的内容完整性

**常见问题排查**：
1. **页面样式错乱**：可能是删除时破坏了 HTML 结构，检查是否多删或少删了标签
2. **菜单点击无反应**：可能是删除了页面但未删除菜单项，或菜单 data-page 值不匹配
3. **其他页面消失**：可能是正则表达式匹配过于宽泛，误删了其他内容

### 工具脚本位置

- 维护脚本：`~/.claude/skills/admin-prototype/prototype_maintain.py`

### 使用示例

完整删除"属性分组"功能的流程：

```bash
# 1. 分析
python3 ~/.claude/skills/admin-prototype/prototype_maintain.py analyze \
  ~/Desktop/海外业务/商品/原型/looply-商品管理后台原型-v27.html \
  属性分组 attr-group 属性分组

# 2. 备份
cp ~/Desktop/海外业务/商品/原型/looply-商品管理后台原型-v27.html \
   ~/Desktop/海外业务/商品/原型/looply-商品管理后台原型-v27-backup.html

# 3. 准备删除配置 delete-config.json
cat > /tmp/delete-config.json <<'EOF'
{
  "menu_items": ["attr-group"],
  "page_ids": ["page-attr-group-list", "page-attr-group-create", "page-attr-group-edit"],
  "table_columns": ["属性分组"],
  "form_fields": ["属性分组"],
  "kpi_items": ["属性分组"],
  "filter_options": ["按属性分组"],
  "new_version": "v28"
}
EOF

# 4. 删除
python3 ~/.claude/skills/admin-prototype/prototype_maintain.py delete \
  ~/Desktop/海外业务/商品/原型/looply-商品管理后台原型-v27.html \
  ~/Desktop/海外业务/商品/原型/looply-商品管理后台原型-v28.html \
  --config /tmp/delete-config.json

# 5. 验证结构
echo "v27 div差值: $(($(grep -o '<div' v27.html | wc -l) - $(grep -o '</div>' v27.html | wc -l)))"
echo "v28 div差值: $(($(grep -o '<div' v28.html | wc -l) - $(grep -o '</div>' v28.html | wc -l)))"

# 6. 浏览器打开验证
open ~/Desktop/海外业务/商品/原型/looply-商品管理后台原型-v28.html
```

---

## 持续补充

本规范会随业务迭代持续补充。新增组件或样式变体时：
1. 更新本 SKILL.md 的对应章节
2. 同步更新 `admin-prototype-css.md` 的 CSS 模板
3. 同步更新 memory 中的 `looply-admin-ui-spec.md`
