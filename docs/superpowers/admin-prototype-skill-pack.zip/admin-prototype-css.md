# Looply 后台原型 CSS 模板

> 直接复制到新原型的 `<style>` 标签内使用
> 来源：looply-商品管理后台原型-v22-风格A-活力亲和.html

## 完整 CSS

```css
/* ══════════════════════════════════════════
   Looply Admin Prototype — Style A 活力亲和
   ══════════════════════════════════════════ */

/* ── Reset & Base ── */
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:#F9FAFB;color:#1F2937;font-size:14px}

/* ── Header ── */
.header{height:60px;background:#FFFFFF;color:#1F2937;display:flex;align-items:center;padding:0 24px;border-bottom:1px solid #E5E7EB}
.logo{font-size:18px;font-weight:700;letter-spacing:1px;display:flex;align-items:center}
.header-divider{width:1px;height:20px;background:#E5E7EB;margin:0 16px}
.system-label{font-size:14px;font-weight:500;color:#6B7280;letter-spacing:0.3px}
.breadcrumb{margin-left:auto;color:#9CA3AF;font-size:13px;font-weight:400}
.breadcrumb:empty{display:none}

/* ── Layout ── */
.container{display:flex;height:calc(100vh - 60px)}
.sidebar{width:220px;background:#FFFFFF;overflow:auto;flex-shrink:0;border-right:none;box-shadow:3px 0 12px rgba(0,0,0,0.06);padding:8px 0}
.main{flex:1;overflow:auto;padding:28px}

/* ══════════════════════════════════════════
   Sidebar Menu
   ══════════════════════════════════════════ */

/* ── 一级独立菜单（44px 触摸目标）── */
.menu-solo{display:flex;align-items:center;padding:12px 16px;color:#374151;cursor:pointer;font-size:14px;font-weight:500;transition:background .15s;border-left:3px solid transparent;outline:none;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.menu-solo:hover{background:rgba(0,0,0,.04)}
.menu-solo:focus-visible{box-shadow:inset 0 0 0 2px rgba(124,58,237,.4)}
.menu-solo.active{color:#7C3AED;background:linear-gradient(90deg,rgba(124,58,237,.12),transparent);font-weight:600;border-left-color:#7C3AED}
.menu-solo .mi{width:18px;height:18px;margin-right:10px;flex-shrink:0;opacity:.55}
.menu-solo.active .mi{opacity:1}

/* ── 分割线 ── */
.menu-divider{height:1px;background:#F3F4F6;margin:8px 16px}

/* ── 一级可折叠组（44px 触摸目标）── */
.menu-group{margin-bottom:0}
.menu-parent{display:flex;align-items:center;padding:12px 16px;color:#374151;cursor:pointer;font-size:14px;font-weight:500;transition:background .15s;user-select:none;border-left:3px solid transparent;outline:none;overflow:hidden}
.menu-parent:hover{background:rgba(0,0,0,.04)}
.menu-parent:focus-visible{box-shadow:inset 0 0 0 2px rgba(124,58,237,.4)}
.menu-parent .mi{width:18px;height:18px;margin-right:10px;flex-shrink:0;opacity:.55}
.menu-parent .arrow{margin-left:auto;width:16px;height:16px;transition:transform .2s;opacity:.4;flex-shrink:0}
.menu-group.open>.menu-parent .arrow{transform:rotate(90deg)}
.menu-parent.active-parent{color:#7C3AED;font-weight:600;border-left-color:#7C3AED}
.menu-parent.active-parent .mi{opacity:1}
.menu-children{max-height:0;overflow:hidden;transition:max-height .3s cubic-bezier(.4,0,.2,1)}
.menu-group.open>.menu-children{max-height:none}

/* ── 二级叶子菜单（40px 触摸目标）── */
.menu-child{display:flex;align-items:center;padding:10px 16px 10px 44px;color:#4B5563;cursor:pointer;font-size:13px;transition:all .15s;border-left:3px solid transparent;outline:none;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.menu-child:hover{color:#374151;background:rgba(0,0,0,.03)}
.menu-child:focus-visible{box-shadow:inset 0 0 0 2px rgba(124,58,237,.4)}
.menu-child.active{color:#7C3AED;background:linear-gradient(90deg,rgba(124,58,237,.1),transparent);border-left-color:#7C3AED;font-weight:600}
.menu-child .ci{width:15px;height:15px;margin-right:8px;flex-shrink:0;opacity:.45}
.menu-child.active .ci{opacity:.8}

/* ── 二级可折叠子组（40px 触摸目标）── */
.menu-subgroup{margin:0}
.menu-subparent{display:flex;align-items:center;padding:10px 16px 10px 44px;color:#4B5563;cursor:pointer;font-size:13px;font-weight:500;transition:background .15s;user-select:none;outline:none;overflow:hidden}
.menu-subparent:hover{color:#374151;background:rgba(0,0,0,.03)}
.menu-subparent:focus-visible{box-shadow:inset 0 0 0 2px rgba(124,58,237,.4)}
.menu-subparent .ci{width:15px;height:15px;margin-right:8px;flex-shrink:0;opacity:.45}
.menu-subparent .arrow-sm{margin-left:auto;width:14px;height:14px;transition:transform .2s;opacity:.35;flex-shrink:0}
.menu-subgroup.open>.menu-subparent .arrow-sm{transform:rotate(90deg)}
.menu-subparent.active-parent{color:#7C3AED;font-weight:600}
.menu-subparent.active-parent .ci{opacity:.8}
.menu-subchildren{max-height:0;overflow:hidden;transition:max-height .25s cubic-bezier(.4,0,.2,1)}
.menu-subgroup.open>.menu-subchildren{max-height:none}

/* ── 三级分组标签（不可点击）── */
.menu-sublabel{padding:8px 16px 4px 64px;color:#6B7280;font-size:11px;font-weight:600;letter-spacing:.3px;user-select:none}

/* ── 三级叶子菜单（36px 触摸目标）── */
.menu-grandchild{display:flex;align-items:center;padding:8px 16px 8px 64px;color:#6B7280;cursor:pointer;font-size:12px;transition:all .15s;border-left:3px solid transparent;outline:none;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.menu-grandchild:hover{color:#374151;background:rgba(0,0,0,.02)}
.menu-grandchild:focus-visible{box-shadow:inset 0 0 0 2px rgba(124,58,237,.4)}
.menu-grandchild.active{color:#7C3AED;background:linear-gradient(90deg,rgba(124,58,237,.08),transparent);border-left-color:#7C3AED;font-weight:600}
.menu-grandchild .gi{width:13px;height:13px;margin-right:8px;flex-shrink:0;opacity:.45}
.menu-grandchild.active .gi{opacity:.75}

/* ── reduced-motion ── */
@media(prefers-reduced-motion:reduce){
  .menu-children,.menu-subchildren,.menu-parent .arrow,.menu-subparent .arrow-sm,.menu-solo,.menu-child,.menu-grandchild,.menu-subparent,.menu-parent{transition:none !important}
}

/* ══════════════════════════════════════════
   Content Components
   ══════════════════════════════════════════ */

/* ── Page & Card ── */
.page{display:none}.page.active{display:block}
.card{background:#fff;border-radius:16px;box-shadow:0 10px 24px rgba(16,24,40,.06);padding:28px}

/* ── Page Head ── */
.page-head{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;margin-bottom:18px}
.page-title{font-size:20px;font-weight:700;margin-bottom:6px}
.page-desc{color:#6B7280;font-size:13px;max-width:760px}
.head-actions{display:flex;gap:10px;flex-wrap:wrap}

/* ── Toolbar ── */
.toolbar{display:flex;gap:12px;align-items:center;flex-wrap:wrap;margin-bottom:16px}
.toolbar .input,.toolbar select{height:34px;border:1px solid #D1D5DB;border-radius:8px;padding:0 12px;background:#fff}

/* ── Button ── */
.btn{height:34px;padding:0 14px;border:1px solid #D1D5DB;background:#fff;border-radius:8px;cursor:pointer;display:inline-flex;align-items:center;justify-content:center}
.btn.primary{background:#7C3AED;border-color:#7C3AED;color:#fff}

/* ── Summary Cards (gradient) ── */
.summary{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin-bottom:18px}
.summary .item{background:linear-gradient(180deg,#FEFCFF 0%,#F3EEFF 100%);border:1px solid #DDD6FE;border-radius:14px;padding:14px 16px}
.summary .num{font-size:24px;font-weight:700;color:#7C3AED;margin-bottom:4px}
.summary .label-sm{font-size:12px;color:#6B7280}

/* ── KPI Cards (flat) ── */
.kpi{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:16px}
.kpi .item{background:#FAF5FF;border:1px solid #DDD6FE;border-radius:14px;padding:14px}
.kpi .num{font-size:24px;font-weight:700;margin-bottom:4px}
.muted{color:#6B7280;font-size:12px}

/* ── Table ── */
.table-wrap{border:1px solid #E5E7EB;border-radius:14px;overflow-x:auto;background:#fff}
table{width:100%;border-collapse:collapse}
th{background:#FFFFFF;padding:10px 12px;text-align:left;font-size:12px;color:#6B7280;border-bottom:1px solid #E5E7EB;text-transform:uppercase;letter-spacing:.02em}
td{padding:11px 12px;border-bottom:1px solid #F3F4F6;font-size:13px;vertical-align:top}
tr:hover{background:#FAF5FF}

/* ── Split Layout & Panel ── */
.split{display:flex;gap:18px}
.left{width:280px;flex-shrink:0}
.mid{width:300px;flex-shrink:0}
.right{flex:1}
.panel{border:1px solid #E5E7EB;border-radius:14px;background:#FFFFFF;padding:16px;min-height:420px}
.panel h3{font-size:13px;color:#6B7280;margin-bottom:12px}
.stack{display:flex;flex-direction:column;gap:16px}

/* ── Tree ── */
.tree-node{padding:8px 10px;border-radius:8px;cursor:pointer}
.tree-node:hover{background:#F3EEFF}
.tree-selected{background:#F3EEFF;color:#7C3AED;font-weight:600}
.tree-child{margin-left:18px}

/* ── Form Grid ── */
.form-grid{display:grid;grid-template-columns:150px 1fr;gap:12px 16px;align-items:center}
.label{color:#6B7280;font-size:13px}
.field{min-height:36px;border:1px solid #D1D5DB;border-radius:8px;background:#fff;padding:8px 12px;display:flex;align-items:center}

/* ── Form Row (alternative) ── */
.form-row{display:flex;gap:16px;margin-bottom:12px}
.form-row .label{width:120px;text-align:right;line-height:34px;color:#6B7280;flex-shrink:0}
.form-row .field{flex:1}
.form-row .input-display{height:34px;line-height:34px;padding:0 12px;border:1px solid #D1D5DB;border-radius:8px;background:#f9fafb}
.form-row textarea.input-display{height:80px;line-height:1.5;padding:8px 12px}

/* ── Form Section & Actions ── */
.form-section{margin-bottom:24px}
.form-section .section-title{font-size:15px;font-weight:600;margin-bottom:12px;padding-bottom:8px;border-bottom:1px solid #E5E7EB}
.form-actions{display:flex;gap:12px;justify-content:flex-end;padding-top:16px;border-top:1px solid #E5E7EB;margin-top:24px}

/* ── Section ── */
.section{margin-top:18px}
.section-title{font-size:14px;font-weight:700;margin-bottom:10px;color:#7C3AED}
.section-note{font-size:12px;color:#6B7280;margin:-4px 0 10px}

/* ── Tags ── */
.tag{display:inline-block;padding:2px 8px;border-radius:999px;font-size:12px;margin-right:4px}
.tag.sale{background:#EFF6FF;color:#2563EB;border:none}
.tag.desc{background:#F0FDF4;color:#16A34A;border:none}
.tag.enum{background:#FFFBEB;color:#D97706;border:none}
.tag.req{background:#FEF2F2;color:#DC2626;border:none}
.tag.opt{background:#F3F4F6;color:#6B7280;border:none}
.tag.on{background:#F0FDF4;color:#16A34A;border:none}
.tag.pending{background:#FFFBEB;color:#D97706;border:none}
.tag.off{background:#F3F4F6;color:#6B7280;border:none}
.tag.warn{background:#FFF1F2;color:#E11D48;border:none}

/* ── Tabs ── */
.tabs{display:flex;border-bottom:1px solid #E5E7EB;margin-bottom:14px;gap:4px}
.tab{padding:10px 18px;cursor:pointer;border-bottom:2px solid transparent;color:#6B7280}
.tab.active{color:#7C3AED;border-bottom-color:#7C3AED;font-weight:600}
.tab-pane{display:none}.tab-pane.active{display:block}

/* ── Wizard Steps ── */
.steps{display:flex;gap:8px;margin-bottom:16px}
.step{flex:1;padding:10px;background:#fafafa;border:1px solid #E5E7EB;border-radius:10px;text-align:center;cursor:pointer;transition:all .2s}
.step b{display:block;margin-bottom:4px}
.step.current{background:#F3EEFF;border-color:#DDD6FE;color:#7C3AED;font-weight:600}
.step.done{background:#ecfdf3;border-color:#abefc6;color:#027a48}
.step.done b{color:#027a48}
.wizard-body .wizard-step{display:none}
.wizard-body .wizard-step.active{display:block}
.wizard-nav{display:flex;gap:12px;justify-content:flex-end;padding-top:16px;border-top:1px solid #E5E7EB;margin-top:24px}

/* ── Misc ── */
.inline-meta{display:flex;gap:8px;flex-wrap:wrap}
.pill{padding:4px 10px;border-radius:999px;background:#F3F4F6;color:#6B7280;font-size:12px}
.rail-note{padding:12px 14px;border-radius:10px;background:#F3EEFF;border:1px solid #DDD6FE;color:#6D28D9;font-size:12px;line-height:1.6}
.placeholder{padding:28px;border:1px dashed #D1D5DB;border-radius:14px;background:#FFFFFF;color:#6B7280}
.preview{margin-top:18px;padding:16px;border:1px solid #E5E7EB;background:#FFFFFF;border-radius:14px}
.preview-line{display:flex;justify-content:space-between;gap:20px;padding:10px 0;border-bottom:1px solid #E5E7EB}
.preview-line:last-child{border-bottom:none}
.sub-table{margin-top:8px}

/* ── Empty State ── */
.empty-state{display:flex;flex-direction:column;align-items:center;padding:60px 20px;text-align:center}
.empty-state .empty-icon{width:48px;height:48px;color:#9CA3AF;margin-bottom:16px}
.empty-state .empty-icon.error{color:#DC2626}
.empty-state .empty-title{font-size:16px;font-weight:600;color:#1F2937;margin-bottom:8px}
.empty-state .empty-desc{font-size:13px;color:#6B7280;margin-bottom:24px;max-width:360px}
.empty-state .btn{margin-top:0}

/* ── Pagination (方案B 居中紧凑式) ── */
.pagination{display:flex;align-items:center;justify-content:center;gap:24px;padding:12px 16px;font-size:13px;color:#6B7280;border-top:1px solid #F3F4F6}
.pagination .pag-section{display:flex;align-items:center;gap:8px}
.pagination .divider{width:1px;height:20px;background:#E5E7EB}
.pagination .page-nums{display:flex;gap:2px;align-items:center}
.pagination .page-num{min-width:32px;height:32px;display:inline-flex;align-items:center;justify-content:center;border-radius:8px;cursor:pointer;font-size:13px;background:transparent;color:#374151;transition:all .15s;border:none}
.pagination .page-num.active{background:#7C3AED;color:#fff;font-weight:600;border-radius:8px}
.pagination .page-num:hover:not(.active):not(.disabled){background:#F3EEFF;color:#7C3AED}
.pagination .page-num.disabled{cursor:default;opacity:.35}
.pagination .page-num.arrow{width:32px;height:32px;border:1px solid #E5E7EB;border-radius:8px;background:#fff}
.pagination .page-num.arrow:hover:not(.disabled){background:#F3EEFF;border-color:#DDD6FE;color:#7C3AED}
.pagination select{height:30px;border:1px solid #E5E7EB;border-radius:6px;padding:0 8px;font-size:12px;background:#fff;color:#374151;cursor:pointer}

/* ── Operation Log ── */
.op-log{margin-top:24px}
.op-log-title{font-size:14px;font-weight:700;color:#7C3AED;margin-bottom:12px}
.op-log .table-wrap{margin-top:0}
.op-time{color:#6B7280;font-size:12px}
.op-user{color:#374151}
.op-type{font-weight:500}
.op-detail{color:#4B5563}
```

## HTML 骨架模板

```html
<!DOCTYPE html>
<html lang='zh-CN'>
<head>
  <meta charset='UTF-8'>
  <meta name='viewport' content='width=device-width,initial-scale=1.0'>
  <title>Looply {模块名}后台原型</title>
  <style>
    /* 粘贴上方完整 CSS */
  </style>
</head>
<body>
  <div class='header'>
    <div class='logo'>
      <img src="logo-new.png" height="28" alt="Looply">
    </div>
    <div class='header-divider'></div>
    <span class='system-label'>{模块名}系统</span>
    <div class='breadcrumb'></div>
  </div>
  <div class='container'>
    <div class='sidebar' role="navigation" aria-label="主导航">
      <!-- 侧边栏菜单（按模块定制） -->
    </div>
    <div class='main'>
      <!-- 页面内容 -->
    </div>
  </div>
  <script>
    /* 页面切换 JS（见下方） */
  </script>
</body>
</html>
```

## 页面切换 JS 模板

```javascript
/* ── 菜单折叠 ── */
window.toggleGroup = function(parent) {
  const group = parent.closest('.menu-group');
  group.classList.toggle('open');
  parent.setAttribute('aria-expanded', group.classList.contains('open'));
};

window.toggleSubgroup = function(subparent) {
  const group = subparent.closest('.menu-subgroup');
  group.classList.toggle('open');
  subparent.setAttribute('aria-expanded', group.classList.contains('open'));
};

/* ── 清除所有激活态 ── */
function clearAllActive() {
  document.querySelectorAll('.menu-solo,.menu-child,.menu-grandchild').forEach(el => el.classList.remove('active'));
  document.querySelectorAll('.menu-parent').forEach(el => el.classList.remove('active-parent'));
  document.querySelectorAll('.menu-subparent').forEach(el => el.classList.remove('active-parent'));
}

/* ── 页面导航 ── */
function navigateTo(pageId, label) {
  clearAllActive();
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  const target = document.getElementById('page-' + pageId + '-list') || document.getElementById('page-' + pageId);
  if (target) target.classList.add('active');
  document.querySelector('.breadcrumb').textContent = label || '';
}

/* ── 子页面切换（列表/新建/编辑/详情）── */
function showSubPage(module, action) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  const target = document.getElementById('page-' + module + '-' + action);
  if (target) target.classList.add('active');
}

/* ── 绑定菜单点击 ── */
document.querySelectorAll('[data-page]').forEach(item => {
  item.addEventListener('click', function() {
    const pageId = this.dataset.page;
    const label = this.querySelector('span')?.textContent || '';
    navigateTo(pageId, label);
    this.classList.add('active');
    // 展开父级
    const group = this.closest('.menu-group');
    if (group) {
      group.classList.add('open');
      group.querySelector('.menu-parent')?.classList.add('active-parent');
    }
    const subgroup = this.closest('.menu-subgroup');
    if (subgroup) {
      subgroup.classList.add('open');
      subgroup.querySelector('.menu-subparent')?.classList.add('active-parent');
    }
  });
});

/* ── Tab 切换 ── */
document.querySelectorAll('.tabs').forEach(tabBar => {
  tabBar.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', function() {
      const paneId = this.dataset.pane;
      tabBar.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      this.classList.add('active');
      const container = tabBar.parentElement;
      container.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
      const pane = container.querySelector('#' + paneId);
      if (pane) pane.classList.add('active');
    });
  });
});

/* ── 默认激活第一个菜单 ── */
const firstMenu = document.querySelector('[data-page]');
if (firstMenu) firstMenu.click();
```

## 侧边栏图标 SVG 模板

常用图标（直接复制使用）：

```html
<!-- 一级图标 class="mi"，18x18 -->
<!-- 网格/类目 -->
<svg class="mi" aria-hidden="true" viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="5.5" height="5.5" rx="1.2"/><rect x="10.5" y="2" width="5.5" height="5.5" rx="1.2"/><rect x="2" y="10.5" width="5.5" height="5.5" rx="1.2"/><rect x="10.5" y="10.5" width="5.5" height="5.5" rx="1.2"/></svg>

<!-- 星标/品牌 -->
<svg class="mi" aria-hidden="true" viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M9 2L11.5 7.5H16L12.5 10.5L14 16L9 13L4 16L5.5 10.5L2 7.5H6.5Z"/></svg>

<!-- 层叠/系列 -->
<svg class="mi" aria-hidden="true" viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12.5L9 15.5L14 12.5"/><path d="M4 9L9 12L14 9"/><path d="M4 5.5L9 8.5L14 5.5L9 2.5Z"/></svg>

<!-- 滑块/属性 -->
<svg class="mi" aria-hidden="true" viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="5" cy="5" r="1.5"/><line x1="6.5" y1="5" x2="16" y2="5"/><circle cx="13" cy="9" r="1.5"/><line x1="2" y1="9" x2="11.5" y2="9"/><circle cx="7" cy="13" r="1.5"/><line x1="8.5" y1="13" x2="16" y2="13"/></svg>

<!-- 靶心/作用域 -->
<svg class="mi" aria-hidden="true" viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="9" r="6.5"/><circle cx="9" cy="9" r="3.5"/><circle cx="9" cy="9" r="1" fill="currentColor"/></svg>

<!-- 盒子/商品 -->
<svg class="mi" aria-hidden="true" viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6L9 3L15 6V12L9 15L3 12Z"/><path d="M3 6L9 9L15 6"/><line x1="9" y1="9" x2="9" y2="15"/></svg>

<!-- 购物袋/商品管理 -->
<svg class="mi" aria-hidden="true" viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 2H13L15.5 6H2.5Z"/><rect x="3" y="6" width="12" height="10" rx="1"/><path d="M7 9H11"/></svg>

<!-- 标签 -->
<svg class="mi" aria-hidden="true" viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M2 9.2V3.5A1.5 1.5 0 013.5 2h5.7a1.5 1.5 0 011.06.44l5.3 5.3a1.5 1.5 0 010 2.12l-5.3 5.3a1.5 1.5 0 01-2.12 0l-5.3-5.3A1.5 1.5 0 012 9.2Z"/><circle cx="6" cy="6" r="1" fill="currentColor"/></svg>

<!-- 箭头（折叠用）-->
<svg class="arrow" aria-hidden="true" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M6 4L10 8L6 12"/></svg>

<!-- 二级图标 class="ci"，15x15 -->
<!-- 三级图标 class="gi"，13x13 -->
<!-- 按需从商品原型中复制对应图标 -->
```
