# Looply 后台原型 UI 规范

> 提取自：looply-商品管理后台原型-v22-风格A-活力亲和.html
> 适用范围：所有后台模块原型（商品、订单、营销、运营等）
> 风格定位：活力亲和 — 紫色品牌主色 + 大圆角 + 柔和阴影

---

## 1. 色彩体系

### 品牌色（Purple）
| Token | 值 | 用途 |
|-------|------|------|
| brand-primary | `#7C3AED` | 主按钮、激活态文字、KPI 数字、Tab 激活 |
| brand-dark | `#6D28D9` | 提示条文字 |
| brand-bg-light | `#FAF5FF` | KPI 卡片背景、表格行 hover |
| brand-bg-medium | `#F3EEFF` | 激活态渐变起点、树节点选中、步骤当前态、提示条背景 |
| brand-border | `#DDD6FE` | KPI 卡片边框、步骤当前态边框、提示条边框 |
| brand-gradient-active | `linear-gradient(90deg, rgba(124,58,237,.12), transparent)` | 侧边栏激活态背景 |
| brand-gradient-summary | `linear-gradient(180deg, #FEFCFF 0%, #F3EEFF 100%)` | 统计卡片渐变背景 |

### 中性色（Gray）
| Token | 值 | 用途 |
|-------|------|------|
| bg-page | `#F9FAFB` | 页面背景 |
| bg-card | `#FFFFFF` | 卡片、Header、侧边栏背景 |
| text-primary | `#1F2937` | 主文字、Header 文字 |
| text-secondary | `#374151` | 侧边栏一级菜单、hover 文字 |
| text-tertiary | `#4B5563` | 侧边栏二级菜单 |
| text-muted | `#6B7280` | 标签文字、描述文字、表头、三级菜单 |
| text-light | `#9CA3AF` | 面包屑 |
| text-disabled | `#667085` | 禁用/只读字段 |
| border-primary | `#E5E7EB` | 主分割线、表头底线、Tab 底线、Header 底线 |
| border-light | `#F3F4F6` | 表格行底线、侧边栏分割线 |
| border-input | `#D1D5DB` | 输入框/按钮边框 |
| bg-disabled | `#f9fafb` | 禁用/只读字段背景 |

### 语义色（Status Tags）
| 语义 | 背景 | 文字 | CSS class |
|------|------|------|-----------|
| 在售/蓝 | `#EFF6FF` | `#2563EB` | `.tag.sale` |
| 启用/成功/绿 | `#F0FDF4` | `#16A34A` | `.tag.on` `.tag.desc` |
| 待审/警告/黄 | `#FFFBEB` | `#D97706` | `.tag.enum` `.tag.pending` |
| 错误/红 | `#FEF2F2` | `#DC2626` | `.tag.req` |
| 停用/中性/灰 | `#F3F4F6` | `#6B7280` | `.tag.opt` `.tag.off` |
| 危险/粉 | `#FFF1F2` | `#E11D48` | `.tag.warn` |
| 步骤完成/绿 | `#ecfdf3` bg / `#abefc6` border | `#027a48` | `.step.done` |

---

## 2. 字体体系

| 层级 | 字号 | 字重 | 颜色 | 场景 |
|------|------|------|------|------|
| 页面标题 | 20px | 700 | text-primary | `.page-title` |
| Logo | 18px | 700 | text-primary | `.logo` |
| 区块标题 | 15px | 600 | text-primary | `.form-section .section-title` |
| 小节标题 | 14px | 700 | brand-primary | `.section-title`（紫色） |
| 正文/菜单L1 | 14px | 500 | text-secondary | 侧边栏一级、系统标签 |
| 正文/菜单L2 | 13px | 400 | text-tertiary | 侧边栏二级、表格正文、页面描述 |
| 表头 | 12px | 400 | text-muted | `uppercase` + `letter-spacing: 0.02em` |
| 菜单L3/KPI标签 | 12px | 400 | text-muted | 三级菜单、KPI 说明文字 |
| 分组标签 | 11px | 600 | text-muted | `letter-spacing: 0.3px`，侧边栏三级分组标题 |
| Tag | 12px | 400 | 语义色 | 状态标签 |
| KPI 数字 | 24px | 700 | brand-primary | 统计数字 |
| 字体族 | `-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif` | | | 全局 |

---

## 3. 圆角体系

| 尺寸 | 值 | 适用组件 |
|------|------|----------|
| xl | `16px` | 卡片 `.card` |
| lg | `14px` | KPI 卡片、表格容器、面板、预览区、占位符、步骤 |
| md | `10px` | 步骤项 `.step`、提示条 `.rail-note` |
| sm | `8px` | 按钮、输入框、树节点 |
| pill | `999px` | Tag、Pill 标签 |

---

## 4. 阴影体系

| 名称 | 值 | 适用 |
|------|------|------|
| card | `0 10px 24px rgba(16,24,40,.06)` | 内容卡片 |
| sidebar | `3px 0 12px rgba(0,0,0,0.06)` | 侧边栏（无 border-right，用阴影分隔） |
| focus | `inset 0 0 0 2px rgba(124,58,237,.4)` | 键盘焦点态（:focus-visible） |

---

## 5. 布局框架

```
┌─ Header (60px, white, border-bottom 1px #E5E7EB) ──────────────┐
│  Logo(18px 700) │ divider │ SystemLabel(14px 500) ... Breadcrumb │
├─────────────────┬──────────────────────────────────────────────────┤
│  Sidebar        │  Main Content                                    │
│  220px          │  padding: 28px                                   │
│  white          │  bg: #F9FAFB                                     │
│  shadow 分隔     │                                                  │
│  padding: 8px 0 │  .card { padding: 28px; radius: 16px; shadow }  │
└─────────────────┴──────────────────────────────────────────────────┘
```

- Header 高度：60px
- 侧边栏宽度：220px，白色背景，右侧阴影分隔（无 border）
- 主内容区 padding：28px
- 卡片 padding：28px

---

## 6. 组件规范

### 6.1 按钮
- 高度：34px
- 内边距：0 14px
- 圆角：8px
- 内容对齐：按钮文字必须水平+垂直居中，统一使用 `display:inline-flex; align-items:center; justify-content:center;`
- 默认：bg white, border 1px #D1D5DB
- 主要：bg #7C3AED, border #7C3AED, color white

### 6.2 输入框 / 下拉
- 高度：34px
- 内边距：0 12px
- 圆角：8px
- 边框：1px solid #D1D5DB
- 背景：white

### 6.3 表格
- 容器：border 1px #E5E7EB, radius 14px, overflow hidden
- 表头：bg white, padding 10px 12px, font 12px uppercase #6B7280, border-bottom 1px #E5E7EB
- 单元格：padding 11px 12px, font 13px, border-bottom 1px #F3F4F6
- 行 hover：bg #FAF5FF

### 6.4 KPI 统计卡片
- 布局：grid 4列等宽, gap 12px
- 样式：bg #FAF5FF, border 1px #DDD6FE, radius 14px, padding 14px
- 数字：24px 700 #7C3AED
- 标签：12px #6B7280
- 变体（summary）：渐变背景 linear-gradient(180deg, #FEFCFF, #F3EEFF), padding 14px 16px

### 6.5 Tag 状态标签
- padding：2px 8px
- 圆角：999px（pill）
- 字号：12px
- 无边框（border: none）
- 颜色见「语义色」章节

### 6.6 Tab 标签页
- 底线：border-bottom 1px #E5E7EB
- 间距：gap 4px
- 单项 padding：10px 18px
- 默认：color #6B7280, border-bottom 2px transparent
- 激活：color #7C3AED, border-bottom 2px #7C3AED, weight 600

### 6.7 侧边栏菜单
- 一级独立菜单：padding 12px 16px, font 14px 500, 左侧 3px 透明 border
- 一级折叠组：同上 + 右侧箭头（16px, rotate 90deg 展开）
- 二级叶子：padding 10px 16px 10px 44px, font 13px
- 二级折叠子组：同上 + 右侧小箭头（14px）
- 三级分组标签：padding 8px 16px 4px 64px, font 11px 600, 不可点击
- 三级叶子：padding 8px 16px 8px 64px, font 12px
- 激活态统一：color #7C3AED, weight 600, border-left 3px #7C3AED, 渐变背景
- Hover：bg rgba(0,0,0,.04)（一级）/ rgba(0,0,0,.03)（二级）/ rgba(0,0,0,.02)（三级）
- 图标尺寸：一级 18px, 二级 15px, 三级 13px
- 分割线：height 1px, bg #F3F4F6, margin 8px 16px
- 菜单层级插入规则（硬性）：新增独立一级菜单时，只能插入到 sidebar 根层级，作为 `.menu-solo` 或完整 `.menu-group` 的同级节点；禁止按注释名直接插入到某个 `.menu-group` 开始标签前，否则会误入折叠组内部变成子菜单
- 菜单修改后验证规则（硬性）：必须同时检查 ① DOM 层级是否为 sidebar 直属子节点 ② 点击后激活的 page 是否与其他 `.page` 平级，不能嵌套在现有 page 或弹窗容器内

### 6.8 表单
- 网格布局：grid 150px(label) + 1fr(field), gap 12px 16px
- 行布局：flex, label 120px 右对齐, field flex:1
- Label：13px #6B7280
- Field 容器：min-height 36px, border 1px #D1D5DB, radius 8px, padding 8px 12px
- 表单操作栏：flex 右对齐, gap 12px, padding-top 16px, border-top 1px #E5E7EB, margin-top 24px

### 6.9 向导步骤条
- 布局：flex, gap 8px, 等宽
- 默认：bg #fafafa, border 1px #E5E7EB, radius 10px, padding 10px, 居中
- 当前：bg #F3EEFF, border #DDD6FE, color #7C3AED, weight 600
- 完成：bg #ecfdf3, border #abefc6, color #027a48

### 6.10 面板 / 分栏
- 面板：border 1px #E5E7EB, radius 14px, bg white, padding 16px
- 分栏布局：flex, gap 18px
- 左栏 280px / 中栏 300px / 右栏 flex:1

### 6.11 树形控件
- 节点：padding 8px 10px, radius 8px
- Hover：bg #F3EEFF
- 选中：bg #F3EEFF, color #7C3AED, weight 600
- 子节点缩进：margin-left 18px

### 6.12 辅助元素
- Pill 标签：padding 4px 10px, radius 999px, bg #F3F4F6, color #6B7280, font 12px
- 提示条：padding 12px 14px, radius 10px, bg #F3EEFF, border 1px #DDD6FE, color #6D28D9, font 12px
- 占位符：padding 28px, border 1px dashed #D1D5DB, radius 14px, bg white, color #6B7280
- 预览区：padding 16px, border 1px #E5E7EB, radius 14px, bg white

### 6.13 操作日志

- **位置**：放在页面内容区域最后
  - 详情页：在详情信息后
  - 编辑页：在表单/向导后（`.wizard-nav` 或 `.form-actions` 之后）
- **结构**：`.op-log` 容器 + `.op-log-title` 标题 + `.table-wrap` 表格容器
- **表格列**：操作时间 | 操作人 | 操作类型 | 操作内容
- **样式类**：
  - `.op-time` — 操作时间（12px, color `#6B7280`）
  - `.op-user` — 操作人（13px, color `#374151`）
  - `.op-type` — 操作类型（13px, weight 500）
  - `.op-detail` — 操作内容（13px, color `#4B5563`）
- **向导式页面特殊处理**：合并所有步骤的操作记录，按时间倒序排列（最新在上）
- **数据示例**：包含创建、编辑、添加配置等操作类型，体现完整操作历史

### 6.14 空态组件

所有列表页必须支持以下 3 种空态（权限不足态当前版本不涉及，预留位置）：

#### (a) 零数据引导态（首次使用，列表无任何数据）
- 容器：`.empty-state`，居中布局（flex column, align-items center），padding 60px 20px
- 图标：48px, color #9CA3AF（text-light），margin-bottom 16px
- 标题：16px 600 text-primary（#1F2937），margin-bottom 8px
- 描述：13px 400 text-muted（#6B7280），margin-bottom 24px，max-width 360px，text-align center
- CTA 按钮：主按钮样式（bg #7C3AED, color white, 34px 高, radius 8px, padding 0 14px）
- 文案模板：标题"暂无{实体名称}"，描述"点击下方按钮创建第一个{实体名称}"，CTA"新增{实体名称}"

#### (b) 筛选无匹配态（搜索或筛选后无结果）
- 容器：同上 `.empty-state`
- 图标：48px, color #9CA3AF
- 标题：16px 600 text-primary，内容固定"未找到匹配结果"
- 描述：13px 400 text-muted，内容固定"请尝试调整搜索关键词或筛选条件"
- 操作按钮：默认按钮样式（bg white, border 1px #D1D5DB），文案"清除筛选条件"

#### (c) 网络异常态（请求失败）
- 容器：同上 `.empty-state`
- 图标：48px, color #DC2626（错误红）
- 标题：16px 600 text-primary，内容固定"加载失败"
- 描述：13px 400 text-muted，内容固定"网络异常，请检查网络连接后重试"
- 操作按钮：主按钮样式，文案"重试"

#### (d) 权限不足态（预留，当前版本不实现）
- 预留规范位置，待权限模块上线后补充

#### 空态通用规则
- 空态组件替换表格区域（`.table-wrap`），toolbar 保持可见（用户可修改筛选条件）
- 零数据态：toolbar 隐藏（无数据可筛选）
- 筛选无匹配态：toolbar 可见
- 网络异常态：toolbar 可见

---

## 7. 页面结构模板

### 列表页
```
.card
  .page-head（标题 + 描述 | 操作按钮）
  .kpi（4列统计卡片，可选）
  .toolbar（搜索 + 筛选 + 查询按钮）
  .table-wrap > table          ← 有数据时
  .empty-state                 ← 无数据时（替换 table-wrap）
```

### 新建/编辑页
```
.card
  .page-head（标题 + 描述 | 返回按钮）
  .form-section × N
    .section-title
    .form-grid 或 .form-row
  .form-actions（取消 + 保存）
```

### 向导页
```
.card
  .page-head
  .steps（步骤条）
  .wizard-body > .wizard-step × N
  .wizard-nav（上一步 + 下一步/完成）
```

### 详情/分栏页
```
.card
  .page-head
  .split
    .left > .panel（树/列表）
    .mid > .panel（中间面板，可选）
    .right > .panel（详情/表格）
```

### 6.15 模态弹窗（Dialog / Modal）

- **遮罩层**：position fixed, 全屏, background rgba(0,0,0,.45), z-index 999, flex 居中
- **弹窗容器**：bg white, radius 16px, padding 28px, width 按内容定（常用 480px / 560px）, box-shadow 0 20px 60px rgba(0,0,0,.15)
- **标题区**：font 18px 700, margin-bottom 18px，纯标题，不放按钮
- **内容区**：弹窗主体内容
- **底部操作栏**：flex, gap 12px, justify-content flex-end, margin-top 18px
- **关闭/取消按钮位置（硬性）**：关闭或取消按钮只能出现在底部操作栏，标题区不放关闭按钮。整个弹窗只能有一个关闭/取消入口，禁止标题区和底部同时出现关闭按钮
- **按钮规范**：
  - 表单类弹窗：底部放「取消」+「确定/保存」（主按钮）
  - 信息/上传类弹窗：底部放「关闭」
  - 危险操作弹窗：底部放「取消」+「确认XX」（红色按钮）

---

## 8. 交互规范

- 过渡动画：`transition: .15s`（菜单）/ `.2s`（箭头旋转）/ `.3s`（折叠展开）
- 折叠缓动：`cubic-bezier(.4,0,.2,1)`
- 减弱动效：`@media(prefers-reduced-motion:reduce)` 全部 transition:none
- 键盘焦点：`:focus-visible` 使用 inset box-shadow 紫色环
- 触摸目标：一级 44px / 二级 40px / 三级 36px

---

## 9. 使用说明

新建后台模块原型时：
1. 复制本规范中的 CSS 变量和组件样式
2. 替换 Header 中的「系统标签」为对应模块名（如"订单系统""营销系统"）
3. 侧边栏菜单结构按模块需求调整，保持层级规范
4. 页面内容使用对应的页面结构模板
5. 所有颜色、圆角、间距严格使用本规范定义的 Token 值

---

## Skill 转换追踪
- 规范最后修改日期：2026-05-02（新增 6.15 模态弹窗规范，明确关闭按钮只能在底部操作栏）
- 连续未修改使用次数：0
- 转换提醒阈值：4 次
