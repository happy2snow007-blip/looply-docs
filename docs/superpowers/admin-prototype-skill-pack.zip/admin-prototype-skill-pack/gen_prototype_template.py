#!/usr/bin/env python3
"""
Looply 后台原型生成器 — 通用模板
=================================
数据驱动架构：改页面只改 MENU / DATA / PAGES，不碰 HTML/CSS/JS。
CSS 使用 v22 风格A（活力亲和）规范。

使用方式：
1. 复制本文件到模块目录，重命名为 gen_{模块名}_prototype.py
2. 修改 MODULE_NAME、OUTPUT_FILE
3. 定义 MENU（侧边栏菜单结构）
4. 定义 DATA（模拟数据）
5. 编写 page_xxx() 函数，使用 helper 函数组装页面
6. 在 PAGES 列表中注册所有页面函数
7. 运行：python gen_{模块名}_prototype.py
"""

import os

# ══════════════════════════════════════════
# 配置区（每个模块必改）
# ══════════════════════════════════════════

MODULE_NAME = "示例模块"  # Header 系统标签显示的名称
OUTPUT_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUT_FILE = os.path.join(OUTPUT_DIR, "looply-示例模块后台原型-v1.html")

# ── 侧边栏菜单结构 ──
# 支持三级嵌套：
#   一级独立菜单：{"id": "xxx", "label": "名称", "icon": "svg字符串"}
#   一级折叠组：  {"label": "组名", "icon": "svg", "children": [...]}
#   二级叶子：    {"id": "xxx", "label": "名称"}
#   二级折叠子组：{"label": "子组名", "children": [...]}
#   三级叶子：    {"id": "xxx", "label": "名称"}
#   三级分组标签：{"label": "标签名", "type": "sublabel"}
#   分割线：      {"type": "divider"}
MENU = [
    {"id": "example-list", "label": "示例管理", "icon": "grid"},
    {"type": "divider"},
    {"label": "子模块", "icon": "box", "children": [
        {"id": "sub-a", "label": "子页面 A"},
        {"id": "sub-b", "label": "子页面 B"},
    ]},
]

# ── 模拟数据 ──
DATA = {
    "examples": [
        {"id": "EX001", "name": "示例一", "status": "启用", "updated_at": "2026-04-20 10:00"},
        {"id": "EX002", "name": "示例二", "status": "停用", "updated_at": "2026-04-19 14:30"},
    ],
}

# ══════════════════════════════════════════
# 图标库（SVG 字符串，按 key 引用）
# ══════════════════════════════════════════

ICONS = {
    # ── 一级图标 class="mi" 18x18 ──
    "grid": '<svg class="mi" aria-hidden="true" viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="5.5" height="5.5" rx="1.2"/><rect x="10.5" y="2" width="5.5" height="5.5" rx="1.2"/><rect x="2" y="10.5" width="5.5" height="5.5" rx="1.2"/><rect x="10.5" y="10.5" width="5.5" height="5.5" rx="1.2"/></svg>',
    "star": '<svg class="mi" aria-hidden="true" viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M9 2L11.5 7.5H16L12.5 10.5L14 16L9 13L4 16L5.5 10.5L2 7.5H6.5Z"/></svg>',
    "layers": '<svg class="mi" aria-hidden="true" viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12.5L9 15.5L14 12.5"/><path d="M4 9L9 12L14 9"/><path d="M4 5.5L9 8.5L14 5.5L9 2.5Z"/></svg>',
    "sliders": '<svg class="mi" aria-hidden="true" viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="5" cy="5" r="1.5"/><line x1="6.5" y1="5" x2="16" y2="5"/><circle cx="13" cy="9" r="1.5"/><line x1="2" y1="9" x2="11.5" y2="9"/><circle cx="7" cy="13" r="1.5"/><line x1="8.5" y1="13" x2="16" y2="13"/></svg>',
    "target": '<svg class="mi" aria-hidden="true" viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="9" r="6.5"/><circle cx="9" cy="9" r="3.5"/><circle cx="9" cy="9" r="1" fill="currentColor"/></svg>',
    "box": '<svg class="mi" aria-hidden="true" viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6L9 3L15 6V12L9 15L3 12Z"/><path d="M3 6L9 9L15 6"/><line x1="9" y1="9" x2="9" y2="15"/></svg>',
    "bag": '<svg class="mi" aria-hidden="true" viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 2H13L15.5 6H2.5Z"/><rect x="3" y="6" width="12" height="10" rx="1"/><path d="M7 9H11"/></svg>',
    "tag": '<svg class="mi" aria-hidden="true" viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M2 9.2V3.5A1.5 1.5 0 013.5 2h5.7a1.5 1.5 0 011.06.44l5.3 5.3a1.5 1.5 0 010 2.12l-5.3 5.3a1.5 1.5 0 01-2.12 0l-5.3-5.3A1.5 1.5 0 012 9.2Z"/><circle cx="6" cy="6" r="1" fill="currentColor"/></svg>',
    "list": '<svg class="mi" aria-hidden="true" viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><line x1="3" y1="4.5" x2="15" y2="4.5"/><line x1="3" y1="9" x2="15" y2="9"/><line x1="3" y1="13.5" x2="15" y2="13.5"/></svg>',
    "settings": '<svg class="mi" aria-hidden="true" viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="9" r="2.5"/><path d="M9 2v2M9 14v2M2 9h2M14 9h2M4.2 4.2l1.4 1.4M12.4 12.4l1.4 1.4M4.2 13.8l1.4-1.4M12.4 5.6l1.4-1.4"/></svg>',
    "chart": '<svg class="mi" aria-hidden="true" viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><path d="M2 14V4"/><path d="M6 14V8"/><path d="M10 14V6"/><path d="M14 14V2"/></svg>',
    "users": '<svg class="mi" aria-hidden="true" viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="7" cy="6" r="3"/><path d="M2 15c0-2.8 2.2-5 5-5s5 2.2 5 5"/><circle cx="13" cy="7" r="2"/><path d="M16 15c0-2 -1.3-3.5-3-4"/></svg>',
    "dollar": '<svg class="mi" aria-hidden="true" viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><line x1="9" y1="2" x2="9" y2="16"/><path d="M13 5.5H7.5a2.5 2.5 0 000 5h3a2.5 2.5 0 010 5H5"/></svg>',
    "truck": '<svg class="mi" aria-hidden="true" viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="4" width="10" height="8" rx="1"/><path d="M11 7h3l2 3v4h-5V7z"/><circle cx="5" cy="14" r="1.5"/><circle cx="14" cy="14" r="1.5"/></svg>',
}

# 折叠箭头
ARROW_SVG = '<svg class="arrow" aria-hidden="true" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M6 4L10 8L6 12"/></svg>'
ARROW_SM_SVG = '<svg class="arrow-sm" aria-hidden="true" viewBox="0 0 14 14" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 3.5L9 7L5 10.5"/></svg>'


# ══════════════════════════════════════════
# CSS — v22 风格A（活力亲和）完整样式
# ══════════════════════════════════════════

CSS = """\
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:#F9FAFB;color:#1F2937;font-size:14px}
.op-log{margin-top:24px}
.op-log-title{font-size:14px;font-weight:700;color:#7C3AED;margin-bottom:12px}
.op-log .table-wrap{margin-top:0}
.op-time{color:#6B7280;font-size:12px}
.op-user{color:#374151}
.op-type{font-weight:500}
.op-detail{color:#4B5563}
.header{height:60px;background:#FFFFFF;color:#1F2937;display:flex;align-items:center;padding:0 24px;border-bottom:1px solid #E5E7EB}
.logo{font-size:18px;font-weight:700;letter-spacing:1px;display:flex;align-items:center}
.header-divider{width:1px;height:20px;background:#E5E7EB;margin:0 16px}
.system-label{font-size:14px;font-weight:500;color:#6B7280;letter-spacing:0.3px}
.breadcrumb{margin-left:auto;color:#9CA3AF;font-size:13px;font-weight:400}
.breadcrumb:empty{display:none}
.container{display:flex;height:calc(100vh - 60px)}
.sidebar{width:220px;background:#FFFFFF;overflow:auto;flex-shrink:0;border-right:none;box-shadow:3px 0 12px rgba(0,0,0,0.06);padding:8px 0}
.main{flex:1;overflow:auto;padding:28px}
.menu-solo{display:flex;align-items:center;padding:12px 16px;color:#374151;cursor:pointer;font-size:14px;font-weight:500;transition:background .15s;border-left:3px solid transparent;outline:none;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.menu-solo:hover{background:rgba(0,0,0,.04)}
.menu-solo:focus-visible{box-shadow:inset 0 0 0 2px rgba(124,58,237,.4)}
.menu-solo.active{color:#7C3AED;background:linear-gradient(90deg,rgba(124,58,237,.12),transparent);font-weight:600;border-left-color:#7C3AED}
.menu-solo .mi{width:18px;height:18px;margin-right:10px;flex-shrink:0;opacity:.55}
.menu-solo.active .mi{opacity:1}
.menu-divider{height:1px;background:#F3F4F6;margin:8px 16px}
.menu-group{margin-bottom:0}
.menu-parent{display:flex;align-items:center;padding:12px 16px;color:#374151;cursor:pointer;font-size:14px;font-weight:500;transition:background .15s;user-select:none;border-left:3px solid transparent;outline:none;overflow:hidden}
.menu-parent:hover{background:rgba(0,0,0,.04)}
.menu-parent:focus-visible{box-shadow:inset 0 0 0 2px rgba(124,58,237,.4)}
.menu-parent .mi{width:18px;height:18px;margin-right:10px;flex-shrink:0;opacity:.55}
.menu-parent .arrow{margin-left:auto;width:16px;height:16px;transition:transform .2s;opacity:.4;flex-shrink:0}
.menu-group.open>.menu-parent .arrow{transform:rotate(90deg)}
.menu-parent.active-parent{color:#7C3AED;font-weight:600;border-left-color:#7C3AED}
.menu-parent.active-parent .mi{opacity:1}
.menu-children{max-height:0;overflow:hidden;transition:max-height .3s cubic-bezier(.4,0,.2,1)}
.menu-group.open>.menu-children{max-height:none}
.menu-child{display:flex;align-items:center;padding:10px 16px 10px 44px;color:#4B5563;cursor:pointer;font-size:13px;transition:all .15s;border-left:3px solid transparent;outline:none;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.menu-child:hover{color:#374151;background:rgba(0,0,0,.03)}
.menu-child:focus-visible{box-shadow:inset 0 0 0 2px rgba(124,58,237,.4)}
.menu-child.active{color:#7C3AED;background:linear-gradient(90deg,rgba(124,58,237,.1),transparent);border-left-color:#7C3AED;font-weight:600}
.menu-child .ci{width:15px;height:15px;margin-right:8px;flex-shrink:0;opacity:.45}
.menu-child.active .ci{opacity:.8}
.menu-subgroup{margin:0}
.menu-subparent{display:flex;align-items:center;padding:10px 16px 10px 44px;color:#4B5563;cursor:pointer;font-size:13px;font-weight:500;transition:background .15s;user-select:none;outline:none;overflow:hidden}
.menu-subparent:hover{color:#374151;background:rgba(0,0,0,.03)}
.menu-subparent:focus-visible{box-shadow:inset 0 0 0 2px rgba(124,58,237,.4)}
.menu-subparent .ci{width:15px;height:15px;margin-right:8px;flex-shrink:0;opacity:.45}
.menu-subparent .arrow-sm{margin-left:auto;width:14px;height:14px;transition:transform .2s;opacity:.35;flex-shrink:0}
.menu-subgroup.open>.menu-subparent .arrow-sm{transform:rotate(90deg)}
.menu-subparent.active-parent{color:#7C3AED;font-weight:600}
.menu-subparent.active-parent .ci{opacity:.8}
.menu-subchildren{max-height:0;overflow:hidden;transition:max-height .25s cubic-bezier(.4,0,.2,1)}
.menu-subgroup.open>.menu-subchildren{max-height:none}
.menu-sublabel{padding:8px 16px 4px 64px;color:#6B7280;font-size:11px;font-weight:600;letter-spacing:.3px;user-select:none}
.menu-grandchild{display:flex;align-items:center;padding:8px 16px 8px 64px;color:#6B7280;cursor:pointer;font-size:12px;transition:all .15s;border-left:3px solid transparent;outline:none;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.menu-grandchild:hover{color:#374151;background:rgba(0,0,0,.02)}
.menu-grandchild:focus-visible{box-shadow:inset 0 0 0 2px rgba(124,58,237,.4)}
.menu-grandchild.active{color:#7C3AED;background:linear-gradient(90deg,rgba(124,58,237,.08),transparent);border-left-color:#7C3AED;font-weight:600}
.menu-grandchild .gi{width:13px;height:13px;margin-right:8px;flex-shrink:0;opacity:.45}
.menu-grandchild.active .gi{opacity:.75}
@media(prefers-reduced-motion:reduce){.menu-children,.menu-subchildren,.menu-parent .arrow,.menu-subparent .arrow-sm,.menu-solo,.menu-child,.menu-grandchild,.menu-subparent,.menu-parent{transition:none !important}}
.page{display:none}.page.active{display:block}
.card{background:#fff;border-radius:16px;box-shadow:0 10px 24px rgba(16,24,40,.06);padding:28px}
.page-head{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;margin-bottom:18px}
.page-title{font-size:20px;font-weight:700;margin-bottom:6px}
.page-desc{color:#6B7280;font-size:13px;max-width:760px}
.head-actions{display:flex;gap:10px;flex-wrap:wrap}
.toolbar{display:flex;gap:12px;align-items:center;flex-wrap:wrap;margin-bottom:16px}
.toolbar .input,.toolbar select{height:34px;border:1px solid #D1D5DB;border-radius:8px;padding:0 12px;background:#fff}
.btn{height:34px;padding:0 14px;border:1px solid #D1D5DB;background:#fff;border-radius:8px;cursor:pointer;display:inline-flex;align-items:center;justify-content:center}
.btn.primary{background:#7C3AED;border-color:#7C3AED;color:#fff}
.summary{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin-bottom:18px}
.summary .item{background:linear-gradient(180deg,#FEFCFF 0%,#F3EEFF 100%);border:1px solid #DDD6FE;border-radius:14px;padding:14px 16px}
.summary .num{font-size:24px;font-weight:700;color:#7C3AED;margin-bottom:4px}
.summary .label-sm{font-size:12px;color:#6B7280}
.kpi{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:16px}
.kpi .item{background:#FAF5FF;border:1px solid #DDD6FE;border-radius:14px;padding:14px}
.kpi .num{font-size:24px;font-weight:700;margin-bottom:4px}
.muted{color:#6B7280;font-size:12px}
.table-wrap{border:1px solid #E5E7EB;border-radius:14px;overflow-x:auto;background:#fff}
table{width:100%;border-collapse:collapse}
th{background:#FFFFFF;padding:10px 12px;text-align:left;font-size:12px;color:#6B7280;border-bottom:1px solid #E5E7EB;text-transform:uppercase;letter-spacing:.02em}
td{padding:11px 12px;border-bottom:1px solid #F3F4F6;font-size:13px;vertical-align:top}
tr:hover{background:#FAF5FF}
.split{display:flex;gap:18px}.left{width:280px;flex-shrink:0}.mid{width:300px;flex-shrink:0}.right{flex:1}
.panel{border:1px solid #E5E7EB;border-radius:14px;background:#FFFFFF;padding:16px;min-height:420px}
.panel h3{font-size:13px;color:#6B7280;margin-bottom:12px}
.stack{display:flex;flex-direction:column;gap:16px}
.tree-node{padding:8px 10px;border-radius:8px;cursor:pointer}
.tree-node:hover{background:#F3EEFF}
.tree-selected{background:#F3EEFF;color:#7C3AED;font-weight:600}
.tree-child{margin-left:18px}
.form-grid{display:grid;grid-template-columns:150px 1fr;gap:12px 16px;align-items:center}
.label{color:#6B7280;font-size:13px}
.field{min-height:36px;border:1px solid #D1D5DB;border-radius:8px;background:#fff;padding:8px 12px;display:flex;align-items:center}
.form-row{display:flex;gap:16px;margin-bottom:12px}
.form-row .label{width:120px;text-align:right;line-height:34px;color:#6B7280;flex-shrink:0}
.form-row .field{flex:1}
.form-row .input-display{height:34px;line-height:34px;padding:0 12px;border:1px solid #D1D5DB;border-radius:8px;background:#f9fafb}
.form-row textarea.input-display{height:80px;line-height:1.5;padding:8px 12px}
.form-section{margin-bottom:24px}
.form-section .section-title{font-size:15px;font-weight:600;margin-bottom:12px;padding-bottom:8px;border-bottom:1px solid #E5E7EB}
.form-actions{display:flex;gap:12px;justify-content:flex-end;padding-top:16px;border-top:1px solid #E5E7EB;margin-top:24px}
.section{margin-top:18px}
.section-title{font-size:14px;font-weight:700;margin-bottom:10px;color:#7C3AED}
.section-note{font-size:12px;color:#6B7280;margin:-4px 0 10px}
.tag{display:inline-block;padding:2px 8px;border-radius:999px;font-size:12px;margin-right:4px}
.tag.sale{background:#EFF6FF;color:#2563EB;border:none}
.tag.desc{background:#F0FDF4;color:#16A34A;border:none}
.tag.enum{background:#FFFBEB;color:#D97706;border:none}
.tag.req{background:#FEF2F2;color:#DC2626;border:none}
.tag.opt{background:#F3F4F6;color:#6B7280;border:none}
.tag.on{background:#F0FDF4;color:#16A34A;border:none}
.tag.pending{background:#FFFBEB;color:#D97706;border:none}
.tag.off{background:#F3F4F6;color:#6B7280;border:none}
.tag.warn{background:#FFF1F2;color:#E11D48;border:none}
.tabs{display:flex;border-bottom:1px solid #E5E7EB;margin-bottom:14px;gap:4px}
.tab{padding:10px 18px;cursor:pointer;border-bottom:2px solid transparent;color:#6B7280}
.tab.active{color:#7C3AED;border-bottom-color:#7C3AED;font-weight:600}
.tab-pane{display:none}.tab-pane.active{display:block}
.steps{display:flex;gap:8px;margin-bottom:16px}
.step{flex:1;padding:10px;background:#fafafa;border:1px solid #E5E7EB;border-radius:10px;text-align:center;cursor:pointer;transition:all .2s}
.step b{display:block;margin-bottom:4px}
.step.current{background:#F3EEFF;border-color:#DDD6FE;color:#7C3AED;font-weight:600}
.step.done{background:#ecfdf3;border-color:#abefc6;color:#027a48}
.step.done b{color:#027a48}
.wizard-body .wizard-step{display:none}
.wizard-body .wizard-step.active{display:block}
.wizard-nav{display:flex;gap:12px;justify-content:flex-end;padding-top:16px;border-top:1px solid #E5E7EB;margin-top:24px}
.inline-meta{display:flex;gap:8px;flex-wrap:wrap}
.pill{padding:4px 10px;border-radius:999px;background:#F3F4F6;color:#6B7280;font-size:12px}
.rail-note{padding:12px 14px;border-radius:10px;background:#F3EEFF;border:1px solid #DDD6FE;color:#6D28D9;font-size:12px;line-height:1.6}
.placeholder{padding:28px;border:1px dashed #D1D5DB;border-radius:14px;background:#FFFFFF;color:#6B7280}
.preview{margin-top:18px;padding:16px;border:1px solid #E5E7EB;background:#FFFFFF;border-radius:14px}
.preview-line{display:flex;justify-content:space-between;gap:20px;padding:10px 0;border-bottom:1px solid #E5E7EB}
.preview-line:last-child{border-bottom:none}
.sub-table{margin-top:8px}
.empty-state{display:flex;flex-direction:column;align-items:center;padding:60px 20px;text-align:center}
.empty-state .empty-icon{width:48px;height:48px;color:#9CA3AF;margin-bottom:16px}
.empty-state .empty-icon.error{color:#DC2626}
.empty-state .empty-title{font-size:16px;font-weight:600;color:#1F2937;margin-bottom:8px}
.empty-state .empty-desc{font-size:13px;color:#6B7280;margin-bottom:24px;max-width:360px}
.empty-state .btn{margin-top:0}
.list-data-view{}
.pagination{display:flex;align-items:center;justify-content:space-between;padding:12px 16px;font-size:13px;color:#6B7280;border-top:1px solid #F3F4F6}
.pagination .page-nums{display:flex;gap:4px;align-items:center}
.pagination .page-num{min-width:32px;height:32px;display:inline-flex;align-items:center;justify-content:center;border:1px solid #D1D5DB;border-radius:6px;cursor:pointer;font-size:13px;background:#fff}
.pagination .page-num.active{background:#7C3AED;color:#fff;border-color:#7C3AED}
.pagination .page-num:hover:not(.active){background:#F3EEFF}
.pagination select{height:32px;border:1px solid #D1D5DB;border-radius:6px;padding:0 8px;font-size:12px;background:#fff}
.empty-state-toggle{margin-top:12px;display:flex;gap:8px;justify-content:center}
"""


# ══════════════════════════════════════════
# Helper 函数（页面函数中直接调用）
# ══════════════════════════════════════════

def table(headers, rows):
    """生成表格 HTML"""
    thead = ''.join(f'<th>{h}</th>' for h in headers)
    tbody = []
    for row in rows:
        tbody.append('<tr>' + ''.join(f'<td>{c}</td>' for c in row) + '</tr>')
    return f'<div class="table-wrap"><table><thead><tr>{thead}</tr></thead><tbody>{"".join(tbody)}</tbody></table></div>'


def pagination(total, per_page=10):
    """生成分页器 HTML。total: 总条数"""
    return (
        f'<div class="pagination"><span>共 {total} 条，每页 '
        f'<select><option>10</option><option>20</option><option>50</option></select> 条</span>'
        f'<div class="page-nums"><span class="page-num" style="cursor:default;opacity:.4">&lt;</span>'
        f'<span class="page-num active">1</span>'
        f'<span class="page-num" style="cursor:default;opacity:.4">&gt;</span></div>'
        f'<span>第 1/1 页</span></div>'
    )


def _stat_cards(container_class, label_class, items):
    """生成统计卡片底层结构。"""
    cards = []
    for item in items:
        cards.append(f'<div class="item"><div class="num">{item["num"]}</div><div class="{label_class}">{item["label"]}</div></div>')
    return f'<div class="{container_class}">{"".join(cards)}</div>'


def kpi_cards(items):
    """生成 KPI 统计卡片。items: [{"num": "24", "label": "品牌总数"}, ...]"""
    return _stat_cards("kpi", "muted", items)


def summary_cards(items):
    """生成渐变统计卡片。items: [{"num": "24", "label": "品牌总数"}, ...]"""
    return _stat_cards("summary", "label-sm", items)


def render_tree(nodes, level=0, selected=None):
    """生成树形控件。nodes: [{"name": "xxx", "children": [...]}]"""
    html = []
    for node in nodes:
        cls = 'tree-node tree-selected' if node['name'] == selected else 'tree-node'
        prefix = '<span class="muted">&bull;</span> ' if level else ''
        html.append(f'<div class="{cls}">{prefix}{node["name"]}</div>')
        if node.get('children'):
            html.append('<div class="tree-child">')
            html.append(render_tree(node['children'], level + 1, selected))
            html.append('</div>')
    return ''.join(html)


def tag(text, style="on"):
    """生成状态标签。style: on/off/sale/desc/enum/req/opt/pending/warn"""
    return f'<span class="tag {style}">{text}</span>'


def status_tag(status):
    """根据状态文字自动选择样式"""
    style_map = {"启用": "on", "停用": "off", "在售": "sale", "待审": "pending", "下架": "off"}
    return tag(status, style_map.get(status, "opt"))


def _empty_state(icon_svg, title, desc, action_html="", icon_extra_class=""):
    """生成空态底层结构。"""
    icon_class = f'empty-icon {icon_extra_class}'.strip()
    return f'''<div class="empty-state">
        <div class="{icon_class}">{icon_svg}</div>
        <div class="empty-title">{title}</div>
        <div class="empty-desc">{desc}</div>
        {action_html}
    </div>'''


def page_head(title, desc="", actions_html=""):
    """生成页面头部。"""
    return f'<div class="page-head"><div><div class="page-title">{title}</div><div class="page-desc">{desc}</div></div><div class="head-actions">{actions_html}</div></div>'


def toolbar(inner_html):
    """生成工具栏容器。"""
    return f'<div class="toolbar">{inner_html}</div>'


def list_page_card(title, desc, actions_html="", stats_html="", toolbar_html="", body_html="",
                    entity_name="", create_onclick="", pagination_html=""):
    """生成列表页卡片主体。

    当提供 entity_name 时，自动在 body_html 后追加 3 种空态（默认隐藏）：
      (a) 零数据引导态  (b) 筛选无匹配态  (c) 网络异常态
    原型演示时可通过页面内按钮切换查看。

    参数:
      entity_name   — 实体中文名（如"市场""国家"），传入后自动生成空态
      create_onclick — 零数据态 CTA 按钮的 onclick（如 "showSubPage('xxx','create')"）
      pagination_html — 分页器 HTML（放在 body_html 之后、空态之前）
    """
    empty_html = ""
    if entity_name:
        create_action = f'onclick="{create_onclick}"' if create_onclick else ''
        empty_html = f'''
      <!-- 空态：零数据引导 -->
      <div class="empty-state-zero" style="display:none">{empty_state_zero(entity_name, create_action)}</div>
      <!-- 空态：筛选无匹配 -->
      <div class="empty-state-no-match" style="display:none">{empty_state_no_match()}</div>
      <!-- 空态：网络异常 -->
      <div class="empty-state-error" style="display:none">{empty_state_error()}</div>
      <!-- 原型演示：空态切换按钮 -->
      <div class="empty-state-toggle" style="margin-top:12px;display:flex;gap:8px;justify-content:center">
        <button class="btn" onclick="toggleEmptyState(this,'data')">正常数据</button>
        <button class="btn" onclick="toggleEmptyState(this,'zero')">零数据态</button>
        <button class="btn" onclick="toggleEmptyState(this,'no-match')">无匹配态</button>
        <button class="btn" onclick="toggleEmptyState(this,'error')">异常态</button>
      </div>'''

    return f'''<div class="card">
      {page_head(title, desc, actions_html)}
      {stats_html}
      {toolbar_html}
      <div class="list-data-view">{body_html}{pagination_html}</div>{empty_html}
    </div>'''


def empty_state_zero(entity_name, create_action=""):
    """零数据引导态"""
    icon_svg = '<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="8" y="8" width="32" height="32" rx="4"/><line x1="16" y1="20" x2="32" y2="20"/><line x1="16" y1="28" x2="28" y2="28"/></svg>'
    btn = f'<button class="btn primary" {create_action}>新增{entity_name}</button>' if create_action else ''
    return _empty_state(icon_svg, f'暂无{entity_name}', f'点击下方按钮创建第一个{entity_name}', btn)


def empty_state_no_match():
    """筛选无匹配态"""
    icon_svg = '<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="22" cy="22" r="12"/><line x1="31" y1="31" x2="40" y2="40"/></svg>'
    action_html = '<button class="btn">清除筛选条件</button>'
    return _empty_state(icon_svg, '未找到匹配结果', '请尝试调整搜索关键词或筛选条件', action_html)


def empty_state_error():
    """网络异常态"""
    icon_svg = '<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="24" cy="24" r="18"/><line x1="24" y1="14" x2="24" y2="28"/><circle cx="24" cy="34" r="1.5" fill="currentColor"/></svg>'
    action_html = '<button class="btn primary" onclick="location.reload()">重试</button>'
    return _empty_state(icon_svg, '加载失败', '网络异常，请检查网络连接后重试', action_html, 'error')


def operation_log(records):
    """生成操作日志 HTML。

    records: [
        {"time": "2026-04-20 14:22", "user": "pm@looply.com", "type": "编辑", "detail": "修改上线日期为 2026-09-01"},
        ...
    ]
    """
    rows = []
    for r in records:
        rows.append(f'<tr><td class="op-time">{r["time"]}</td><td class="op-user">{r["user"]}</td><td class="op-type">{r["type"]}</td><td class="op-detail">{r["detail"]}</td></tr>')

    return f'''<div class="op-log">
  <div class="op-log-title">操作记录</div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>操作时间</th><th>操作人</th><th>操作类型</th><th>操作内容</th></tr></thead>
      <tbody>{"".join(rows)}</tbody>
    </table>
  </div>
</div>'''


# ══════════════════════════════════════════
# 侧边栏生成器（自动从 MENU 结构生成）
# ══════════════════════════════════════════

def _get_icon(icon_key):
    """获取图标 SVG，支持 ICONS 字典 key 或直接传 SVG 字符串"""
    if not icon_key:
        return ''
    if icon_key.startswith('<svg'):
        return icon_key
    return ICONS.get(icon_key, '')


def menu_html():
    """从 MENU 结构生成完整侧边栏 HTML"""
    parts = []
    group_counter = [0]

    def render_l3(items):
        """渲染三级菜单"""
        for item in items:
            if item.get("type") == "sublabel":
                parts.append(f'<div class="menu-sublabel" role="presentation">{item["label"]}</div>')
            elif item.get("id"):
                parts.append(f'<div class="menu-grandchild" tabindex="0" role="menuitem" data-page="{item["id"]}"><span>{item["label"]}</span></div>')

    def render_l2(items):
        """渲染二级菜单"""
        for item in items:
            if item.get("id"):
                # 二级叶子
                icon = _get_icon(item.get("icon"))
                parts.append(f'<div class="menu-child" tabindex="0" role="menuitem" data-page="{item["id"]}">{icon}<span>{item["label"]}</span></div>')
            elif item.get("children"):
                # 二级折叠子组
                group_counter[0] += 1
                gid = f'subchildren-{group_counter[0]}'
                parts.append(f'<div class="menu-subgroup">')
                parts.append(f'<div class="menu-subparent" tabindex="0" role="button" aria-expanded="false" aria-controls="{gid}" onclick="toggleSubgroup(this)"><span>{item["label"]}</span>{ARROW_SM_SVG}</div>')
                parts.append(f'<div class="menu-subchildren" id="{gid}" role="group">')
                render_l3(item["children"])
                parts.append('</div></div>')

    for item in MENU:
        if item.get("type") == "divider":
            parts.append('<div class="menu-divider" role="separator"></div>')
        elif item.get("id"):
            # 一级独立菜单
            icon = _get_icon(item.get("icon"))
            parts.append(f'<div class="menu-solo" tabindex="0" role="menuitem" data-page="{item["id"]}">{icon}<span>{item["label"]}</span></div>')
        elif item.get("children"):
            # 一级折叠组
            group_counter[0] += 1
            gid = f'children-{group_counter[0]}'
            icon = _get_icon(item.get("icon"))
            parts.append(f'<div class="menu-group">')
            parts.append(f'<div class="menu-parent" tabindex="0" role="button" aria-expanded="false" aria-controls="{gid}" onclick="toggleGroup(this)">{icon}<span>{item["label"]}</span>{ARROW_SVG}</div>')
            parts.append(f'<div class="menu-children" id="{gid}" role="group">')
            render_l2(item["children"])
            parts.append('</div></div>')

    return '\n'.join(parts)


# ══════════════════════════════════════════
# 页面函数区（每个模块自定义）
# ══════════════════════════════════════════

def page_example_list():
    """示例列表页 — 替换为你的实际页面"""
    rows = []
    for item in DATA["examples"]:
        rows.append([
            f'<b>{item["id"]}</b>',
            item["name"],
            status_tag(item["status"]),
            item["updated_at"],
            '<button class="btn" onclick="showSubPage(\'example\',\'edit\')">编辑</button>'
        ])
    actions_html = '<button class="btn primary" onclick="showSubPage(\'example-list\',\'create\')">新增</button>'
    toolbar_html = toolbar('<input class="input" placeholder="搜索 ID / 名称"><select><option>全部状态</option><option>启用</option><option>停用</option></select><button class="btn">查询</button>')
    body_html = table(['ID', '名称', '状态', '更新时间', '操作'], rows)
    card_html = list_page_card(
        title='示例管理',
        desc='这是一个示例列表页。',
        actions_html=actions_html,
        stats_html=kpi_cards([{"num": "2", "label": "总数"}, {"num": "1", "label": "启用"}, {"num": "1", "label": "停用"}, {"num": "0", "label": "待审"}]),
        toolbar_html=toolbar_html,
        body_html=body_html,
        entity_name="示例",
        create_onclick="showSubPage('example-list','create')",
        pagination_html=pagination(2),
    )
    return f'''\n    <div class="page" id="page-example-list-list">{card_html}</div>'''


# ── 注册所有页面函数 ──
PAGES = [
    page_example_list,
    # page_example_create,
    # page_example_edit,
    # page_sub_a_list,
    # page_sub_b_list,
]


# ══════════════════════════════════════════
# JS — 页面切换逻辑
# ══════════════════════════════════════════

JS = """\
window.toggleGroup = function(parent) {
  var group = parent.closest('.menu-group');
  group.classList.toggle('open');
  parent.setAttribute('aria-expanded', group.classList.contains('open'));
};
window.toggleSubgroup = function(subparent) {
  var group = subparent.closest('.menu-subgroup');
  group.classList.toggle('open');
  subparent.setAttribute('aria-expanded', group.classList.contains('open'));
};
function clearAllActive() {
  document.querySelectorAll('.menu-solo,.menu-child,.menu-grandchild').forEach(function(el){el.classList.remove('active')});
  document.querySelectorAll('.menu-parent').forEach(function(el){el.classList.remove('active-parent')});
  document.querySelectorAll('.menu-subparent').forEach(function(el){el.classList.remove('active-parent')});
}
function navigateTo(pageId, label) {
  clearAllActive();
  document.querySelectorAll('.page').forEach(function(p){p.classList.remove('active')});
  var target = document.getElementById('page-' + pageId + '-list') || document.getElementById('page-' + pageId);
  if (target) target.classList.add('active');
  document.querySelector('.breadcrumb').textContent = label || '';
}
function showSubPage(module, action) {
  document.querySelectorAll('.page').forEach(function(p){p.classList.remove('active')});
  var target = document.getElementById('page-' + module + '-' + action);
  if (target) target.classList.add('active');
}
document.querySelectorAll('[data-page]').forEach(function(item) {
  item.addEventListener('click', function() {
    var pageId = this.dataset.page;
    var label = this.querySelector('span') ? this.querySelector('span').textContent : '';
    navigateTo(pageId, label);
    this.classList.add('active');
    var group = this.closest('.menu-group');
    if (group) { group.classList.add('open'); var p = group.querySelector('.menu-parent'); if(p) p.classList.add('active-parent'); }
    var subgroup = this.closest('.menu-subgroup');
    if (subgroup) { subgroup.classList.add('open'); var sp = subgroup.querySelector('.menu-subparent'); if(sp) sp.classList.add('active-parent'); }
  });
});
document.querySelectorAll('.tabs').forEach(function(tabBar) {
  tabBar.querySelectorAll('.tab').forEach(function(tab) {
    tab.addEventListener('click', function() {
      var paneId = this.dataset.pane;
      tabBar.querySelectorAll('.tab').forEach(function(t){t.classList.remove('active')});
      this.classList.add('active');
      var container = tabBar.parentElement;
      container.querySelectorAll('.tab-pane').forEach(function(p){p.classList.remove('active')});
      var pane = container.querySelector('#' + paneId);
      if (pane) pane.classList.add('active');
    });
  });
});
window.toggleEmptyState = function(btn, mode) {
  var card = btn.closest('.card');
  if (!card) return;
  var dataView = card.querySelector('.list-data-view');
  var zero = card.querySelector('.empty-state-zero');
  var noMatch = card.querySelector('.empty-state-no-match');
  var error = card.querySelector('.empty-state-error');
  if (dataView) dataView.style.display = mode === 'data' ? '' : 'none';
  if (zero) zero.style.display = mode === 'zero' ? '' : 'none';
  if (noMatch) noMatch.style.display = mode === 'no-match' ? '' : 'none';
  if (error) error.style.display = mode === 'error' ? '' : 'none';
};
var firstMenu = document.querySelector('[data-page]');
if (firstMenu) firstMenu.click();
"""


# ══════════════════════════════════════════
# 组装 & 输出
# ══════════════════════════════════════════

def build():
    pages_html = '\n'.join(fn() for fn in PAGES)
    html = f"""<!DOCTYPE html>
<html lang='zh-CN'>
<head>
<meta charset='UTF-8'>
<meta name='viewport' content='width=device-width,initial-scale=1.0'>
<title>Looply {MODULE_NAME}后台原型</title>
<style>
{CSS}
</style>
</head>
<body>
<div class='header'>
  <div class='logo'><img src="logo-new.png" height="28" alt="Looply"></div>
  <div class='header-divider'></div>
  <span class='system-label'>{MODULE_NAME}系统</span>
  <div class='breadcrumb'></div>
</div>
<div class='container'>
  <div class='sidebar' role="navigation" aria-label="主导航">
{menu_html()}
  </div>
  <div class='main'>
{pages_html}
  </div>
</div>
<script>
{JS}
</script>
</body>
</html>"""
    with open(OUTPUT_FILE, 'w', encoding='utf-8') as f:
        f.write(html)
    print(f"Generated: {OUTPUT_FILE}")


if __name__ == '__main__':
    build()
