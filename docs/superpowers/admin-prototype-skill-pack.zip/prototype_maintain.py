#!/usr/bin/env python3
"""
后台原型维护工具
================

统一提供两类能力：
1. analyze：分析某个功能在 HTML 原型中的位置
2. delete：按配置删除某个功能，并输出新版本 HTML

用法：
  python3 prototype_maintain.py analyze <html文件路径> <功能名称> <关键词1> [关键词2 ...]
  python3 prototype_maintain.py delete <输入文件> <输出文件> --config <配置JSON路径>
"""

import argparse
import json
import re
import sys
from pathlib import Path


def read_text(file_path):
    return Path(file_path).read_text(encoding='utf-8')


def write_text(file_path, content):
    Path(file_path).write_text(content, encoding='utf-8')


def line_number(content, pos):
    return content[:pos].count('\n') + 1


def analyze_feature(html_path, feature_name, feature_keywords):
    content = read_text(html_path)

    print('=' * 80)
    print(f'{feature_name}功能位置分析报告')
    print('=' * 80)

    result = {
        'menu_items': [],
        'page_ids': [],
        'text_references': {},
        'total_references': 0,
    }

    print('\n【1. 菜单项】')
    for keyword in feature_keywords:
        menu_pattern = rf'<div class="menu-child"[^>]*data-page="{re.escape(keyword)}"[^>]*>.*?</div>'
        matches = list(re.finditer(menu_pattern, content, re.DOTALL))
        if matches:
            print(f"找到 {len(matches)} 个菜单项 (data-page='{keyword}'):")
            for index, match in enumerate(matches, 1):
                print(f'  {index}. 行 {line_number(content, match.start())}')
                result['menu_items'].append(keyword)

    print('\n【2. 页面】')
    page_ids = []
    for keyword in feature_keywords:
        page_pattern = rf'<div class="page" id="([^"]*{re.escape(keyword)}[^"]*)"'
        page_ids.extend(re.findall(page_pattern, content))

    for page_id in sorted(set(page_ids)):
        position = content.find(f'id="{page_id}"')
        if position < 0:
            continue
        title_match = re.search(
            rf'id="{re.escape(page_id)}".*?<div class="page-title">([^<]+)</div>',
            content,
            re.DOTALL,
        )
        title = title_match.group(1) if title_match else '未知'
        print(f'  ✓ {page_id} (行 {line_number(content, position)}) - {title}')
        result['page_ids'].append(page_id)

    print(f"\n【3. 文本引用 '{feature_name}'】")
    text_matches = list(re.finditer(re.escape(feature_name), content))
    print(f'找到 {len(text_matches)} 处引用')
    result['total_references'] = len(text_matches)

    references = {
        '菜单': [],
        '页面标题': [],
        '表格表头': [],
        '表格数据': [],
        '表单字段': [],
        'KPI统计': [],
        '其他': [],
    }

    for match in text_matches:
        pos = match.start()
        current_line = line_number(content, pos)
        context = content[max(0, pos - 100):min(len(content), pos + 100)]

        if 'menu-child' in context or 'data-page' in context:
            references['菜单'].append(current_line)
        elif 'page-title' in context:
            references['页面标题'].append(current_line)
        elif '<th>' in context:
            references['表格表头'].append(current_line)
        elif '<td>' in context:
            references['表格数据'].append(current_line)
        elif 'label' in context and 'field' in context:
            references['表单字段'].append(current_line)
        elif 'muted' in context or 'num' in context:
            references['KPI统计'].append(current_line)
        else:
            references['其他'].append(current_line)

    for category, lines in references.items():
        if not lines:
            continue
        print(f'\n  【{category}】({len(lines)} 处)')
        for item in lines[:5]:
            print(f'    行 {item}')
        if len(lines) > 5:
            print(f'    ... 还有 {len(lines) - 5} 处')
        result['text_references'][category] = lines

    print('\n' + '=' * 80)
    print('【删除操作清单】')
    print('=' * 80)

    unique_menu_items = sorted(set(result['menu_items']))
    print(f'\n1. 删除菜单项（{len(unique_menu_items)} 个）')
    for item in unique_menu_items:
        print(f"   - data-page='{item}'")

    print(f"\n2. 删除页面（{len(result['page_ids'])} 个）")
    for page_id in result['page_ids']:
        print(f'   - {page_id}')

    print(f"\n3. 修改引用（{result['total_references']} 处）")
    for category, lines in result['text_references'].items():
        if lines:
            print(f'   - {category}: {len(lines)} 处')

    return result


def load_delete_config(config_path):
    config = json.loads(read_text(config_path))
    if not isinstance(config, dict):
        raise ValueError('删除配置必须是 JSON 对象')
    return config


def delete_feature(html_path, output_path, delete_config):
    content = read_text(html_path)
    original_size = len(content)

    print('=' * 80)
    print('执行删除操作')
    print('=' * 80)

    print('\n【步骤 1】删除菜单项')
    for menu_item in delete_config.get('menu_items', []):
        before = len(content)
        content = re.sub(
            rf'<div class="menu-child"[^>]*data-page="{re.escape(menu_item)}"[^>]*>.*?</div>\s*',
            '',
            content,
            flags=re.DOTALL,
        )
        deleted = before - len(content)
        if deleted > 0:
            print(f"  ✓ 删除菜单项 '{menu_item}': {deleted} 字符")
        else:
            print(f"  ✗ 未找到菜单项 '{menu_item}'")

    print('\n【步骤 2】删除页面')
    for page_id in delete_config.get('page_ids', []):
        before = len(content)
        pattern = rf'<div class="page" id="{re.escape(page_id)}">.*?(?=<div class="page"|<script>|<!-- =====|</body>)'
        content = re.sub(pattern, '', content, flags=re.DOTALL)
        deleted = before - len(content)
        if deleted > 0:
            print(f"  ✓ 删除页面 '{page_id}': {deleted} 字符")
        else:
            print(f"  ✗ 未找到页面 '{page_id}'")

    print('\n【步骤 3】删除表格列')
    for column in delete_config.get('table_columns', []):
        before = len(content)
        content = re.sub(rf'<th>{re.escape(column)}</th>', '', content)
        print(f"  ✓ 删除表头 '{column}': {before - len(content)} 字符")

        before = len(content)
        content = re.sub(
            r'(<td>[^<]+</td><td>[^<]+</td>)<td>[^<]+</td>(<td>)',
            r'\1\2',
            content,
        )
        print(f'  ✓ 删除数据列: {before - len(content)} 字符')

    print('\n【步骤 4】删除表单字段')
    for field in delete_config.get('form_fields', []):
        before = len(content)
        content = re.sub(
            rf'<div class="label">{re.escape(field)}</div>\s*<div class="field">.*?</div>\s*',
            '',
            content,
            flags=re.DOTALL,
        )
        print(f"  ✓ 删除表单字段 '{field}': {before - len(content)} 字符")

    print('\n【步骤 5】删除 KPI 统计项')
    for kpi in delete_config.get('kpi_items', []):
        before = len(content)
        content = re.sub(
            rf'<div class="item"><div class="num">\d+</div><div class="muted">{re.escape(kpi)}</div></div>',
            '',
            content,
        )
        print(f"  ✓ 删除 KPI '{kpi}': {before - len(content)} 字符")

    print('\n【步骤 6】删除筛选选项')
    for option in delete_config.get('filter_options', []):
        before = len(content)
        content = re.sub(rf'{re.escape(option)}、', '', content)
        print(f"  ✓ 删除筛选选项 '{option}': {before - len(content)} 字符")

    if delete_config.get('new_version'):
        content = re.sub(
            r'<title>Looply 商品管理后台原型 v\d+</title>',
            f'<title>Looply 商品管理后台原型 {delete_config["new_version"]}</title>',
            content,
        )

    write_text(output_path, content)

    print('\n✅ 删除完成')
    print(f'📊 文件大小: {len(content) / 1024:.1f} KB')
    print(f'📊 减少: {(original_size - len(content)) / 1024:.1f} KB')

    return content


def build_parser():
    parser = argparse.ArgumentParser(description='后台原型维护工具')
    subparsers = parser.add_subparsers(dest='command', required=True)

    analyze_parser = subparsers.add_parser('analyze', help='分析功能位置')
    analyze_parser.add_argument('html_path', help='原型 HTML 文件路径')
    analyze_parser.add_argument('feature_name', help='功能名称，例如 属性分组')
    analyze_parser.add_argument('feature_keywords', nargs='+', help='关键词列表，例如 attr-group 属性分组')

    delete_parser = subparsers.add_parser('delete', help='删除功能并输出新文件')
    delete_parser.add_argument('html_path', help='输入 HTML 文件路径')
    delete_parser.add_argument('output_path', help='输出 HTML 文件路径')
    delete_parser.add_argument('--config', required=True, help='删除配置 JSON 文件路径')

    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)

    try:
        if args.command == 'analyze':
            analyze_feature(args.html_path, args.feature_name, args.feature_keywords)
        elif args.command == 'delete':
            delete_config = load_delete_config(args.config)
            delete_feature(args.html_path, args.output_path, delete_config)
    except Exception as exc:
        print(f'❌ 执行失败: {exc}', file=sys.stderr)
        return 1

    return 0


if __name__ == '__main__':
    raise SystemExit(main())
