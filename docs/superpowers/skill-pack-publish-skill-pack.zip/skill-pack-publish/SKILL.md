---
name: skill-pack-publish
description: Use when packaging skill files for download and publishing them to the looply workflow documentation site (workflow.html and skills-hub-hybrid.html). Triggers on skill pack creation, updating skill downloads, batch-checking/refreshing published skill packs, uploading skills to looply-docs, syncing skill files to GitHub Pages, or the weekly skill-download refresh. Also use when the user says "检查更新 workflow 和 skills-hub 的核心 skill", "批量巡检下载包", "更新 skill 下载包", or wants a team update notification for published skill changes.
---

# Skill 交付包发布

把本地 skill 打包发布到 looply 文档站供团队下载，并产出可直接转发的团队更新通知。

## 两个发布页面（都要覆盖，别只看一个）

| 页面 | 承载什么 | 更新方式 |
|------|---------|---------|
| `~/looply-docs/workflow.html` | 阶段化的 skill 卡片 + 下载按钮 + **"更新于"日期** | 换 zip + **手改日期 span** |
| `~/looply-docs/skills-hub-hybrid.html` | `const skills` 数组，条目带 `downloadPack` 字段 | 换同名文件即生效，**无日期字段** |

下载包目录：`~/looply-docs/docs/superpowers/`。GitHub Pages：`happy2snow007-blip.github.io/looply-docs/`。

**一个包可能同时挂在两个页面**（如 antd-admin-prototype）。改一个包务必两个页面都核对——只改 workflow 会让 hub 的入口滞后，反之亦然。清单见文末《已有下载包清单》，也是脚本 `scripts/packs.manifest` 的人读版。

## 两种模式，先判断走哪个

- **模式 B · 批量巡检更新**（默认，用户说"检查更新核心 skill""批量巡检""每周更新下载包"时走这个）：一次性比对两个页面所有已发布包与本地内容，只更新有变化的，最后产出团队通知。
- **模式 A · 单个发布**（用户明确"发布/更新某个 skill"时走这个）：只处理指定的一个包。

两种模式共用同一套"打包→双页面更新→校验→推送→验证"落地动作，区别只在前面的巡检范围。

---

## 模式 B：批量巡检更新

### B1. 跑巡检脚本，拿到差异清单

```bash
bash ~/.claude/skills/skill-pack-publish/scripts/inspect.sh            # 全量
bash ~/.claude/skills/skill-pack-publish/scripts/inspect.sh --skip prd-writing   # 排除未定稿的
```

脚本读 `scripts/packs.manifest`，把每个线上包解压后与本地 skill 目录（含外部依赖）逐文件 `diff`，自动忽略 `.DS_Store`/`*.backup`/`__pycache__` 等垃圾，只报 `DIFF`/`NEW`/`!MISS`/`!DEP`。退出码 0=全一致，1=有待处理项。

> 用户若指明排除某个 skill（如 prd-writing 还在改），用 `--skip`，不要自作主张纳入。

### B2. 先汇报差异，别急着打包（硬性检查点）

把脚本结果整理成一张表给用户：哪些 `SAME`（不动）、哪些 `DIFF`（待发布）、`DIFF` 具体差在哪（哪个文件、大概是什么改动）。**逐个确认交付文件后**才进入打包——沿用模式 A 的第 1 步确认纪律。

对每个待发布包，如果它有外部依赖（manifest 第 4 列非 `-`），确认依赖取的是最新版。

### B3. 逐个打包 + 双页面更新

对每个确认要发的包，走下面《落地动作》。多个包可一次性 `git add` 后一起 commit/push。

### B4. 产出团队更新通知

发布完成后**必须**生成一段团队通知（见《团队更新通知》），这是模式 B 的规定产物，不是可选项。

---

## 模式 A：单个 skill 发布

### 1. 确定交付文件（硬性检查点：必须与用户确认）

列出候选交付文件（SKILL.md + 引擎/模板/规范等依赖），向用户确认包含哪些、去掉哪些、有无遗漏。**确认前不能打包**，不能自行判定"最小交付集"就执行。

### 2. 对比线上版本（硬性检查点）

与 `~/looply-docs/docs/superpowers/` 已有包 `diff`（可直接用 `scripts/inspect.sh` 看这一个包的结果）。无差异→告知无需更新，结束；有差异才继续。

### 3+. 走下面《落地动作》。

---

## 落地动作（两种模式共用）

### 打包

以 `~/.claude/skills/{skill}/` 为根打包，保留目录结构。有外部文件（如引擎在 `~/Templates/` 下）时**必须先与用户确认打包结构**，不能自行决定放置位置——manifest 已登记的外部依赖沿用既定位置即可。

```bash
# 标准：全部文件都在 skill 文件夹内
cd ~/.claude/skills && zip -rq /tmp/{skill}-skill-pack.zip {skill}/ -x '*.DS_Store' -x '*.backup'

# 有外部依赖（如 swimlane 的 engine.py/template.py 在 ~/Templates/swimlane/）
rm -rf /tmp/{skill}-pack && mkdir -p /tmp/{skill}-pack/{skill}
cp ~/.claude/skills/{skill}/*.md /tmp/{skill}-pack/{skill}/
cp ~/Templates/{...}/engine.py ~/Templates/{...}/template.py /tmp/{skill}-pack/{skill}/
cd /tmp/{skill}-pack && zip -rq {skill}-skill-pack.zip {skill}/
```

命名：`{skill}-skill-pack.zip`，与文件夹同名。单文件 skill 直接发 `.md` 不打 zip。打完 `unzip -l` 看一眼内容对不对。

### 替换到仓库

```bash
cp /tmp/{包名} ~/looply-docs/docs/superpowers/{包名}
```

### 更新 workflow.html（该包挂 workflow 时）

找到对应下载按钮下方的"更新于"span，改成当天日期：

```html
<span style="display:block;margin-top:6px;font-size:11px;color:#94a3b8;">更新于 YYYY-MM-DD</span>
```

新增卡片时同时加下载按钮 + 时间标签，按钮配色按阶段（manifest 第 5 列）：
- 阶段 1 系统建模：`background:#d1fae5;color:#059669;`
- 阶段 2 需求设计：`background:#dbeafe;color:#2563eb;`
- 阶段 3 版本交付：`background:#ede9fe;color:#7c3aed;`

### 更新 skills-hub-hybrid.html（该包挂 hub 时）

`downloadPack` 指向的文件名不变时，换掉 `docs/superpowers/` 里的同名文件即自动生效，**无需改 hub**。只有在下列情况才动 hub：
- 新增带下载的条目 → 加 `downloadPack: { url, filename, label }`
- skill 改名/下线 → 同步改条目的 `name`/`path`/`command`/`knowledgeAssets`/`downloadPack`

改完用脚本校验 JSON 不破（见下）。

### 校验（改 HTML 后必做）

```bash
cd ~/looply-docs
# hub 的 const skills 数组能否被 JSON 解析 + 所有 path/下载文件是否存在
python3 - <<'PY'
import json
s=open('skills-hub-hybrid.html',encoding='utf-8').read()
i=s.index('const skills = ['); j=s.index('\n];',i)
arr=json.loads(s[i+len('const skills = '):j+2])
print('hub 条目数:',len(arr))
import os
for x in arr:
    p=x['path'].replace('~',os.path.expanduser('~'))
    print('MISS-path',p) if not os.path.isfile(p) else None
    d=x.get('downloadPack')
    if d and not os.path.isfile(d['url']): print('MISS-dl',d['url'])
PY
# workflow.html 引用的 zip 是否都存在
grep -o 'docs/superpowers/[A-Za-z0-9._-]*' workflow.html | sort -u | while read u; do [ -f "$u" ] || echo "MISS $u"; done
```

### 提交推送

```bash
cd ~/looply-docs
git add docs/superpowers/ workflow.html skills-hub-hybrid.html
git commit -m "更新{...}下载包"
git push
```

push 报 `SSL_ERROR_SYSCALL` / HTTP2 framing → 先查代理（用户用 AnyConnect，`git config --get http.proxy` 应为空），再 `git config http.version HTTP/1.1` 重试。

### 验证部署

等 1-2 分钟（GitHub Pages 有缓存），核对线上：

```bash
# 页面日期
curl -s "https://happy2snow007-blip.github.io/looply-docs/workflow.html?v=$RANDOM" | grep -A1 "{包名}" | grep "更新于"
# 更稳：把线上包拉下来与本次打的包逐字节比对
curl -s "https://happy2snow007-blip.github.io/looply-docs/docs/superpowers/{包名}" -o /tmp/onl_{包名} && diff <(unzip -l /tmp/onl_{包名}) <(unzip -l /tmp/{skill}-pack/{包名})
```

---

## 团队更新通知（模式 B 必产，模式 A 建议产）

用户要把它转发给团队同学，所以：**讲清"改了什么 + 为什么值得重下 + 怎么下"，不堆代号**。每个有更新的 skill 一段，结构：

```
**【PM 工作流 Skill 更新 · YYYY-MM-DD】**

**N. {Skill 中文名} — 建议重新下载**
{一句话说清这次解决了什么实际问题/加了什么能力，用大白话}。
{若改动涉及外部依赖(如引擎脚本)：明确提示"只更新 SKILL.md 不换引擎无效，请下载完整包覆盖 ~/Templates/xxx/"}。
下载：{workflow 页 → 阶段X → 卡片名 → 按钮文案} 或 {Skills Hub → 条目名 → 按钮}

... 其余有更新的 skill 同上 ...

**其余 N 个 skill 本次无变化，不需要重新下载。**
```

写通知的三条纪律：
- **只列真有变化的**。SAME 的不要写进通知，末尾一句"其余不变"即可，别让同学误重下。
- **"为什么值得重下"要具体**。不是"优化了流程图"，而是"修复了 3 分支中间列连线看不见的问题"——同学据此判断和自己相不相关。
- **引擎级/外部依赖改动要单独提示下载方式**，否则同学只覆盖 SKILL.md 会拿不到修复。

## 过程中发现规范问题 → 根因处理（硬性）

巡检/打包中经常顺带发现"某个规范文件与实际不符"。这类问题**不能只在当前对话口头提一句就过**，要按记忆规则《功能删除/调整必须先做影响范围分析》处理：

1. **定位根因**：差异往往是"规范是快照、滞后于实际"。例：sync-docs 的模块清单（9 个）滞后于 `sync.py`（19 个）；ER 规范写"HTML 交互版为主"但 skill 早已删该章、所有模块实际用 SVG。
2. **改源头，不打补丁**：修正规范文件本身的错误表述，并在其中标明"唯一准绳在哪"（如"模块是否已注册必须查 sync.py，本表仅参考"），避免同一类滞后再次误导。
3. **同步关联位置**：改了 memory 规范要同步 `MEMORY.md` 索引描述；改了 skill 内容要判断是否需要重新发包。
4. **待用户拍板的先问再改**：涉及业务策略取舍（如"HTML 版是彻底废弃还是保留为可选"）的，用大白话讲清背景+影响+推荐方案，让用户定，不自行决定。

## 已有下载包清单

**单一数据源是 `scripts/packs.manifest`**（新增/下线包改那里一行，脚本与流程自动跟随）。下表为人读快照，与 manifest 不一致时以 manifest 为准并回填本表。

| 文件名 | Skill | 阶段 | 页面 | 外部依赖 |
|--------|-------|------|------|---------|
| product-architecture-diagram-skill-pack.zip | 产品架构图 | 1-系统建模 | workflow | 无 |
| er-diagram-generation-skill-pack.zip | 实体关系图 | 1-系统建模 | workflow | 无 |
| swimlane-skill-pack.zip | 系统流程图 | 2-需求设计 | workflow | `~/Templates/swimlane/engine.py`、`template.py` |
| ui-design-workflow-skill-pack.zip | UI 设计稿 | 2-需求设计 | workflow | 无 |
| antd-admin-prototype-skill-pack.zip | 后台原型（antd 版） | 2-需求设计 | workflow + hub | 无 |
| prd-writing-skill-pack.zip | PRD | 2-需求设计 | workflow | 无 |
| req-versioning-skill-pack.zip | 需求迭代版本管理 | 3-版本交付 | workflow | 无 |
| issue-doc-to-delivery-skill-pack.zip | 需求问题闭环主线 | 编排主线 | hub | 无 |
| sync-docs-SKILL.md | 文档中心同步 | 交付收口 | hub | 无 |
| prd-review-simulation-SKILL.md | PRD 评审模拟 | 4-评审 | hub | 无 |

## 常见错误

| 错误 | 原因 | 修复 |
|------|------|------|
| 页面没更新 | 只换 zip 没改 workflow.html 的"更新于"日期 | 两步一起做 |
| hub 入口滞后 | 只改了 workflow 没核对 hub（或反之） | 双页面清单都过一遍 |
| 下载 404 | 文件名与 `fetchDownload`/`downloadPack.url` 不一致 | 核对路径 |
| hub 页面白屏 | `const skills` JSON 被改坏 | 用上面校验脚本先解析 |
| 引擎改了同学没拿到 | 只发 SKILL.md，外部依赖没入包 | 按 manifest 外部依赖列一并打包 |
| 部署未生效 | GitHub Pages 1-2 分钟缓存 | 等待后 `curl?v=$RANDOM` 或比对线上包 |
| 把垃圾文件当差异/入包 | `.DS_Store`/`*.backup` 干扰 | 脚本已忽略；手工打包也要 `-x` 排除 |
