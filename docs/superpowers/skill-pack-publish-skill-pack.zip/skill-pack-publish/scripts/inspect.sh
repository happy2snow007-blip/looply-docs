#!/usr/bin/env bash
# 批量巡检：把每个已发布下载包与本地 skill 内容比对，只报"有实质差异"的包。
# 忽略 .DS_Store / *.backup / __pycache__ 等本地垃圾——它们不构成差异，也不该入包。
# 用法：bash inspect.sh            # 巡检全部
#      bash inspect.sh --skip prd-writing   # 排除某个 skill（如未定稿）
# 退出码：0 全部一致；1 有差异（差异清单打到 stdout，供人判断是否发布）。
set -uo pipefail

SUP="$HOME/looply-docs/docs/superpowers"
SK="$HOME/.claude/skills"
HERE="$(cd "$(dirname "$0")" && pwd)"
MAN="$HERE/packs.manifest"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT

SKIP=""
[ "${1:-}" = "--skip" ] && SKIP="${2:-}"

IGNORE=(-x '*.DS_Store' -x '*.backup' -x '*__pycache__*' -x '*.pyc')
# diff 时忽略同样的垃圾文件
DIFF_EXCL="-x .DS_Store -x *.backup -x __pycache__ -x *.pyc"

had_diff=0
printf '%-46s %-8s %s\n' "包" "结果" "说明"
printf '%s\n' "--------------------------------------------------------------------------"

while IFS=$'\t' read -r pack skill pages extdeps stage; do
  [ -z "${pack:-}" ] && continue
  case "$pack" in \#*) continue;; esac
  [ -n "$SKIP" ] && [ "$skill" = "$SKIP" ] && { printf '%-46s %-8s %s\n' "$pack" "SKIP" "用户指定排除"; continue; }

  local_dir="$SK/$skill"
  if [ ! -e "$local_dir" ]; then
    printf '%-46s %-8s %s\n' "$pack" "!MISS" "本地无 $skill 目录（可能已删/改名）"; had_diff=1; continue
  fi

  online="$SUP/$pack"
  if [ ! -e "$online" ]; then
    printf '%-46s %-8s %s\n' "$pack" "NEW" "线上无此文件，需首次发布"; had_diff=1; continue
  fi

  if [[ "$pack" == *.md ]]; then
    # 单文件 skill：线上 .md vs 本地 SKILL.md
    if diff -q "$online" "$local_dir/SKILL.md" >/dev/null; then
      printf '%-46s %-8s %s\n' "$pack" "SAME" "无差异"
    else
      printf '%-46s %-8s %s\n' "$pack" "DIFF" "SKILL.md 有更新"; had_diff=1
    fi
    continue
  fi

  # zip 包：解压线上包，组装本地"应打包内容"，逐文件比对
  ex="$TMP/ex_$skill"; mkdir -p "$ex"
  unzip -q "$online" "${IGNORE[@]}" -d "$ex" 2>/dev/null
  root="$(ls "$ex" | head -1)"

  want="$TMP/want_$skill/$skill"; mkdir -p "$want"
  # 拷本地 skill 目录（去掉垃圾文件）
  ( cd "$local_dir" && find . \( -name '.DS_Store' -o -name '*.backup' -o -name '*.pyc' -o -name '__pycache__' \) -prune -o -type f -print \
      | while read -r f; do mkdir -p "$want/$(dirname "$f")"; cp "$f" "$want/$f"; done )
  # 拷外部依赖
  if [ "$extdeps" != "-" ] && [ -n "$extdeps" ]; then
    IFS=';' read -ra deps <<< "$extdeps"
    for d in "${deps[@]}"; do
      dp="${d/#\~/$HOME}"
      [ -f "$dp" ] && cp "$dp" "$want/" || { printf '%-46s %-8s %s\n' "$pack" "!DEP" "外部依赖缺失: $d"; had_diff=1; }
    done
  fi

  out="$(diff -rq $DIFF_EXCL "$ex/$root" "$want" 2>&1)"
  if [ -z "$out" ]; then
    printf '%-46s %-8s %s\n' "$pack" "SAME" "无差异"
  else
    n="$(printf '%s\n' "$out" | grep -c .)"
    printf '%-46s %-8s %s\n' "$pack" "DIFF" "$n 处差异，见下"; had_diff=1
    printf '%s\n' "$out" | sed 's/^/    /'
  fi
done < "$MAN"

printf '%s\n' "--------------------------------------------------------------------------"
if [ "$had_diff" -eq 0 ]; then
  echo "✅ 全部一致，无需发布。"
else
  echo "⚠️ 有差异/待处理项（见上），逐个确认交付文件后再发布。"
fi
exit "$had_diff"
