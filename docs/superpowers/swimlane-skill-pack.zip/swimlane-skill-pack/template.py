#!/usr/bin/env python3
"""
泳道图最小模板 - 新项目复制此文件，改 3 处即可生成泳道图

使用方法：
  1. 复制此文件到项目目录
  2. 修改 LANE_CONFIG（泳道配置）
  3. 修改 SECTIONS（流程数据）
  4. 修改底部输出路径和标题
  5. python3 gen_flowchart.py
"""

import os, sys
sys.path.insert(0, os.path.expanduser("~/Templates/swimlane"))
from engine import *

# ========== 1. 泳道配置（改这里） ==========
LANE_CONFIG = [
    {"key": "A", "name": "核心业务系统", "color": "#4A6CF7", "bg": "rgba(74,108,247,0.04)"},
    {"key": "B", "name": "内部服务",     "color": "#F59E0B", "bg": "rgba(245,158,11,0.04)"},
    {"key": "C", "name": "外部服务",     "color": "#EF4444", "bg": "rgba(239,68,68,0.04)"},
]

# ========== 2. 流程数据（改这里） ==========
SECTIONS = [
    ("① 示例流程", [
        S("开始"),
        P("A", "接收请求"),
        D("A", "校验通过?", no="返回错误"),
        X("A", "B", "调用内部服务"),
        P("B", "处理业务逻辑"),
        X("B", "C", "调用外部接口"),
        P("C", "返回结果"),
        X("C", "A", "接收响应"),
        S("完成"),
    ]),

    # ---- MB 多分支示例（按需使用，不需要可删除） ----
    # 判断口诀：逐步骤问"所有分支走法一样吗？"
    #   一样 → 公共路径，放 MB 之前或之后
    #   不一样（哪怕只有一条不同）→ 放进 MB 分支
    ("② 多分支示例", [
        S("开始"),
        P("A", "公共步骤（所有分支都走）"),
        MB("A", "类型判断?", branches=[
            {"label": "类型A", "nodes": [
                P("A", "A专属步骤1"),
                P("A", "A专属步骤2"),
            ]},
            {"label": "类型B", "nodes": [
                P("A", "B专属步骤"),
                D("A", "B特殊判断?", no="返回错误"),
            ]},
            {"label": "类型C", "nodes": [
                P("A", "C专属步骤"),
            ]},
        ], w=130),
        P("A", "公共步骤（汇合后都走）"),
        S("完成"),
    ]),
]

# 初始化泳道（传 sections 自动扩宽，C/MB 节点不会跨泳道）
ctx = init_lanes(LANE_CONFIG, sections=SECTIONS)

# patches 用于特殊处理（如三分支判断），一般不需要
patches = {}

# ========== 3. 输出（改标题和路径） ==========
result = build_svg(ctx, SECTIONS,
                   title="项目名 &#183; 模块系统流程图",
                   version="V1.0",
                   patches=patches)

write_svg(result, os.path.expanduser("~/Desktop/output-flowchart.svg"))
