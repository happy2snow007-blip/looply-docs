---
name: swimlane-diagram-generation
description: Use when designing, creating, or modifying swimlane flowchart diagrams with multiple actors. Triggers on tasks involving system flowcharts, cross-role process visualization, SVG swimlane diagrams, or multi-actor workflow diagrams.
---

# 泳道图生成方法与规范

## 核心原则

绝对不要手写 SVG 坐标。泳道图节点多、连线复杂，手写坐标必然出错且反复调试。必须用 Python 脚本生成。

**优先使用数据驱动架构**：流程用数据声明（节点类型 DSL），布局引擎自动计算坐标和连线。只在引擎无法处理的特殊情况下才手写坐标。

**重构不抄旧值**：重构旧代码时，硬编码数值不能直接照搬。必须从需求出发重新推导：先定约束（如"箭头不被遮挡""错误框不跨泳道"），再算数值。旧代码的数值可能本身就有 bug。

## 泳道划分原则（必须严格遵守）

泳道划分是整张图的骨架，骨架错了后面全白干。必须在动手画图之前确定。

### 核心判断标准

每条泳道必须代表一个**可独立部署、独立迭代的系统或模块**。用这个问题检验："这些泳道之间，是不是可以独立部署的系统？"

### 常见错误维度

| 错误维度 | 示例 | 问题 |
|---------|------|------|
| 角色维度 | 用户 / 商家 / 管理员 | 角色不是系统，同一个系统服务多个角色 |
| 技术分层 | 前端 / 后端 / 数据库 | 技术层不是独立系统，前后端属于同一个业务模块 |
| 角色+技术混搭 | 用户 / 前端 / 后端 / 外部服务 | 维度不统一，90%节点挤在"后端"一条泳道 |

### 正确做法

按**系统边界**划分。例如登录注册模块：
- 登录注册系统（核心业务逻辑）
- 消息通知（验证码生成/存储/校验 + 投递调度）
- 外部服务（邮件服务商、OAuth Provider）

### 验证方法

划分完成后做两个检查：
1. **均匀性检查**：预估各泳道的节点数量，如果某条泳道占 80%+ 节点，说明粒度不对
2. **跨泳道交互检查**：如果大部分流程段都不涉及跨泳道，说明泳道划分过细或维度不对

### 先想再画的顺序

1. 确认泳道划分（系统边界）→ 做均匀性和交互检查
2. 确认段划分（用户入口）→ 做完整性和独立性检查
3. 每个段先用文字写清楚步骤和判断分支
4. 标注哪些步骤涉及跨泳道调用
5. 最后才动手写 Python 脚本生成 SVG

## 段划分原则（必须严格遵守）

段划分决定流程图的信息结构。泳道划分回答"哪些系统参与"，段划分回答"用户有哪些操作路径"。

### 核心原则：按用户入口划分，每段画完整技术链路

### 5 条判断规则

1. **一个入口 = 一段流程**。入口指用户或系统触发的起点动作（点击注册、点击登录、前端检测到 token 过期等）。不同入口即使后半段技术路径相似，也分开画。
2. **技术能力不独立成段**。风控检测、设备指纹采集、验证码校验这类"被调用的技术能力"，嵌入到调用它的业务流程中，不单独画段。判断标准：它是不是用户能感知到的独立操作？不是→内嵌。
3. **路径分叉用引用而非重复画**。如 OAuth 认证中"已绑定→转②登录流程"，用错误框标注跳转，不在本段重复画登录路径。判断标准：分叉后的路径是否已有独立段覆盖？是→引用。
4. **同一入口的变体可以合并**。OAuth 注册和 OAuth 登录入口相同（点击三方登录按钮），前半段路径一致（授权回调），在"已绑定?"处分叉，适合合并。但邮箱注册和邮箱登录入口不同（注册页 vs 登录页），路径完全不同，不合并。
5. **被动触发也算入口**。Token 刷新（前端自动触发）、协议版本检测（中间件自动触发）、被动退出（接口返回 401）都是独立入口，各自成段。

### 自检方法

划分完成后问两个问题：
1. 每段的第一个节点，是不是一个明确的触发动作？不是→段划分有问题
2. 段内有没有"只被调用不被用户触发"的独立技术模块？有→应该内嵌而非独立

## 流程完成后双视角走查（必须严格遵守）

流程节点全部画完后，必须从两个视角逐步走查，再交付。

### 1. 用户体验走查

从用户视角逐步模拟操作，每个节点问：
- 用户此时的操作预期是什么？系统的返回/提示是否符合这个预期？
- 用户还没完成基本输入时，是否会收到不相关的错误（如格式没填对就触发风控拦截）？
- 异常分支的提示文案，用户能看懂吗？

典型问题：轻量校验（格式、必填项）应排在重量级检查（风控、查库）之前，否则用户体验不合理。

### 2. 技术时序走查

从开发视角逐节点检查：
- **依赖存在性**：这步依赖的数据/对象此时已经创建了吗？（如 Session 在签发 Token 时才创建，关联操作必须在之后）
- **成本排序**：这步的计算成本是什么级别？轻量操作（内存/前端校验）应排在重量操作（查库/外部调用）之前
- **信息泄露**：这步的返回信息会不会泄露系统内部状态？（如"邮箱不存在"会被用于枚举攻击，应改为统一提示）
- **锁定/限频前置**：账号已锁定/已限频时，后续操作（如密码比对）不应执行

### 3. 节点文案可读性检查

逐个节点检查：遮住上下文只看这一个节点，能否知道在做什么？不能→文案不够具体。

### 4. D 节点方向检查（必须逐个验证）

D 节点结构固定：主线向下 = 是，右侧错误框 = 否。每个 D 节点必须验证：**"是"在业务语义上等于"继续主线"**。

检查方法：读菱形文案，回答"是"，问自己：这个回答是否意味着流程应该继续往下走？
- 是 → 正确
- 不是 → 菱形提问方向反了，必须换一种问法

典型错误：`D("A", "Hide My Email?", no="跳过写入")` — "Hide My Email? → 是"意味着隐藏了邮箱应该跳过，但 D 节点的"是"是主线继续，逻辑矛盾。正确做法：改问 `"给了真实邮箱?"` ，让"是→继续写入"成立。

规则：**先确定哪个分支走主线，再反推菱形的提问方式**，不能从技术概念直接写问题。

### 5. 幽灵箭头检查（必须逐条验证）

生成 SVG 后，逐条检查所有箭头连线：**每条箭头的起点必须有可见的图形元素（节点、线段、汇合点）**。如果箭头起点处没有任何可见元素，就是幽灵箭头，必须修复。

常见成因与修复：
- **C 节点空否分支 + `draw_merge=False`**：菱形底部到 merge_y 之间没有线段，但下一个节点从 merge_y 画箭头。修复：补画 `svg_polyline_plain()` 从菱形底部到 merge_y
- **MB 内 C 节点空否分支**：同上，引擎已在 MB 列 C 节点处理中修复（`not bnode.no_nodes` 时补画线段）
- **MB 非主线列汇合**：列末端到 merge_y 之间缺少连接线段。修复：检查 `mb_merge_pending` 机制是否正确记录了所有非主线列

检查方法：在浏览器打开 SVG，放大到 200%，沿每条箭头从箭尾往回看，箭尾处必须连着一个可见元素。重点检查 C 节点和 MB 节点附近的箭头。

## 图形规范

- **圆角矩形** → 开始/结束节点
- **矩形** → 操作/处理步骤
- **菱形** → 判断/决策节点（用"是否XX？"提问形式）
- **操作和判断必须分离**：如"平台审核"用矩形，后面跟"是否通过？"用菱形
- 每条分支都要有明确的结束节点
- 所有连线使用直角折线，**绝对不能穿过任何节点**
- 实线箭头表示正常流向，虚线箭头表示回退/重试
- 底部包含完整图例：图形说明 + 角色色块

## 编码支持（YAML metadata 嵌入，所有泳道图必须执行）

每张泳道图 SVG 都必须在 `<metadata>` 标签内嵌入完整的 YAML 流程定义，供研发编码参考。这是标准流程，不是可选项。

### 嵌入方式

在生成脚本中实现 `sections_to_yaml(SECTIONS)` 函数，将 DSL 数据转为 YAML 字符串，然后插入 SVG 的 `<defs>` 之前：

```python
yaml_str = sections_to_yaml(SECTIONS)
metadata_block = f'<metadata>\n<![CDATA[\n{yaml_str}\n]]>\n</metadata>'
svg_content = svg_content.replace('\n<defs>', f'\n{metadata_block}\n<defs>', 1)
```

### YAML 格式（完整流程逻辑）

```yaml
# 项目名 模块名 版本号
# 研发编码参考数据，从 SVG <metadata> 提取

swimlanes:
  - key: "A"
    name: "登录注册系统"
  - key: "M"
    name: "消息通知"

sections:
  - name: "① 邮箱注册"
    steps:
      - type: start_end
        text: "开始注册"
      - type: process
        lane: "A"
        text: "接收注册请求(邮箱+密码)"
      - type: decision
        lane: "A"
        text: "邮箱格式正确?"
        on_no: "返回邮箱格式错误"
        yes_label: "是"
        no_label: "否"
      - type: cross_lane
        from: "A"
        to: "M"
        text: "生成验证码并存储"
      - type: condition_branch
        lane: "A"
        text: "邮箱已注册?"
        yes_label: "是"
        no_label: "否"
        yes_branch:
          - text: "关联已有账号"
        no_branch:
          - text: "创建新账号"
      - type: multi_branch
        lane: "A"
        text: "Provider类型?"
        branches:
          - label: "Google"
            nodes:
              - type: process
                text: "email写入凭证表"
          - label: "Apple"
            nodes:
              - type: condition_branch
                text: "给了真实邮箱?"
                yes_label: "是"
                no_label: "否"
                yes_branch:
                  - text: "email写入凭证表"
      - type: note
        title: "注释标题"
        lines:
          - "注释内容行1"
          - "注释内容行2"
```

### 节点类型映射

| DSL 类型 | YAML type | 特殊字段 |
|---------|-----------|---------|
| S | start_end | text |
| P | process | lane, text |
| D | decision | lane, text, on_no, yes_label, no_label |
| X | cross_lane | from, to, text |
| C | condition_branch | lane, text, yes_label, no_label, yes_branch, no_branch |
| MB | multi_branch | lane, text, branches（每条含 label + nodes） |
| N | note | title, lines |

### 参考实现

完整的 `sections_to_yaml()` 函数见 `~/Templates/swimlane/gen_looply_v5_engine.py`（支持所有 7 种节点类型的递归转换）。

## 两种布局模式

### 纵向泳道（推荐用于系统流程图）
- 泳道从左到右排列（如：登录注册系统 → 消息通知 → 外部服务）
- 流程从上到下走
- 跨泳道用直角折线连接
- 多个流程段纵向堆叠，左侧竖条显示段标题（逐字自上而下竖排。中文逐字拆分，英文/数字整词保持不拆。短英文词≤5字符水平渲染+基于 SEC_LABEL_W 动态缩小字号；长英文词>5字符旋转90°渲染避免溢出）
- 适合：流程步骤多、需要清晰展示跨系统交互

### 横向泳道
- 泳道从上到下排列，流程从左到右走
- 跨泳道用垂直 L 形折线连接
- 错误分支从菱形下方出（纵向是右侧）
- 不分段，适合步骤较少的单一流程
- 引擎已实现：`init_lanes_h()` + `layout_section_h()` + `build_svg_h()`，复用同一套 DSL（S/P/D/X/N）和绘图原语
- 当前状态：核心架构可用，页面样式待优化（连线间距、节点对齐等细节）

```python
# 横向泳道用法
ctx = init_lanes_h(LANE_CONFIG)  # 每条泳道可用 "h" 指定独立高度
nodes = [S("开始"), P("A", "操作"), D("A", "判断?", no="错误"), S("结束")]
result = build_svg_h(ctx, nodes, title="标题", version="V1.0")
write_svg(result, "output.svg")
```

## 前置分析（必须严格遵守）

画泳道图之前，必须先完成以下对照分析：

1. **确定泳道划分** — 按系统边界划分泳道，做均匀性检查和跨泳道交互检查（见"泳道划分原则"）
2. **读取产品架构图** — 确认该模块有哪些功能项
3. **读取实体关系图** — 确认有哪些实体、字段、关系
4. **交叉比对** — 逐项检查架构图的每个功能项和 ER 图的每个实体/字段，是否已有对应的流程图覆盖
5. **列出缺失清单** — 明确哪些流程缺失、哪些流程覆盖不完整
6. **排优先级** — 结合业务阶段和依赖关系，给缺失流程排 P0/P1/P2/P3
7. **确认范围** — 与用户确认本次要补哪些流程，再开始画图
8. **标注已知演进方向** — 检查当前方案是否有已确认的未来变更计划（如入口统一、新渠道扩展、MFA 接入等）。如果有，在对应流程段用注释框（N 节点）标注预留设计和迁移路径

这个过程确保流程图与架构图、ER 图三者一致，不遗漏、不多画，且已知演进方向有迹可循。

## 生成架构：数据驱动（推荐）

### 架构概览

数据驱动架构将流程图拆分为三层：**数据层**（流程定义）、**引擎层**（布局计算）、**渲染层**（SVG 输出）。修改流程只需改数据，不碰坐标。

```
数据层（SECTIONS）→ 引擎层（layout_section）→ 渲染层（render_items + main 拼装）
```

### 节点类型 DSL

7 种节点类型，覆盖所有泳道图场景：

```python
class S:  # 开始/结束 圆角胶囊
    def __init__(self, text, color=None)

class P:  # 操作步骤 矩形
    def __init__(self, lane, text, w=160)

class D:  # 判断菱形，no= 异常分支文案（单分支，异常走右侧错误框）
    def __init__(self, lane, text, no=None, yes_label="是", no_label="否",
                 w=130, no_w=100, no_h=26)

class C:  # 条件分支（双分支，两条路径最终汇合到下一个节点）
    def __init__(self, lane, text, yes_nodes=None, no_nodes=None,
                 yes_label="是", no_label="否", w=130)

class MB:  # 多分支（N条路径，每条包含完整节点序列，最终汇合）
    def __init__(self, lane, text, branches=None, w=130, col_gap=40)

class X:  # 跨泳道步骤（从 from_lane 连线到 to_lane）
    def __init__(self, from_lane, to_lane, text, w=160)

class N:  # 注释框（段末尾）
    def __init__(self, title, lines, w=360, line_h=16)
```

### C 节点（条件分支）详解

D 节点是单分支判断（正常走下方，异常走右侧错误框）。C 节点是双分支判断（两条路径各有步骤，最终汇合到下一个节点）。

**布局规则**：
- 菱形判断 → 否分支走主线（菱形下方）→ 是分支画在右侧 → 两条分支汇合到下一个节点
- `yes_nodes` / `no_nodes` 中的元素只支持 P 类型
- 空列表表示该分支无额外步骤，直接汇合

**用法示例**：

```python
# 两条分支都有步骤
C("A", "邮箱已注册?",
  yes_nodes=[P("A", "关联已有账号")],
  no_nodes=[P("A", "创建新账号")],
  yes_label="是", no_label="否")

# yes 分支为空（如 Apple Hide My Email? 是→跳过，否→写凭证表）
C("A", "Apple Hide My Email?",
  yes_nodes=[],
  no_nodes=[P("A", "provider_email写入凭证表", w=200)],
  yes_label="是", no_label="否", w=170)

# no 分支为空（如 Facebook无邮箱? 是→标记，否→跳过）
C("A", "Facebook无邮箱?",
  yes_nodes=[P("A", "标记待补邮箱")],
  no_nodes=[],
  yes_label="是", no_label="否", w=150)
```

**空分支处理**：
- 空 yes 分支：画水平 stub 短线 + 标签，通过 `c_yes_pending` 延迟到下一个节点画先下后横折线
- 空 no 分支：只画标签不画箭头，`prev_type='D'` 让下一个节点从菱形底部直接连线（避免双箭头）
- 两条都空：理论上不应出现，但有防御处理

**引擎内部架构**（使用者无需关心，修改引擎时必读）：

C 节点的分支布局逻辑统一由 `_layout_c_branch()` 函数处理，主流程和 MB 内部共用同一份代码：

```python
def _layout_c_branch(bnode, bnode_cx, diamond_cy, g, lane_map=None, draw_merge=True):
    """C 节点的完整分支布局（菱形已由调用方画好）

    draw_merge=True:  画是分支汇合折线和否分支空线段（MB 内使用）
    draw_merge=False: 不画，由调用方通过 c_yes_pending 延迟处理（主流程使用）
    """
```

`draw_merge` 参数控制汇合线的绘制时机：
- `draw_merge=False`（主流程 + MB 内部）：不画汇合线，通过 `c_yes_pending`（主流程）或 `mb_c_yes_pending`（MB 内部）延迟到下一个节点画先下后横折线，指向下一个节点的右侧中点
- `draw_merge=True`：C 节点自己画完所有汇合线（当前未使用，保留为备用）

**MB 内部 C 节点的空否分支处理**：当 C 节点在 MB 列内且 `no_nodes=[]` 时，`draw_merge=False` 不会画菱形底部到 merge_y 的线段。但下一个 P 节点从 merge_y 画箭头，导致"幽灵箭头"（箭头起点无可见元素）。引擎在 MB 列的 C 节点处理中补画了一条 `svg_polyline_plain()` 从菱形底部到 merge_y，填补视觉断裂。

这个设计解决了之前 C 节点在主流程和 MB 内部各写一套布局逻辑导致的 bug（幽灵箭头、断线、双箭头）。修改 C 节点布局时只需改 `_layout_c_branch()` 一个函数。

连线偏移量统一由 `_t_off(prev_type)` 计算：

```python
def _t_off(prev_type):
    """统一计算从上一个节点底部到连线起点的偏移量"""
    if prev_type in ('C_merge', 'MB_merge'):
        return 0       # 汇合点本身就是连线起点
    if prev_type == 'D':
        return 25      # 菱形半高
    return 16          # 矩形/圆角矩形半高
```

所有需要计算 `top_offset` 的地方都调用 `_t_off()`，不再各自硬编码。新增 `prev_type` 值时只需在此函数加一行。

**泳道自动扩宽**：C 节点的 yes 分支在主线右侧，可能超出泳道边界。引擎通过 `_calc_min_lane_widths()` 自动扫描所有 C 节点，计算最小泳道宽度。使用时必须把 `sections` 传给 `init_lanes()`：

```python
# 必须传 sections 才能触发自动扩宽
ctx = init_lanes(LANE_CONFIG, sections=SECTIONS)
```

扩宽公式与 `layout_section` 中 `right_cx` 计算一致：`lane_width = 2 * max(左侧从cx, 右侧从cx)`。

### MB 节点（多分支）详解

C 节点是双分支（是/否两条路径汇合）。MB 节点是 N 分支（3/4/5...条路径，每条包含完整节点序列，最终汇合到下一个节点）。

**布局规则**：
- 菱形判断 → N 条分支从左到右排列（居中于泳道 cx）→ 所有分支汇合到下一个节点
- 第一列从菱形左顶点水平连线再向下，其余列从菱形右顶点水平连线再向下（所有列统一 L 形折线，不走底部直连）
- 每列内支持 P、D、X、C 类型节点（不支持 S、N、MB 嵌套）。列内 C 节点调用 `_layout_c_branch(draw_merge=True)` 直接画汇合线
- 汇合点 y = 最长列末端 + 节点半高
- 汇合折线：所有偏离泳道中心的列统一延迟到下一个节点画 L 形折线（先下后横），左侧列连目标节点左侧中点，右侧列连右侧中点（`mb_merge_pending` 机制，类似 `c_yes_pending`）

**参数说明**：
- `branches`: 分支列表，每项为 dict `{"label": "标签", "nodes": [节点列表], "col_w": 可选列宽}`
- `col_gap`: 列之间的间距，默认 40px
- `w`: 菱形宽度，默认 130

**用法示例**：

```python
# 三分支：Provider 特殊处理
MB("A", "Provider类型?", branches=[
    {"label": "Google", "nodes": [
        P("A", "email写入凭证表"),
        P("A", "预填昵称"),
    ]},
    {"label": "Apple", "nodes": [
        D("A", "Hide My Email?", no="跳过写凭证表", w=150, no_w=80),
        P("A", "预填昵称(仅首次)", w=160),
    ]},
    {"label": "Facebook", "nodes": [
        P("A", "email写入凭证表"),
        P("A", "预填昵称"),
        D("A", "有邮箱?", no="标记待补邮箱"),
    ]},
], w=130)
```

**列宽计算**：
- 每列宽度 = 该列所有节点最大宽度，最小 160px
- 列内有 C 节点时：列宽 = 否分支最大宽度 + 40 + 是分支最大宽度
- 可通过 `col_w` 手动指定列宽覆盖自动计算

**泳道自动扩宽**：MB 节点的所有列居中排列，总宽度可能超出泳道。引擎通过 `_calc_min_lane_widths()` 自动扫描 MB 节点计算最小泳道宽度，与 C 节点共用同一机制。

**宽度优化技巧**：MB 分支内放 C 节点会显著增加列宽（每列需容纳否分支+是分支）。如果多个分支有相同的 C 节点（如"邮箱已注册?"），应将公共 C 节点提到 MB 之前，MB 内只保留 Provider 特殊差异。这样可大幅减少总宽度（如从 1872px 降到 1272px）。

**公共路径 vs 分支流程的判断方法**：

逐步骤问"这步所有分支走法一样吗？"
- 一样 → 公共路径，放 MB 之前或之后
- 不一样（哪怕只有一条分支不同）→ 放进 MB 分支

示例（OAuth认证，Google/Apple/Facebook 三分支）：

```
公共路径（MB 之前）：
  获取用户信息 → provider_uid已绑定? → 邮箱已注册? → 写入OAuth绑定记录
  ↑ 三个 Provider 都要走，逻辑完全一样

分支流程（MB 内）：
  Google:   email写入凭证表 → 预填昵称
  Apple:    Hide My Email? → 预填昵称(仅首次)    ← 凭证表写入有条件
  Facebook: email写入凭证表 → 预填昵称 → 有邮箱?  ← 多一个邮箱检查

公共路径（MB 之后）：
  签发Token → 记录设备指纹 → 完成
  ↑ 三个 Provider 都要走，逻辑完全一样
```

每段流程是一个 `(段名, [节点列表])` 元组，节点按执行顺序排列：

```python
SECTIONS = [
    ("① 注册流程", [
        S("开始注册"),
        P("A", "接收注册请求(邮箱+密码)"),
        D("A", "格式校验通过?", no="返回格式错误"),
        D("A", "已勾选协议?", no="返回未勾选"),
        D("A", "邮箱已注册?", no="返回已注册", yes_label="否", no_label="是"),
        P("A", "请求发送验证码"),
        X("A", "M", "生成验证码并存储"),
        X("M", "E", "邮件服务商投递"),
        X("E", "A", "接收验证码输入"),
        D("M", "验证码正确?", no="返回验证码错误"),
        X("M", "A", "创建账号"),
        P("A", "签发Token"),
        S("注册完成"),
    ]),
    # ... 更多段
]
```

### 布局引擎

`layout_section(ctx, nodes, y0)` 自动完成：
- 根据节点类型计算间距（S/P/D/X 各有不同间距规则）
- 根据泳道标识确定 X 坐标（支持每条泳道独立宽度）
- 自动生成同泳道直线连线和跨泳道折线连线
- 自动处理判断节点的异常分支（错误框 + 红色虚线箭头）
- 动态约束错误框不超出泳道边界
- 错误框宽度自动撑开：根据文案长度估算最小宽度，取 `max(no_w, 文案实际需要宽度)`

当前限制：引擎仅支持**纵向泳道**（泳道左右排列，流程从上到下）。横向泳道需手写坐标。

```python
def layout_section(ctx, nodes, y0):
    """返回 (items, lines, total_height, note_svg)
    items: [(kind, node, cx, cy, ...), ...]  布局结果
    lines: [svg_string, ...]  连线 SVG
    """
```

### 泳道初始化

`init_lanes()` 支持两个可选能力：

1. **独立泳道宽度**：在 `LANE_CONFIG` 中用 `"w"` 字段指定，未指定则用默认值 320px
2. **可配置间距**：通过 `gaps` 参数覆盖默认间距，可用于缩小间距减少总高度

```python
# 独立泳道宽度示例：A 泳道加宽
LANE_CONFIG = [
    {"key": "A", "name": "核心系统", "color": "#4A6CF7", "bg": "...", "w": 400},
    {"key": "M", "name": "消息通知", "color": "#F59E0B", "bg": "..."},  # 默认 320
]

# 可配置间距示例：缩小间距减少高度
ctx = init_lanes(LANE_CONFIG, gaps={
    "step": 40,       # 默认 48
    "decision": 50,   # 默认 60
    "after_dec": 48,  # 默认 58
    "cross": 44,      # 默认 52
})
```

注意：缩小间距会让连线变短，过度缩小会导致连线拥挤。建议先生成对比再决定。

### 错误框动态定位（引擎内置）

引擎自动处理错误框的泳道边界约束，不需要手动计算：

```python
# 在 layout_section 内部，判断节点的异常分支：
if node.no:
    lane_right = SEC_LABEL_W + LANE_W * (lane_idx + 1) - 4
    arrow_start = cx + 65          # 菱形右顶点（默认 w=130）
    no_left = arrow_start + 12     # 箭头最小可见长度 12px
    actual_no_w = min(no_w, lane_right - no_left)  # 不超出泳道
    no_cx = no_left + actual_no_w // 2
```

约束链：`菱形右顶点 → 12px 箭头 → 错误框左边缘 → 错误框宽度 ≤ 泳道剩余空间`

### 渲染层

`render_items()` 将布局结果转为 SVG 字符串，`main()` 负责两遍构建和最终拼装。

### 特殊情况处理

引擎无法自动处理的场景（如三分支判断），用 patch 函数在渲染后追加。

**推荐方式**：使用 `make_multi_branch_patch()` 通用函数，无需手写坐标：

```python
from engine import *

patches = {
    "⑧ 风控决策": make_multi_branch_patch("综合风险等级?", [
        {"side": "right", "label": "中", "text": "中→发验证码", "offset": 120, "w": 80},
        {"side": "left",  "label": "高", "text": "高→拦截提示",
         "offset": 115, "w": 70, "label_color": "#DC2626"},
    ])
}

result = build_svg(ctx, SECTIONS, title="...", version="...", patches=patches)
```

参数说明：
- `side`: "right" 或 "left"，分支方向
- `label`: 连线上的标签文字
- `text`: 分支框内文案
- `offset`: 分支框中心距判断节点中心的水平距离（默认 120）
- `w`: 分支框宽度（默认 80）
- `label_color`: 标签颜色（默认 #64748B，高风险用 #DC2626）

**注意**：patch 函数绕过了引擎，不会自动执行泳道边界约束。必须手动验证：
1. 所有 box 满足 `center - w/2 >= SEC_LABEL_W`（不侵入左侧段标题区）
2. 所有 box 满足 `center + w/2 <= 泳道右边界`（不跨泳道）
3. 箭头终点对齐 box 边缘（不被 box 遮挡）

如需完全自定义 patch，可手写函数（签名：`func(items, lines_svg, y0) -> (extra_nodes, extra_lines)`）。

### 修改流程对比

| 操作 | 手写坐标（v3） | 数据驱动（v4） |
|------|---------------|---------------|
| 加一个步骤 | 改坐标 + 改后续所有 y + 改段高度 | 在列表中插入一行 `P(...)` |
| 改判断文案 | 找到 dm() 调用改文字 | 改 `D(...)` 的 text 参数 |
| 调整错误框 | 手算坐标 + 验证边界 | 改 `D(...)` 的 no_w 参数 |
| 加一个流程段 | 写 100+ 行 build 函数 | 加一个 `(段名, [...])` 元组 |
| 调整全局间距 | 改每个 build 函数 | 改引擎的 GAP 常量 |

## 生成流程（旧版手写坐标方式）

> 当流程段少（≤3段）或需要极精细控制时，可用手写坐标方式。多段流程图必须用数据驱动架构。

1. 写 Python 脚本的 helper 函数（节点绘制 + 连线绘制）
2. 计算泳道布局参数（泳道宽度/高度、中心坐标、段间距）
3. 生成第一层：所有背景（标题栏、泳道背景、泳道标签、图例背景）
4. 用 `lines_svg[]` 和 `nodes_svg[]` 分别收集连线和节点
5. 按段逐步添加节点和连线，用 y 变量递增追踪纵坐标
6. 最终按 背景 + lines_svg + nodes_svg + `</svg>` 顺序拼接输出

## SVG 根元素规则（必须严格遵守）

`<svg>` 标签必须同时包含 `width`、`height` 和 `viewBox`，确保浏览器直接打开时按原始尺寸居左渲染，不会白屏或自动缩放：

```python
f'<svg xmlns="http://www.w3.org/2000/svg" width="{TOTAL_W}" height="{TOTAL_H}" viewBox="0 0 {TOTAL_W} {TOTAL_H}" ...>'
```

只写 `viewBox` 不写 `width`/`height` → 浏览器可能渲染为 0 尺寸（白屏）或自动缩放到视口宽度。

## SVG 分层规则（必须严格遵守）

SVG 没有 z-index，绘制顺序 = 层级顺序。必须按三层绘制，防止跨泳道连线被背景遮挡：

1. **第一层**：所有背景（标题栏 + 泳道标签区/内容区 + 段标题 + 图例背景）
2. **第二层**：所有连线（`lines_svg[]`）
3. **第三层**：所有节点（`nodes_svg[]`）+ 图例内容

## 段标题背景覆盖规则（必须严格遵守）

左侧段标题蓝色背景必须完整覆盖该段的泳道标签行 + 内容区，不能留白色空白：

```python
# ✅ 正确：背景从泳道标签行起始，覆盖标签行+内容区
label_y = sec_y_starts[i] - LANE_HDR_H
svg_parts.append(f'<rect x="0" y="{label_y}" width="{SEC_LABEL_W}" height="{content_h + LANE_HDR_H}" '
                 f'fill="#DBEAFE" rx="0"/>')

# ❌ 错误：背景只覆盖内容区，泳道标签行左侧露出白色
svg_parts.append(f'<rect x="0" y="{content_y}" width="{SEC_LABEL_W}" height="{content_h}" '
                 f'fill="#DBEAFE" rx="0"/>')
```

段标题文字在蓝色背景总高度（`content_h + LANE_HDR_H`）内垂直居中：

```python
total_area_h = content_h + LANE_HDR_H
text_start_y = label_y + (total_area_h - total_text_h) // 2 + 14  # 14 = baseline offset
```

## Helper 函数定义

```python
# 圆角矩形（开始/结束节点）
def rr(cx, cy, t, sk="#64748B", w=110, h=30):
    return f'<rect x="{cx-w//2}" y="{cy-h//2}" width="{w}" height="{h}" rx="15" .../>'

# 矩形（操作步骤）
def rc(cx, cy, t, w=140, h=32):
    return f'<rect x="{cx-w//2}" y="{cy-h//2}" width="{w}" height="{h}" rx="4" .../>'

# 菱形（判断节点），half-height = h//2 = 25
def dm(cx, cy, t, w=140, h=50):
    p = f"{cx},{cy-h//2} {cx+w//2},{cy} {cx},{cy+h//2} {cx-w//2},{cy}"
    return f'<polygon points="{p}" .../>'

# 实线箭头
def ar(x1, y1, x2, y2): ...

# 红色虚线箭头（异常/回退）
def ard(x1, y1, x2, y2): ...

# 折线箭头（跨泳道连线）
def pa(pts): ...    # 实线折线
def pad(pts): ...   # 虚线折线

# 标签
def lb(x, y, t, c="#64748B"): ...
```

## 节点间距规范（必须严格遵守）

| 连接类型 | 间距(px) | 说明 |
|---------|---------|------|
| 矩形 → 矩形 | 42~52 | 标准操作步骤间距 |
| 矩形 → 菱形 | 58~68 | 菱形 half-height=25，需要更大间距 |
| 菱形 → 矩形 | 55~58 | 同上 |
| 菱形 → 菱形 | **70（最小值）** | 保证连线至少 20px 可见长度 |
| 首节点距段顶部 | 25~30 | `y = Y0 + 25` 或 `y = Y0 + 30` |

**为什么菱形间距最小 70px**：菱形 half-height=25px，两个菱形之间的连线长度 = 间距 - 25 - 25。间距 50px 时连线长度 = 0px（不可见）。间距 70px 时连线长度 = 20px，加上箭头 marker 消耗 ~7px，实际可见约 13px。

## 连线对齐规范（必须严格遵守）

### 菱形到错误提示矩形的虚线箭头

`ard()` 的终点 x 坐标必须精确对齐到目标矩形的左边缘：

```python
# 错误提示矩形：中心 cx+155, 宽度 100
# 左边缘 = cx+155 - 100/2 = cx+105
ard(cx + 65, y, cx + 105, y)  # ✅ 对齐到左边缘

ard(cx + 65, y, cx + 98, y)   # ❌ 留了 7px 间隙，箭头悬空
```

**计算公式**：`ard_end_x = error_rect_cx - error_rect_w / 2`

每个 `ard()` 调用都必须按此公式计算，不能凭感觉估算。

### 跨泳道折线连接

使用 L 形折线，只拐一个弯，比 Z 形（横→下→横，拐2个弯）更干净。L 形有两种方向：

1. **先下后横**（纵向泳道常用）：从起点垂直下到目标行，再水平到目标泳道
2. **先横后下**：从起点水平到目标泳道列，再垂直下到目标节点

根据起点和终点的相对位置选择更自然的方向。数据驱动引擎中默认用"先下后横"：

```python
# 先下后横：polyline([(from_cx, y1+top_offset), (from_cx, y2), (to_cx±80, y2)])
pa([(A, y7+16), (A, y8), (M-80, y8)])  # A→M
pa([(M, y9+25), (M, y10), (A+80, y10)])  # M→A（前一个是菱形，top_offset=25）

# 先横后下：polyline([(from_cx±80, y1), (to_cx, y1), (to_cx, y2-16)])
pa([(A+80, y3), (M, y3), (M, y4-25)])  # A→M，终点是菱形
```

禁止使用 Z 形折线（3段折线拐2个弯），L 形折线视觉更清晰。

### 判断节点标签位置

- YES 方向（通常向下）：`lb(cx+12, y+38, "是")`
- NO 方向（通常向右）：`lb(cx+86, y-7, "否", "#DC2626")`

## 段高度计算与验证

每个段的高度必须容纳所有节点。计算方法：

```python
# 最后一个节点的 y 坐标 + 节点半高 + 余量
last_node_bottom = last_y + 13  # 圆角矩形半高=13
required_height = last_node_bottom - Y0 + 10  # 加 10px 余量

# 验证：last_node_bottom 必须 < Y0 + SEC_CONTENT_H[i]
```

**每次修改节点间距后，必须重新计算段高度并更新 `SEC_CONTENT_H`**。

## 浮动注释框定位

浮动注释框（如"会话失效说明"）必须基于实际节点位置定位，不用固定偏移：

```python
# ✅ 基于最后一个流程节点定位
note_y = last_flow_node_y + 30

# ❌ 基于段起始位置的固定偏移
note_y = Y0 + 350  # 危险：节点位置变化后会遮挡
```

## 纵向泳道布局参数模板

新项目只需修改 `LANE_CONFIG`，其余常量和映射自动生成：

```python
# ========== 泳道配置（新项目只改这里） ==========
LANE_CONFIG = [
    {"key": "A", "name": "核心业务系统", "color": "#4A6CF7", "bg": "rgba(74,108,247,0.04)"},
    {"key": "M", "name": "消息/通知服务", "color": "#F59E0B", "bg": "rgba(245,158,11,0.04)"},
    {"key": "E", "name": "外部服务",     "color": "#EF4444", "bg": "rgba(239,68,68,0.04)"},
]

# ========== 布局常量（一般不需要改） ==========
SEC_LABEL_W = 40   # 左侧段标题宽度
LANE_W = 320       # 每条泳道宽度（根据泳道数量调整，保证 TOTAL_W 合理）
LANES = len(LANE_CONFIG)
TOTAL_W = SEC_LABEL_W + LANE_W * LANES
HEADER_H = 46      # 顶部标题栏高度
LANE_HDR_H = 24    # 泳道标签行高度

# 自动生成泳道中心 X 和映射
LANE_MAP = {}
for _i, _cfg in enumerate(LANE_CONFIG):
    _cx = SEC_LABEL_W + LANE_W * _i + LANE_W // 2
    LANE_MAP[_cfg["key"]] = _cx
    globals()[_cfg["key"]] = _cx  # 创建全局变量，方便 SECTIONS 数据引用

LANE_COLORS = [c["color"] for c in LANE_CONFIG]
LANE_NAMES = [c["name"] for c in LANE_CONFIG]
LANE_BG = [c["bg"] for c in LANE_CONFIG]
```

增减泳道只需增删 `LANE_CONFIG` 条目，`LANE_MAP`、中心坐标、颜色列表全部自动适配。

# 收集方式
lines_svg = []  # 第二层
nodes_svg = []  # 第三层

# 用 y 变量递增追踪
y = Y0 + 30
nodes_svg.append(rr(A, y, "开始")); y1 = y
y += 48
nodes_svg.append(rc(A, y, "操作步骤")); y2 = y
```

## 颜色规范

颜色按泳道分配，具体色值根据项目调整。以下为参考：

| 元素 | 颜色 |
|------|------|
| 泳道1（核心业务） | #4A6CF7（蓝） |
| 泳道2（内部服务） | #F59E0B（黄） |
| 泳道3（外部服务） | #EF4444（红） |
| 泳道4（如有） | #10B981（绿） |
| 正常连线 | #475569 |
| 异常连线 | #DC2626（红色虚线） |
| 判断节点填充 | #FEF3C7，边框 #D97706 |
| 段标题背景 | #DBEAFE |
| 画布背景 | #F8FAFC |
| 标题栏 | #1E1F2E |

## 常见错误与修复

| 错误 | 原因 | 修复 |
|------|------|------|
| 连线不可见（长度=0） | 菱形间距 50px，half-height 25+25=50 | 间距改为 70px |
| 虚线箭头悬空 | ard 终点没对齐矩形左边缘 | 按公式计算 end_x |
| 节点溢出段边界 | 段高度不够 | 重算 SEC_CONTENT_H |
| 连线被背景遮挡 | 没按三层顺序输出 | 背景→连线→节点 |
| 注释框遮挡节点 | 用固定偏移定位 | 改为基于节点位置定位 |
| 箭头 marker 吃掉连线 | marker refX=10 消耗 ~7px | 确保连线长度 >= 15px |
| 节点画在标题栏上 | build 函数内部修改了全局 Y0 | build 函数禁止修改 Y0，只读取 |
| 注释框坐标全错 | 两遍构建模式下第一遍的 note_boxes 基于 Y0=0 | 第二遍必须重新收集 note_boxes |
| 错误框跨泳道 | center+w/2 超过泳道右边界 | 按泳道边界约束公式重算 center 和 w |
| ard 箭头方向反了 | ard_start_x > ard_end_x（终点在起点左边） | 确保 ard_end_x > ard_start_x，差值 >= 15px |
| 红色虚线箭头不可见 | 箭头坐标落在错误框矩形内部，被矩形遮挡 | 箭头终点必须在错误框左边缘之外（no_left - 1），不能与矩形重叠 |
| 段标题英文词溢出 | 字号公式基于 LANE_W(320) 而非 SEC_LABEL_W(40) | 短词≤5字符：`fs=min(13, int((SEC_LABEL_W-8)/(len*0.6)))`；长词>5字符：旋转90° |
| 照搬旧代码坐标导致 bug | 旧代码的硬编码值本身有 bug，直接复制传播错误 | 从约束出发重新推导数值，不抄旧值 |
| 多会话零产出 | 大批量修改用逐行 Edit，上下文压缩后丢进度 | 超过 5 处同 pattern 改动必须写脚本批量处理 |
| 段标题左侧白色空白 | 蓝色背景只覆盖内容区，没覆盖泳道标签行（LANE_HDR_H） | 背景 y 从 label_y 开始，高度为 content_h + LANE_HDR_H |
| MB 内 C 节点空否分支幽灵箭头 | `draw_merge=False` 不画菱形底部到 merge_y 的线段，下一个 P 节点从 merge_y 画箭头但该处无可见元素 | 引擎已修复：MB 列 C 节点处理中，`not bnode.no_nodes` 时补画 `svg_polyline_plain()` 从菱形底部到 merge_y |

## 两遍构建模式规则（必须严格遵守）

多段泳道图需要两遍构建：第一遍 Y0=0 算各段高度，第二遍设正确 Y0 重新画。这个模式有两条铁律：

1. **build 函数只读 Y0，绝不写 Y0**：Y0 由 main 函数在调用 build 前设置，build 内部不能调用 `set_y0()` 或 `global Y0` 赋值。违反会导致第二遍的正确 Y0 被覆盖，节点画到错误位置。
2. **第二遍必须重新收集所有返回值**：第一遍返回的 note_boxes、高度等数据的坐标都基于 Y0=0，不能直接用于最终输出。第二遍 `lines_svg.clear(); nodes_svg.clear(); note_boxes = []`，然后重新调用每个 build 函数收集。

## 错误提示框泳道边界约束（必须严格遵守）

判断节点右侧的错误提示矩形，必须完全在所属泳道内，不能跨越泳道分隔线。

### 计算公式

```python
# 泳道右边界 = SEC_LABEL_W + LANE_W * (lane_index + 1)
# Lane A 右边界 = 40 + 320 = 360
# Lane M 右边界 = 40 + 640 = 680

# 错误框必须满足：center_x + w/2 <= 泳道右边界
# 推荐固定 pattern（以 Lane A 为例，A=200）：
rc(A+120, y, "错误文本", w=80, h=26)
# 验证：左边缘 = A+120-40 = A+80，右边缘 = A+120+40 = A+160 = 360 ✓

# 对应虚线箭头（菱形默认 w=130，half=65）：
ard(A+65, y, A+80, y)  # 起点=菱形右顶点，终点=错误框左边缘，长度15px ✓

# 对应标签：
lb(A+72, y-7, "否", "#DC2626")

# Lane M 同理：
rc(M+120, y, "错误文本", w=80, h=26)
ard(M+65, y, M+80, y)
lb(M+72, y-7, "否", "#DC2626")
```

### 宽菱形的处理

菱形宽度非默认值时，ard 起点 x = 实际 half-width，可能 >= lane+80（默认错误框左边缘），导致箭头反向或太短。必须把错误框右移+缩小宽度。

**核心原则**：`ard_end_x = error_rect_center - error_rect_w/2`，且 `ard_end_x > ard_start_x + 10`。

```python
# 菱形 w=170 → half=85，ard 起点 = A+85
dm(A, y, "Apple Hide My Email?", w=170)
rc(A+130, y, "relay不写凭证表", w=60, h=26)  # 右边缘=200+130+30=360 ✓
ard(A+85, y, A+100, y)  # 长度=15px ✓
lb(A+92, y-7, "是", "#DC2626")

# 菱形 w=150 → half=75，ard 起点 = A+75
dm(A, y, "Facebook无邮箱?", w=150)
rc(A+120, y, "标记待补邮箱", w=60, h=26)  # 右边缘=200+120+30=350 ✓
ard(A+75, y, A+90, y)  # 长度=15px ✓
lb(A+82, y-7, "是", "#DC2626")

# 菱形 w=155 → half=78（M泳道）
dm(M, y, "验证码正确+未过期?", w=155)
rc(M+130, y, "返回错误/已过期", w=60, h=26)  # 右边缘=520+130+30=680 ✓
ard(M+78, y, M+100, y)  # 长度=22px ✓
lb(M+88, y-7, "否", "#DC2626")
```

**计算步骤**：
1. 算菱形 half-width：`diamond_half = diamond_w // 2`
2. 算错误框 center：`err_center = lane + max(120, diamond_half + 45)`（保证箭头 >= 15px）
3. 算错误框 w：`err_w = min(80, (lane_right - err_center) * 2)`（保证不跨泳道）
4. 算 ard 终点：`ard_end = err_center - err_w // 2`
5. 验证：`ard_end - diamond_half >= 10` 且 `err_center + err_w//2 <= lane_right`

### 自检清单

每次写错误提示框时，必须验证：
1. `error_rect_center + error_rect_w/2 <= 泳道右边界` — 不跨泳道
2. `ard_start_x < ard_end_x` — 箭头方向正确（向右）
3. `ard_end_x == error_rect_center - error_rect_w/2` — 箭头对齐框左边缘
4. `ard_end_x - ard_start_x >= 15` — 箭头可见长度足够

## 大批量修改策略（必须严格遵守）

当需要修改泳道图脚本中超过 5 处同类 pattern 时（如统一调整错误框位置、统一修改间距），禁止逐行 Edit，必须用以下流程：

### 流程

1. **识别 pattern** — 列出所有需要修改的代码模式（如 `rc(A+155, y, ..., w=110)` → `rc(A+120, y, ..., w=80)`）
2. **写批量修复脚本** — 用 Python 逐行扫描 + `re.match()` 匹配，对原始行做替换。**必须对原始行（含缩进）做正则匹配，不能 strip 后匹配再拼接，否则会丢失缩进**
3. **跑脚本** — 执行修复脚本，检查输出的修改行数是否符合预期
4. **合并 + 生成** — `cat part1-5 > gen.py && python3 gen.py`
5. **自动化验证** — 写验证脚本检查生成的 SVG（错误框边界、箭头方向、箭头长度）
6. **手动修复遗漏** — 批量脚本无法覆盖的特殊 case（如宽菱形），逐个手动 Edit

### 注意事项

- 批量脚本只处理"标准 pattern"，宽菱形等特殊 case 需要验证脚本发现后手动修
- 验证脚本参考：`/tmp/fix_swimlane_bugs.py`（批量修复）+ 内联验证脚本（检查 SVG 输出）
- 修复脚本的正则必须匹配原始行（含前导空格），不能用 `line.strip()` 后匹配，否则替换结果丢失缩进导致 IndentationError
5. **写进度文件** — 在 /tmp 写 checklist，记录哪些文件已改、哪些待改

### 为什么

- 逐行 Edit 在大文件中容易遗漏、容易改错坐标
- 上下文压缩后会丢失"改到哪了"的进度
- 脚本可重复执行，改错了可以回滚重来

### 反模式（禁止）

- 读完 5 个文件后"准备开始改"但实际没改 — 2 轮无写操作必须切换策略
- 逐行 Edit 改了一半被压缩，恢复后从头再来
- 改完不跑生成脚本就认为完成

## 参考脚本

- 可复用引擎模块：`~/Templates/swimlane/engine.py`
- 新项目最小模板：`~/Templates/swimlane/template.py`
- 引擎版项目示例（Looply 三泳道9段，含MB节点）：`~/Templates/swimlane/gen_looply_v5_engine.py`
- 引擎版项目示例（Looply 三泳道12段，旧版）：`~/Templates/swimlane/gen_looply_v4_engine.py`
- 独立版生成器（三泳道12段版）：`~/Templates/swimlane/gen_flowchart_v4.py`
- 手写坐标生成器（旧版）：`~/Templates/swimlane/gen_flowchart_v3.py`

## 已知待改进

- **关联注释节点**：当前 N 节点只能放段末尾，无法贴近目标节点。需要时用 patch 手写定位（参考 V5 风控注释框）。未来可考虑新增关联注释节点类型，声明时指定关联目标，引擎自动定位到旁边

## Skill 转换追踪

- 最后修改日期：2026-03-30（新增走查第5条"幽灵箭头检查"强制检查项）
- 连续未修改使用次数：0
- 转换提醒阈值：4 次
