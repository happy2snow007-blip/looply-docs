#!/usr/bin/env python3
"""
Looply 登录注册模块系统流程图 V7.0 - 9段版
使用 engine.py 引擎

变更：V6→V7
- MB 分支内 C 节点 yes 分支汇合线指向后续节点右侧中点（Apple/Facebook 的 email写入凭证表）
- SVG 内嵌 YAML metadata，供研发编码参考
"""

import os
import sys
sys.path.insert(0, os.path.dirname(__file__))

from engine import *

# ========== 泳道配置 ==========
LANE_CONFIG = [
    {"key": "A", "name": "登录注册系统", "color": "#4A6CF7", "bg": "rgba(74,108,247,0.04)"},
    {"key": "M", "name": "消息通知",     "color": "#F59E0B", "bg": "rgba(245,158,11,0.04)"},
    {"key": "E", "name": "外部服务",     "color": "#EF4444", "bg": "rgba(239,68,68,0.04)"},
]

SECTIONS = [
    ("① 邮箱注册", [
        S("开始注册"),
        P("A", "接收注册请求(邮箱+密码)"),
        D("A", "邮箱格式正确?", no="返回邮箱格式错误"),
        D("A", "密码规则通过?", no="返回密码规则提示"),
        D("A", "已勾选协议?", no="返回未勾选"),
        P("A", "采集设备指纹+IP"),
        D("A", "注册限频?", no="返回请求过多", yes_label="否", no_label="是"),
        D("A", "邮箱未注册?", no="返回已注册"),
        D("A", "风控检测通过?", no="拦截/要求验证"),
        P("A", "请求发送验证码"),
        X("A", "M", "生成验证码并存储"),
        X("M", "E", "邮件服务商投递"),
        X("E", "A", "用户输入验证码"),
        X("A", "M", "校验验证码"),
        D("M", "验证码有效?", no="返回错误/已过期", no_w=92),
        X("M", "A", "创建账号"),
        P("A", "签发Token"),
        P("A", "记录设备指纹+关联Session", w=200),
        S("注册完成"),
    ]),
    ("② 邮箱登录", [
        S("开始登录"),
        P("A", "接收登录请求(邮箱+密码)"),
        D("A", "邮箱格式正确?", no="返回邮箱格式错误"),
        P("A", "采集设备指纹+IP"),
        D("A", "风控检测通过?(规则同①)", no="拦截/要求验证", w=160),
        D("A", "邮箱存在?", no="返回邮箱或密码错误"),
        D("A", "密码错误>=5次?", no="锁定账号30分钟", yes_label="否", no_label="是"),
        D("A", "密码正确?", no="返回邮箱或密码错误"),
        P("A", "签发Token设Cookie"),
        P("A", "记录设备指纹+关联Session", w=200),
        S("登录完成"),
        N("Identifier-First 统一入口(预留)", [
            "当前：①② 分离式注册/登录入口",
            "预留：Identifier-First 统一入口模式",
            "迁移：前置 /api/auth/identify 端点",
            "返回 {action: register|login, methods: [...]}",
            "①② 后端流程段零改动，仅新增路由层",
        ]),
    ]),
    ("③ OAuth认证", [
        S("开始"),
        P("A", "接收三方登录/注册请求", w=180),
        P("A", "采集设备指纹+IP"),
        D("A", "风控检测通过?(规则同①)", no="拦截/要求验证", w=160),
        X("A", "E", "跳转OAuth授权页"),
        P("E", "用户授权,返回授权码"),
        X("E", "A", "用code换取token"),
        P("A", "获取用户信息(uid/email/name)", w=200),
        D("A", "provider_uid已绑定?", no="直接签发Token完成", yes_label="否", no_label="是", w=160, no_w=110),
        C("A", "邮箱已注册?",
          yes_nodes=[P("A", "关联已有账号")],
          no_nodes=[P("A", "创建新账号")],
          yes_label="是", no_label="否"),
        P("A", "写入OAuth绑定记录"),
        MB("A", "Provider类型?", branches=[
            {"label": "Google", "nodes": [
                P("A", "email写入凭证表"),
                P("A", "预填昵称"),
            ]},
            {"label": "Apple", "nodes": [
                C("A", "给了真实邮箱?",
                  yes_nodes=[P("A", "email写入凭证表")],
                  no_nodes=[],
                  yes_label="是", no_label="否", w=140),
                P("A", "预填昵称(仅首次)", w=160),
            ]},
            {"label": "Facebook", "nodes": [
                C("A", "有邮箱?",
                  yes_nodes=[P("A", "email写入凭证表")],
                  no_nodes=[P("A", "标记待补邮箱")],
                  yes_label="是", no_label="否", w=130),
                P("A", "预填昵称"),
            ]},
        ], w=130),
        P("A", "签发Token"),
        P("A", "记录设备指纹+关联Session", w=200),
        S("认证完成"),
        N("已绑定用户(老用户)路径", [
            "provider_uid已绑定 = 老用户重复OAuth登录",
            "直接: 签发Token → 记录设备指纹+关联Session → 完成",
            "跳过下方所有注册/绑定/Provider特殊处理步骤",
        ]),
    ]),
    ("④ 忘记密码", [
        S("开始"),
        P("A", "接收重置密码请求(邮箱)"),
        D("A", "邮箱格式正确?", no="返回邮箱格式错误"),
        D("A", "邮箱存在?", no="返回已发送(防枚举)", no_w=100),
        P("A", "请求发送验证码"),
        D("M", "发信限频?", no="返回请求过多", yes_label="否", no_label="是"),
        P("M", "生成验证码并存储"),
        X("M", "E", "邮件服务商投递"),
        X("E", "A", "用户输入验证码"),
        X("A", "M", "校验验证码"),
        D("M", "验证码有效?", no="返回错误/已过期", no_w=92),
        X("M", "A", "用户输入新密码(两次)"),
        D("A", "密码规则校验?", no="返回密码规则提示"),
        D("A", "与旧密码相同?", no="返回不能相同", yes_label="否", no_label="是"),
        P("A", "更新密码哈希"),
        P("A", "失效旧Token"),
        P("A", "写入审计日志(重置密码)", w=180),
        S("流程结束"),
    ]),
    ("⑤ 密码修改", [
        S("开始"),
        P("A", "接收修改密码请求"),
        D("A", "旧密码正确?", no="返回密码错误", no_w=80),
        D("A", "新旧密码相同?", no="返回不能相同", yes_label="否", no_label="是", no_w=80),
        D("A", "密码规则校验?", no="返回密码规则提示", no_w=80),
        P("A", "更新密码哈希"),
        P("A", "吊销所有其他Session", w=180),
        P("A", "写入审计日志(改密码)", w=180),
        S("流程结束"),
    ]),
    ("⑥ 退出登录", [
        S("开始"),
        P("A", "接收退出请求"),
        P("A", "清除Session/Token"),
        S("退出完成"),
        N("会话失效（被动退出）", [
            "1. 接口返回 401",
            "2. 检测到 Token 失效",
            "3. 清除本地 Token / Cookie",
            "4. 跳转首页 + 提示 Session expired",
            "触发：Token过期 / 密码修改 / 管理员强制下线",
        ]),
    ]),
    ("⑦ 账号注销", [
        S("开始"),
        P("A", "接收注销请求"),
        D("A", "身份验证通过?", no="返回验证失败", no_w=80),
        P("A", "标记status=注销"),
        P("A", "记录deactivated_at"),
        P("A", "吊销所有Session"),
        P("A", "写入审计日志(注销)", w=170),
        S("注销完成"),
        N("注销冷静期说明", [
            "1. 注销后 30 天内可联系客服恢复",
            "2. 超过 30 天数据永久删除",
            "3. 冷静期内账号不可登录",
            "身份验证：有密码→验密码，仅OAuth→重新授权",
        ]),
    ]),
    ("⑧ Token刷新", [
        S("触发"),
        P("A", "检测access_token过期", w=180),
        P("A", "携带refresh_token请求刷新", w=200),
        D("A", "refresh_token有效?", no="返回401", w=150, no_w=80),
        D("A", "Session状态活跃?", no="返回401(已吊销)", no_w=80),
        P("A", "签发新access_token", w=170),
        P("A", "滑动续期refresh_token", w=190),
        S("刷新完成"),
    ]),
    ("⑨ 协议版本检测", [
        S("触发"),
        P("A", "用户访问任意页面"),
        D("A", "协议版本有更新?", no="正常访问", no_w=80),
        P("A", "弹出协议更新弹窗"),
        D("A", "用户同意?", no="强制退出登录", no_w=80),
        P("A", "提交同意请求"),
        P("A", "写入ConsentRecord"),
        P("A", "记录协议版本+国家", w=170),
        S("完成"),
    ]),
]

ctx = init_lanes(LANE_CONFIG, sections=SECTIONS)

# ========== 风控注释框 patch ==========
def patch_risk_note(items, lines_svg, y0):
    """在 ① 的'风控检测通过?'判断节点右侧（M泳道区域）放置注释框"""
    for entry in items:
        if entry[0] == 'D' and entry[1].text == "风控检测通过?":
            cx, cy = entry[2], entry[3]
            # 注释框放在 M 泳道区域，与判断节点同一 y 位置
            note_x = cx + 180  # A 泳道中心右移到 M 泳道区域
            note_y = cy - 50
            lines = [
                "1. 设备指纹是否已知(未知→创建记录)",
                "2. 是否信任设备(不信任→额外验证)",
                "3. IP地理位置异常?(异常→异地风险)",
                "4. 暴力破解检测(触发→拦截/封禁)",
                "5. 综合风险: 低→放行 中→验证码 高→拦截",
            ]
            note_w = 260
            note_h = 40 + len(lines) * 16 + 10
            extra_nodes = [svg_note_box(note_x, note_y, note_w, note_h, "风控检测规则", lines)]
            return extra_nodes, []
    return [], []

patches = {
    "① 邮箱注册": patch_risk_note,
}

result = build_svg(ctx, SECTIONS,
                   title="Looply &#183; 登录注册模块系统流程图",
                   version="V7.0 &#183; 2026.03",
                   patches=patches)

# ========== YAML metadata 嵌入 ==========
def sections_to_yaml(sections):
    """将 SECTIONS DSL 转为 YAML 字符串，供研发编码参考"""
    lines = []
    lines.append("# Looply 登录注册模块系统流程图 V7.0")
    lines.append("# 研发编码参考数据，从 SVG <metadata> 提取")
    lines.append("")
    lines.append("swimlanes:")
    for lc in LANE_CONFIG:
        lines.append(f'  - key: "{lc["key"]}"')
        lines.append(f'    name: "{lc["name"]}"')
    lines.append("")
    lines.append("sections:")

    for sec_name, nodes in sections:
        lines.append(f'  - name: "{sec_name}"')
        lines.append(f'    steps:')
        for node in nodes:
            if isinstance(node, S):
                lines.append(f'      - type: start_end')
                lines.append(f'        text: "{node.text}"')
            elif isinstance(node, P):
                lines.append(f'      - type: process')
                lines.append(f'        lane: "{node.lane}"')
                lines.append(f'        text: "{node.text}"')
            elif isinstance(node, D):
                lines.append(f'      - type: decision')
                lines.append(f'        lane: "{node.lane}"')
                lines.append(f'        text: "{node.text}"')
                if node.no:
                    lines.append(f'        on_no: "{node.no}"')
                lines.append(f'        yes_label: "{node.yes_label}"')
                lines.append(f'        no_label: "{node.no_label}"')
            elif isinstance(node, X):
                lines.append(f'      - type: cross_lane')
                lines.append(f'        from: "{node.from_lane}"')
                lines.append(f'        to: "{node.to_lane}"')
                lines.append(f'        text: "{node.text}"')
            elif isinstance(node, C):
                lines.append(f'      - type: condition_branch')
                lines.append(f'        lane: "{node.lane}"')
                lines.append(f'        text: "{node.text}"')
                lines.append(f'        yes_label: "{node.yes_label}"')
                lines.append(f'        no_label: "{node.no_label}"')
                if node.yes_nodes:
                    lines.append(f'        yes_branch:')
                    for yn in node.yes_nodes:
                        lines.append(f'          - text: "{yn.text}"')
                if node.no_nodes:
                    lines.append(f'        no_branch:')
                    for nn in node.no_nodes:
                        lines.append(f'          - text: "{nn.text}"')
            elif isinstance(node, MB):
                lines.append(f'      - type: multi_branch')
                lines.append(f'        lane: "{node.lane}"')
                lines.append(f'        text: "{node.text}"')
                lines.append(f'        branches:')
                for br in node.branches:
                    lines.append(f'          - label: "{br["label"]}"')
                    lines.append(f'            nodes:')
                    for bn in br["nodes"]:
                        if isinstance(bn, P):
                            lines.append(f'              - type: process')
                            lines.append(f'                text: "{bn.text}"')
                        elif isinstance(bn, C):
                            lines.append(f'              - type: condition_branch')
                            lines.append(f'                text: "{bn.text}"')
                            lines.append(f'                yes_label: "{bn.yes_label}"')
                            lines.append(f'                no_label: "{bn.no_label}"')
                            if bn.yes_nodes:
                                lines.append(f'                yes_branch:')
                                for yn in bn.yes_nodes:
                                    lines.append(f'                  - text: "{yn.text}"')
                            if bn.no_nodes:
                                lines.append(f'                no_branch:')
                                for nn in bn.no_nodes:
                                    lines.append(f'                  - text: "{nn.text}"')
                        elif isinstance(bn, D):
                            lines.append(f'              - type: decision')
                            lines.append(f'                text: "{bn.text}"')
                            if bn.no:
                                lines.append(f'                on_no: "{bn.no}"')
            elif isinstance(node, N):
                lines.append(f'      - type: note')
                lines.append(f'        title: "{node.title}"')
                lines.append(f'        lines:')
                for l in node.lines:
                    lines.append(f'          - "{l}"')
    return "\n".join(lines)

yaml_str = sections_to_yaml(SECTIONS)

# 将 YAML 嵌入 SVG 的 <metadata> 块
svg_content, total_w, total_h, sec_heights = result
# 在 <defs> 之前插入 <metadata>
metadata_block = f'<metadata>\n<![CDATA[\n{yaml_str}\n]]>\n</metadata>'
svg_content = svg_content.replace('\n<defs>', f'\n{metadata_block}\n<defs>', 1)
result = (svg_content, total_w, total_h, sec_heights)

out_dir = os.path.expanduser("~/Desktop/海外业务登录注册/系统流程图")
write_svg(result, os.path.join(out_dir, "looply-登录注册系统流程图-v7.svg"))
