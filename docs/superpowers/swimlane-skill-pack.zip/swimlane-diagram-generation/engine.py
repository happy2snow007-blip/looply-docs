#!/usr/bin/env python3
"""
泳道图 SVG 生成引擎 - 可复用模块
新项目 import 后只需定义 LANE_CONFIG + SECTIONS + patches，调用 build_svg() 即可。

用法：
    from engine import *
    LANE_CONFIG = [...]
    ctx = init_lanes(LANE_CONFIG)
    SECTIONS = [...]
    svg = build_svg(ctx, SECTIONS, title="标题", version="V1.0")
    write_svg(svg, "output.svg")
"""

import re

# ========== 节点类型 DSL ==========

class S:
    """开始/结束节点"""
    def __init__(self, text, color=None):
        self.text = text
        self.color = color

class P:
    """操作步骤"""
    def __init__(self, lane, text, w=160):
        self.lane = lane
        self.text = text
        self.w = w

class D:
    """判断节点"""
    def __init__(self, lane, text, no=None, yes_label="是", no_label="否", w=130, no_w=100, no_h=26):
        self.lane = lane
        self.text = text
        self.no = no
        self.yes_label = yes_label
        self.no_label = no_label
        self.w = w
        self.no_w = no_w
        self.no_h = no_h

class X:
    """跨泳道步骤"""
    def __init__(self, from_lane, to_lane, text, w=160):
        self.from_lane = from_lane
        self.to_lane = to_lane
        self.text = text
        self.w = w

class N:
    """注释框"""
    def __init__(self, title, lines, w=360, line_h=16):
        self.title = title
        self.lines = lines
        self.w = w
        self.line_h = line_h

    @property
    def h(self):
        return 40 + len(self.lines) * self.line_h + 20


class C:
    """条件分支节点：两条路径最终汇合到下一个节点

    布局：菱形判断 → 否分支走主线（中间），是分支画在右侧 → 汇合到下一个节点
    yes_nodes/no_nodes 中的元素只支持 P 类型（操作步骤）
    空列表表示该分支无额外步骤，直接汇合
    """
    def __init__(self, lane, text, yes_nodes=None, no_nodes=None,
                 yes_label="是", no_label="否", w=130):
        self.lane = lane
        self.text = text
        self.yes_nodes = yes_nodes or []
        self.no_nodes = no_nodes or []
        self.yes_label = yes_label
        self.no_label = no_label
        self.w = w


class MB:
    """多分支节点：N 条路径（3/4/5...），每条包含完整节点序列，最终汇合

    布局：菱形判断 → N 条分支从左到右排列 → 所有分支汇合到下一个节点
    branches 中每条分支的 nodes 支持 P、D、C、X 等类型（不支持 S、N、MB 嵌套）

    用法：
        MB("A", "Provider类型?", branches=[
            {"label": "Google",   "nodes": [P("A", "步骤1"), P("A", "步骤2")]},
            {"label": "Apple",    "nodes": [P("A", "步骤A"), D("A", "判断?", no="错误")]},
            {"label": "Facebook", "nodes": [P("A", "步骤X")]},
        ], w=130)

    每条 branch dict 包含：
        label: str  分支标签（显示在连线上）
        nodes: list 该分支的节点序列
        col_w: int  可选，该列宽度（默认自动计算）
    """
    def __init__(self, lane, text, branches=None, w=130, col_gap=40):
        self.lane = lane
        self.text = text
        self.branches = branches or []
        self.w = w
        self.col_gap = col_gap  # 列之间的间距


# ========== 布局常量 ==========

SEC_LABEL_W = 40
HEADER_H = 46
LANE_HDR_H = 24

GAP_STEP = 48
GAP_DECISION = 60
GAP_AFTER_DEC = 58
GAP_CROSS = 52
GAP_START = 30
GAP_NOTE = 30

# 错误框文案宽度估算：中文字符约 9.5px，英文/数字约 5.5px，加左右 padding 16px
def _estimate_text_w(text, font_size=9.5, padding=16):
    w = 0
    for ch in text:
        if '\u4e00' <= ch <= '\u9fff' or '\u3000' <= ch <= '\u303f' or '\uff00' <= ch <= '\uffef':
            w += font_size
        else:
            w += font_size * 0.58
    return int(w + padding)


# ========== 泳道上下文 ==========

def _calc_min_lane_widths(sections, lane_config, default_w):
    """扫描所有 C 和 MB 节点，计算每条泳道需要的最小宽度。

    cx 在泳道中心，左右两边独立计算：
    C 节点：右侧(从cx)= right_cx偏移 + yes节点半宽 + 边距
    MB 节点：所有列总宽度 / 2（居中排列，从 cx 向两侧扩展）
    泳道宽度 = 2 * max(左侧, 右侧)
    """
    key_to_idx = {cfg["key"]: i for i, cfg in enumerate(lane_config)}
    min_widths = [0] * len(lane_config)

    section_list = sections if isinstance(sections, list) else [("", sections)]
    for _, nodes in section_list:
        for node in nodes:
            if isinstance(node, C):
                idx = key_to_idx.get(node.lane)
                if idx is None:
                    continue

                # yes 分支节点宽度
                if node.yes_nodes:
                    yes_max_w = max(getattr(n, 'w', 160) for n in node.yes_nodes)
                else:
                    yes_max_w = 0

                # no 分支节点半宽
                if node.no_nodes:
                    no_max_hw = max(getattr(n, 'w', 160) for n in node.no_nodes) // 2
                else:
                    no_max_hw = 0

                # 右侧需求（从 cx 算起）：与 layout_section 中 right_cx 公式一致
                if yes_max_w > 0:
                    yes_max_hw = yes_max_w // 2
                    right_cx_offset = max(no_max_hw + 20 + yes_max_hw, 120)
                    right_from_cx = right_cx_offset + yes_max_hw + 8
                else:
                    right_from_cx = 0

                # 左侧需求（从 cx 算起）：至少容纳默认宽度节点的一半
                left_from_cx = max(no_max_hw + 8, default_w // 2)

                needed = 2 * max(left_from_cx, right_from_cx)
                if needed > min_widths[idx]:
                    min_widths[idx] = needed

            elif isinstance(node, MB):
                idx = key_to_idx.get(node.lane)
                if idx is None:
                    continue

                # 计算每列宽度，然后算总宽度
                col_widths = _mb_col_widths(node)
                total_cols_w = sum(col_widths) + node.col_gap * (len(col_widths) - 1)
                # 居中排列，从 cx 向两侧各需 total_cols_w/2 + 边距
                half_needed = total_cols_w // 2 + 16
                needed = 2 * half_needed
                if needed > min_widths[idx]:
                    min_widths[idx] = needed

    return min_widths


def _mb_col_widths(node):
    """计算 MB 节点每列的宽度：取该列所有节点最大宽度，最小 160。
    C 节点的是分支在右侧，列宽 = 否分支宽 + 间距 + 是分支宽。
    D 节点带错误框时，列宽需容纳菱形半宽 + 箭头间距 + 错误框宽度。
    """
    col_widths = []
    for branch in node.branches:
        branch_nodes = branch.get("nodes", [])
        col_w = branch.get("col_w", 0)
        if col_w > 0:
            col_widths.append(col_w)
        elif branch_nodes:
            max_w = 160
            for n in branch_nodes:
                nw = getattr(n, 'w', 160)
                if nw > max_w:
                    max_w = nw
                # D 节点带错误框：列居中排列，需对称扩宽
                # 右侧从cx = 菱形半宽 + 箭头12px + 错误框宽
                if isinstance(n, D) and n.no:
                    no_w_actual = max(n.no_w, _estimate_text_w(n.no))
                    right_from_cx = n.w // 2 + 12 + no_w_actual
                    left_from_cx = max(nw // 2, 80)
                    d_needed = 2 * max(left_from_cx, right_from_cx)
                    if d_needed > max_w:
                        max_w = d_needed
                # C 节点：列宽 = 否分支最大宽度 + 间距 + 是分支最大宽度
                if isinstance(n, C):
                    no_w = max((getattr(p, 'w', 160) for p in n.no_nodes), default=160) if n.no_nodes else 160
                    yes_w = max((getattr(p, 'w', 160) for p in n.yes_nodes), default=0) if n.yes_nodes else 0
                    if yes_w > 0:
                        c_needed = no_w + 40 + yes_w
                    else:
                        c_needed = no_w
                    if c_needed > max_w:
                        max_w = c_needed
            col_widths.append(max_w)
        else:
            col_widths.append(160)
    return col_widths if col_widths else [160]


def init_lanes(lane_config, lane_w=320, gaps=None, sections=None):
    """根据 LANE_CONFIG 初始化泳道上下文，返回 ctx dict

    每条泳道可在 LANE_CONFIG 中用 "w" 字段指定独立宽度，未指定则用 lane_w 默认值。
    gaps 可覆盖默认间距，如 {"step": 40, "decision": 50} 缩小间距以减少总高度。
    sections 可选，传入后自动扫描 C 节点计算最小泳道宽度，不够时自动扩宽。
    """
    lanes = len(lane_config)
    lane_widths = [cfg.get("w", lane_w) for cfg in lane_config]

    # 如果传入了 sections，自动扫描 C 节点扩宽泳道
    if sections is not None:
        min_widths = _calc_min_lane_widths(sections, lane_config, lane_w)
        for i in range(lanes):
            if min_widths[i] > lane_widths[i]:
                lane_widths[i] = min_widths[i]
    lane_lefts = []
    x = SEC_LABEL_W
    for w in lane_widths:
        lane_lefts.append(x)
        x += w
    total_w = x
    lane_map = {}
    for i, cfg in enumerate(lane_config):
        lane_map[cfg["key"]] = lane_lefts[i] + lane_widths[i] // 2

    g = {"step": GAP_STEP, "decision": GAP_DECISION, "after_dec": GAP_AFTER_DEC,
         "cross": GAP_CROSS, "start": GAP_START, "note": GAP_NOTE}
    if gaps:
        g.update(gaps)

    return {
        "lane_config": lane_config,
        "lane_w": lane_w,
        "lane_widths": lane_widths,
        "lane_lefts": lane_lefts,
        "lanes": lanes,
        "total_w": total_w,
        "lane_map": lane_map,
        "lane_colors": [c["color"] for c in lane_config],
        "lane_names": [c["name"] for c in lane_config],
        "lane_bg": [c["bg"] for c in lane_config],
        "default_lane": lane_config[0]["key"],
        "gaps": g,
    }


# ========== SVG 绘图原语 ==========

def svg_rr(cx, cy, t, sk="#4A6CF7", w=90, h=26):
    return (f'<rect x="{cx-w//2}" y="{cy-h//2}" width="{w}" height="{h}" rx="15" '
            f'fill="#fff" stroke="{sk}" stroke-width="1.5"/>'
            f'<text x="{cx}" y="{cy+4}" text-anchor="middle" fill="{sk}" '
            f'font-size="10" font-weight="600">{t}</text>')

def svg_rc(cx, cy, t, w=160, h=32):
    return (f'<rect x="{cx-w//2}" y="{cy-h//2}" width="{w}" height="{h}" rx="4" '
            f'fill="#fff" stroke="#475569" stroke-width="1.4"/>'
            f'<text x="{cx}" y="{cy+4}" text-anchor="middle" fill="#1E293B" '
            f'font-size="9.5">{t}</text>')

def svg_dm(cx, cy, t, w=130, h=50):
    hw, hh = w//2, h//2
    pts = f"{cx},{cy-hh} {cx+hw},{cy} {cx},{cy+hh} {cx-hw},{cy}"
    return (f'<polygon points="{pts}" fill="#FEF3C7" stroke="#D97706" stroke-width="1.4"/>'
            f'<text x="{cx}" y="{cy+4}" text-anchor="middle" fill="#92400E" '
            f'font-size="8.5" font-weight="600">{t}</text>')

def svg_arrow(x1, y1, x2, y2):
    return (f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" '
            f'stroke="#475569" stroke-width="1.2" marker-end="url(#arr)"/>')

def svg_arrow_err(x1, y1, x2, y2):
    return (f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" '
            f'stroke="#DC2626" stroke-width="1.1" stroke-dasharray="5,3" marker-end="url(#arr-r)"/>')

def svg_polyline(pts):
    p = " ".join(f"{x},{y}" for x, y in pts)
    return (f'<polyline points="{p}" fill="none" '
            f'stroke="#475569" stroke-width="1.2" marker-end="url(#arr)"/>')

def svg_polyline_plain(pts):
    p = " ".join(f"{x},{y}" for x, y in pts)
    return (f'<polyline points="{p}" fill="none" '
            f'stroke="#475569" stroke-width="1.2"/>')

def svg_polyline_err(pts):
    p = " ".join(f"{x},{y}" for x, y in pts)
    return (f'<polyline points="{p}" fill="none" '
            f'stroke="#DC2626" stroke-width="1.1" stroke-dasharray="5,3" marker-end="url(#arr-r)"/>')

def svg_label(x, y, t, c="#64748B"):
    return (f'<text x="{x}" y="{y}" text-anchor="middle" fill="{c}" '
            f'font-size="8">{t}</text>')

def svg_note_box(x, y, w, h, title, lines):
    svg = (f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="8" '
           f'fill="#FEF2F2" stroke="#FECACA" stroke-width="1" opacity="0.7"/>')
    svg += (f'<text x="{x+w//2}" y="{y+22}" text-anchor="middle" fill="#991B1B" '
            f'font-size="11" font-weight="600">{title}</text>')
    for i, line in enumerate(lines):
        svg += (f'<text x="{x+w//2}" y="{y+40+i*16}" text-anchor="middle" '
                f'fill="#7F1D1D" font-size="9">{line}</text>')
    return svg


# ========== 布局公共函数 ==========

def _t_off(prev_type):
    """统一计算从上一个节点底部到连线起点的偏移量"""
    if prev_type in ('C_merge', 'MB_merge'):
        return 0
    if prev_type == 'D':
        return 25
    return 16


def _layout_c_branch(bnode, bnode_cx, diamond_cy, g, lane_map=None, draw_merge=True):
    """C 节点的完整分支布局（菱形已由调用方画好）

    draw_merge=True: 画是分支汇合折线和否分支空线段（MB 内使用）
    draw_merge=False: 不画，由调用方通过 c_yes_pending 延迟处理（主流程使用）

    返回 dict:
        items: [(kind, node, cx, cy, ...), ...]
        lines: [svg_string, ...]
        merge_y: 汇合点 y 坐标
        no_last_cx, no_last_cy: 否分支末端坐标
        yes_last_cx, yes_last_cy: 是分支末端坐标
        no_branch_h, yes_branch_h: 两条分支的高度
        right_cx: 是分支的 x 中心
    """
    items = []
    lines = []

    # 动态计算右侧偏移
    no_max_hw = max((getattr(n, 'w', 160) for n in bnode.no_nodes), default=0) // 2 if bnode.no_nodes else 0
    yes_max_hw = max((getattr(n, 'w', 160) for n in bnode.yes_nodes), default=0) // 2 if bnode.yes_nodes else 0
    right_cx = bnode_cx + max(no_max_hw + 20 + yes_max_hw, 120)

    # === 否分支（主线，菱形下方） ===
    no_branch_h = 0
    no_last_cx, no_last_cy = bnode_cx, diamond_cy
    for ni, np_node in enumerate(bnode.no_nodes):
        step_gap = g["after_dec"] if ni == 0 else g["step"]
        no_branch_h += step_gap
        np_cy = diamond_cy + no_branch_h
        np_cx = lane_map.get(getattr(np_node, 'lane', None), bnode_cx) if lane_map else bnode_cx
        items.append(('P', np_node, np_cx, np_cy))
        if ni == 0:
            lines.append(svg_arrow(bnode_cx, diamond_cy + 25, np_cx, np_cy - 16))
            lines.append(svg_label(bnode_cx + 12, diamond_cy + 38, bnode.no_label))
        else:
            lines.append(svg_arrow(no_last_cx, no_last_cy + 16, np_cx, np_cy - 16))
        no_last_cx, no_last_cy = np_cx, np_cy

    # === 是分支（右侧） ===
    yes_branch_h = 0
    yes_last_cx, yes_last_cy = right_cx, diamond_cy
    for yi, yp_node in enumerate(bnode.yes_nodes):
        step_gap = g["after_dec"] if yi == 0 else g["step"]
        yes_branch_h += step_gap
        yp_cy = diamond_cy + yes_branch_h
        yp_cx = right_cx
        items.append(('P', yp_node, yp_cx, yp_cy))
        if yi == 0:
            lines.append(svg_polyline([
                (bnode_cx + bnode.w // 2, diamond_cy),
                (yp_cx, diamond_cy),
                (yp_cx, yp_cy - 16)
            ]))
            lines.append(svg_label(bnode_cx + bnode.w // 2 + 7, diamond_cy - 7, bnode.yes_label))
        else:
            lines.append(svg_arrow(yes_last_cx, yes_last_cy + 16, yp_cx, yp_cy - 16))
        yes_last_cx, yes_last_cy = yp_cx, yp_cy

    # === 汇合点 ===
    max_branch_h = max(no_branch_h, yes_branch_h)
    if max_branch_h > 0:
        merge_y = diamond_cy + max_branch_h + 16
    else:
        merge_y = diamond_cy + g["after_dec"]

    # 否分支汇合线
    if bnode.no_nodes:
        if no_last_cy + 16 < merge_y - 2:
            lines.append(svg_arrow(no_last_cx, no_last_cy + 16, bnode_cx, merge_y))
    else:
        if draw_merge:
            lines.append(svg_label(bnode_cx + 12, diamond_cy + 38, bnode.no_label))
            # 否分支为空，画从菱形底部到汇合点的普通线段
            if merge_y > diamond_cy + 27:
                lines.append(svg_polyline_plain([
                    (bnode_cx, diamond_cy + 25),
                    (bnode_cx, merge_y)
                ]))
        else:
            # 主流程：只画标签，不画线段（下一个节点从菱形底部直接连线）
            lines.append(svg_label(bnode_cx + 12, diamond_cy + 38, bnode.no_label))

    # 是分支汇合折线
    if draw_merge:
        if bnode.yes_nodes:
            if yes_last_cy + 16 < merge_y - 2:
                # 是分支较短，延伸到汇合点再折回主线
                lines.append(svg_polyline([
                    (yes_last_cx, yes_last_cy + 16),
                    (yes_last_cx, merge_y),
                    (bnode_cx + 80, merge_y)
                ]))
            else:
                # 是分支是最长的，画无箭头折线回主线中心
                lines.append(svg_polyline_plain([
                    (yes_last_cx, yes_last_cy + 16),
                    (yes_last_cx, merge_y),
                    (bnode_cx, merge_y)
                ]))
        elif not bnode.yes_nodes:
            # 是分支为空，画 stub
            mid_x = bnode_cx + bnode.w // 2 + 30
            lines.append(svg_polyline_plain([
                (bnode_cx + bnode.w // 2, diamond_cy),
                (mid_x, diamond_cy),
            ]))
            lines.append(svg_label(bnode_cx + bnode.w // 2 + 7, diamond_cy - 7, bnode.yes_label))

    return {
        "items": items,
        "lines": lines,
        "merge_y": merge_y,
        "no_last_cx": no_last_cx, "no_last_cy": no_last_cy,
        "yes_last_cx": yes_last_cx, "yes_last_cy": yes_last_cy,
        "no_branch_h": no_branch_h, "yes_branch_h": yes_branch_h,
        "right_cx": right_cx,
    }


# ========== 布局引擎 ==========

def layout_section(ctx, nodes, y0):
    """计算一段流程的所有节点位置
    返回 (items, lines, total_height, note_svg)
    """
    lane_map = ctx["lane_map"]
    lane_widths = ctx.get("lane_widths")
    lane_lefts = ctx.get("lane_lefts")
    lane_w = ctx["lane_w"]
    default_cx = lane_map[ctx["default_lane"]]
    g = ctx.get("gaps", {"step": GAP_STEP, "decision": GAP_DECISION,
                         "after_dec": GAP_AFTER_DEC, "cross": GAP_CROSS,
                         "start": GAP_START, "note": GAP_NOTE})

    items = []
    lines = []
    note_svg = None
    y = g["start"]
    prev_cx = None
    prev_cy = None
    prev_type = None
    prev_yes_label = None
    prev_hw = 80
    # C 节点是分支末端信息，用于下一个节点画汇合折线
    c_yes_pending = None  # (yes_last_cx, yes_last_cy) or None
    # MB 节点非主线列的汇合折线，延迟到下一个节点画
    mb_merge_pending = []  # [(col_cx, col_last_cy, top_offset), ...]

    for node in nodes:
        if isinstance(node, N):
            nb_y = y0 + y + g["note"]
            cx = default_cx
            note_svg = svg_note_box(cx - node.w // 2 + 80, nb_y, node.w, node.h, node.title, node.lines)
            y += g["note"] + node.h + 20
            continue

        # 确定间距
        if prev_type is None:
            gap = 0
        elif isinstance(node, S):
            gap = g["step"]
        elif isinstance(node, D):
            gap = g["decision"] if prev_type != 'D' else 70
        elif isinstance(node, C):
            gap = g["decision"] if prev_type != 'D' else 70
        elif isinstance(node, MB):
            gap = g["decision"] if prev_type != 'D' else 70
        elif isinstance(node, X):
            gap = g["cross"] if prev_type != 'D' else g["after_dec"]
        elif isinstance(node, P):
            if prev_type == 'D':
                gap = g["after_dec"]
            elif prev_type == 'X':
                gap = g["cross"]
            else:
                gap = g["step"]

        y += gap
        cy = y0 + y

        if isinstance(node, S):
            cx = prev_cx if prev_cx else default_cx
            items.append(('S', node, cx, cy))
            if prev_cy is not None and prev_type != 'MB_merge_all_pending':
                s_top = 0 if prev_type in ('C_merge', 'MB_merge') else (25 if prev_type == 'D' else 16)
                lines.append(svg_arrow(prev_cx, prev_cy + s_top, cx, cy - 13))
            # 是分支延迟汇合：先下后横折线到当前节点
            if c_yes_pending:
                if len(c_yes_pending) == 4 and c_yes_pending[2] == 'bypass':
                    start_x, start_y, _, bypass_x = c_yes_pending
                    lines.append(svg_polyline([
                        (start_x, start_y),
                        (bypass_x, start_y),
                        (bypass_x, cy),
                        (cx + 80, cy)
                    ]))
                else:
                    ycx, ycy = c_yes_pending[0], c_yes_pending[1]
                    lines.append(svg_polyline([
                        (ycx, ycy + 16),
                        (ycx, cy),
                        (cx + 80, cy)
                    ]))
                c_yes_pending = None
            # MB 非主线列延迟汇合折线
            if mb_merge_pending:
                for _mcx, _mcy, _mtoff in mb_merge_pending:
                    if _mcx == cx:
                        lines.append(svg_arrow(_mcx, _mcy + _mtoff, cx, cy - 13))
                    else:
                        _edge = -45 if _mcx < cx else 45
                        lines.append(svg_polyline([
                            (_mcx, _mcy + _mtoff),
                            (_mcx, cy),
                            (cx + _edge, cy)
                        ]))
                mb_merge_pending = []
            prev_cx, prev_cy, prev_type = cx, cy, 'S'
            prev_yes_label = None
            prev_hw = 45

        elif isinstance(node, P):
            cx = lane_map[node.lane]
            items.append(('P', node, cx, cy))
            if prev_cy is not None and prev_type != 'MB_merge_all_pending':
                if prev_cx == cx:
                    top_offset = _t_off(prev_type)
                    lines.append(svg_arrow(cx, prev_cy + top_offset, cx, cy - 16))
                    if prev_yes_label:
                        lines.append(svg_label(cx + 12, prev_cy + top_offset + 13, prev_yes_label))
                else:
                    top_offset = _t_off(prev_type)
                    if prev_yes_label:
                        lines.append(svg_label(prev_cx + 12, prev_cy + top_offset + 13, prev_yes_label))
                    target_edge = -80 if cx > prev_cx else 80
                    lines.append(svg_polyline([
                        (prev_cx, prev_cy + top_offset),
                        (prev_cx, cy),
                        (cx + target_edge, cy)
                    ]))
            # 是分支延迟汇合：先下后横折线到当前节点
            if c_yes_pending:
                if len(c_yes_pending) == 4 and c_yes_pending[2] == 'bypass':
                    start_x, start_y, _, bypass_x = c_yes_pending
                    target_edge = node.w // 2
                    lines.append(svg_polyline([
                        (start_x, start_y),
                        (bypass_x, start_y),
                        (bypass_x, cy),
                        (cx + target_edge, cy)
                    ]))
                else:
                    ycx, ycy = c_yes_pending[0], c_yes_pending[1]
                    target_edge = node.w // 2
                    lines.append(svg_polyline([
                        (ycx, ycy + 16),
                        (ycx, cy),
                        (cx + target_edge, cy)
                    ]))
                c_yes_pending = None
            # MB 非主线列延迟汇合折线
            if mb_merge_pending:
                for _mcx, _mcy, _mtoff in mb_merge_pending:
                    if _mcx == cx:
                        lines.append(svg_arrow(_mcx, _mcy + _mtoff, cx, cy - 16))
                    else:
                        _edge = -(node.w // 2) if _mcx < cx else (node.w // 2)
                        lines.append(svg_polyline([
                            (_mcx, _mcy + _mtoff),
                            (_mcx, cy),
                            (cx + _edge, cy)
                        ]))
                mb_merge_pending = []
            prev_cx, prev_cy, prev_type = cx, cy, 'P'
            prev_yes_label = None
            prev_hw = node.w // 2

        elif isinstance(node, D):
            cx = lane_map[node.lane]
            items.append(('D', node, cx, cy))
            # 是分支延迟汇合
            if c_yes_pending:
                if len(c_yes_pending) == 4 and c_yes_pending[2] == 'bypass':
                    # コ形绕行：从上方菱形右顶点 → 向右 → 竖直向下 → 折回当前菱形上顶点
                    start_x, start_y, _, bypass_x = c_yes_pending
                    lines.append(svg_polyline([
                        (start_x, start_y),
                        (bypass_x, start_y),
                        (bypass_x, cy - 25),
                        (cx, cy - 25)
                    ]))
                else:
                    # 有节点的是分支：从末端汇入主线箭头起点
                    ycx, ycy = c_yes_pending[0], c_yes_pending[1]
                    if prev_cy is not None:
                        top_offset = _t_off(prev_type)
                        merge_point_y = prev_cy + top_offset
                    else:
                        merge_point_y = cy - 50
                    lines.append(svg_polyline_plain([
                        (ycx, ycy + 16),
                        (ycx, merge_point_y),
                        (cx, merge_point_y)
                    ]))
                c_yes_pending = None
            if prev_cy is not None and prev_type != 'MB_merge_all_pending':
                if prev_cx == cx:
                    top_offset = _t_off(prev_type)
                    lines.append(svg_arrow(cx, prev_cy + top_offset, cx, cy - 25))
                    if prev_yes_label:
                        lines.append(svg_label(cx + 12, prev_cy + top_offset + 13, prev_yes_label))
                else:
                    top_offset = _t_off(prev_type)
                    if prev_yes_label:
                        lines.append(svg_label(prev_cx + 12, prev_cy + top_offset + 13, prev_yes_label))
                    target_edge = -65 if cx > prev_cx else 65
                    lines.append(svg_polyline([
                        (prev_cx, prev_cy + top_offset),
                        (prev_cx, cy),
                        (cx + target_edge, cy)
                    ]))
            # 异常分支
            if node.no:
                no_w = max(node.no_w, _estimate_text_w(node.no))
                lane_values = list(lane_map.values())
                lane_idx = lane_values.index(cx) if cx in lane_values else 0
                if lane_lefts:
                    lane_right = lane_lefts[lane_idx] + lane_widths[lane_idx] - 4
                else:
                    lane_right = SEC_LABEL_W + lane_w * (lane_idx + 1) - 4
                arrow_start = cx + node.w // 2
                no_left = arrow_start + 12
                actual_no_w = min(no_w, lane_right - no_left)
                no_cx = no_left + actual_no_w // 2
                items.append(('ERR_custom', node, no_cx, cy, actual_no_w))
                lines.append(svg_arrow_err(arrow_start, cy, no_left - 1, cy))
                lines.append(svg_label(arrow_start + 6, cy - 7, node.no_label, "#DC2626"))

            # MB 非主线列延迟汇合折线
            if mb_merge_pending:
                for _mcx, _mcy, _mtoff in mb_merge_pending:
                    if _mcx == cx:
                        lines.append(svg_arrow(_mcx, _mcy + _mtoff, cx, cy - 25))
                    else:
                        _edge = -(node.w // 2) if _mcx < cx else (node.w // 2)
                        lines.append(svg_polyline([
                            (_mcx, _mcy + _mtoff),
                            (_mcx, cy),
                            (cx + _edge, cy)
                        ]))
                mb_merge_pending = []
            prev_cx, prev_cy, prev_type = cx, cy, 'D'
            prev_yes_label = node.yes_label
            prev_hw = node.w // 2

        elif isinstance(node, C):
            cx = lane_map[node.lane]
            diamond_cy = cy

            # 画菱形
            items.append(('D_plain', node, cx, cy))

            # 是分支延迟汇合
            if c_yes_pending:
                if len(c_yes_pending) == 4 and c_yes_pending[2] == 'bypass':
                    # コ形绕行：从上方菱形右顶点 → 向右 → 竖直向下 → 折回当前菱形上顶点
                    start_x, start_y, _, bypass_x = c_yes_pending
                    lines.append(svg_polyline([
                        (start_x, start_y),
                        (bypass_x, start_y),
                        (bypass_x, cy - 25),
                        (cx, cy - 25)
                    ]))
                else:
                    # 有节点的是分支：从末端汇入主线箭头起点
                    ycx, ycy = c_yes_pending[0], c_yes_pending[1]
                    if prev_cy is not None:
                        top_offset = _t_off(prev_type)
                        merge_point_y = prev_cy + top_offset
                    else:
                        merge_point_y = cy - 50
                    lines.append(svg_polyline_plain([
                        (ycx, ycy + 16),
                        (ycx, merge_point_y),
                        (cx, merge_point_y)
                    ]))
                c_yes_pending = None

            # 从上一个节点连线到菱形
            if prev_cy is not None and prev_type != 'MB_merge_all_pending':
                if prev_cx == cx:
                    top_offset = _t_off(prev_type)
                    lines.append(svg_arrow(cx, prev_cy + top_offset, cx, cy - 25))
                    if prev_yes_label:
                        lines.append(svg_label(cx + 12, prev_cy + top_offset + 13, prev_yes_label))
                else:
                    top_offset = _t_off(prev_type)
                    if prev_yes_label:
                        lines.append(svg_label(prev_cx + 12, prev_cy + top_offset + 13, prev_yes_label))
                    target_edge = -65 if cx > prev_cx else 65
                    lines.append(svg_polyline([
                        (prev_cx, prev_cy + top_offset),
                        (prev_cx, cy),
                        (cx + target_edge, cy)
                    ]))

            # 调用公共函数布局分支（不画汇合线，由主流程 c_yes_pending 延迟处理）
            cr = _layout_c_branch(node, cx, diamond_cy, g, lane_map, draw_merge=False)
            items.extend(cr["items"])
            lines.extend(cr["lines"])
            merge_y = cr["merge_y"]

            # 是分支汇合线 → 延迟到下一个节点画（先下后横折线）
            if node.yes_nodes:
                c_yes_pending = (cr["yes_last_cx"], cr["yes_last_cy"], 'has_nodes')
            else:
                # 是分支无步骤：记录菱形右顶点和否分支右侧 x，延迟画コ形绕行折线
                start_x = cx + node.w // 2
                bypass_x = cr["right_cx"] + 30  # 绕行到否分支右侧再偏移30px
                lines.append(svg_label(start_x + 7, diamond_cy - 7, node.yes_label))
                c_yes_pending = (start_x, diamond_cy, 'bypass', bypass_x)

            # 更新状态
            if not node.no_nodes and not node.yes_nodes:
                y = merge_y - y0
                prev_cx, prev_cy = cx, diamond_cy
                prev_type = 'D'
                prev_yes_label = node.no_label
            elif not node.no_nodes:
                y = merge_y - y0
                prev_cx, prev_cy = cx, diamond_cy
                prev_type = 'D'
                prev_yes_label = node.no_label
            else:
                y = merge_y - y0
                prev_cx, prev_cy = cx, merge_y
                prev_type = 'C_merge'
                prev_yes_label = None
            prev_hw = 80

        elif isinstance(node, MB):
            cx = lane_map[node.lane]
            diamond_cy = cy

            # 画菱形
            items.append(('D_plain', node, cx, cy))

            # 是分支延迟汇合：上一个 C 节点的是分支连到当前菱形
            if c_yes_pending:
                if len(c_yes_pending) == 4 and c_yes_pending[2] == 'bypass':
                    start_x, start_y, _, bypass_x = c_yes_pending
                    lines.append(svg_polyline([
                        (start_x, start_y),
                        (bypass_x, start_y),
                        (bypass_x, cy - 25),
                        (cx, cy - 25)
                    ]))
                else:
                    ycx, ycy = c_yes_pending[0], c_yes_pending[1]
                    target_edge = node.w // 2
                    lines.append(svg_polyline([
                        (ycx, ycy + 16),
                        (ycx, cy),
                        (cx + target_edge, cy)
                    ]))
                c_yes_pending = None

            # 从上一个节点连线到菱形
            if prev_cy is not None and prev_type != 'MB_merge_all_pending':
                if prev_cx == cx:
                    top_offset = _t_off(prev_type)
                    lines.append(svg_arrow(cx, prev_cy + top_offset, cx, cy - 25))
                    if prev_yes_label:
                        lines.append(svg_label(cx + 12, prev_cy + top_offset + 13, prev_yes_label))
                else:
                    top_offset = _t_off(prev_type)
                    if prev_yes_label:
                        lines.append(svg_label(prev_cx + 12, prev_cy + top_offset + 13, prev_yes_label))
                    target_edge = -65 if cx > prev_cx else 65
                    lines.append(svg_polyline([
                        (prev_cx, prev_cy + top_offset),
                        (prev_cx, cy),
                        (cx + target_edge, cy)
                    ]))

            # 计算列宽和列中心 X
            col_widths = _mb_col_widths(node)
            n_cols = len(col_widths)
            total_cols_w = sum(col_widths) + node.col_gap * (n_cols - 1)
            # 居中排列：第一列左边缘 = cx - total_cols_w/2
            col_left = cx - total_cols_w // 2
            col_cxs = []
            x_acc = col_left
            for cw in col_widths:
                col_cxs.append(x_acc + cw // 2)
                x_acc += cw + node.col_gap

            # 布局每列分支
            branch_ends = []  # [(last_cx, last_cy, branch_h)] 每列末端信息
            for bi, branch in enumerate(node.branches):
                b_label = branch.get("label", "")
                b_nodes = branch.get("nodes", [])
                b_cx = col_cxs[bi]
                b_y = diamond_cy  # 从菱形 y 开始算

                # 画菱形到该列的连线 + 标签
                if b_cx < cx:
                    # 列在菱形左侧：从菱形左顶点水平到列 cx，再向下
                    if b_nodes:
                        first_cy = diamond_cy + g["after_dec"]
                        lines.append(svg_polyline([
                            (cx - node.w // 2, diamond_cy),
                            (b_cx, diamond_cy),
                            (b_cx, first_cy - 16)
                        ]))
                        lines.append(svg_label(
                            cx - node.w // 2 - (cx - node.w // 2 - b_cx) // 2,
                            diamond_cy - 7, b_label))
                    else:
                        lines.append(svg_polyline_plain([
                            (cx - node.w // 2, diamond_cy),
                            (b_cx, diamond_cy),
                        ]))
                        lines.append(svg_label(
                            cx - node.w // 2 - (cx - node.w // 2 - b_cx) // 2,
                            diamond_cy - 7, b_label))
                elif b_cx > cx:
                    # 列在菱形右侧：从菱形右顶点水平到列 cx，再向下
                    if b_nodes:
                        first_cy = diamond_cy + g["after_dec"]
                        lines.append(svg_polyline([
                            (cx + node.w // 2, diamond_cy),
                            (b_cx, diamond_cy),
                            (b_cx, first_cy - 16)
                        ]))
                        lines.append(svg_label(
                            cx + node.w // 2 + (b_cx - cx - node.w // 2) // 2,
                            diamond_cy - 7, b_label))
                    else:
                        lines.append(svg_polyline_plain([
                            (cx + node.w // 2, diamond_cy),
                            (b_cx, diamond_cy),
                        ]))
                        lines.append(svg_label(
                            cx + node.w // 2 + (b_cx - cx - node.w // 2) // 2,
                            diamond_cy - 7, b_label))
                else:
                    # 列中心与菱形对齐：从菱形底部直线向下
                    if b_nodes:
                        first_cy = diamond_cy + g["after_dec"]
                        lines.append(svg_arrow(cx, diamond_cy + 25, b_cx, first_cy - 16))
                        lines.append(svg_label(b_cx + 12, diamond_cy + 38, b_label))
                    else:
                        lines.append(svg_label(b_cx + 12, diamond_cy + 38, b_label))

                # 布局该列的节点序列
                col_y = g["after_dec"]  # 相对于 diamond_cy 的偏移
                col_prev_cx = b_cx
                col_prev_cy = diamond_cy + col_y if b_nodes else diamond_cy
                col_prev_type = None
                mb_c_yes_pending = None  # C 节点 yes 分支延迟汇合

                for ni, bnode in enumerate(b_nodes):
                    if ni == 0:
                        node_cy = diamond_cy + col_y
                    else:
                        if isinstance(bnode, D) or isinstance(bnode, C):
                            step_gap = 70 if col_prev_type == 'D' else g["decision"]
                        else:
                            step_gap = g["after_dec"] if col_prev_type == 'D' else g["step"]
                        col_y += step_gap
                        node_cy = diamond_cy + col_y

                    if isinstance(bnode, P):
                        bnode_cx = b_cx
                        items.append(('P', bnode, bnode_cx, node_cy))
                        if ni > 0:
                            t_off = _t_off(col_prev_type)
                            lines.append(svg_arrow(col_prev_cx, col_prev_cy + t_off, bnode_cx, node_cy - 16))
                        # C 节点 yes 分支延迟汇合：折线到当前节点右侧中点
                        if mb_c_yes_pending:
                            ycx, ycy = mb_c_yes_pending
                            target_right = bnode_cx + bnode.w // 2
                            lines.append(svg_polyline([
                                (ycx, ycy + 16),
                                (ycx, node_cy),
                                (target_right, node_cy)
                            ]))
                            mb_c_yes_pending = None
                        col_prev_cx, col_prev_cy, col_prev_type = bnode_cx, node_cy, 'P'

                    elif isinstance(bnode, D):
                        bnode_cx = b_cx
                        items.append(('D', bnode, bnode_cx, node_cy))
                        if ni > 0:
                            t_off = _t_off(col_prev_type)
                            lines.append(svg_arrow(col_prev_cx, col_prev_cy + t_off, bnode_cx, node_cy - 25))
                        # 异常分支错误框
                        if bnode.no:
                            no_w = max(bnode.no_w, _estimate_text_w(bnode.no))
                            # 错误框放在该列右侧，约束在列宽内
                            col_right = col_cxs[bi] + col_widths[bi] // 2
                            arrow_start = bnode_cx + bnode.w // 2
                            no_left = arrow_start + 12
                            actual_no_w = min(no_w, col_right - no_left)
                            if actual_no_w < 40:
                                actual_no_w = 40
                            no_cx = no_left + actual_no_w // 2
                            items.append(('ERR_custom', bnode, no_cx, node_cy, actual_no_w))
                            lines.append(svg_arrow_err(arrow_start, node_cy, no_left - 1, node_cy))
                            lines.append(svg_label(arrow_start + 6, node_cy - 7, bnode.no_label, "#DC2626"))
                        col_prev_cx, col_prev_cy, col_prev_type = bnode_cx, node_cy, 'D'

                    elif isinstance(bnode, X):
                        # 跨泳道节点在 MB 分支内：目标泳道 cx
                        to_cx = lane_map[bnode.to_lane]
                        bnode_cx = to_cx
                        items.append(('P', bnode, bnode_cx, node_cy))
                        if ni > 0:
                            t_off = _t_off(col_prev_type)
                            from_cx_x = col_prev_cx
                            if from_cx_x == bnode_cx:
                                lines.append(svg_arrow(bnode_cx, col_prev_cy + t_off, bnode_cx, node_cy - 16))
                            else:
                                te = -80 if bnode_cx > from_cx_x else 80
                                lines.append(svg_polyline([
                                    (from_cx_x, col_prev_cy + t_off),
                                    (from_cx_x, node_cy),
                                    (bnode_cx + te, node_cy)
                                ]))
                        col_prev_cx, col_prev_cy, col_prev_type = bnode_cx, node_cy, 'X'

                    elif isinstance(bnode, C):
                        # C 节点在 MB 分支内：调用公共函数
                        bnode_cx = b_cx
                        c_diamond_cy = node_cy
                        items.append(('D_plain', bnode, bnode_cx, c_diamond_cy))

                        # 从上一个节点连线到菱形
                        if ni > 0:
                            t_off = _t_off(col_prev_type)
                            lines.append(svg_arrow(col_prev_cx, col_prev_cy + t_off, bnode_cx, c_diamond_cy - 25))

                        # 调用公共函数布局分支（draw_merge=False，yes汇合线延迟到下一个节点画）
                        cr = _layout_c_branch(bnode, bnode_cx, c_diamond_cy, g, draw_merge=False)
                        items.extend(cr["items"])
                        lines.extend(cr["lines"])

                        # 否分支为空时，补画从菱形底部到 merge_y 的普通线段（避免幽灵箭头）
                        if not bnode.no_nodes and cr["merge_y"] > c_diamond_cy + 27:
                            lines.append(svg_polyline_plain([
                                (bnode_cx, c_diamond_cy + 25),
                                (bnode_cx, cr["merge_y"])
                            ]))

                        # 更新列内状态
                        col_y = cr["merge_y"] - diamond_cy
                        col_prev_cx, col_prev_cy = bnode_cx, cr["merge_y"]
                        col_prev_type = 'C_merge'
                        # 记录 yes 分支末端，延迟画汇合线到下一个节点右侧中点
                        if cr["yes_last_cx"] != bnode_cx or cr["yes_branch_h"] > 0:
                            mb_c_yes_pending = (cr["yes_last_cx"], cr["yes_last_cy"])

                # 记录该列末端
                if b_nodes:
                    branch_ends.append((col_prev_cx, col_prev_cy, col_y, col_prev_type))
                else:
                    # 空分支，末端就是菱形位置
                    branch_ends.append((b_cx, diamond_cy, 0, 'D'))

            # 汇合：找最长列
            max_col_y = max(be[2] for be in branch_ends)
            # 汇合点 y = 菱形 + 最长列偏移 + 节点半高(16) + 间距
            merge_y = diamond_cy + max_col_y + 16

            # 每列画汇合线
            # mb_pending 记录需要延迟画折线的非主线列
            mb_pending_lines = []
            for bi, (be_cx, be_cy, be_h, be_type) in enumerate(branch_ends):
                t_off = _t_off(be_type)
                if be_cx == cx and be_cy + t_off >= merge_y - 2:
                    # 该列末端在泳道中心且是最长列，直接由下一个节点从 merge_y 连线
                    pass
                else:
                    # 所有非最长列统一延迟到下一个节点画折线汇合
                    mb_pending_lines.append((be_cx, be_cy, t_off))

            # 更新状态
            y = merge_y - y0
            # 检查是否有分支在泳道中心结束（即不在 pending 里）
            has_center_branch = len(mb_pending_lines) < len(branch_ends)
            if has_center_branch:
                # 有主线列在泳道中心，下一个节点从 merge_y 直连
                prev_cx, prev_cy = cx, merge_y
                prev_type = 'MB_merge'
            else:
                # 所有分支都偏离泳道中心，全部走 pending 折线
                # 设 prev_cy 足够远使下一个节点不画直连箭头
                prev_cx, prev_cy = cx, merge_y
                prev_type = 'MB_merge_all_pending'
            prev_yes_label = None
            prev_hw = 80
            c_yes_pending = None  # 清除 C 节点的 pending
            mb_merge_pending = mb_pending_lines

        elif isinstance(node, X):
            to_cx = lane_map[node.to_lane]
            from_cx = lane_map[node.from_lane] if prev_cx is None else prev_cx
            items.append(('P', node, to_cx, cy))
            if prev_cy is not None and prev_type != 'MB_merge_all_pending':
                top_offset = _t_off(prev_type)
                if prev_yes_label:
                    lines.append(svg_label(from_cx + 12, prev_cy + top_offset + 13, prev_yes_label))
                if from_cx == to_cx:
                    lines.append(svg_arrow(to_cx, prev_cy + top_offset, to_cx, cy - 16))
                else:
                    target_edge = -80 if to_cx > from_cx else 80
                    lines.append(svg_polyline([
                        (from_cx, prev_cy + top_offset),
                        (from_cx, cy),
                        (to_cx + target_edge, cy)
                    ]))
            # 是分支延迟汇合：先下后横折线到当前节点
            if c_yes_pending:
                if len(c_yes_pending) == 4 and c_yes_pending[2] == 'bypass':
                    start_x, start_y, _, bypass_x = c_yes_pending
                    target_edge = node.w // 2
                    lines.append(svg_polyline([
                        (start_x, start_y),
                        (bypass_x, start_y),
                        (bypass_x, cy),
                        (to_cx + target_edge, cy)
                    ]))
                else:
                    ycx, ycy = c_yes_pending[0], c_yes_pending[1]
                    target_edge = node.w // 2
                    lines.append(svg_polyline([
                        (ycx, ycy + 16),
                        (ycx, cy),
                        (to_cx + target_edge, cy)
                    ]))
                c_yes_pending = None
            # MB 非主线列延迟汇合折线
            if mb_merge_pending:
                for _mcx, _mcy, _mtoff in mb_merge_pending:
                    if _mcx == to_cx:
                        lines.append(svg_arrow(_mcx, _mcy + _mtoff, to_cx, cy - 16))
                    else:
                        _edge = -(node.w // 2) if _mcx < to_cx else (node.w // 2)
                        lines.append(svg_polyline([
                            (_mcx, _mcy + _mtoff),
                            (_mcx, cy),
                            (to_cx + _edge, cy)
                        ]))
                mb_merge_pending = []
            prev_cx, prev_cy, prev_type = to_cx, cy, 'X'
            prev_yes_label = None
            prev_hw = node.w // 2

    total_h = y + 20
    return items, lines, total_h, note_svg


def render_items(items, lines_list):
    """将 items 转为 SVG 字符串列表"""
    nodes_svg = []
    lines_svg = list(lines_list)

    for entry in items:
        kind = entry[0]
        if kind == 'S':
            _, node, cx, cy = entry
            sk = node.color or "#4A6CF7"
            nodes_svg.append(svg_rr(cx, cy, node.text, sk=sk))
        elif kind == 'P':
            _, node, cx, cy = entry
            w = node.w if hasattr(node, 'w') else 160
            nodes_svg.append(svg_rc(cx, cy, node.text, w=w))
        elif kind == 'D':
            _, node, cx, cy = entry
            nodes_svg.append(svg_dm(cx, cy, node.text, w=node.w))
        elif kind == 'D_plain':
            _, node, cx, cy = entry
            nodes_svg.append(svg_dm(cx, cy, node.text, w=node.w))
        elif kind == 'ERR':
            _, node, cx, cy = entry
            nodes_svg.append(svg_rc(cx, cy, node.no, w=node.no_w, h=node.no_h))
        elif kind == 'ERR_custom':
            _, node, cx, cy, actual_w = entry
            nodes_svg.append(svg_rc(cx, cy, node.no, w=actual_w, h=node.no_h))

    return nodes_svg, lines_svg


# ========== Patch 工具函数 ==========

def find_decision_node(items, text):
    """在 items 中查找指定文案的判断节点，返回 (cx, cy) 或 None"""
    for entry in items:
        if entry[0] == 'D' and entry[1].text == text:
            return entry[2], entry[3]
    return None


def make_multi_branch_patch(decision_text, branches):
    """生成多分支判断的 patch 函数。

    参数：
        decision_text: 判断节点的文案（如 "综合风险等级?"）
        branches: 分支列表，每项为 dict:
            {"side": "right"|"left", "label": "中", "text": "中→发验证码",
             "offset": 120, "w": 80, "label_color": "#64748B"}
            - side: 分支方向
            - label: 连线上的标签文字
            - text: 分支框内文案
            - offset: 分支框中心距判断节点中心的水平距离（默认 120）
            - w: 分支框宽度（默认 80）
            - label_color: 标签颜色（默认 #64748B，高风险用 #DC2626）

    返回：
        patch 函数，签名 (items, lines_svg, y0) -> (extra_nodes, extra_lines)

    用法：
        patches = {
            "⑧ 风控决策": make_multi_branch_patch("综合风险等级?", [
                {"side": "right", "label": "中", "text": "中→发验证码"},
                {"side": "left",  "label": "高", "text": "高→拦截提示",
                 "offset": 115, "w": 70, "label_color": "#DC2626"},
            ])
        }
    """
    def patch_func(items, lines_svg, y0):
        pos = find_decision_node(items, decision_text)
        if pos is None:
            return [], []
        cx, cy = pos
        extra_nodes = []
        extra_lines = []
        for b in branches:
            side = b.get("side", "right")
            offset = b.get("offset", 120)
            w = b.get("w", 80)
            label = b.get("label", "")
            text = b.get("text", "")
            label_color = b.get("label_color", "#64748B")
            diamond_half = 65  # 默认菱形 w=130 的半宽

            if side == "right":
                box_cx = cx + offset
                extra_nodes.append(svg_rc(box_cx, cy, text, w=w, h=26))
                extra_lines.append(svg_polyline([(cx + diamond_half, cy), (box_cx - w // 2, cy)]))
                extra_lines.append(svg_label(cx + diamond_half + 7, cy - 7, label, label_color))
            else:  # left
                box_cx = cx - offset
                extra_nodes.append(svg_rc(box_cx, cy, text, w=w, h=26))
                extra_lines.append(svg_polyline([(cx - diamond_half, cy), (box_cx + w // 2, cy)]))
                extra_lines.append(svg_label(cx - diamond_half - 7, cy - 7, label, label_color))

        return extra_nodes, extra_lines
    return patch_func


# ========== SVG 组装 ==========

def _render_section_title(svg_parts, sec_name, label_y, total_area_h):
    """渲染左侧段标题竖排文字
    中文逐字拆分，英文/数字整词保持不拆。
    短英文词（≤5字符）水平渲染+动态缩小字号；
    长英文词（>5字符）旋转90°渲染，避免溢出 SEC_LABEL_W。
    """
    tokens = re.findall(r'[a-zA-Z0-9]+|[^\sa-zA-Z0-9]', sec_name)
    char_h = 18
    total_text_h = len(tokens) * char_h
    text_start_y = label_y + (total_area_h - total_text_h) // 2 + 14
    usable_w = SEC_LABEL_W - 8  # 左右各留 4px
    for ci, tok in enumerate(tokens):
        ty = text_start_y + ci * char_h
        if re.match(r'[a-zA-Z0-9]', tok):
            if len(tok) <= 5:
                # 短词水平渲染，基于实际可用宽度动态缩小字号
                fs = min(13, int(usable_w / (len(tok) * 0.6)))
                fs = max(7, fs)
                svg_parts.append(f'<text x="20" y="{ty}" text-anchor="middle" fill="#1E40AF" '
                                 f'font-size="{fs}" font-weight="700">{tok}</text>')
            else:
                # 长词旋转 90° 渲染
                fs = min(11, int(usable_w / (len(tok) * 0.6)))
                fs = max(7, fs)
                svg_parts.append(f'<text x="20" y="{ty}" text-anchor="middle" fill="#1E40AF" '
                                 f'font-size="{fs}" font-weight="700" '
                                 f'transform="rotate(-90,20,{ty})">{tok}</text>')
        else:
            svg_parts.append(f'<text x="20" y="{ty}" text-anchor="middle" fill="#1E40AF" '
                             f'font-size="13" font-weight="700">{tok}</text>')


def sections_to_yaml(lane_config, sections, title="系统流程图", version="V1.0"):
    """将 SECTIONS DSL 转为 YAML 字符串，供研发编码参考。
    内置于引擎，build_svg() 自动调用嵌入 SVG <metadata>。
    """
    lines = []
    lines.append(f"# {title} {version}")
    lines.append("# 研发编码参考数据，从 SVG <metadata> 提取")
    lines.append("")
    lines.append("swimlanes:")
    for lc in lane_config:
        lines.append(f'  - key: "{lc["key"]}"')
        lines.append(f'    name: "{lc["name"]}"')
    lines.append("")
    lines.append("sections:")
    for sec_name, nodes in sections:
        lines.append(f'  - name: "{sec_name}"')
        lines.append(f'    steps:')
        for node in nodes:
            if isinstance(node, S):
                lines.append(f'      - type: start_end')
                lines.append(f'        text: "{node.text}"')
            elif isinstance(node, P):
                lines.append(f'      - type: process')
                lines.append(f'        lane: "{node.lane}"')
                lines.append(f'        text: "{node.text}"')
            elif isinstance(node, D):
                lines.append(f'      - type: decision')
                lines.append(f'        lane: "{node.lane}"')
                lines.append(f'        text: "{node.text}"')
                if node.no:
                    lines.append(f'        on_no: "{node.no}"')
                lines.append(f'        yes_label: "{node.yes_label}"')
                lines.append(f'        no_label: "{node.no_label}"')
            elif isinstance(node, X):
                lines.append(f'      - type: cross_lane')
                lines.append(f'        from: "{node.from_lane}"')
                lines.append(f'        to: "{node.to_lane}"')
                lines.append(f'        text: "{node.text}"')
            elif isinstance(node, C):
                lines.append(f'      - type: condition_branch')
                lines.append(f'        lane: "{node.lane}"')
                lines.append(f'        text: "{node.text}"')
                lines.append(f'        yes_label: "{node.yes_label}"')
                lines.append(f'        no_label: "{node.no_label}"')
                if node.yes_nodes:
                    lines.append(f'        yes_branch:')
                    for yn in node.yes_nodes:
                        lines.append(f'          - text: "{yn.text}"')
                if node.no_nodes:
                    lines.append(f'        no_branch:')
                    for nn in node.no_nodes:
                        lines.append(f'          - text: "{nn.text}"')
            elif isinstance(node, MB):
                lines.append(f'      - type: multi_branch')
                lines.append(f'        lane: "{node.lane}"')
                lines.append(f'        text: "{node.text}"')
                lines.append(f'        branches:')
                for br in node.branches:
                    lines.append(f'          - label: "{br["label"]}"')
                    lines.append(f'            nodes:')
                    for bn in br["nodes"]:
                        if isinstance(bn, P):
                            lines.append(f'              - type: process')
                            lines.append(f'                text: "{bn.text}"')
                        elif isinstance(bn, C):
                            lines.append(f'              - type: condition_branch')
                            lines.append(f'                text: "{bn.text}"')
                            lines.append(f'                yes_label: "{bn.yes_label}"')
                            lines.append(f'                no_label: "{bn.no_label}"')
                            if bn.yes_nodes:
                                lines.append(f'                yes_branch:')
                                for yn in bn.yes_nodes:
                                    lines.append(f'                  - text: "{yn.text}"')
                            if bn.no_nodes:
                                lines.append(f'                no_branch:')
                                for nn in bn.no_nodes:
                                    lines.append(f'                  - text: "{nn.text}"')
                        elif isinstance(bn, D):
                            lines.append(f'              - type: decision')
                            lines.append(f'                text: "{bn.text}"')
                            if bn.no:
                                lines.append(f'                on_no: "{bn.no}"')
            elif isinstance(node, N):
                lines.append(f'      - type: note')
                lines.append(f'        title: "{node.title}"')
                lines.append(f'        lines:')
                for l in node.lines:
                    lines.append(f'          - "{l}"')
    return "\n".join(lines)


def build_svg(ctx, sections, title="系统流程图", version="V1.0", patches=None):
    """
    两遍构建 + 三层渲染，生成完整 SVG 字符串。
    自动嵌入 YAML metadata 供研发编码参考。

    参数：
        ctx: init_lanes() 返回的上下文
        sections: [(段名, [节点列表]), ...]
        title: 标题栏文字
        version: 版本号
        patches: {段名: patch_func(items, lines_svg, y0) -> (extra_nodes, extra_lines)} 可选
    """
    patches = patches or {}
    total_w = ctx["total_w"]
    lanes = ctx["lanes"]
    lane_w = ctx["lane_w"]
    lane_widths = ctx.get("lane_widths", [lane_w] * lanes)
    lane_lefts = ctx.get("lane_lefts", [SEC_LABEL_W + lane_w * i for i in range(lanes)])
    lane_colors = ctx["lane_colors"]
    lane_names = ctx["lane_names"]
    lane_bg = ctx["lane_bg"]

    # 第一遍：计算各段高度
    sec_heights = []
    for name, nodes in sections:
        _, _, h, _ = layout_section(ctx, nodes, 0)
        sec_heights.append(h)

    # 计算各段起始 Y
    sec_y_starts = []
    cur_y = HEADER_H
    for i in range(len(sections)):
        cur_y += LANE_HDR_H
        sec_y_starts.append(cur_y)
        cur_y += sec_heights[i]
        cur_y += 8

    total_h = cur_y + 70

    # 第二遍：正确 Y0 重新布局
    all_nodes_svg = []
    all_lines_svg = []
    all_notes = []

    for i, (name, nodes) in enumerate(sections):
        items, lines, h, note_svg = layout_section(ctx, nodes, sec_y_starts[i])
        nodes_svg, lines_svg = render_items(items, lines)

        if name in patches:
            extra_n, extra_l = patches[name](items, lines_svg, sec_y_starts[i])
            nodes_svg.extend(extra_n)
            lines_svg.extend(extra_l)

        all_nodes_svg.extend(nodes_svg)
        all_lines_svg.extend(lines_svg)
        if note_svg:
            all_notes.append(note_svg)

    # 拼 SVG
    svg_parts = []
    svg_parts.append(
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{total_w}" height="{total_h}" '
        f'viewBox="0 0 {total_w} {total_h}" '
        f'font-family="\'PingFang SC\',\'Microsoft YaHei\',\'Helvetica Neue\',Arial,sans-serif">'
    )

    # metadata YAML（自动嵌入，供研发编码参考）
    yaml_str = sections_to_yaml(ctx["lane_config"], sections, title, version)
    svg_parts.append(f'<metadata>\n<![CDATA[\n{yaml_str}\n]]>\n</metadata>')

    # defs
    svg_parts.append('''<defs>
<marker id="arr" viewBox="0 0 10 10" refX="10" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0L10 5L0 10z" fill="#475569"/></marker>
<marker id="arr-r" viewBox="0 0 10 10" refX="10" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0L10 5L0 10z" fill="#DC2626"/></marker>
</defs>''')

    # === 第一层：背景 ===
    svg_parts.append(f'<rect width="{total_w}" height="{total_h}" fill="#F8FAFC"/>')

    # 标题栏
    svg_parts.append(f'<rect width="{total_w}" height="{HEADER_H}" fill="#1E1F2E"/>')
    svg_parts.append(f'<text x="{total_w//2}" y="30" text-anchor="middle" fill="#fff" '
                     f'font-size="17" font-weight="600">{title}</text>')
    svg_parts.append(f'<text x="{total_w-30}" y="30" text-anchor="end" fill="rgba(255,255,255,0.5)" '
                     f'font-size="10">{version}</text>')

    # 每段泳道标签 + 背景 + 段标题
    for i in range(len(sections)):
        label_y = sec_y_starts[i] - LANE_HDR_H
        content_y = sec_y_starts[i]
        content_h = sec_heights[i]
        sec_bottom = content_y + content_h

        # 泳道标签行
        for j in range(lanes):
            lx = lane_lefts[j]
            lw = lane_widths[j]
            svg_parts.append(f'<rect x="{lx}" y="{label_y}" width="{lw}" height="{LANE_HDR_H}" '
                             f'fill="{lane_colors[j]}" opacity="0.85"/>')
            svg_parts.append(f'<text x="{lx + lw//2}" y="{label_y+17}" text-anchor="middle" '
                             f'fill="#fff" font-size="11" font-weight="600">{lane_names[j]}</text>')

        # 泳道背景列
        for j in range(lanes):
            lx = lane_lefts[j]
            lw = lane_widths[j]
            svg_parts.append(f'<rect x="{lx}" y="{label_y}" width="{lw}" height="{content_h + LANE_HDR_H}" '
                             f'fill="{lane_bg[j]}"/>')
            if j > 0:
                svg_parts.append(f'<line x1="{lx}" y1="{label_y}" x2="{lx}" y2="{sec_bottom}" '
                                 f'stroke="#E2E8F0" stroke-width="0.7"/>')

        # 段底部分隔线
        svg_parts.append(f'<line x1="0" y1="{sec_bottom}" x2="{total_w}" y2="{sec_bottom}" '
                         f'stroke="#E2E8F0" stroke-width="0.8"/>')

        # 段标题蓝色背景（覆盖标签行+内容区）
        sec_name = sections[i][0]
        total_area_h = content_h + LANE_HDR_H
        svg_parts.append(f'<rect x="0" y="{label_y}" width="{SEC_LABEL_W}" height="{total_area_h}" '
                         f'fill="#DBEAFE" rx="0"/>')
        _render_section_title(svg_parts, sec_name, label_y, total_area_h)

    # === 第二层：连线 ===
    for line in all_lines_svg:
        svg_parts.append(line)

    # === 第三层：节点 ===
    for node in all_nodes_svg:
        svg_parts.append(node)

    # 注释框
    for nb in all_notes:
        svg_parts.append(nb)

    # 图例
    legend_y = total_h - 60
    svg_parts.append(f'<rect x="0" y="{legend_y}" width="{total_w}" height="60" fill="#fff" '
                     f'stroke="#E2E8F0" stroke-width="1"/>')

    lx = 20
    svg_parts.append(f'<text x="{lx}" y="{legend_y+25}" fill="#1E293B" font-size="12" font-weight="600">图例：</text>')

    lx = 75
    svg_parts.append(f'<rect x="{lx}" y="{legend_y+13}" width="50" height="20" rx="10" fill="#fff" stroke="#64748B" stroke-width="1.2"/>')
    svg_parts.append(f'<text x="{lx+25}" y="{legend_y+27}" text-anchor="middle" fill="#64748B" font-size="8">开始/结束</text>')

    lx = 140
    svg_parts.append(f'<rect x="{lx}" y="{legend_y+13}" width="50" height="20" rx="3" fill="#fff" stroke="#475569" stroke-width="1.2"/>')
    svg_parts.append(f'<text x="{lx+25}" y="{legend_y+27}" text-anchor="middle" fill="#475569" font-size="8">操作步骤</text>')

    lx = 210
    svg_parts.append(f'<polygon points="{lx+15},{legend_y+13} {lx+30},{legend_y+23} {lx+15},{legend_y+33} {lx},{legend_y+23}" '
                     f'fill="#FEF3C7" stroke="#D97706" stroke-width="1.2"/>')
    svg_parts.append(f'<text x="{lx+15}" y="{legend_y+27}" text-anchor="middle" fill="#92400E" font-size="7">判断</text>')

    lx = 260
    svg_parts.append(f'<line x1="{lx}" y1="{legend_y+23}" x2="{lx+50}" y2="{legend_y+23}" '
                     f'stroke="#475569" stroke-width="1.3" marker-end="url(#arr)"/>')
    svg_parts.append(f'<text x="{lx+25}" y="{legend_y+18}" text-anchor="middle" fill="#475569" font-size="8">正常流向</text>')

    lx = 330
    svg_parts.append(f'<line x1="{lx}" y1="{legend_y+23}" x2="{lx+50}" y2="{legend_y+23}" '
                     f'stroke="#DC2626" stroke-width="1.2" stroke-dasharray="5,3" marker-end="url(#arr-r)"/>')
    svg_parts.append(f'<text x="{lx+25}" y="{legend_y+18}" text-anchor="middle" fill="#DC2626" font-size="8">异常/回退</text>')

    # 泳道色块图例
    lx = 420
    for j in range(lanes):
        svg_parts.append(f'<rect x="{lx}" y="{legend_y+15}" width="12" height="12" rx="2" fill="{lane_colors[j]}" opacity="0.3"/>')
        svg_parts.append(f'<text x="{lx+18}" y="{legend_y+26}" fill="{lane_colors[j]}" font-size="9">{lane_names[j]}</text>')
        lx += 100

    svg_parts.append('</svg>')

    return "\n".join(svg_parts), total_w, total_h, sec_heights


def write_svg(result, out_path):
    """写入 SVG 文件"""
    import os
    svg_content, total_w, total_h, sec_heights = result
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(svg_content)
    print(f"Generated: {out_path}")
    print(f"Size: {total_w} x {total_h}")


# ========== 横向泳道引擎 ==========

# 横向布局常量
H_LANE_LABEL_H = 40   # 左侧泳道标签宽度（横向时泳道标签在左侧）
H_HEADER_H = 46       # 顶部标题栏高度
H_LANE_H = 120        # 每条泳道默认高度

H_GAP_STEP = 120      # 步骤之间水平间距
H_GAP_DECISION = 140  # 判断节点前
H_GAP_AFTER_DEC = 130 # 判断节点后
H_GAP_CROSS = 120     # 跨泳道
H_GAP_START = 60      # 左侧到第一个节点


def init_lanes_h(lane_config, lane_h=120, gaps=None):
    """横向泳道初始化，返回 ctx dict

    泳道从上到下排列，流程从左到右走。
    每条泳道可用 "h" 字段指定独立高度，未指定则用 lane_h 默认值。
    """
    lanes = len(lane_config)
    lane_heights = [cfg.get("h", lane_h) for cfg in lane_config]
    lane_tops = []
    y = H_HEADER_H
    for h in lane_heights:
        lane_tops.append(y)
        y += h
    total_h_body = y - H_HEADER_H
    lane_map = {}
    for i, cfg in enumerate(lane_config):
        lane_map[cfg["key"]] = lane_tops[i] + lane_heights[i] // 2

    g = {"step": H_GAP_STEP, "decision": H_GAP_DECISION, "after_dec": H_GAP_AFTER_DEC,
         "cross": H_GAP_CROSS, "start": H_GAP_START, "note": 40}
    if gaps:
        g.update(gaps)

    return {
        "lane_config": lane_config,
        "lane_h": lane_h,
        "lane_heights": lane_heights,
        "lane_tops": lane_tops,
        "lanes": lanes,
        "total_h_body": total_h_body,
        "lane_map": lane_map,
        "lane_colors": [c["color"] for c in lane_config],
        "lane_names": [c["name"] for c in lane_config],
        "lane_bg": [c["bg"] for c in lane_config],
        "default_lane": lane_config[0]["key"],
        "gaps": g,
        "direction": "horizontal",
    }


def layout_section_h(ctx, nodes, x0):
    """横向布局：计算一段流程的所有节点位置
    流程从左到右，泳道从上到下。
    返回 (items, lines, total_width, note_svg)
    """
    lane_map = ctx["lane_map"]
    lane_heights = ctx["lane_heights"]
    lane_tops = ctx["lane_tops"]
    default_cy = lane_map[ctx["default_lane"]]
    g = ctx["gaps"]

    items = []
    lines = []
    note_svg = None
    x = g["start"]
    prev_cx = None
    prev_cy = None
    prev_type = None
    prev_yes_label = None

    for node in nodes:
        if isinstance(node, N):
            nb_x = x0 + x + g["note"]
            cy = default_cy
            note_svg = svg_note_box(nb_x, cy - node.h // 2, node.w, node.h, node.title, node.lines)
            x += g["note"] + node.w + 20
            continue

        # 确定水平间距
        if prev_type is None:
            gap = 0
        elif isinstance(node, S):
            gap = g["step"]
        elif isinstance(node, D):
            gap = g["decision"] if prev_type != 'D' else 150
        elif isinstance(node, X):
            gap = g["cross"] if prev_type != 'D' else g["after_dec"]
        elif isinstance(node, P):
            if prev_type == 'D':
                gap = g["after_dec"]
            elif prev_type == 'X':
                gap = g["cross"]
            else:
                gap = g["step"]

        x += gap
        cx = x0 + x

        if isinstance(node, S):
            cy = prev_cy if prev_cy else default_cy
            items.append(('S', node, cx, cy))
            if prev_cx is not None:
                # 水平箭头：从前一个节点右边缘到当前左边缘
                right_off = 25 if prev_type == 'D' else (45 if prev_type == 'S' else 80)
                lines.append(svg_arrow(prev_cx + right_off, cy, cx - 45, cy))
            prev_cx, prev_cy, prev_type = cx, cy, 'S'
            prev_yes_label = None

        elif isinstance(node, P):
            cy = lane_map[node.lane]
            items.append(('P', node, cx, cy))
            if prev_cx is not None:
                if prev_cy == cy:
                    # 同泳道水平箭头
                    right_off = node.w // 2 if prev_type == 'D' else (45 if prev_type == 'S' else 80)
                    if prev_type == 'D':
                        right_off = 65  # 菱形默认半宽
                    elif prev_type == 'S':
                        right_off = 45
                    else:
                        right_off = prev_cx + 80 - prev_cx  # 前一个 P 的半宽
                        right_off = 80
                    lines.append(svg_arrow(prev_cx + right_off, cy, cx - node.w // 2, cy))
                    if prev_yes_label:
                        lines.append(svg_label(prev_cx + right_off + 15, cy - 8, prev_yes_label))
                else:
                    # 跨泳道 L 形折线：先右后下/上
                    right_off = 65 if prev_type == 'D' else (45 if prev_type == 'S' else 80)
                    if prev_yes_label:
                        lines.append(svg_label(prev_cx + right_off + 15, prev_cy - 8, prev_yes_label))
                    target_edge = -16 if cy > prev_cy else 16
                    lines.append(svg_polyline([
                        (prev_cx + right_off, prev_cy),
                        (cx, prev_cy),
                        (cx, cy + target_edge)
                    ]))
            prev_cx, prev_cy, prev_type = cx, cy, 'P'
            prev_yes_label = None

        elif isinstance(node, D):
            cy = lane_map[node.lane]
            items.append(('D', node, cx, cy))
            if prev_cx is not None:
                if prev_cy == cy:
                    right_off = 65 if prev_type == 'D' else (45 if prev_type == 'S' else 80)
                    lines.append(svg_arrow(prev_cx + right_off, cy, cx - node.w // 2, cy))
                    if prev_yes_label:
                        lines.append(svg_label(prev_cx + right_off + 15, cy - 8, prev_yes_label))
                else:
                    right_off = 65 if prev_type == 'D' else (45 if prev_type == 'S' else 80)
                    if prev_yes_label:
                        lines.append(svg_label(prev_cx + right_off + 15, prev_cy - 8, prev_yes_label))
                    target_edge = -25 if cy > prev_cy else 25
                    lines.append(svg_polyline([
                        (prev_cx + right_off, prev_cy),
                        (cx, prev_cy),
                        (cx, cy + target_edge)
                    ]))
            # 异常分支（下方）
            if node.no:
                no_h = node.no_h
                no_w = max(node.no_w, _estimate_text_w(node.no))
                lane_values = list(lane_map.values())
                lane_idx = lane_values.index(cy) if cy in lane_values else 0
                lane_bottom = lane_tops[lane_idx] + lane_heights[lane_idx] - 4
                arrow_start_y = cy + 25  # 菱形下顶点
                no_top = arrow_start_y + 12
                actual_no_h = min(no_h, lane_bottom - no_top)
                no_cy = no_top + actual_no_h // 2
                items.append(('ERR_h', node, cx, no_cy, no_w, actual_no_h))
                lines.append(svg_arrow_err(cx, arrow_start_y, cx, no_top - 1))
                lines.append(svg_label(cx + 12, arrow_start_y + 6, node.no_label, "#DC2626"))

            prev_cx, prev_cy, prev_type = cx, cy, 'D'
            prev_yes_label = node.yes_label

        elif isinstance(node, X):
            to_cy = lane_map[node.to_lane]
            from_cy = lane_map[node.from_lane] if prev_cy is None else prev_cy
            from_cx = prev_cx if prev_cx else x0
            items.append(('P', node, cx, to_cy))
            if prev_cx is not None:
                right_off = 65 if prev_type == 'D' else (45 if prev_type == 'S' else 80)
                if prev_yes_label:
                    lines.append(svg_label(from_cx + right_off + 15, from_cy - 8, prev_yes_label))
                if from_cy == to_cy:
                    lines.append(svg_arrow(from_cx + right_off, to_cy, cx - node.w // 2, to_cy))
                else:
                    target_edge = -16 if to_cy > from_cy else 16
                    lines.append(svg_polyline([
                        (from_cx + right_off, from_cy),
                        (cx, from_cy),
                        (cx, to_cy + target_edge)
                    ]))
            prev_cx, prev_cy, prev_type = cx, to_cy, 'X'
            prev_yes_label = None

    total_w = x + 80
    return items, lines, total_w, note_svg


def render_items_h(items, lines_list):
    """横向版：将 items 转为 SVG 字符串列表"""
    nodes_svg = []
    lines_svg = list(lines_list)

    for entry in items:
        kind = entry[0]
        if kind == 'S':
            _, node, cx, cy = entry
            sk = node.color or "#4A6CF7"
            nodes_svg.append(svg_rr(cx, cy, node.text, sk=sk))
        elif kind == 'P':
            _, node, cx, cy = entry
            w = node.w if hasattr(node, 'w') else 160
            nodes_svg.append(svg_rc(cx, cy, node.text, w=w))
        elif kind == 'D':
            _, node, cx, cy = entry
            nodes_svg.append(svg_dm(cx, cy, node.text, w=node.w))
        elif kind == 'ERR_h':
            _, node, cx, cy, w, h = entry
            nodes_svg.append(svg_rc(cx, cy, node.no, w=w, h=h))

    return nodes_svg, lines_svg


def build_svg_h(ctx, nodes, title="系统流程图", version="V1.0", patches=None):
    """横向泳道：单流程，泳道从上到下，流程从左到右。

    参数：
        ctx: init_lanes_h() 返回的上下文
        nodes: [节点列表]（不分段，单一流程）
        title: 标题栏文字
        version: 版本号
        patches: {patch_func(items, lines_svg) -> (extra_nodes, extra_lines)} 可选
    """
    patches = patches or {}
    lanes = ctx["lanes"]
    lane_heights = ctx["lane_heights"]
    lane_tops = ctx["lane_tops"]
    lane_colors = ctx["lane_colors"]
    lane_names = ctx["lane_names"]
    lane_bg = ctx["lane_bg"]

    # 布局
    items, lines, content_w, note_svg = layout_section_h(ctx, nodes, H_LANE_LABEL_H)

    total_w = H_LANE_LABEL_H + content_w + 40
    body_h = ctx["total_h_body"]
    total_h = H_HEADER_H + body_h + 60  # 60 = 图例高度

    # 应用 patches
    all_nodes_svg = []
    all_lines_svg = []
    nodes_svg, lines_svg = render_items_h(items, lines)

    for pname, pfunc in patches.items():
        extra_n, extra_l = pfunc(items, lines_svg, 0)
        nodes_svg.extend(extra_n)
        lines_svg.extend(extra_l)

    all_nodes_svg.extend(nodes_svg)
    all_lines_svg.extend(lines_svg)

    # 拼 SVG
    svg_parts = []
    svg_parts.append(
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{total_w}" height="{total_h}" '
        f'viewBox="0 0 {total_w} {total_h}" '
        f'font-family="\'PingFang SC\',\'Microsoft YaHei\',\'Helvetica Neue\',Arial,sans-serif">'
    )

    # metadata YAML（自动嵌入，供研发编码参考）
    sections_wrapped = [(title, nodes)]
    yaml_str = sections_to_yaml(ctx["lane_config"], sections_wrapped, title, version)
    svg_parts.append(f'<metadata>\n<![CDATA[\n{yaml_str}\n]]>\n</metadata>')

    # defs
    svg_parts.append('''<defs>
<marker id="arr" viewBox="0 0 10 10" refX="10" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0L10 5L0 10z" fill="#475569"/></marker>
<marker id="arr-r" viewBox="0 0 10 10" refX="10" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0L10 5L0 10z" fill="#DC2626"/></marker>
</defs>''')

    # === 第一层：背景 ===
    svg_parts.append(f'<rect width="{total_w}" height="{total_h}" fill="#F8FAFC"/>')

    # 标题栏
    svg_parts.append(f'<rect width="{total_w}" height="{H_HEADER_H}" fill="#1E1F2E"/>')
    svg_parts.append(f'<text x="{total_w//2}" y="30" text-anchor="middle" fill="#fff" '
                     f'font-size="17" font-weight="600">{title}</text>')
    svg_parts.append(f'<text x="{total_w-30}" y="30" text-anchor="end" fill="rgba(255,255,255,0.5)" '
                     f'font-size="10">{version}</text>')

    # 泳道标签（左侧）+ 泳道背景行
    for j in range(lanes):
        ly = lane_tops[j]
        lh = lane_heights[j]
        # 泳道背景
        svg_parts.append(f'<rect x="{H_LANE_LABEL_H}" y="{ly}" width="{total_w - H_LANE_LABEL_H}" '
                         f'height="{lh}" fill="{lane_bg[j]}"/>')
        # 泳道分隔线
        if j > 0:
            svg_parts.append(f'<line x1="0" y1="{ly}" x2="{total_w}" y2="{ly}" '
                             f'stroke="#E2E8F0" stroke-width="0.7"/>')
        # 泳道标签
        svg_parts.append(f'<rect x="0" y="{ly}" width="{H_LANE_LABEL_H}" height="{lh}" '
                         f'fill="{lane_colors[j]}" opacity="0.85"/>')
        svg_parts.append(f'<text x="{H_LANE_LABEL_H//2}" y="{ly + lh//2 + 4}" text-anchor="middle" '
                         f'fill="#fff" font-size="10" font-weight="600">{lane_names[j]}</text>')

    # 底部分隔线
    body_bottom = H_HEADER_H + body_h
    svg_parts.append(f'<line x1="0" y1="{body_bottom}" x2="{total_w}" y2="{body_bottom}" '
                     f'stroke="#E2E8F0" stroke-width="0.8"/>')

    # === 第二层：连线 ===
    for line in all_lines_svg:
        svg_parts.append(line)

    # === 第三层：节点 ===
    for node in all_nodes_svg:
        svg_parts.append(node)

    # 注释框
    if note_svg:
        svg_parts.append(note_svg)

    # 图例
    legend_y = total_h - 60
    svg_parts.append(f'<rect x="0" y="{legend_y}" width="{total_w}" height="60" fill="#fff" '
                     f'stroke="#E2E8F0" stroke-width="1"/>')

    lx = 20
    svg_parts.append(f'<text x="{lx}" y="{legend_y+25}" fill="#1E293B" font-size="12" '
                     f'font-weight="600">图例：</text>')

    lx = 75
    svg_parts.append(f'<rect x="{lx}" y="{legend_y+13}" width="50" height="20" rx="10" '
                     f'fill="#fff" stroke="#64748B" stroke-width="1.2"/>')
    svg_parts.append(f'<text x="{lx+25}" y="{legend_y+27}" text-anchor="middle" fill="#64748B" '
                     f'font-size="8">开始/结束</text>')

    lx = 140
    svg_parts.append(f'<rect x="{lx}" y="{legend_y+13}" width="50" height="20" rx="3" '
                     f'fill="#fff" stroke="#475569" stroke-width="1.2"/>')
    svg_parts.append(f'<text x="{lx+25}" y="{legend_y+27}" text-anchor="middle" fill="#475569" '
                     f'font-size="8">操作步骤</text>')

    lx = 210
    svg_parts.append(f'<polygon points="{lx+15},{legend_y+13} {lx+30},{legend_y+23} '
                     f'{lx+15},{legend_y+33} {lx},{legend_y+23}" '
                     f'fill="#FEF3C7" stroke="#D97706" stroke-width="1.2"/>')
    svg_parts.append(f'<text x="{lx+15}" y="{legend_y+27}" text-anchor="middle" fill="#92400E" '
                     f'font-size="7">判断</text>')

    lx = 260
    svg_parts.append(f'<line x1="{lx}" y1="{legend_y+23}" x2="{lx+50}" y2="{legend_y+23}" '
                     f'stroke="#475569" stroke-width="1.3" marker-end="url(#arr)"/>')
    svg_parts.append(f'<text x="{lx+25}" y="{legend_y+18}" text-anchor="middle" fill="#475569" '
                     f'font-size="8">正常流向</text>')

    lx = 330
    svg_parts.append(f'<line x1="{lx}" y1="{legend_y+23}" x2="{lx+50}" y2="{legend_y+23}" '
                     f'stroke="#DC2626" stroke-width="1.2" stroke-dasharray="5,3" marker-end="url(#arr-r)"/>')
    svg_parts.append(f'<text x="{lx+25}" y="{legend_y+18}" text-anchor="middle" fill="#DC2626" '
                     f'font-size="8">异常/回退</text>')

    # 泳道色块图例
    lx = 420
    for j in range(lanes):
        svg_parts.append(f'<rect x="{lx}" y="{legend_y+15}" width="12" height="12" rx="2" '
                         f'fill="{lane_colors[j]}" opacity="0.3"/>')
        svg_parts.append(f'<text x="{lx+18}" y="{legend_y+26}" fill="{lane_colors[j]}" '
                         f'font-size="9">{lane_names[j]}</text>')
        lx += 100

    svg_parts.append('</svg>')

    return "\n".join(svg_parts), total_w, total_h, [content_w]
