-- ============================================================
-- looply 商家模块 - 种子数据方案
-- 目标：为商品模块提供最小可用的商家数据
-- 依赖：商家ID（8位纯数字编码）+ 商家名称
-- 编码规则：merchant.id 从 10000001 起自增，即 id = 商家编码
-- ============================================================

-- 1. 创建商家主体表
CREATE TABLE IF NOT EXISTS `merchant` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '商家ID（主键，同时作为8位商家编码）',
  `name` VARCHAR(200) NOT NULL COMMENT '商家名称（对外展示）',
  `status` ENUM('pending_review', 'active', 'suspended', 'closed') NOT NULL DEFAULT 'active' COMMENT '状态',
  `type` ENUM('individual', 'company') NOT NULL COMMENT '类型：个人卖家/企业卖家',
  `cooperation_type` ENUM('self_operated', 'third_party') NOT NULL COMMENT '合作类型：自营/三方',
  `owner_staff_id` BIGINT UNSIGNED NOT NULL COMMENT '主账号ID（关联 merchant_staff.id）',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_owner_staff_id` (`owner_staff_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=10000001 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='商家主体表（法律实体）';

-- 2. 创建商家员工表
CREATE TABLE IF NOT EXISTS `merchant_staff` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '员工ID（主键）',
  `merchant_id` BIGINT UNSIGNED NOT NULL COMMENT '商家ID（关联 merchant.id）',
  `email` VARCHAR(100) NOT NULL COMMENT '登录邮箱',
  `name` VARCHAR(100) NOT NULL COMMENT '员工姓名',
  `role` ENUM('owner', 'admin', 'staff') NOT NULL COMMENT '角色：主账号/管理员/普通员工',
  `status` ENUM('active', 'inactive', 'pending_invitation') NOT NULL DEFAULT 'active' COMMENT '状态',
  `invited_by` BIGINT UNSIGNED NULL COMMENT '邀请人ID（自关联 merchant_staff.id）',
  `joined_at` TIMESTAMP NULL COMMENT '接受邀请时间',
  `last_login_at` TIMESTAMP NULL COMMENT '最后登录时间',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_email` (`email`),
  KEY `idx_merchant_id` (`merchant_id`),
  KEY `idx_invited_by` (`invited_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='商家员工表（所有操作人员）';

-- 3. 添加外键约束（建表后添加，避免循环依赖）
ALTER TABLE `merchant`
  ADD CONSTRAINT `fk_merchant_owner_staff`
  FOREIGN KEY (`owner_staff_id`) REFERENCES `merchant_staff` (`id`) ON DELETE RESTRICT;

ALTER TABLE `merchant_staff`
  ADD CONSTRAINT `fk_staff_merchant`
  FOREIGN KEY (`merchant_id`) REFERENCES `merchant` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_staff_invited_by`
  FOREIGN KEY (`invited_by`) REFERENCES `merchant_staff` (`id`) ON DELETE SET NULL;

-- ============================================================
-- 插入种子数据
-- ============================================================

-- 临时禁用外键检查（解决循环依赖）
SET FOREIGN_KEY_CHECKS = 0;

-- 插入种子员工
INSERT INTO `merchant_staff` (
  `id`,
  `merchant_id`,
  `email`,
  `name`,
  `role`,
  `status`,
  `invited_by`,
  `joined_at`,
  `last_login_at`,
  `created_at`,
  `updated_at`
) VALUES (
  1,                              -- id
  10000001,                       -- merchant_id: 关联种子商家
  'admin@looply.com',             -- email
  'Looply Admin',                 -- name
  'owner',                        -- role: 主账号
  'active',                       -- status
  NULL,                           -- invited_by: owner 无邀请人
  NOW(),                          -- joined_at
  NULL,                           -- last_login_at
  NOW(),                          -- created_at
  NOW()                           -- updated_at
);

-- 插入种子商家
INSERT INTO `merchant` (
  `id`,
  `name`,
  `status`,
  `type`,
  `cooperation_type`,
  `owner_staff_id`,
  `created_at`,
  `updated_at`
) VALUES (
  10000001,                       -- id: 8位商家编码
  'Looply Official',              -- name: 自营官方店
  'active',                       -- status: 已审核通过
  'company',                      -- type: 企业卖家
  'self_operated',                -- cooperation_type: 自营
  1,                              -- owner_staff_id: 关联种子员工
  NOW(),                          -- created_at
  NOW()                           -- updated_at
);

-- 恢复外键检查
SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================
-- 验证数据
-- ============================================================

SELECT
  m.id AS merchant_code,
  m.name AS merchant_name,
  m.type,
  m.cooperation_type,
  m.status,
  s.id AS owner_staff_id,
  s.name AS owner_name,
  s.email AS owner_email
FROM merchant m
JOIN merchant_staff s ON m.owner_staff_id = s.id
WHERE m.id = 10000001;

-- 预期结果：
-- merchant_code | merchant_name   | type    | cooperation_type | status | owner_staff_id | owner_name   | owner_email
-- 10000001      | Looply Official | company | self_operated    | active | 1              | Looply Admin | admin@looply.com

-- ============================================================
-- 商品模块引用方式
-- ============================================================

/*
inventory_item.seller_id = 10000001（种子商家编码）

查询商家名称：
SELECT i.*, m.name AS merchant_name
FROM inventory_item i
JOIN merchant m ON i.seller_id = m.id;
*/
