# Looply Contact Us 设计 Checklist v0.1

> 状态：已生成 PRD v0.1
> 更新日期：2026-07-24
> 当前参考页：[Looply Contact Us](https://looply.com/pages/contact)

## 一、输入源盘点

| 输入源 | 当前情况 | 处理方式 |
|---|---|---|
| Looply 现有 PC 页面 | 已提供，包含联系表单、hCaptcha、客服联系方式及注册地址说明 | 作为当前页面内容和字段的主要参考 |
| PC 端入口 | 已确认：首页 Footer → Contact Us | 纳入当前版本 |
| Mobile 端入口 | 已确认：个人中心 → Contact Us | 纳入当前版本 |
| Mobile 端设计稿 | 暂未提供 | 后续页面结构收口后补齐或确认沿用统一移动端页面样式 |
| 产品架构图 | 暂未发现 Contact Us 专项内容 | 当前不阻塞轻量页面方案讨论 |
| 系统流程图 | 暂未发现 | 根据后续确认的提交规则判断是否需要补充 |
| ER 图 | 暂未发现 | 联系表单的数据去向和保存方式待后续确认 |
| 竞品调研 | 本次不单独开展 | 用户确认直接参考 Looply 现有页面 |

## 二、已确认设计

### 2.1 页面入口

| 终端 | 页面入口 | 结果 |
|---|---|---|
| PC Web | 首页 Footer → Contact Us | 打开 Contact Us 页面 |
| Mobile | 游客态和登录态的个人中心 → Contact Us | 打开 Contact Us 页面，不触发登录 |

### 2.2 联系表单字段

当前版本沿用现有页面的三个字段，不增加订单号、问题类型或附件上传。

| 字段 | 页面文案 | 控件类型 |
|---|---|---|
| 姓名 | Full Name | 单行文本输入框 |
| 邮箱 | Email | 邮箱输入框 |
| 留言 | Message | 多行文本输入框 |

提交操作文案沿用 `Send`。

## 三、已收口的提交规则

### 3.1 提交校验与结果反馈

- 三个字段均为必填，并在失焦和点击 Send 时校验；
- 验证中和提交中禁止重复点击；
- 提交成功后显示页面内提示并按用户状态重置表单；
- 提交失败时保留内容并允许重试；
- PC 与 Mobile 均保留 Invisible hCaptcha 及第三方隐私与服务条款声明。

### 3.2 留言接收渠道

- Contact Us 表单由 Looply 服务端发送至 `service@looply.com`；
- 邮件内容包含用户提交的 Full Name、Email 和 Message；
- 用户浏览器不直接发送邮件；
- 仅在邮件服务确认已受理发送请求后，页面显示提交成功。

### 3.3 用户确认邮件

- 当前版本不向用户自动发送确认邮件；
- 提交结果仅在 Contact Us 页面内反馈；
- 客服后续从 `service@looply.com` 人工回复用户填写的 Email。

### 3.4 Mobile 游客入口

- 游客态和登录态的个人中心均展示 Contact Us；
- 游客点击后直接进入页面，不触发登录或注册；
- 游客与登录用户均可查看联系信息并提交表单。

### 3.5 登录用户字段初始值

- 登录用户进入页面时自动带入账户姓名和邮箱，游客保持空白；
- 登录用户可修改自动带入的姓名和邮箱；
- 修改后的邮箱只作为本次客服回复地址，不回写账户邮箱；
- 账户姓名或邮箱缺失、读取失败时，对应字段保持空白并允许手动填写；
- 提交成功后，登录用户清空 Message 并恢复账户姓名和邮箱，游客清空三个字段。

### 3.6 未提交内容与离开确认

- 当前任一字段值与页面初始值不同时，点击页面返回或站内跳转显示 `Leave without sending?`；
- 点击 Stay 留在页面并保留内容，点击 Leave 清空内容并继续离开；
- 提交成功并重置字段后，离开页面不再提示；
- hCaptcha Privacy Policy 与 Terms of Service 在外部浏览器或新页面打开，不关闭当前表单页；
- 关闭浏览器、App 被系统终止或跨设备访问时，不保存、不恢复草稿。

## 四、上线依赖

- 技术配置服务端邮件发送能力，并确保 `service@looply.com` 可正常收信；
- 客服、运营与法务复核邮箱、电话、注册地址、响应时效和退货地址提示；
- 完成 hCaptcha 站点配置、服务端验证及 Looply Privacy Policy 披露；
- 设计补齐 PC 与 Mobile 的字段错误、验证中、提交中、成功和失败状态。

## 五、产出文件

- `docs/product/looply-Contact-Us-PRD-v0.1.md`
- `docs/product/looply-Contact-Us-PRD-修订记录.md`
- `prototypes/contact-us/looply-contact-us-prototype-v0.1.html`

## 六、原型一致性检查

- 已覆盖 PC 首页 Footer → Contact Us，以及 Mobile 游客态 / 登录态个人中心 → Contact Us；
- 已覆盖游客空白字段、登录用户账户姓名与邮箱自动带入且可编辑；
- 已覆盖字段错误、hCaptcha 验证中、提交中、成功、提交失败、hCaptcha 失败和未提交离开确认；
- 已验证 Stay 保留内容，Leave 清空内容并离开，Mobile 返回后回到个人中心；
- 已验证 PC 与 Mobile 均展示 hCaptcha 声明和外链，联系邮箱为 `service@looply.com`；
- 2026-07-24 浏览器交互验收通过，未发现控制台错误；原型与 PRD 当前版本的字段、入口和核心可见状态一致。
