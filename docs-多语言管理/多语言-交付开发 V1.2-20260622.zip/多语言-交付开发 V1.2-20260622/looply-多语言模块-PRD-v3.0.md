# looply 多语言模块 PRD

> 版本：V3.0  
> 日期：2026-06-22  
> 状态：评审版  
> 变更：基于 Localized Content 分离架构重写。删除 translation_request 表，统一触发路径（源语言编辑→标记 outdated→自动重译），所有源文本在翻译模块可编辑，key_type 降级为 UI 分类标签

---

## 一、概述

### 1.1 背景与目标

looply 作为面向全球市场的二手电商平台，需要将商品信息、页面文案、通知模板、法律文档等内容翻译为多种目标语言，以支撑多国销售。

多语言模块是 looply 的基础能力模块，为所有业务模块提供统一的多语言内容存储与翻译服务。

**核心目标**：

1. 统一多语言管理后台，运营可集中管理所有业务内容的源文本和翻译
2. AI 自动翻译为主，人工修正为辅，无审核环节，追求翻译效率
3. 注册表模式接入，各业务模块按需注册可翻译字段，翻译模块不感知业务细节
4. 术语表保证品牌名、专业术语在所有语言中的翻译一致性
5. Localized Content 分离架构：所有多语言文本（含源语言）统一存储在翻译模块，业务表只保留结构化数据

### 1.2 本期不做

| 不做的事 | 理由 |
|---------|------|
| 审核/审批流程 | 本期 AI 直译 + 人工可修正，无审核节点 |
| 翻译任务/批量作业管理 | 本期全部自动触发，不做手动创建批量任务 |
| 翻译历史版本 | 只保留当前有效版本，变更通过审计日志追溯 |
| 商家端翻译界面 | 本期只做运营后台 |
| 多渠道差异化翻译 | 所有渠道使用同一份翻译 |
| 语言列表管理 | 语言归属 Market 模块，翻译模块只引用 |
| 翻译设置页面 | AI 翻译模型、提示词模板等参数本期写死代码，不做后台配置界面 |
| Key 导出功能 | 本期只做导入，不做 CSV 导出 |

### 1.3 用户角色

| 角色 | 说明 | 主要操作 |
|------|------|---------|
| 翻译运营 | 负责多语言内容管理和质量修正 | 编辑源文本、查看翻译进度、修正译文、管理术语表 |
| 系统管理员 | 负责翻译模块配置 | 注册可翻译字段（Key 管理） |

### 1.4 术语说明

| 术语 | 说明 |
|------|------|
| Key | 可翻译字段的注册标识，对应 translatable_field_config 中一条记录 |
| resource_type | 资源类型标识（如 product、page-home、legal-tos），由业务模块定义 |
| key_type | Key 的 UI 分类标签：entity_field（业务实体字段）/ static_content（页面文案/法律文档等）。仅用于后台分类展示，不影响数据存储和触发链路 |
| source_hash | 源文本的哈希值，用于检测源内容是否变更 |
| 术语概念 | glossary_concept 中的一条记录，一个源词条目对应多个目标语言译法 |
| 源语言记录 | translation 表中 source_language_code = language_code 的记录，表示原始录入内容而非翻译产物 |

### 1.5 多语言策略

- **语言标识**：使用 ISO 639-1 语言代码（如 en、fr、de、es、ja）
- **源语言**：不固定为英文。每个商家有自己的默认内容语言（merchant.default_content_language），不同资源的源语言可能不同
- **目标语言**：由 Market 模块管理的已开通语言决定
- **统一读取**：前端通过 resource_id + field_name + language_code 查询翻译服务即可获取任何语言的内容，无需区分源语言还是目标语言
- **RTL 支持**：language 表标记是否从右到左（rtl），前端渲染时据此调整布局方向

---

## 二、数据架构

### 2.1 Localized Content 分离原则

平台中的数据分为两类，按类型决定存储位置：

| 类别 | 特征 | 存储位置 | 示例 |
|------|------|---------|------|
| 结构化数据 | 值不随语言/地区变化 | 业务表原字段 | 价格、库存、重量、尺寸、brand_id、成色等级、SKU编码 |
| 本地化内容 | 值随语言/地区变化 | 翻译模块 translation 表 | 标题、描述、SEO 文案、Banner 图、法律文档、通知模板 |

**判断标准**：该字段的值是否随语言/地区变化？是 → 本地化内容，存翻译模块；否 → 结构化数据，存业务表。

**关键设计**：业务表不存任何文本字段。例如 product 表不存 title、description，这些内容全部存在翻译模块的 translation 表中（包括英文源版本）。

### 2.2 key_type 语义

translatable_field_config.key_type 是一个 UI 分类标签，用于后台界面分组展示：

| key_type | 含义 | 示例 |
|----------|------|------|
| entity_field | 来自业务实体的字段 | product.title、category.name、brand.description |
| static_content | 页面文案/法律文档/通知模板 | page-home.hero_title、legal-tos.content、notif-email.subject |

**核心语义**：key_type 不决定数据存储位置和触发链路。两种类型的数据存储和触发路径完全一致：

- 存储：均存 translation 表（含源语言）
- 触发：均为"源语言记录编辑 → 其他语言标记 outdated → 自动重译"
- 读取：均通过翻译服务统一查询

### 2.3 翻译状态定义

translation 表的 status 字段只有两个值：

| 状态值 | 中文显示 | 含义 |
|--------|---------|------|
| translated | 已翻译 | AI 或人工翻译完成，当前有效 |
| outdated | 待更新 | 源内容已变更，当前译文可能不准确 |

**"未翻译"不是数据库状态**：未翻译 = translation 表中无对应记录。前端根据"注册字段总数 × 已开通语言数 - 已有翻译记录数"计算未翻译数量。

### 2.4 数据模型概览

本 PRD 数据模型依据多语言模块实体关系图 v2.3，包含 5 张表：

| 实体 | 说明 | 归属 |
|------|------|------|
| language | 语言 | 外部引用（Market 模块） |
| translation | 翻译内容 | 多语言模块核心表 |
| glossary_concept | 术语概念 | 多语言模块规则表 |
| glossary_translation | 术语翻译 | 多语言模块规则表 |
| translatable_field_config | 可翻译字段配置 | 多语言模块规则表 |

详细字段定义见：`~/Desktop/海外业务/多语言/实体关系图/looply-多语言模块实体关系图-v2.3.svg`

---

## 三、业务模块集成规范

本节定义 Localized Content 分离架构对各业务模块的设计要求。所有需要多语言支持的业务模块必须遵守。

### 3.1 核心原则：业务表不存文本

每个业务模块在设计数据模型时，必须将字段分为两类分别存储：

| 字段类型 | 判断标准 | 存储位置 | 示例 |
|---------|---------|---------|------|
| 结构化数据 | 值不随语言变化 | 业务表 | price、stock、weight、brand_id、condition_grade |
| 本地化内容 | 值随语言变化 | 翻译模块 translation 表 | title、description、seo_title、banner_image |

**硬性规则**：业务表中不允许存在任何"会随语言变化"的文本/图片字段。这些内容全部由翻译模块管理。

**典型示例**：

```
product 表（只存结构化数据）:
  id, brand_id, category_id, condition_grade,
  weight, length, width, height,
  source_language_code,  ← 标记该商品原始录入语言
  created_at, updated_at

  ❌ 不存: title, description, condition_summary 等文本字段
```

### 3.2 受影响的业务表清单

以下业务表的文本字段需从业务表剥离，改由翻译模块存储：

| 业务表 | 需剥离的本地化内容字段 |
|--------|---------------------|
| product | title, description, condition_summary, appearance_desc, accessories_info, supplement_notes |
| listing | listing_title, listing_description, seo_title, meta_description |
| category | category_name |
| brand | brand_name, introduction, description |
| series | series_name, alias, description |
| spu | spu_name, description |
| sku | sku_name |
| attribute_def | attribute_name |
| attribute_option | option_value |
| condition_grade | grade_name, grade_description |

### 3.3 业务后台写入规范

业务后台（如商品管理后台）在用户录入文本内容时，底层必须写入翻译服务而非业务表：

**写入参数**：

| 参数 | 必填 | 说明 |
|------|------|------|
| resource_type | 是 | 资源类型标识，如 product |
| resource_id | 是 | 资源实例 ID |
| field_name | 是 | 字段标识，如 title |
| source_language_code | 是 | 源语言代码（取自商家 default_content_language 或用户当前选择） |
| translated_value | 是 | 文本内容或图片 CDN URL |

**写入时机**：

| 业务场景 | 写入行为 |
|---------|---------|
| 创建资源（如新建商品） | 逐字段写入源语言记录，触发首次翻译 |
| 编辑资源（如修改商品标题） | 更新源语言记录的 translated_value，触发过期检测和重译 |
| 批量导入 | 通过批量写入接口一次提交多条源语言记录 |

**前置条件**：业务模块的可翻译字段必须已在 translatable_field_config 中注册（status=active），否则写入会被拒绝。

### 3.4 业务后台读取规范

业务后台在展示文本内容时（如商品编辑页回显标题），同样从翻译服务读取：

- 调用翻译服务批量查询接口，传入 resource_type + resource_id + field_name + language_code
- language_code 传源语言代码即可获取源文本
- 不需要从业务表读取文本字段（业务表中没有）

### 3.5 资源删除处理

| 场景 | 处理方式 |
|------|---------|
| 业务资源删除（如商品下架删除） | 业务模块调用翻译服务删除接口，清除 resource_type + resource_id 下的所有翻译记录（全部语言全部字段） |
| 业务资源软删除 | 翻译记录保留，不做处理 |

### 3.6 字段注册要求

各业务模块上线前，必须完成以下注册：

1. 梳理本模块的本地化内容字段清单
2. 在 translatable_field_config 中注册每个可翻译字段（通过 Key 管理页面或批量导入）
3. 注册后状态为 active，翻译模块开始接受该字段的源内容写入

**注册时机**：字段注册应在业务模块开发联调阶段完成，作为上线前置条件。

### 3.7 容错设计

| 异常场景 | 业务模块处理方式 |
|---------|----------------|
| 翻译服务暂时不可用 | 源内容写入应重试（异步队列），不阻塞业务操作主流程。录入成功后用户可正常操作结构化数据 |
| 翻译服务返回空（无翻译记录） | 前端展示兜底文案（如"内容暂无翻译"）或降级显示源语言 |
| 源语言记录写入失败 | 提示用户"保存失败，请重试"，该条文本内容不可用 |

### 3.8 source_language_code 维护

每个业务资源需在业务表中保留 `source_language_code` 字段：

- 记录该资源的原始录入语言
- 取值来源：创建资源时取商家的 default_content_language
- 该字段属于结构化数据（不随语言变化），存业务表

---

## 四、翻译流程

### 4.1 统一触发路径

所有翻译的触发路径完全统一，不区分 key_type：

```
源语言记录编辑保存
  → 更新 translation 表源语言记录的 translated_value
  → 重新计算 source_hash
  → 检测 hash 变更
  → 将同一 resource_type + resource_id + field_name 下所有目标语言的 status 标记为 outdated
  → 系统自动触发重新翻译（调用 AI 翻译服务）
  → 翻译完成后更新目标语言记录：status = translated
```

**关键设计**：
- 无中间审核环节，AI 翻译完成后直接标记为 translated
- 运营可事后在翻译详情页手动修正
- 源语言记录的编辑是触发其他语言重译的唯一入口

### 4.2 源内容写入来源

源语言记录（source_language_code = language_code）的写入有两个来源：

| 来源 | 说明 | 场景 |
|------|------|------|
| 业务后台 | 商品后台录入标题/描述时，底层写入翻译服务 | 商品创建、商品编辑 |
| 翻译后台 | 运营在多语言管理后台直接编辑源文本 | 页面文案维护、源文本修正 |

两种来源写入后的行为完全一致：更新 source_hash → 标记目标语言 outdated → 触发自动重译。

### 4.3 过期检测（outdated）

当源内容变更时，系统自动检测并处理：

1. 源语言记录被编辑保存（来自业务后台或翻译后台）
2. 系统计算新的 source_hash
3. 新 hash ≠ 旧 hash → 将同一 resource_type + resource_id + field_name 下所有**目标语言**记录的 status 更新为 outdated
4. 触发自动重新翻译
5. 翻译完成后 status 更新为 translated，source_hash 更新为当前源的 hash

**hash 相同**：源内容未实际变更（如编辑后又改回原文），不触发任何操作。

### 4.4 首次翻译触发

当新资源创建（如新商品上架），源语言记录写入后：

1. 系统检测该 resource_type + resource_id + field_name 的目标语言是否已有翻译记录
2. 无记录 → 系统自动为所有已开通目标语言调用 AI 翻译
3. 翻译完成后写入 translation 表：status = translated，translation_source = ai

### 4.5 字段注册触发回扫

当 translatable_field_config 新注册字段（status 变为 active）时：

1. 系统查询 translation 表中该 resource_type + field_name 已有的源语言记录
2. 对每条源语言记录，检查是否缺少目标语言翻译
3. 缺少的 → 系统自动触发 AI 翻译并写入结果

### 4.6 前端读取时的 Fallback 策略

当前端请求某语言的翻译时，按以下优先级返回：

1. translation 表中有对应语言记录且 status=translated → 返回译文
2. translation 表中有对应语言记录且 status=outdated → 返回旧译文（带标记，提示可能过期）
3. 无翻译记录 → 返回源语言版本（从 translation 表取源语言记录）

---

## 五、前端集成

### 5.1 BFF 统一解析

前端不直接调用翻译模块 API。由 BFF（Backend for Frontend）层统一处理内容获取：

1. 前端请求携带 Accept-Language 头（如 `fr`）
2. BFF 从业务模块获取结构化数据（价格、库存、成色等级等）
3. BFF 从翻译服务批量获取文本内容（标题、描述等，按请求语言返回）
4. BFF 合并结构化数据 + 文本内容，返回前端

**统一性**：不管用户请求的是英文（源语言）还是法语（目标语言），BFF 的调用链路完全一致。不需要判断"当前语言是否是源语言"来走不同路径。

### 5.2 批量查询接口

翻译模块提供批量查询接口，BFF 一次请求获取多个资源的多个字段翻译：

查询参数：
- resource_type + resource_id 列表
- language_code（目标语言）

返回结构：按 resource_id + field_name 组织的内容 map。

### 5.3 多源语言处理

不同商家的商品可能有不同源语言（如日本商家源语言为 ja，美国商家源语言为 en）。

**读取时透明**：BFF 查询翻译时只需传 resource_type + resource_id + field_name + language_code，翻译模块内部通过 translation 表的 source_language_code 字段处理多源语言。调用方无需关心每个商品的源语言是什么。

---

## 六、功能模块

### 6.1 Translation 导航

**功能类型**：页面型

**功能描述**

以卡片网格形式展示所有可翻译资源，按业务域分组，运营可快速定位到具体资源进行翻译管理。

**页面元素**

| 元素 | 说明 |
|------|------|
| 域分组标签（Tab） | 商品域 / 前端页面 / 通知模板 |
| 语言选择器 | 选择当前查看的目标语言 |
| 搜索框 | 按资源名称搜索 |
| 资源卡片网格 | 每个资源类型一张卡片，显示：资源名称、resource_type、翻译进度（已翻译/总字段数）、待更新数 |

**资源类型列表**

| 域 | resource_type | 显示名称 | 字段数（示例） |
|----|--------------|---------|--------------|
| 商品域 | listing | 渠道商品 | 按实际注册字段 |
| 商品域 | product | 实物商品 | - |
| 商品域 | spu | 标品SPU | - |
| 商品域 | sku | 标品SKU | - |
| 商品域 | category | 类目 | - |
| 商品域 | brand | 品牌 | - |
| 商品域 | series | 系列 | - |
| 商品域 | attribute | 属性 | - |
| 商品域 | attribute_option | 属性选项 | - |
| 商品域 | enum | 成色等级 | - |
| 前端页面 | page-auth | 登录注册 | - |
| 前端页面 | page-home | 首页 | 含图片资产 |
| 前端页面 | page-collection | 集合页 | - |
| 前端页面 | page-pdp | 商详页 | - |
| 前端页面 | page-cart | 购物车 | - |
| 前端页面 | page-checkout | 结账页 | - |
| 前端页面 | page-order-success | 支付成功页 | - |
| 前端页面 | page-orders | 订单列表 | - |
| 前端页面 | page-account | 用户中心 | - |
| 前端页面 | page-search | 搜索页 | - |
| 前端页面 | page-nav | 导航栏 | - |
| 前端页面 | page-help | 帮助 / 错误页 | - |
| 前端页面 | legal-tos | 服务条款 | - |
| 前端页面 | legal-privacy | 隐私政策 | - |
| 前端页面 | legal-return | 退货政策 | - |
| 前端页面 | legal-cookie | Cookie政策 | - |
| 通知模板 | notif-email | 邮件模板 | - |
| 通知模板 | notif-message | 站内消息 | - |

**操作流程**

1. 运营进入 Translation 页，默认显示"商品域"标签
2. 选择目标语言（如 fr 法语）
3. 卡片显示每个资源类型在该语言下的翻译进度
4. 点击某资源卡片 → 进入翻译详情页

**交互说明**
- 卡片进度使用进度条 + 数字（如 12/15）
- 有"待更新"内容的卡片显示橙色角标
- 域分组 Tab 后面显示该域的资源数量（如"商品域 10"）

**UI 关联**
- PC 端：`looply-多语言管理后台原型-v11-antd.html` → Translation 导航页

---

### 6.2 翻译详情页（Master-Detail）

**功能类型**：页面型

**功能描述**

左侧展示某资源类型下的所有资源实例列表（Master），右侧展示选中资源的逐字段翻译对照（Detail），支持源文本编辑、译文编辑和图片翻译。

**页面布局**

| 区域 | 内容 |
|------|------|
| 左侧面板（Master） | 资源实例列表，显示：资源名称、resource_id、翻译进度条 |
| 右侧面板（Detail） | 选中资源的逐字段翻译，每字段一行：源文本（可编辑）+ 译文输入框 + 操作按钮 |

**左侧面板元素**

| 元素 | 说明 |
|------|------|
| 搜索框 | 按资源名称/ID 搜索 |
| 状态筛选 | 全部 / 已翻译 / 待更新 / 未翻译 |
| 资源列表 | 每行显示：资源名称、翻译进度（如 3/5）、状态色标 |

**右侧面板元素**

| 元素 | 说明 |
|------|------|
| 资源信息栏 | 资源名称、resource_type、resource_id |
| 一键AI翻译按钮 | 对所有未翻译 + 待更新字段执行 AI 翻译 |
| 字段翻译行 | 每个注册字段一行 |

**字段翻译行结构（文本字段）**

| 元素 | 说明 |
|------|------|
| 字段标签 | field_label（如"商品标题"） |
| 源文本 | TextArea 可编辑，显示源语言内容 |
| 译文输入框 | TextArea，可编辑 |
| AI翻译按钮 | 对该字段执行 AI 翻译 |
| 状态标签 | 已翻译（绿）/ 待更新（橙）/ 未翻译（灰） |

**字段翻译行结构（图片字段）**

| 元素 | 说明 |
|------|------|
| 字段标签 | field_label（如"首页 Banner"） |
| 源图片预览 | 显示源语言图片缩略图，可点击"替换"重新上传 |
| 译图预览 | 显示目标语言图片缩略图（无则显示占位） |
| 上传按钮 | 上传目标语言图片，获取 CDN URL 写入 translated_value |
| 状态标签 | 同文本字段 |

**源文本编辑规则**

所有字段（不区分 key_type）的源文本区域均为可编辑状态：
- 文本字段：源文本显示为 TextArea，运营可直接修改
- 图片字段：源图片区域有"替换"按钮，可重新上传
- 保存时：更新 translation 表中源语言记录的 translated_value，重新计算 source_hash，自动为所有目标语言标记 outdated 并触发重新翻译

**操作流程**

手动编辑译文：
1. 运营在译文输入框中输入/修改内容
2. 点击保存按钮
3. 系统写入 translation 表：translated_value = 输入内容，translation_source = manual，status = translated

编辑源文本：
1. 运营在源文本 TextArea 中修改内容（或替换源图片）
2. 点击保存按钮
3. 系统更新源语言记录的 translated_value + source_hash
4. 系统自动将所有目标语言记录标记为 outdated
5. 系统触发自动重新翻译

单字段 AI 翻译：
1. 运营点击某字段的"AI翻译"按钮
2. 系统调用 AI 翻译服务，传入源文本 + 术语表约束
3. 翻译结果填入译文输入框
4. 系统写入 translation 表：translation_source = ai，status = translated

一键 AI 翻译：
1. 运营点击"一键AI翻译"按钮
2. 系统对所有 status 为"未翻译"或"待更新"的字段批量调用 AI 翻译
3. 结果逐字段写入 translation 表

上传翻译图片：
1. 运营点击图片字段的"上传"按钮
2. 选择本地图片文件
3. 系统上传至 CDN，获取 URL
4. 写入 translation 表：translated_value = CDN URL，translation_source = manual，status = translated

**异常处理**

| 异常场景 | 处理方式 |
|---------|---------|
| AI 翻译服务不可用 | 提示"AI翻译服务暂时不可用，请手动编辑" |
| 保存失败 | 提示"保存失败，请重试"，保留输入内容 |
| 图片上传失败 | 提示"上传失败"，保留原图 |

**UI 关联**
- PC 端：`looply-多语言管理后台原型-v11-antd.html` → 翻译详情页

---

### 6.3 Key 管理

**功能类型**：页面型

**功能描述**

展示所有已注册的可翻译字段（translatable_field_config），支持新增、编辑、导入。

**页面元素**

| 元素 | 说明 |
|------|------|
| 注册 Key 按钮 | 打开注册弹窗 |
| 批量导入按钮 | 打开批量导入弹窗 |
| 搜索框 | 按 resource_type 或 field_name 搜索 |
| key_type 筛选 | 全部 / 业务字段 / 页面文案 |
| 状态筛选 | 全部 / 已激活 / 未激活 / 已废弃 |
| Key 列表表格 | 列见下表 |

**表格列定义**

| 列 | 对应字段 | 说明 |
|----|---------|------|
| Key | resource_type + "." + field_name | 如 "product.title" |
| Key 类型 | key_type | 业务字段 / 页面文案 |
| 字段类型 | field_type | text / image / rich_text |
| 来源/归属 | source_system | 商品中心 / 首页 / 结账页 等 |
| 资源类型 | resource_type + resource_label | 如 "product（商品）" |
| 字段 | field_name + field_label | 如 "title（商品标题）" |
| 状态 | status | 已激活 / 未激活 / 已废弃 |
| 操作 | - | 编辑 |

**key_type 枚举值与显示名映射**

| 数据库值 | 中文显示名 | 含义 |
|---------|-----------|------|
| entity_field | 业务字段 | 来自业务实体的字段（如 product.title、brand.name） |
| static_content | 页面文案 | 页面文案/法律文档/通知模板等（如 page-home.hero_title） |

**注册 Key（弹窗） — 分模式表单**

首选 Key 类型，根据选择展示不同表单：

**模式一：业务字段（entity_field）**

| 字段 | 必填 | 说明 |
|------|------|------|
| key_type | 是 | 固定：业务字段 |
| source_system | 是 | 来源模块（商品中心 / 类目中心 / 品牌中心 等） |
| resource_type | 是 | 实体类型标识，如 product |
| resource_label | 是 | 实体类型显示名，如"商品" |
| field_name | 是 | 字段标识，如 title |
| field_label | 是 | 字段显示名，如"商品标题" |
| field_type | 是 | 下拉：text / image / rich_text |
| Key 名称（自动） | — | 自动拼接：resource_type.field_name（只读展示） |

**模式二：页面文案（static_content）**

| 字段 | 必填 | 说明 |
|------|------|------|
| key_type | 是 | 固定：页面文案 |
| source_system | 是 | 归属页面（首页 / 商详页 / 购物车 / 结账页 等） |
| field_name | 是 | Key 名称，如 hero.title（完整 Key = 页面前缀 + 名称） |
| field_label | 是 | 字段显示名，如"Banner 标题" |
| field_type | 是 | 下拉：text / image / rich_text |
| 源文本 | 是 | 输入源语言原文（文本）或上传源图片（图片） |

**resource_type 自动映射**：模式二中 resource_type 由"归属页面"选择器自动生成，映射关系如下：

| 归属页面 | resource_type |
|---------|--------------|
| 首页 | page-home |
| 商详页 | page-pdp |
| 购物车 | page-cart |
| 结账页 | page-checkout |
| 支付成功页 | page-order-success |
| 用户中心 | page-account |
| 帮助 / 错误页 | page-help |
| 服务条款 | legal-tos |
| 隐私政策 | legal-privacy |

新增页面时由运营在系统配置中维护映射关系。

**校验规则**

| 规则 | 说明 |
|------|------|
| resource_type + field_name 联合唯一 | 不能重复注册 |
| resource_type 格式 | 小写字母、数字、连字符、下划线，最大 50 字符 |
| field_name 格式 | 小写字母、数字、下划线、点号，最大 100 字符 |

**批量导入**

支持 xlsx / CSV / JSON 格式导入，模板包含所有必填字段。导入后显示：成功数 / 失败数 / 失败明细。

**UI 关联**
- PC 端：`looply-多语言管理后台原型-v11-antd.html` → Key管理页

---

### 6.4 术语列表页

**功能类型**：页面型

**功能描述**

以列表形式展示所有术语概念，支持添加、导入、搜索和筛选。点击"详情"进入术语详情页。

**页面元素**

| 元素 | 说明 |
|------|------|
| 添加术语按钮 | 打开添加弹窗 |
| 导入术语按钮 | 打开导入弹窗 |
| 搜索框 | 按源词搜索 |
| 规则筛选 | 全部 / 禁译词 / 强制术语 |
| 语言覆盖筛选 | 全部 / 全部已翻译 / 部分未翻译 / 均未翻译 |
| 术语列表表格 | 列见下表 |

**表格列定义**

| 列 | 说明 |
|----|------|
| 源词 | 源术语文本（加粗显示） |
| 规则 | 禁译词 / 强制术语（标签样式） |
| 已翻译语言 | 禁译词显示"自动锁定"；强制术语显示覆盖率（如 3/5 个语言） |
| 更新时间 | 最后修改时间 |
| 备注 | 使用场景说明 |
| 操作 | 详情 / 删除 |

**术语规则类型**

| 枚举值 | 中文 | AI翻译约束 |
|--------|------|-----------|
| do_not_translate | 禁译词 | 所有语言保留原文不翻译 |
| mandatory | 强制术语 | 必须使用指定译法 |

**添加术语（弹窗）**

| 字段 | 必填 | 说明 |
|------|------|------|
| source_term | 是 | 源术语（如 "looply"） |
| source_language_code | 是 | 源语言 |
| rule_type | 是 | 规则类型（禁译词 / 强制术语） |
| context | 否 | 使用场景说明（备注） |
| 各语言翻译 | 否 | 仅 rule_type=mandatory 时展示：动态展示所有已开通目标语言的翻译输入框，运营可选填（不填则待后续在详情页补充）。rule_type=do_not_translate 时不展示，系统自动保留原文 |

**校验规则**

| 规则 | 说明 |
|------|------|
| source_language_code + source_term 联合唯一 | 同一源语言下源词不能重复 |
| source_term 最大 200 字符 | - |
| translated_term 最大 500 字符 | - |

**UI 关联**
- PC 端：`looply-多语言管理后台原型-v11-antd.html` → 术语列表页

---

### 6.5 术语详情页

**功能类型**：页面型

**功能描述**

展示选中术语概念的详细信息和各目标语言译法，支持编辑源词信息和管理各语言翻译。

**页面元素**

| 元素 | 说明 |
|------|------|
| 返回列表按钮 | 返回术语列表页 |
| 编辑源词按钮 | 打开编辑弹窗，修改源词/规则/备注 |
| 保存修改按钮 | 保存所有译法修改 |
| 源词信息区 | 源词、规则类型、使用场景、创建时间 |
| 各语言翻译表格 | 列见下表 |
| 操作日志 | 展示该术语的变更历史 |

**各语言翻译表格列**

| 列 | 说明 |
|----|------|
| 目标语言 | 语言名称 |
| 语言代码 | ISO 639-1 代码 |
| 翻译 | 标准译法（加粗显示） |
| 状态 | 已翻译 / 未翻译 |
| 更新时间 | 最后修改时间 |
| 操作 | 编辑 |

**UI 关联**
- PC 端：`looply-多语言管理后台原型-v11-antd.html` → 术语详情页

---

## 七、术语管理

### 7.1 术语在翻译中的应用

AI 翻译时，系统自动将术语表规则注入翻译请求：

1. 查询 glossary_concept 表中 status=active 的所有术语
2. 按 rule_type 组织约束指令：
   - do_not_translate → 告知 AI 保留原文
   - mandatory → 告知 AI 必须使用指定译法
3. 将约束指令附加到翻译提示词中

### 7.2 术语覆盖率

术语的翻译覆盖率 = 该概念已有 active 译法的目标语言数 / 系统已开通目标语言总数

- 禁译词：显示"自动锁定"（无需人工翻译）
- 强制术语：显示覆盖率（如 3/5），提醒运营补齐缺失语言

### 7.3 术语状态管理

| 操作 | 效果 |
|------|------|
| 删除术语 | 等同于废弃：glossary_concept.status = deprecated，AI 翻译不再应用该规则。数据保留，可恢复 |
| 废弃单条译法 | glossary_translation.status = deprecated，该语言不再约束 |
| 恢复术语 | status 改回 active，规则重新生效 |

**删除 = 废弃的快捷方式**：列表页"删除"按钮的底层行为是将 status 设为 deprecated（非物理删除），运营可在后续恢复。避免误删导致术语规则丢失。

---

## 八、系统边界

### 8.1 系统定位

多语言模块是 looply 的多语言基础设施层，定位为"所有本地化内容的唯一存储源和翻译管理中心"。

### 8.2 边界判断原则

- 归本模块：与多语言内容的存储、编辑、翻译、查询直接相关的能力
- 不归本模块：语言本身的管理、业务结构化数据的管理、前端渲染逻辑

### 8.3 归属判定

| 能力项 | 归属 | 说明 |
|--------|------|------|
| 所有本地化内容存储（含源语言） | ✅ 多语言模块 | 核心职责，单一数据源 |
| 源文本编辑 | ✅ 多语言模块 | 运营后台编辑入口 |
| AI 翻译执行 | ✅ 多语言模块 | 调用 AI 服务翻译文本 |
| 翻译过期检测与重译触发 | ✅ 多语言模块 | 通过 source_hash 对比 |
| 术语表管理 | ✅ 多语言模块 | 翻译质量保障 |
| 可翻译字段注册 | ✅ 多语言模块 | 注册表模式核心 |
| 批量查询接口（BFF 调用） | ✅ 多语言模块 | 对外提供内容服务 |
| 语言列表管理 | ❌ Market 模块 | 多语言模块只引用 |
| 国家/地区管理 | ❌ Market 模块 | - |
| 商品结构化数据管理 | ❌ 商品模块 | 多语言模块不感知业务实体的结构化字段 |
| 商品后台源文本录入 UI | ❌ 商品模块 | 商品后台负责录入界面，底层调用翻译服务 API 写入 |
| 前端多语言渲染 | ❌ 前端/BFF | 多语言模块只提供数据 |
| CDN 图片存储 | ❌ 基础设施 | 多语言模块只存 CDN URL |

### 8.4 对外接口

| 接口方向 | 对接方 | 交互方式 |
|---------|--------|---------|
| 入（写入） | 各业务模块 | 业务模块通过翻译服务 API 写入源语言记录（如商品后台录入标题时调用） |
| 出（查询） | BFF 层 | 批量查询接口（resource_type + resource_ids + language_code → 内容 map） |
| 引用 | Market 模块 | 读取 language 表获取已开通语言列表 |

---

## 附录

### A. 设计稿索引

| 页面 | 设计稿 |
|------|--------|
| Translation 导航 | `looply-多语言管理后台原型-v11-antd.html` → Translation 导航页 |
| 翻译详情（Master-Detail） | `looply-多语言管理后台原型-v11-antd.html` → 翻译详情页 |
| Key 管理 | `looply-多语言管理后台原型-v11-antd.html` → Key管理页 |
| 术语表管理 | `looply-多语言管理后台原型-v11-antd.html` → 术语表管理页 |

原型文件：`~/Desktop/海外业务/多语言/原型/looply-多语言管理后台原型-v11-antd.html`

### B. 实体关系图

`~/Desktop/海外业务/多语言/实体关系图/looply-多语言模块实体关系图-v2.3.svg`

### C. 版本历史

| 版本 | 日期 | 变更 |
|------|------|------|
| V1.0 | 2026-05-15 | 初版 |
| V1.1 | 2026-05-18 | 调整章节顺序 |
| V2.0 | 2026-06-21 | 全面重写：移除审核流程和任务管理，新增双触发机制、图片资产翻译、多源语言支持、BFF 集成规范；数据模型从 8 表精简为 6 表 |
| V3.0 | 2026-06-22 | 架构升级为 Localized Content 分离：删除 translation_request 表（5 表），统一触发路径（源语言编辑→outdated→自动重译），所有源文本可编辑，key_type 降级为 UI 分类标签，业务表不存文本字段 |
