# looply 商详页 — 数据来源与实现逻辑 V2.1

> **版本**：V2.1 | **日期**：2026-09-22
>
> 数据模型基于：商品主数据 ER v1.9 · Market 主数据 ER v4.0 · 翻译模块 ER v2.1 · 库存系统 ER v4.0
>
> 设计稿：PC-v1.3 · APP-v3
>
> 命名约定：实物商品表 = `product`（原 used_item 已统一重命名）

---

## 阅读指南

本文档回答一个核心问题：**商详页上每个元素的数据从哪来、怎么取、怎么展示？**

- **产品经理**：看每个域的「提供给商详页的数据项」表格，理解数据流转关系
- **研发**：看每张表的具体字段、查询条件、优先级/兜底逻辑，直接对应编码实现

全文按**系统域**组织，每个域独立成章。最后一章是「页面区域 → 数据项」的反向索引，方便按 UI 区域查找。

---

## 一、运行时上下文（页面加载前置条件）

商详页加载时，系统需要确定 5 个上下文参数，所有数据查询都依赖这些参数：

| 上下文参数 | 确定方式 | 影响范围 |
|-----------|---------|---------|
| `market_id` | 用户访问的域名/URL 决定（如 looply.com → US Market） | 决定默认语言、默认货币、配送政策、支付方式、内容版本 |
| `country_code` | 当前 Market 的站点配置；香港站为 `HK` | 决定可售 listing、政策内容、支付方式和推荐过滤 |
| `language_code` | 默认 = Market 默认语言（`market_language.is_default=true`），用户可切换 | 决定所有文本的翻译版本 |
| `currency_code` | 默认 = Market 默认货币（`market_currency.is_default=true`），用户可切换 | 决定价格展示币种、货币符号、小数位 |
| `channel_id` | 当前访问渠道（自营线上商城 = 固定值） | 决定查哪条 listing 记录 |

**核心入参**：通过 URL 获取 `listing_id`（或 `product_id` + `channel_id` 组合），作为整个页面的数据查询起点。

香港站只查询香港 Market/国家/渠道下的 listing。商品没有有效香港 listing 时进入“香港不可售”，不得以美国 listing、价格或购买链接兜底。香港首期展示与交易币种固定为 HKD。

---

## 二、商品域

> 商品域是商详页的主要数据来源，覆盖标题、图片、成色、属性、描述等核心内容。

### 2.1 涉及的表与关系

```
listing ─── product ─── standard_sku ─── spu
                │                          │
                │                     spu_attribute_value ── attribute_def
                │                          │
                │                     spu_image
                │                          │
                │                     backend_category
                │                          │
                │                     series ── brand
                │
                product_condition (1:N)
```

### 2.2 listing 表（渠道挂牌）

listing 是商详页查询的**入口实体**，一个 product 在不同渠道可以有不同的 listing。

| 字段 | 说明 | 展示位置 | 取值逻辑 |
|------|------|---------|---------|
| `listing_id` | 主键 | Description 折叠区 "item #" | URL 入参，对外展示，**不翻译** |
| `product_id` | 关联实物商品 | — | FK，用于关联 product 表 |
| `channel_id` | 所属渠道 | — | 自营线上渠道 |
| `listing_title` | 渠道标题 | 面包屑末级、商品信息区标题、卡片标题 | 不同渠道可设不同标题。为空兜底 product.title |
| `listing_description` | 渠道描述 | 商品描述段落 | 营销性描述文案，可按渠道定制 |
| `listing_price` | 挂牌价 | 商品信息区价格、Sticky 底部栏价格、卡片价格 | 以 `currency_code` 计价的数值 |
| `currency_code` | 定价货币 | — | 创建时自动赋值：`channel.market_id` → `market_currency(is_default=true)` → `currency_code`，运营不可手选 |
| `listing_status` | 挂牌状态 | 页面可见性 + 按钮状态 | ENUM：`active`（在售）、`inactive`（下架）、`draft`（草稿） |

**商详页可售判断逻辑：**

商详页按钮状态由 `listing_status` + 库存状态（来自库存模块）共同决定：

| listing_status | 库存状态 | 商详页展示 |
|---|---|---|
| `active` | 有库存 | **Add to Cart** 可点击，正常购买 |
| `active` | 已预留 / 已售出 | **Sold Out** 灰色不可点击 |
| `inactive` / `draft` | — | 页面显示 **"商品已下架"** 提示 |

> **注意**：库存状态由独立的库存模块管理，商详页通过接口查询当前 listing 对应商品的可售状态。

### 2.3 product 表（实物商品）

每件二手商品一条 product 记录，是商详页信息的核心。

| 字段 | 说明 | 展示位置 | 取值逻辑 |
|------|------|---------|---------|
| `title` | 通用标题 | 商品信息区（兜底） | 优先取 `listing.listing_title`；为空时取 `product.title`；product.title 也为空时系统自动拼接：`{关键属性值} {spu_name}` |
| `grade` | 成色等级 | Condition 折叠区标题 | ENUM(S/A/B/C/D)，需映射为展示名：S→Like New, A→Excellent, B→Very Good, C→Good, D→Fair。展示名走翻译 |
| `images` | 实拍图 | Gallery 区、卡片首图 | JSON 数组，按数组顺序展示。这是二手商品的核心图片 |
| `is_authenticated` | 是否已鉴定 | Condition 折叠区徽章 | Boolean，为 true 时展示 "Certified Authentic" 徽章 |
| `authenticator` | 鉴定机构 | Condition 折叠区（点击查看详情） | 如 "LEGITAPP"，点击可查看鉴定证书信息 |
| `condition_summary` | 成色描述 | Condition 折叠区 | **需补字段**，VARCHAR(500)。整体成色文案，走翻译 |
| 原装配件 | 原装配件 | Condition 折叠区 | 复用质检体系：从 `inspection_result` 中取 `group = "accessories"` 且结果为"有"的质检项名称，配件名走术语表翻译 |

### 2.4 product_condition 表（质检明细）

与 product 为 1:N 关系，记录各部位的质检结果。

| 字段 | 说明 | 展示位置 | 取值逻辑 |
|------|------|---------|---------|
| `check_item` | 检查部位 | Condition 折叠区明细 | 如 "Chain"、"Clasp"，走翻译 |
| `result` | 检查结果 | Condition 折叠区明细 | 如 "Minor tarnish"、"Moderate wear"，走翻译 |
| `sort_order` | 展示排序 | — | 按此字段升序排列 |

**查询条件**：`WHERE product_id = ? ORDER BY sort_order ASC`

### 2.5 standard_sku → spu（标品链路）

product 通过 `standard_sku_id` 关联到标品 SKU，再关联到 SPU。这条链路提供品牌、类目、属性等标品信息。

#### standard_sku_attribute（销售属性）

| 字段 | 说明 | 展示位置 | 取值逻辑 |
|------|------|---------|---------|
| `attribute_value` | 销售属性值 | Description 折叠区（如 Color、Size） | 通过 attribute_def 确定属性名，走翻译 |

**查询条件**：`WHERE standard_sku_id = ?`

#### spu

| 字段 | 说明 | 展示位置 | 取值逻辑 |
|------|------|---------|---------|
| `spu_name` | 标品名称 | product.title 自动拼接时使用 | 走翻译 |
| `description` | 标品描述 | 商品描述段落（兜底） | 优先取 `listing.listing_description`；为空时取 `spu.description`。走翻译 |
| `category_id` | 所属类目 | 面包屑类目层级 | FK → `backend_category` |

#### spu_attribute_value + attribute_def（描述属性）

| 字段 | 说明 | 展示位置 | 取值逻辑 |
|------|------|---------|---------|
| `attribute_def.attribute_name` | 属性名 | Description 折叠区左列（如 Material、Length） | 走翻译 |
| `spu_attribute_value.attribute_value` | 属性值 | Description 折叠区右列（如 Silver-tone Metal、22.8 in） | 走翻译 |

**查询条件**：通过 `attribute_scope_config` 动态驱动——根据 `category_id + brand_id + series_id` 查询 `attribute_type='non_key'` 的属性定义，按 `sort_order` 排序。APP 端超过 8 行截断，点击 "Show more" 展开。

#### spu_image（标品图）

| 字段 | 说明 | 展示位置 | 取值逻辑 |
|------|------|---------|---------|
| `image_url` | 标品图片 | Gallery 区（兜底）、卡片首图（兜底） | `image_type=main`，按 `sort_order` 排序。**仅当 product.images 不足时使用** |

#### backend_category（后台类目）

| 字段 | 说明 | 展示位置 | 取值逻辑 |
|------|------|---------|---------|
| `category_name` | 类目名称 | 面包屑 | 链路：`spu.category_id` → `backend_category`。走翻译 |

#### series → brand（品牌）

| 字段 | 说明 | 展示位置 | 取值逻辑 |
|------|------|---------|---------|
| `brand_name_en` | 品牌名 | 面包屑首级、商品信息区品牌名、卡片品牌名 | 链路：`spu.series_id` → `series.brand_id` → `brand`。奢侈品品牌名通常**不翻译**，通过术语表 `glossary_concept` 标记为禁译词 |

### 2.6 商品域内的优先级/兜底规则汇总

以下字段存在多数据源，按优先级取值：

| 页面元素 | 优先取 | 兜底取 | 说明 |
|---------|--------|-------|------|
| 标题 | `listing.listing_title` | `product.title` → 自动拼接 `{属性值} {spu_name}` | 渠道标题 > 通用标题 > 系统拼接 |
| 描述 | `listing.listing_description` | `spu.description` | 渠道描述 > 标品描述 |
| 图片 | `product.images`（实拍图） | `spu_image`（标品图） | 二手核心是实拍图 |

---

## 三、Market 模块

> Market 模块提供地区化配置：语言列表、货币列表、汇率转换、货币展示格式。

### 3.1 涉及的表

```
market ─── market_language ─── language
       ─── market_currency ─── currency
                           ─── currency_exchange_rate
                           ─── currency_pricing_rule（待设计）
```

### 3.2 语言配置

| 字段 | 来源表 | 展示位置 | 取值逻辑 |
|------|-------|---------|---------|
| 可选语言列表 | `market_language` + `language` | Header 语言下拉 | `WHERE market_id = ?`，取所有关联语言的 `language.language_name` |
| 默认语言 | `market_language.is_default=true` | 页面初始语言 | 决定首次加载时的内容翻译版本 |

### 3.3 货币配置

| 字段 | 来源表 | 展示位置 | 取值逻辑 |
|------|-------|---------|---------|
| 可选货币列表 | `market_currency` + `currency` | Header 货币下拉 | `WHERE market_id = ?`，取所有关联货币的 `currency.currency_name` + `currency.currency_symbol` |
| 默认货币 | `market_currency.is_default=true` | 页面初始货币 | 同时也是 listing 创建时自动赋值的定价货币 |
| 货币符号 | `currency.currency_symbol` | 所有价格前缀（如 "$"） | 随用户切换货币变化 |
| 小数位数 | `currency.decimal_places` | 价格格式化 | 如 USD=2 位，JPY=0 位 |

### 3.4 价格币种转换

香港站首期不开放币种切换：香港 listing 的 `currency_code` 必须为 HKD，页面、购物车和结算统一使用 HKD。以下通用转换规则继续服务其他 Market。

当用户当前货币 ≠ listing 定价货币（`listing.currency_code`）时，需要做币种转换：

```
定价金额                    汇率换算                    尾数规则适配              最终展示价
listing.listing_price  ──→  × exchange_rate        ──→  currency_pricing_rule ──→ 适配金额 + 货币符号 + 小数位格式化
(以 listing.currency_code    (currency_exchange_rate     (待设计)
 计价)                        base → target)
```

**涉及表**：

| 表 | 用途 | 状态 |
|---|------|------|
| `currency_exchange_rate` | 汇率查询：`base_currency` → `target_currency` 的 `rate` | 已有 |
| `currency_pricing_rule` | 尾数定价规则：不同货币的偏好尾数（USD→.99, JPY→整百, EUR→.95） | **待设计** |

**转换规则**：
- 用户当前货币 = 定价货币 → 直接展示，不做转换
- 用户当前货币 ≠ 定价货币 → 汇率换算 → 尾数适配 → 格式化展示
- 划线价和促销价**都需要**做相同的币种转换
- Save 差值 = 转换后的划线价 - 转换后的展示价（差值不做尾数处理）

**结算货币**：用户下单时使用**用户当前看到的展示货币**，不回退到定价货币。

### 3.5 度量单位转换

| 字段 | 来源表 | 展示位置 | 取值逻辑 |
|------|-------|---------|---------|
| 长度单位 | `measurement_unit` | Description 折叠区（如 Length "22.8 in"） | 不同 Market 可能需要单位转换（in ↔ cm）。属性值本身含单位 |

---

## 四、翻译模块

> 翻译模块为商详页提供多语言支持，几乎所有文本内容都需要经过翻译模块。

### 4.1 查询机制

统一通过 `translation` 表查询：

```sql
SELECT translated_text
FROM translation
WHERE resource_type = ?
  AND resource_id = ?
  AND field_name = ?
  AND language_code = {当前语言}
  AND status = 'approved'
```

当前语言 = Market 默认语言时，直接取源值，不查翻译表。

### 4.2 商详页涉及的 resource_type 全量清单

| resource_type | 翻译什么 | 对应页面元素 | resource_id 取值 | field_name 取值 |
|---------------|---------|-------------|-----------------|----------------|
| `listing` | 渠道级内容 | 标题、描述 | listing_id | `listing_title`, `listing_description` |
| `product` | 实物商品内容 | 通用标题、成色描述 | product_id | `title`, `condition_summary` |
| `spu` | 标品内容 | 标品名、标品描述 | spu_id | `spu_name`, `description` |
| `brand` | 品牌名 | 面包屑、信息区、卡片 | brand_id | `brand_name` |
| `category` | 类目名 | 面包屑 | category_id | `category_name` |
| `attribute` | 属性名 | Description 折叠区左列 | attribute_id | `attribute_name` |
| `attribute_option` | 属性值 | Description 折叠区右列 | option_id | `option_value` |
| `condition` | 质检明细 | Condition 折叠区 | condition_id | `check_item`, `result` |
| `enum` | 枚举展示名 | 成色等级展示名 | `grade` | 枚举值（如 `S`, `A`, `B`…） |
| `ui` | 界面文案 | 按钮文案、徽章文案、税费提示 | — | Key（如 `btn.add_to_cart`, `certified_authentic`, `tax_hint`） |
| `content` | CMS 内容 | Shipping & Returns 文案 | content_id | `body` |

### 4.3 不翻译的内容

以下内容**不经过翻译模块**：

| 内容 | 原因 |
|------|------|
| `listing.listing_id`（Listing 编号） | 编号是唯一标识，各语言相同 |
| 品牌名（大部分奢侈品品牌） | 通过术语表 `glossary_concept` 标记为禁译词 |
| 图片 URL | 图片无需翻译 |
| 价格数值 | 数值本身不翻译，仅做币种转换 |
| 货币符号 | 取自 `currency` 表，不走翻译 |

### 4.4 翻译查询的性能建议

商详页一次加载涉及多个 resource_type 的翻译查询，建议**批量查询**：

```sql
SELECT resource_type, resource_id, field_name, translated_text
FROM translation
WHERE (resource_type, resource_id, field_name) IN (...)
  AND language_code = {当前语言}
  AND status = 'approved'
```

---

## 五、促销模块（外部输入）

> 促销模块不属于商品域，但其输出直接影响商详页价格展示。

### 5.1 数据提供方式

促销价由促销模块计算后输出，**不存储在 listing 表中**。

| 数据项 | 来源 | 展示位置 | 展示逻辑 |
|-------|------|---------|---------|
| `promotion_price` | 促销模块计算输出 | 商品信息区、Sticky 底部栏、卡片 | 促销模块根据当前活动规则，传入 listing_id 返回促销价 |

### 5.2 价格展示逻辑

```
有促销价（promotion_price < listing_price）：
  现价 = promotion_price
  划线价 = listing_price（加删除线）
  Save = listing_price - promotion_price

无促销价：
  现价 = listing_price
  划线价 = 不展示
  Save = 不展示
```

**注意**：现价、划线价、Save 三个金额都需要做币种转换（见第三章）。Save = 转换后划线价 - 转换后现价，Save 本身不做尾数处理。

---

## 六、用户域（待设计）

> 用户域提供收藏和浏览历史功能，当前相关实体尚未设计。

### 6.1 需要的实体

| 实体 | 用途 | 展示位置 | 核心字段 |
|------|------|---------|---------|
| `user_wishlist` | 用户收藏 | Gallery 收藏按钮状态、卡片收藏按钮 + 收藏数 | `user_id`, `listing_id`, `created_at` |
| `user_view_history` | 浏览历史 | Recently Viewed 区域 | `user_id`, `listing_id`, `viewed_at` |

### 6.2 展示逻辑

**收藏按钮**：
- 已登录：查 `user_wishlist WHERE user_id = ? AND listing_id = ?`，有记录则显示实心红心，无则空心
- 未登录：点击时触发登录流程
- 收藏数：`COUNT(*) FROM user_wishlist WHERE listing_id = ?`
- 无收藏时只展示空心心形，不显示数字 0

**浏览历史**：
- 已登录：`SELECT listing_id FROM user_view_history WHERE user_id = ? ORDER BY viewed_at DESC LIMIT N`
- 未登录：使用浏览器本地存储（localStorage）记录
- 当前商品不在浏览历史中重复展示
- 无浏览历史时整个区域隐藏

---

## 七、CMS / 内容域

> 提供物流政策、退换货政策等富文本内容。现网配置位于 CMS 管理系统 → 商详页配置；当前 watch、bag、jewelry、accessories 模板属于 US Market。本期新增 HK Market 模板记录后，前台按当前 Market 模板取数。

### 7.1 Shipping & Returns

| 内容块 | 来源 | 展示位置 | 取值逻辑 |
|-------|------|---------|---------|
| 模块标题 | 商详 CMS + 商品翻译 | Shipping & Returns 折叠区 | 按 `market_id + template_id` 读取当前 Market 模板配置 |
| Free Shipping 标题/说明 | 商详 CMS 富文本 + 商品翻译 | Shipping & Returns 折叠区 | 当前为公共配送文案；本期限定为 Market 内公共，HK 与 US 各自维护 |
| Easy Returns 标题/说明 | 商详 CMS 富文本 + 商品翻译 | Shipping & Returns 折叠区 | 按 `market_id + template_id` 维护；HK 四个模板需分别配置 |
| Policy 链接 | CMS 富文本 | Shipping/Returns 说明内 | 跟随各 Market 模板文案维护，香港站链接指向香港政策页 |

英文源文案在商详 CMS 保存，其他语言在商品翻译模块维护。HK 模板可从 US 模板复制初始化，但复制后独立维护。前台读取 HK 内容时不允许跨 Market 回退到 US；保存和变更记录沿用现网机制，并记录 Market 与模板。

### 7.2 Footer 内容

| 内容块 | 来源 | 展示位置 | 取值逻辑 |
|-------|------|---------|---------|
| 页脚所有文案 | CMS + 翻译模块 | Footer | `resource_type='ui'`，自管理 Key |
| 社交媒体链接 | 平台配置 | Footer | 可能按 Market 区分（如欧洲无 TikTok） |

---

## 八、外部服务（非商品域）

> 以下模块与商详页有交互，但不属于商品域管辖范围。

| 模块 | 提供什么 | 展示位置 | 说明 |
|------|---------|---------|------|
| 推荐引擎 | listing_id 列表 | You May Also Like | 输出推荐商品 ID，卡片数据仍从商品域获取 |
| 搜索服务 | 搜索功能 | Header 搜索框 | 独立模块 |
| 支付模块 | 支付方式图标列表 | 支付图标区、Footer 支付图标 | 按 `market_id` / `country` 配置可用支付方式。**待设计** |
| 订单域 | 购物车商品数 | Header Cart 图标角标 | 独立模块 |
| 营销模块 | Newsletter 订阅 | Footer 邮箱输入框 | 独立模块 |
| 前台类目 | 导航栏分类 | Header 导航链接 | **待设计**，已确认单独设计 |
| 税务模块 | 税费提示文案 | 价格下方 | 可能按 `market_country` 展示不同文案。**待确认** |

---

## 九、页面区域 → 数据项反向索引

> 以 UI 区域为维度，快速查找每个元素的数据来自哪个域、哪张表。

### 9.1 Header 导航栏

| 页面元素 | 所属域 | 数据源 | 状态 |
|---------|-------|-------|------|
| 导航链接（New Arrivals / Brands…） | 前台类目 | 待设计 | ⏳ 待设计 |
| 语言切换 | Market 模块 | `market_language` + `language` | ✅ 已确认 |
| 货币切换 | Market 模块 | `market_currency` + `currency` | ✅ 已确认 |
| 搜索 | 搜索服务 | 外部服务 | ⚪ 非本域 |
| Wishlist 图标 | 用户域 | `user_wishlist` | ⏳ 待设计 |
| Cart 图标 | 订单域 | 外部服务 | ⚪ 非本域 |

### 9.2 面包屑

| 页面元素 | 所属域 | 数据源 | 状态 |
|---------|-------|-------|------|
| 品牌名 "LOUIS VUITTON" | 商品域 + 翻译 | `brand.brand_name_en`（通常禁译） | ✅ 已确认 |
| 末级类目 "Necklace" | 商品域 + 翻译 | `backend_category.category_name` | ✅ 已确认 |
| 商品标题 | 商品域 + 翻译 | `listing.listing_title` → `product.title` | ✅ 已确认 |

### 9.3 Gallery 商品图片区

| 页面元素 | 所属域 | 数据源 | 状态 |
|---------|-------|-------|------|
| 商品图片 | 商品域 | `product.images`（实拍图）→ `spu_image`（兜底） | ✅ 已确认 |
| 收藏按钮 | 用户域 | `user_wishlist` | ⏳ 待设计 |
| 翻页/Lightbox | 前端逻辑 | 无后端依赖 | ✅ 已确认 |

### 9.4 商品信息区

| 页面元素 | 所属域 | 数据源 | 状态 |
|---------|-------|-------|------|
| 品牌名 | 商品域 + 翻译 | `brand.brand_name_en`（通常禁译） | ✅ 已确认 |
| 商品标题 | 商品域 + 翻译 | `listing.listing_title` → `product.title` | ✅ 已确认 |
| 商品描述 | 商品域 + 翻译 | `listing.listing_description` → `spu.description` | ✅ 已确认 |
| 现价 | 商品域 + Market | `listing.listing_price` + 币种转换 | ✅ 已确认 |
| 促销价 | 促销模块 | `promotion_price`（外部计算） | ✅ 已确认 |
| 划线价 + Save | 商品域 + 促销 | 有促销时展示 | ✅ 已确认 |
| 税费提示 | 税务模块 | 按 Market 配置 | ⏳ 待确认 |
| 按钮状态 | 商品域 + 库存模块 | `listing_status` + 库存状态 组合判断（详见 2.2） | ✅ 已确认 |
| 按钮文案 | 翻译模块 | `resource_type='ui'` | ✅ 已确认 |

### 9.5 支付方式图标

| 页面元素 | 所属域 | 数据源 | 状态 |
|---------|-------|-------|------|
| 支付图标列表 | 支付模块 | 按 Market/Country 配置 | ⏳ 待设计 |

### 9.6 Condition（成色）折叠区

| 页面元素 | 所属域 | 数据源 | 状态 |
|---------|-------|-------|------|
| Certified Authentic 徽章 | 商品域 | `product.is_authenticated` + `product.authenticator` | ✅ 已确认 |
| 成色等级 "Very Good" | 商品域 + 翻译 | `product.grade` → 枚举映射 → 翻译 | ✅ 已确认 |
| 成色描述 | 商品域 + 翻译 | `product.condition_summary` | ⏳ 需补字段 |
| 部位质检明细 | 商品域 + 翻译 | `product_condition` 表 | ✅ 已确认 |
| 原装配件 | 商品域 + 翻译 | 质检结果 `inspection_result`（group="accessories"） | ✅ 复用质检体系 |

### 9.7 Description（描述）折叠区

| 页面元素 | 所属域 | 数据源 | 状态 |
|---------|-------|-------|------|
| item # Listing 编号 | 商品域 | `listing.listing_id`（不翻译） | ✅ 已确认 |
| 属性列表（Material/Color/Size/Length…） | 商品域 + 翻译 | `spu_attribute_value` + `standard_sku_attribute` + `attribute_def` | ✅ 已确认 |
| Size Guide | 商品域 | 尺码体系（PRD v0.8） | ✅ 已确认 |

### 9.8 Shipping & Returns 折叠区

| 页面元素 | 所属域 | 数据源 | 状态 |
|---------|-------|-------|------|
| 模块标题 | 商详 CMS | 当前 Market 下 PDP 模板的 Shipping & Returns 配置 | 🔄 本期调整 |
| Free Shipping 标题/说明 | 商详 CMS + 商品翻译 | Market 内公共配送文案；香港站按 HK Market 读取 | 🔄 本期调整 |
| Easy Returns 标题/说明 | 商详 CMS + 商品翻译 | 按 `market_id + template_id` 读取；HK watch/bag/jewelry/accessories 分别配置 | 🔄 本期调整 |
| Policy 链接 | 商详 CMS 富文本 | 链接随当前 Market 模板文案保存，香港站进入香港政策页 | 🔄 本期调整 |

现网流程：进入 CMS 管理系统 → 商详页配置 → 选择商品模板 → Shipping & Returns；英文源文案在此保存，其他语言在商品翻译模块维护，保存操作进入配置变更记录。本期确认关系为“Market → PDP 模板 → 模块配置”：现有四个模板属于 US Market，HK 需建立自己的模板记录，可从 US 复制初始化，复制后不联动，不做运行时 US 回退。

前台取数键为当前 `market_id + template_id`。HK 配置缺失时不得回退 US；必填项不完整时阻止保存，香港站上线前需完成 4 个商品模板的内容验收。

### 9.9 You May Also Like + Recently Viewed

| 页面元素 | 所属域 | 数据源 | 状态 |
|---------|-------|-------|------|
| 推荐列表 | 推荐引擎 | 输出 listing_id 列表 | ⚪ 非本域 |
| 浏览历史 | 用户域 | `user_view_history` | ⏳ 待设计 |
| 商品卡片字段 | 商品域 + 翻译 + Market | 多表联查（详见下表） | ✅ 已确认 |
| 收藏数 | 用户域 | `COUNT(user_wishlist)` | ⏳ 待设计 |

香港站推荐和浏览历史只保留有效香港 listing，卡片金额统一使用 HKD；只有美国 listing 的商品不展示。

**商品卡片字段映射**（推荐区和浏览历史通用）：

| 卡片元素 | 数据源 | 取值逻辑 |
|---------|-------|---------|
| 图片 | `product.images[0]` → `spu_image` | 取首张实拍图，无则取标品主图 |
| 品牌名 | `brand.brand_name_en` | 通常禁译 |
| 商品名 | `listing.listing_title` → `product.title` | 渠道标题 > 通用标题 |
| 现价 | `listing.listing_price` 或 `promotion_price` | 有促销价时展示促销价 |
| 划线价 | `listing.listing_price` | 仅促销时展示 |
| Save | 划线价 - 现价 | 均经币种转换后计算 |
| 收藏数 | `COUNT(user_wishlist WHERE listing_id=?)` | 无收藏不显示数字 |

### 9.10 Footer

| 页面元素 | 所属域 | 数据源 | 状态 |
|---------|-------|-------|------|
| 文案 | CMS + 翻译 | `resource_type='ui'` | ✅ 已确认 |
| Newsletter | 营销模块 | 外部服务 | ⚪ 非本域 |
| 社交媒体 | 平台配置 | 按 Market 区分 | ⚪ 非本域 |

### 9.11 APP Sticky 底部购买栏（APP 独有）

| 页面元素 | 所属域 | 数据源 | 状态 |
|---------|-------|-------|------|
| 价格 | 商品域 + Market | `listing.listing_price` 或 `promotion_price` + 币种转换 | ✅ 已确认 |
| Verified 标记 | 商品域 | `product.is_authenticated` | ✅ 已确认 |
| Add to Cart | 商品域 + 库存模块 | `listing_status` + 库存状态 组合判断（详见 2.2） | ✅ 已确认 |
| Checkout | 订单域 | 直接结算当前商品 | ⚪ 非本域 |

---

## 十、待补充项汇总

| 项目 | 类型 | 所属域 | 说明 |
|------|------|-------|------|
| `product.condition_summary` | 补字段 | 商品域 | 成色描述文案，VARCHAR(500) |
| 原装配件（质检体系） | 复用现有 | 商品域 | 通过 `inspection_item.group="accessories"` + `inspection_result` 获取，无需新增字段 |
| `user_wishlist` | 新实体 | 用户域 | user_id + listing_id + created_at |
| `user_view_history` | 新实体 | 用户域 | user_id + listing_id + viewed_at |
| `currency_pricing_rule` | 新表 | Market 模块 | 尾数定价规则：currency_code + rounding_strategy + rounding_unit |
| 前台类目模块 | 新模块 | 独立模块 | Header 导航栏数据源，已确认单独设计 |
| 支付模块配置 | 模块设计 | 支付模块 | 按 Market 配置可用支付方式 |
| Shipping & Returns Market 维度 | 现有能力扩展 | CMS 域 | 现有模块增加 Market 选择，HK 配置不得回退 US |

---

## 版本记录

| 版本 | 日期 | 变更说明 |
|------|------|---------|
| V1.0 | 2026-05-24 | 初稿，按页面区域组织 |
| V1.3 | 2026-05-25 | 补充商品描述、认证徽章、定价货币赋值逻辑 |
| V2.0 | 2026-05-25 | **重构**：按系统域重新组织；新增翻译 resource_type 全量清单；新增页面区域反向索引；新增 APP Sticky 栏；补充 PC/APP 差异 |
| V2.1 | 2026-09-22 | 核对现网 CMS 配置流程；增加香港站上下文、HK listing/HKD 规则、Shipping & Returns Market 维度和推荐/浏览历史过滤 |
