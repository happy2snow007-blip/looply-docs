# looply 商详页—新开站点支持迭代 PRD V1.0

> 日期：2026-09-22  
> 开发基线：商详交付 V1.2 / 全量 PRD V1.8  
> 对应归档：全量 PRD V1.9  
> 目标：定义商详页支持后续新 Market / 新国家站点的通用增量能力；香港站是本期首个落地站点和验收样例。

## 一、背景与目标

现有商详已支持 Market、渠道、listing、币种和 CMS 模板等基础概念，但运行规则及 Shipping & Returns 配置仍以美国站为唯一实际场景。后续开新站点时，商详必须先锁定当前站点的 Market 上下文，再读取该 Market 下的商品、价格、政策、模板和交易能力，不能串到美国站或其他 Market。

本期成功标准：用户从任一新站点进入商详后，看到当前站点对应的商品、币种、政策和交易上下文；有有效当前 Market listing 时可以加购或立即购买；没有当前 Market listing 时明确不可售；任何场景都不使用美国站数据兜底。香港站作为首个落地样例，配置为 HK Market / HKD / 香港政策。

## 二、本期范围

1. 商详运行时增加新站点 Market 上下文，按当前站点稳定使用对应 Market。
2. 只读取当前 Market / 渠道下的 listing；无当前 Market listing 时展示当前站点不可售。
3. 价格展示和购买链路使用当前 Market 的默认币种；香港站首期为 HKD。
4. Add to Cart、Buy Now 在动作前重新校验当前 Market listing、价格、币种和库存。
5. CMS 商详页模板增加 Market 归属，模板和 Shipping & Returns 内容按 Market 独立维护。
6. 推荐和浏览历史过滤为当前 Market 可售商品。

本期不调整商详页面布局，不新增 C 端视觉组件，不重做推荐算法，不开放香港站多币种切换。CMS 后台只调整商详页配置的信息架构和模板归属，不新建独立业务模块。

## 三、运行时与商品取数

### 3.1 上下文

页面上下文为 `market_id + country_code + channel_id + language_code + currency_code`。当前站点的 URL 或用户主动切站结果优先，不因 IP、浏览器历史偏好或旧的美国偏好覆盖。

香港站首期样例：`market_id=HK Market`，`country_code=HK`，`currency_code=HKD`。

### 3.2 listing 规则

- 页面只查询当前 Market / 渠道下的 listing。
- 找到 active 当前 Market listing：继续读取对应 Market 的价格和库存。
- 商品存在但没有有效当前 Market listing：页面主体可浏览，CTA 显示当前站点不可售文案，购买按钮禁用，并提供返回当前站点 Shop 的入口。
- 禁止使用美国 listing、美国价格或美国购买链接兜底。

香港站首期不可售文案：`Not available in Hong Kong`。

### 3.3 价格规则

- 页面价格默认使用当前 Market 默认币种。
- listing 的 `currency_code` 必须与当前 Market 交易币种一致；缺失或不一致时不可购买。
- 商品信息、CTA、推荐卡、购物车和结算金额必须一致。
- 香港站首期只开放 HKD，统一显示 `HK$`；美国站现有币种规则不受影响。

## 四、购买链路

### 4.1 可售判断

当前站点商品可售需同时满足：当前 Market listing 为 active、价格有效且币种与当前 Market 交易币种一致、库存服务返回 `available_qty > 0`。

| 状态 | 页面表现 | 购买行为 |
|---|---|---|
| 当前站点可售 | 正常商详和当前 Market 价格 | Add to Cart、Buy Now 可用 |
| 当前站点已售罄 | 沿用 Sold Out | 两个按钮禁用 |
| 当前站点不可售 | 当前站点不可售文案 + 返回当前站点 Shop | 禁止加购和结算 |
| 当前站点价格无效 | 价格区不展示错误金额，CTA 禁用 | 禁止购买并记录异常 |

### 4.2 Add to Cart / Buy Now

点击时重新校验 Market、当前 Market listing、币种、价格和库存。加购写入的 `market_id`、`listing_id`、币种和金额必须与商详一致。Buy Now 使用同一组校验后进入当前 Market 对应结算；结算返回时仍回到当前站点商详。

## 五、CMS 商详页模板与 Shipping & Returns

### 5.1 已有流程

现网入口为：CMS 管理系统 → 商详页配置。当前 watch、bag、jewelry、accessories 四个 PDP 模板均属于 US Market；每个模板下包含 Certified Authentic、Condition、Description、Shipping & Returns 等模块。英文源文案在 CMS 保存，其他语言在商品翻译模块维护，保存操作进入配置变更记录。

### 5.2 本期后台改动

商详页配置先选择 Market，再管理该 Market 下的 PDP 模板。新站点需要有自己的模板记录；可以从已有 Market 复制模板初始化，但复制后各 Market 模板独立维护。

| 配置项 | 配置粒度 | 新站点要求 |
|---|---|---|
| PDP 模板 | Market + 模板 | 新 Market 下建立对应模板记录；模板归属具体 Market |
| 新建模板 | 当前 Market | 新建入口与 watch/bag/jewelry/accessories 模板 Tab 同一层级；创建后只属于当前 Market |
| 删除模板 | 当前 Market + 模板 | 支持删除当前 Market 下的模板；不得影响其他 Market 的同名模板 |
| 模块标题 | Market + 模板 | 各 Market 模板独立配置 |
| Free Shipping 标题/说明 | Market 内公共或模板复用 | 必须限定在当前 Market 内复用，不跨 Market 共用 |
| Easy Returns 标题/说明 | Market + 模板 | 各 Market × 各模板分别维护 |
| Policy 链接 | 对应富文本 | 指向当前 Market 的政策页 |
| 模块开关 | Market + 模板 + 模块 | 当前 Market 可独立开关，不影响其他 Market |

后台需要提供“从其他 Market 复制模板”能力，用于把 US 模板复制为新 Market 初始模板。复制只是初始化数据，不建立后续联动。当前 Market 必填项不完整时阻止保存。保存、前台预览、模块开关和变更记录沿用现网交互，并记录 Market 与模板。

香港站首期要求：在 HK Market 下建立 watch、bag、jewelry、accessories 模板记录；Shipping & Returns 链接指向香港政策页。

### 5.3 前台读取与语言

- 前台按 `market_id + template_id` 定位 PDP 模板，再读取模板下的 Shipping & Returns。
- 当前 Market 无模板或模板配置缺失时不得运行时回退 US。
- 英文源文取当前 Market 模板配置；目标语言在商品翻译模块维护。
- 目标语言无译文时只允许回退当前 Market 英文源文，不得跨 Market 回退。

## 六、推荐与浏览历史

- You May Also Like 的结果先过滤为有效当前 Market listing，价格使用当前 Market 币种。
- Recently Viewed 只展示仍有有效当前 Market listing 的商品。
- 过滤后推荐不足 2 条时沿用现有隐藏规则，不用美国商品补满。
- 点击卡片继续进入当前站点商详。

## 七、依赖与上线条件

| 模块 | 上线条件 |
|---|---|
| Market | 新站点 URL / 切站结果可稳定识别对应 Market |
| 商品 | 试售商品已建立当前 Market listing 和对应币种价格 |
| 库存 | 购买前可重新校验同一实物商品库存 |
| CMS | Market 维度完成；当前 Market 的模板和政策文案配置完成 |
| 商品翻译 | 新站点首发语言的政策译文完成 |
| 购物车/结算 | 接收并保持当前 Market、当前 Market listing 和币种 |
| 支付 | 只返回当前 Market 已开通方式 |

香港站首期上线条件：HK Market 可识别；试售商品有香港 listing 和 HKD 价格；HK watch/bag/jewelry/accessories 模板、配送文案、退货文案和香港政策链接配置完成。

## 八、验收标准

1. 从新站点进入有库存商品，显示当前 Market listing、当前 Market 币种、当前 Market Shipping & Returns。
2. Add to Cart 后购物车的商品、Market、金额和币种与商详一致。
3. Buy Now 进入当前 Market 结算，返回后仍为当前站点。
4. 同一商品只有美国 listing 时，在新站点展示不可售，不允许购买。
5. 当前 Market 模板或配置缺失时不展示 US Shipping & Returns。
6. watch、bag、jewelry、accessories 均能读取各自当前 Market 退货说明。
7. 目标语言译文缺失时回退当前 Market 英文源文，不回退 US 内容。
8. 推荐和浏览历史不出现只有美国 listing 的商品。

香港站验收样例：页面显示 HK listing、`HK$` 和香港 Shipping & Returns；出现 USD、美国政策、美国 listing 或跳回美国站，均判定失败。

## 九、数据与埋点

商详曝光、加购、立即购买、不可售曝光记录：`market_id`、`country_code`、`channel_id`、`listing_id`、`currency_code`、`language_code`、可售状态。当前站点不可售额外记录原因：无当前 Market listing、listing 下架、币种无效或库存不可售。

## 十、设计说明

PC 与移动 Web 沿用现有商详设计。当前站点不可售复用现有不可售提示区和禁用 CTA 样式；CMS 调整为 Market → PDP 模板 → 模块配置的信息架构，不新增独立页面。
